import json,os
from pathlib import Path
from sqlalchemy import create_engine,text
from sqlalchemy.engine import make_url
url=make_url(os.environ['B83_SOCIAL_TEST_DB_URL'])
if (url.drivername!='postgresql+psycopg2' or url.host!='127.0.0.1' or url.port!=55412 or url.database!='b83_social_test' or url.username!='pr865_spec_owner' or url.query):raise RuntimeError('Owned fixture only')
e=create_engine(url);P=Path('/evidence')
with e.begin()as db:
 if db.scalar(text('SELECT current_database()'))!='b83_social_test' or db.scalar(text('SELECT version_num FROM alembic_version'))!='a756b20a0001':raise RuntimeError('Wrong fixture')
 names=['social_posts','social_post_revisions','social_publications','social_post_targets','social_publish_attempts','social_source_cursors','social_source_events']
 def counts():return {n:db.scalar(text('SELECT count(*) FROM '+n))for n in names}
 before=counts()
 roles=db.scalar(text("SELECT count(*) FROM pg_roles WHERE rolname LIKE 'b118_worker_%'"))
 if roles!=0:raise RuntimeError('Worker test role leaked')
 social=db.scalars(text("SELECT tablename FROM pg_tables WHERE schemaname=current_schema() AND tablename LIKE 'social_%'" )).all()
 db.execute(text('TRUNCATE '+','.join('"'+n+'"'for n in social)+' CASCADE'))
 db.execute(text('TRUNCATE etl_dispatch_worker,etl_dispatch_commands,etl_dispatch_domains,seeding_domain_claims,ingestion_jobs RESTART IDENTITY CASCADE'))
 db.execute(text('TRUNCATE countries RESTART IDENTITY CASCADE'))
 after=counts()
 if any(after.values()):raise RuntimeError('Owned test artifacts remain')
 P.joinpath('final-owned-state.json').write_text(json.dumps({'database':'b83_social_test','head':'a756b20a0001','before_fixture_teardown':before,'after_fixture_teardown':after,'leftover_worker_fixture_roles':roles,'synthetic_approved_fixture_only':True},indent=2)+'\n')
e.dispose()
