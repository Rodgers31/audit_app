from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent

def need(value,message):
    if not value:raise RuntimeError(message)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name):return json.loads((P/name).read_text())
def cases(name):
    result=[]
    for node in ET.parse(P/name).getroot().iter('testcase'):
        result.append({'id':node.get('classname','')+'::'+node.get('name',''),'outcome':'error'if node.find('error')is not None else 'failure'if node.find('failure')is not None else 'skipped'if node.find('skipped')is not None else 'pass','junit':name})
    return result
lanes={'pg':('independent-normal-sealed','independent-optimized-sealed',22),'direct':('direct-controls/normal','direct-controls/optimized',130)}
ledger=[];mode_ids={}
for lane,(normal,optimized,count)in lanes.items():
    for mode,label in [('normal',normal),('true_optimized',optimized)]:
        data=cases(label+'.xml');status=read(label+'.exit.json')['exit_code']
        need(type(status)is int and status==0,label+' exit not exact0')
        need(len(data)==count and len({x['id']for x in data})==count,label+' count/uniqueness')
        need(all(x['outcome']=='pass'for x in data),label+' nonpassing case')
        mode_ids.setdefault(mode,set()).update(x['id']for x in data)
        for x in data:ledger.append({**x,'mode':mode,'lane':lane,'junit_sha256':sha(P/x['junit'])})
need(mode_ids['normal']==mode_ids['true_optimized'] and len(mode_ids['normal'])==152,'mode case inventory mismatch')
red=cases('baseline-six-red.xml');need(len(red)==6 and all(x['outcome']=='failure'for x in red),'baseline must have exactly6 desired failures')
need(read('baseline-six-red.exit.json')['exit_code']==1,'baseline exit not1')
need({x['id']for x in red}.issubset(mode_ids['normal']),'baseline not final controls')
source_after=read('SOURCE-AFTER.json');need(source_after['candidate_mismatches']==[]and source_after['projection_mismatches']==[]and source_after['manifest_file_unchanged']is True,'source changed')
cleanup=read('CLEANUP.json');need(cleanup['owned_pg_removed']is True and cleanup['private_env_deleted']is True and cleanup['remaining_owned_containers']==[],'own cleanup incomplete')
child=read('direct-controls/RECEIPT.json');need((P/'direct-controls/REPORT.md').is_file(),'child report missing')
child_after=read('direct-controls/SOURCE-AFTER.json')
need((P/'REPORT.md').is_file(),'main report missing')
final_state=read('final-owned-state.json');need(not any(final_state['after_fixture_teardown'].values())and final_state['leftover_worker_fixture_roles']==0,'own fixture state not cleared')
(P/'CASE-LEDGER.json').write_text(json.dumps({'normal':152,'true_optimized':152,'same_ids_each_mode':True,'distinct_final_cases':152,'final_case_executions':304,'cases':ledger,'baseline_red_expected':red,'uncredited_attempts':read('SETUP-ATTEMPTS.json')},indent=2)+'\n')
artifacts={}
for path in sorted(P.iterdir()):
    if path.is_file()and path.name!='FINAL-RECEIPT.json':artifacts[path.name]=sha(path)
for path in sorted((P/'direct-controls').iterdir()):
    if path.is_file():artifacts[str(path.relative_to(P))]=sha(path)
receipt={'verdict':'Scoped pass; known predecessor-verdict defect reproduced and fixed; no remaining confirmed finding','inputs':read('INPUT-PINS.json'),'gate_sha256':'28583346e4be248d0f831d2614d3665d9d4a30786c489e29255c7fbe96842d40','results':{'normal':152,'true_optimized':152,'independent_actual_pg_each_mode':22,'independent_direct_each_mode':130,'final_failures':0,'final_errors':0,'final_skips':0,'baseline_expected_failures':6,'same_ids_each_mode':True},'baseline_overlay':read('RED-PROJECTION.json'),'source_after':source_after,'cleanup':cleanup,'final_fixture_state':final_state,'uncredited_attempts':read('SETUP-ATTEMPTS.json'),'artifacts_sha256':artifacts,'limitations':['Synthetic source inputs/real writers, receipts, migrated PG and restricted gates; no new genuine source adoption claim.','Only two synthetic approved-revision cases use inert local approval/publication and an opened fake DB publishing switch to reach the source gate; no worker/provider action or attempts.','Other20 actualPG cases assert no social generation state.','No production/shared/dependency database or container touched; no project edits.']}
(P/'FINAL-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'verdict':receipt['verdict'],'results':receipt['results'],'source_after':source_after,'cleanup':cleanup},indent=2))
