"""Independent PR865 actual-write and installed restricted authority transitions.

All source inputs/account/approval state are synthetic and remain inside owned PG.
No worker/provider process is started and no publication is dispatched.
"""
from copy import deepcopy
from decimal import Decimal
import pytest
from sqlalchemy import select,func,text
from models import RevenueBySource,BudgetLine,Loan,SourceDocument,Extraction,Country,IngestionJob,IngestionStatus
from seeding.source_observations import SourceObservationUnavailable
from seeding.native_financial_observations import read_native_financial_observation
from seeding.generation_dispatch import dispatch_committed_generation
from social.generation.contracts import SourceObservation
from social.generation.worker_authority import capture_worker_authority,verify_worker_authority
from social.models import SocialPost,SocialPostRevision,SocialPublication,SocialPostTarget,SocialPublishAttempt,SocialCommandReceipt,SocialControls
from social.generation.models import SourceCursor,SourceEvent
from social.service import SocialError
from test_b83_generation_postgres import pg
from native_worker_fixture import restricted
from test_source_admission_separation_postgres import ingest_native_refresh
from test_native_financial_changes_postgres import enable,ingest_revenue
from test_automatic_cohort_timeout_postgres import ingest_cohort

DOMAINS=['revenue_by_source','national_budget','pending_bills']

def flags(factory,patch):
    enable(factory,patch)
    patch.setenv('SEED_NATIVE_FINANCIAL_SOURCE_ADMISSION_ENABLED','true')
    patch.setenv('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','false')
    patch.setenv('SOCIAL_GENERATION_HOOK_ENABLED','true')
    patch.setenv('SOCIAL_REPORT_GENERATION_ENABLED','false')

def current(factory,domain,job,record):
    raw=read_native_financial_observation(factory,domain=domain,record_id=record,ingestion_id=job)
    return SourceObservation.model_validate(raw).model_dump(mode='json')

def witness(factory,value):
    with factory.begin()as db:out=capture_worker_authority(db,value)
    assert type(out)is dict and out['kind']=='financial'
    return out

def verify(worker,value,proof):
    with worker.begin()as conn:return verify_worker_authority(conn,value,proof)

def no_generation(factory):
    with factory()as db:
        for model in [SocialPost,SocialPostRevision,SocialPublication,SocialPostTarget,SocialPublishAttempt,SocialCommandReceipt,SourceCursor,SourceEvent]:
            assert db.scalar(select(func.count()).select_from(model))==0,model.__tablename__
        assert db.get(SocialControls,1).publishing_enabled is False

def refused(factory,worker,domain,job,record,old,proof):
    with pytest.raises(SourceObservationUnavailable):current(factory,domain,job,record)
    with pytest.raises(SocialError,match='SOURCE_REVIEW_REQUIRED'):verify(worker,old,proof)
    with pytest.raises(SocialError,match='SOURCE_REVIEW_REQUIRED'):
        with factory.begin()as db:capture_worker_authority(db,old)

def state(factory,model):
    with factory()as db:return {r.id:(r.publishable,r.quarantine_reason)for r in db.scalars(select(model))}

@pytest.mark.parametrize('domain',DOMAINS)
@pytest.mark.parametrize('changed',[False,True],ids=['same','corrected'])
def test_actual_writer_off_refresh_retires_all_rows_and_worker_then_on_requalifies(restricted,tmp_path,monkeypatch,domain,changed):
    factory,_,worker,_=restricted;flags(factory,monkeypatch)
    initial,record,model,measure,_=ingest_native_refresh(factory,tmp_path,monkeypatch,domain)
    before=current(factory,domain,initial,record);proof=witness(factory,before)
    assert verify(worker,before,proof)is None
    original=state(factory,model);assert original and all(v==(True,None)for v in original.values())
    monkeypatch.setenv('SEED_NATIVE_FINANCIAL_SOURCE_ADMISSION_ENABLED','false')
    monkeypatch.setenv('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','true')
    later,same,_,_,amount=ingest_native_refresh(factory,tmp_path,monkeypatch,domain,changed=changed,expect_publishable=False)
    assert later>initial and same==record
    disabled=state(factory,model);assert set(disabled)==set(original)
    assert all(p is False for p,q in disabled.values())
    with factory()as db:assert getattr(db.get(model,record),measure)==amount
    refused(factory,worker,domain,later,record,before,proof)
    result=dispatch_committed_generation(factory,domain=domain,ingestion_id=later,dry_run=False,include_reports=False)
    assert result['drafts_created']==0 and result['refused']>0,result
    no_generation(factory)
    # Merely turning the permission back on does not repair a disabled write.
    monkeypatch.setenv('SEED_NATIVE_FINANCIAL_SOURCE_ADMISSION_ENABLED','true')
    with pytest.raises(SourceObservationUnavailable):current(factory,domain,later,record)
    monkeypatch.setenv('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','false')
    admitted,same,_,_,_=ingest_native_refresh(factory,tmp_path,monkeypatch,domain,changed=changed)
    assert same==record and admitted>later
    after=current(factory,domain,admitted,record)
    assert any(Decimal(f['value'])==amount for f in after['facts'])
    fresh=witness(factory,after);assert verify(worker,after,fresh)is None
    with pytest.raises(SocialError,match='SOURCE_REVIEW_REQUIRED'):verify(worker,before,proof)
    assert all(p is True and q is None for p,q in state(factory,model).values())
    no_generation(factory)

@pytest.mark.parametrize('domain',DOMAINS)
def test_flag_toggle_without_write_keeps_exact_current_source_and_installed_witness(restricted,tmp_path,monkeypatch,domain):
    factory,_,worker,_=restricted;flags(factory,monkeypatch)
    job,record,model,_,_=ingest_native_refresh(factory,tmp_path,monkeypatch,domain)
    before=current(factory,domain,job,record);proof=witness(factory,before);rows=state(factory,model)
    for admitted in ['false','true']:
        monkeypatch.setenv('SEED_NATIVE_FINANCIAL_SOURCE_ADMISSION_ENABLED',admitted)
        assert current(factory,domain,job,record)==before
        assert state(factory,model)==rows
        assert verify(worker,before,proof)is None
    no_generation(factory)

@pytest.mark.parametrize('changed',[False,True],ids=['same','corrected'])
def test_retained_pending_pdf_refresh_off_cannot_reuse_verdict_and_readmission_recovers(restricted,tmp_path,monkeypatch,changed):
    factory,_,worker,_=restricted;flags(factory,monkeypatch)
    first=ingest_cohort(factory,tmp_path)
    with factory()as db:record=db.scalar(select(Loan.id).order_by(Loan.id))
    before=current(factory,'pending_bills',first,record);proof=witness(factory,before)
    monkeypatch.setenv('SEED_NATIVE_FINANCIAL_SOURCE_ADMISSION_ENABLED','false')
    monkeypatch.setenv('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','true')
    off=ingest_cohort(factory,tmp_path,retained=True,correction='all'if changed else None,expect_publishable=False)
    assert len(state(factory,Loan))==46 and all(p is False for p,q in state(factory,Loan).values())
    refused(factory,worker,'pending_bills',off,record,before,proof)
    out=dispatch_committed_generation(factory,domain='pending_bills',ingestion_id=off,dry_run=False,include_reports=False)
    assert out['drafts_created']==0 and out['refused']==46,out
    monkeypatch.setenv('SEED_NATIVE_FINANCIAL_SOURCE_ADMISSION_ENABLED','true')
    monkeypatch.setenv('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','false')
    on=ingest_cohort(factory,tmp_path,retained=True,correction='all'if changed else None)
    value=current(factory,'pending_bills',on,record);assert verify(worker,value,witness(factory,value))is None
    assert all(p is True for p,q in state(factory,Loan).values())
    no_generation(factory)

@pytest.mark.parametrize('domain',DOMAINS)
def test_failure_after_disabled_gate_rolls_back_new_lineage_value_and_retirement(restricted,tmp_path,monkeypatch,domain):
    import seeding.native_financial_gate as gate
    factory,_,worker,_=restricted;flags(factory,monkeypatch)
    job,record,model,_,_=ingest_native_refresh(factory,tmp_path,monkeypatch,domain)
    before=current(factory,domain,job,record);proof=witness(factory,before);rows=state(factory,model)
    original=gate.qualify_native_financial_rows
    called=[]
    def fail(db,actual_rows,**kw):
        original(db,actual_rows,**kw);called.append(len(actual_rows))
        assert actual_rows and all(r.publishable is False for r in actual_rows)
        raise RuntimeError('owned failure after disabled retirement')
    with monkeypatch.context()as patch:
        patch.setenv('SEED_NATIVE_FINANCIAL_SOURCE_ADMISSION_ENABLED','false')
        patch.setattr(gate,'qualify_native_financial_rows',fail)
        with pytest.raises(RuntimeError,match='owned failure after disabled retirement'):
            ingest_native_refresh(factory,tmp_path,patch,domain,changed=True,expect_publishable=False)
    assert called and current(factory,domain,job,record)==before
    assert state(factory,model)==rows and verify(worker,before,proof)is None
    no_generation(factory)

@pytest.mark.parametrize('broken',['publisher','country','lineage','receipt','job','source'])
def test_other_current_inputs_cannot_resurrect_worker_when_source_permission_is_off(restricted,tmp_path,monkeypatch,broken):
    factory,_,worker,_=restricted;flags(factory,monkeypatch)
    job,record=ingest_revenue(factory,tmp_path,monkeypatch)
    old=current(factory,'revenue_by_source',job,record);proof=witness(factory,old)
    monkeypatch.setenv('SEED_NATIVE_FINANCIAL_SOURCE_ADMISSION_ENABLED','false')
    with factory.begin()as db:
        row=db.get(RevenueBySource,record);doc=db.get(SourceDocument,row.source_document_id)
        if broken=='publisher':doc.publisher='World Bank'
        elif broken=='country':db.scalar(select(Country).where(Country.iso_code=='KEN')).iso_code='UGA'
        elif broken=='lineage':db.execute(text("UPDATE revenue_by_source SET metadata=jsonb_set(metadata,'{ingestion_job_id}','true'::jsonb) WHERE id=:id"),{'id':record})
        elif broken=='receipt':db.get(Extraction,row.meta['source_evidence'][0]['receipt']['extraction_id']).extracted_json={}
        elif broken=='job':db.get(IngestionJob,job).status=IngestionStatus.COMPLETED_WITH_ERRORS
        else:doc.url='https://not-a-publisher.invalid/forged'
    refused(factory,worker,'revenue_by_source',job,record,old,proof)
    no_generation(factory)

@pytest.mark.parametrize('changed',[False,True],ids=['same','corrected'])
def test_actual_approved_revision_is_held_by_restricted_worker_after_source_off_writer_refresh(restricted,tmp_path,monkeypatch,changed):
    from test_native_worker_authority import configure,queue,gate,bound_witness
    from social.generation.service import verify_generated_revision
    factory,_,worker,_=restricted
    registry,aid=configure(factory,monkeypatch,financial=True)
    monkeypatch.setenv('SOCIAL_REPORT_GENERATION_ENABLED','false')
    job,record=ingest_revenue(factory,tmp_path,monkeypatch)
    source=current(factory,'revenue_by_source',job,record)
    publication=queue(factory,registry,source)
    source,proof=bound_witness(factory,publication)
    assert proof and gate(worker,publication,aid)is None
    with factory()as db:
        pub=db.get(SocialPublication,publication);revision=db.get(SocialPostRevision,pub.revision_id)
        old_document=deepcopy(revision.document);old_id=revision.id
        assert db.get(SocialPost,pub.post_id).editorial_state=='approved'
    monkeypatch.setenv('SEED_NATIVE_FINANCIAL_SOURCE_ADMISSION_ENABLED','false')
    later,same=ingest_revenue(factory,tmp_path,monkeypatch,paye='561'if changed else'560',extra=b'<!-- approved stale source refresh -->')
    assert later>job and same==record
    assert gate(worker,publication,aid)=='SOURCE_REVIEW_REQUIRED'
    with pytest.raises(SocialError,match='SOURCE_REVIEW_REQUIRED'):verify(worker,source,proof)
    with factory()as db:
        pub=db.get(SocialPublication,publication);revision=db.get(SocialPostRevision,pub.revision_id)
        assert revision.id==old_id and revision.document==old_document
        with pytest.raises(SocialError,match='SOURCE_REVIEW_REQUIRED'):
            verify_generated_revision(db,db.get(SocialPost,pub.post_id),revision)
        assert db.scalar(select(func.count()).select_from(SocialPublishAttempt))==0
