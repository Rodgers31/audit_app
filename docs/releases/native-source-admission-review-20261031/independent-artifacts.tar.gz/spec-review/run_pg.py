import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent
label,mode,*selection=sys.argv[1:]
selection=selection or ['/evidence/test_native_refresh_authority.py']
cmd=['docker','run','--pull','never','--rm','--name','pr865-spec-'+label,'--network','container:pr865-spec-pg','--cpus','1','--memory','768m','--pids-limit','256','--env-file',str(P/'private-pg.env'),'-v',str(P/'source')+':/work:ro','-v',str(P)+':/evidence','-w','/work/backend','pr863-python-patch-parity:local','python']+(['-O']if mode=='optimized'else[])+['-m','pytest','-q','-p','no:cacheprovider',*selection,'--junitxml=/evidence/'+label+'.xml']
(P/(label+'.command.json')).write_text(json.dumps({'argv':cmd,'own_loopback_pg_only':True,'no_published_ports':True},indent=2)+'\n');start=time.monotonic()
with (P/(label+'.txt')).open('w')as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
(P/(label+'.exit.json')).write_text(json.dumps({'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2)+'\n');print(json.dumps({'label':label,'exit':r.returncode,'seconds':round(time.monotonic()-start,3)}));raise SystemExit(r.returncode)
