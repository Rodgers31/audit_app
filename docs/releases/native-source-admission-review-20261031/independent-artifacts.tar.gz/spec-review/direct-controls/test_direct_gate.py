from decimal import Decimal
from types import SimpleNamespace
import pytest
from models import BudgetLine,RevenueBySource,Loan,DocumentStatus
from seeding import native_financial_gate as gate
from seeding.native_financial_admission import SOURCE_ADMISSION_FLAG
from seeding.native_report_authority import DOMAINS
from seeding.source_observations import SourceObservationUnavailable
DOMAINS3=['national_budget','revenue_by_source','pending_bills']
MODELS={'national_budget':BudgetLine,'revenue_by_source':RevenueBySource,'pending_bills':Loan}
GEN='SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED'
JOB=23
class DictSubclass(dict):pass
class ForbiddenRows:
 def __iter__(self):raise AssertionError('Rows iterated for invalid context')
class Session:
 def __init__(self,states=()):self.states=states;self.calls=[]
 def execute(self,query):self.calls.append(query);return SimpleNamespace(all=lambda:list(self.states))
class ForbiddenSession:
 def execute(self,*a,**k):raise AssertionError('SQL reached invalid context')

@pytest.fixture(autouse=True)
def clean_flags(monkeypatch):
 monkeypatch.delenv(SOURCE_ADMISSION_FLAG,raising=False);monkeypatch.setenv(GEN,'false')

def source_flag(monkeypatch,raw):
 if raw is None:monkeypatch.delenv(SOURCE_ADMISSION_FLAG,raising=False)
 else:monkeypatch.setenv(SOURCE_ADMISSION_FLAG,raw)
def row(domain,identity=101,sid=10,reason=None,job=JOB,category='county'):
 kw=dict(id=identity,source_document_id=sid,publishable=True,quarantine_reason=reason)
 entry={'ingestion_job_id':job,'category':category}
 if domain=='revenue_by_source':kw.update(meta=entry,amount_billion_kes=Decimal('100'))
 elif domain=='national_budget':kw.update(provenance=[entry],allocated_amount=Decimal('100'),actual_spent=Decimal('90'))
 else:kw.update(provenance=entry,outstanding=Decimal('100'))
 return MODELS[domain](**kw)
def state(domain,sid=10,**changes):
 x=dict(status=DocumentStatus.AVAILABLE,publisher=DOMAINS[domain][2],url='https://'+DOMAINS[domain][1][0]+'/owned.pdf',country=1,binding={'ingestion_id':JOB,'country_id':1});x.update(changes)
 return (sid,x['status'],x['publisher'],x['url'],x['country'],x['binding'])
def ctx():return SimpleNamespace(dry_run=False,job_id=JOB)
def no_qualifier(*a,**k):raise AssertionError('Numeric qualifier must not run')
def verified(monkeypatch,domain,cell=None,capture=None):
 def call(session,table,views):
  if capture is not None:capture.append((table,views))
  q=cell or {'status':'verified','value_checked':True,'document_bytes_checked':True}
  return {v.id:{m:dict(q)for m in gate.TABLES[domain][1]}for v in views}
 monkeypatch.setattr(gate,'qualify_rows',call)

@pytest.mark.parametrize('domain',DOMAINS3)
@pytest.mark.parametrize('flag',[None,'false','TRUE'])
@pytest.mark.parametrize('reason',[None,gate.REASON,'operator_hold'])
def test_source_off_exact_current_native_cannot_inherit_publishable(monkeypatch,domain,flag,reason):
 source_flag(monkeypatch,flag);monkeypatch.setenv(GEN,'true');monkeypatch.setattr(gate,'qualify_rows',no_qualifier);r=row(domain,reason=reason);s=Session([state(domain)])
 gate.qualify_native_financial_rows(s,[r],domain=domain,context=ctx())
 assert r.publishable is False;assert r.quarantine_reason==reason;assert len(s.calls)==1

FOREIGN=['missing_source','publisher','external_url','binding_none','binding_subclass','binding_job_bool','binding_job_float','wrong_job','binding_country_bool','wrong_country']
@pytest.mark.parametrize('domain',DOMAINS3)
@pytest.mark.parametrize('kind',FOREIGN)
def test_source_off_preserves_foreign_scope_verdicts(monkeypatch,domain,kind):
 source_flag(monkeypatch,'false');monkeypatch.setattr(gate,'qualify_rows',no_qualifier);r=row(domain);states=[state(domain)]
 if kind=='missing_source':states=[]
 elif kind=='publisher':states=[state(domain,publisher='Different Publisher')]
 elif kind=='external_url':states=[state(domain,url='https://foreign.example/owned.pdf')]
 elif kind=='binding_none':states=[state(domain,binding=None)]
 elif kind=='binding_subclass':states=[state(domain,binding=DictSubclass(ingestion_id=JOB,country_id=1))]
 elif kind=='binding_job_bool':states=[state(domain,binding={'ingestion_id':True,'country_id':1})]
 elif kind=='binding_job_float':states=[state(domain,binding={'ingestion_id':float(JOB),'country_id':1})]
 elif kind=='wrong_job':states=[state(domain,binding={'ingestion_id':JOB-1,'country_id':1})]
 elif kind=='binding_country_bool':states=[state(domain,binding={'ingestion_id':JOB,'country_id':True})]
 else:states=[state(domain,binding={'ingestion_id':JOB,'country_id':2})]
 s=Session(states);gate.qualify_native_financial_rows(s,[r],domain=domain,context=ctx());assert r.publishable is True;assert r.quarantine_reason is None;assert len(s.calls)==1

@pytest.mark.parametrize('category',['national','county_assembly',None])
def test_pending_noncounty_scope_untouched(monkeypatch,category):
 monkeypatch.setattr(gate,'qualify_rows',no_qualifier);r=row('pending_bills',category=category);s=Session([state('pending_bills')]);gate.qualify_native_financial_rows(s,[r],domain='pending_bills',context=ctx());assert r.publishable is True

BAD_CTX=[None,SimpleNamespace(),SimpleNamespace(dry_run=False),SimpleNamespace(job_id=JOB),SimpleNamespace(dry_run=True,job_id=JOB),SimpleNamespace(dry_run=0,job_id=JOB),SimpleNamespace(dry_run=None,job_id=JOB),SimpleNamespace(dry_run='false',job_id=JOB),SimpleNamespace(dry_run=False,job_id=True),SimpleNamespace(dry_run=False,job_id=float(JOB)),SimpleNamespace(dry_run=False,job_id=str(JOB)),SimpleNamespace(dry_run=False,job_id=0),SimpleNamespace(dry_run=False,job_id=-1),SimpleNamespace(dry_run=False,job_id=None)]
@pytest.mark.parametrize('flag',['false','true'])
@pytest.mark.parametrize('context',BAD_CTX)
def test_invalid_context_never_reads_rows_or_sql(monkeypatch,flag,context):
 source_flag(monkeypatch,flag);monkeypatch.setattr(gate,'qualify_rows',no_qualifier)
 try:gate.qualify_native_financial_rows(ForbiddenSession(),ForbiddenRows(),domain='pending_bills',context=context)
 except AttributeError:pass

@pytest.mark.parametrize('flag',['false','true'])
def test_empty_and_overbound_cohorts_do_not_query(monkeypatch,flag):
 source_flag(monkeypatch,flag);gate.qualify_native_financial_rows(ForbiddenSession(),[],domain='pending_bills',context=ctx())
 with pytest.raises(ValueError,match='Bounded'):gate.qualify_native_financial_rows(ForbiddenSession(),[object()for _ in range(1001)],domain='pending_bills',context=ctx())

@pytest.mark.parametrize('domain',DOMAINS3)
def test_mixed_current_and_foreign_changes_only_current(monkeypatch,domain):
 monkeypatch.setattr(gate,'qualify_rows',no_qualifier);native=row(domain);foreign=row(domain,102,11);s=Session([state(domain),state(domain,11,publisher='Foreign')]);gate.qualify_native_financial_rows(s,[native,foreign],domain=domain,context=ctx());assert native.publishable is False;assert foreign.publishable is True

@pytest.mark.parametrize('domain',DOMAINS3)
def test_duplicate_object_identity_is_harmless(monkeypatch,domain):
 monkeypatch.setattr(gate,'qualify_rows',no_qualifier);r=row(domain);s=Session([state(domain)]);gate.qualify_native_financial_rows(s,[r,r],domain=domain,context=ctx());assert r.publishable is False;assert len(s.calls)==1

@pytest.mark.parametrize('domain',DOMAINS3)
@pytest.mark.parametrize('kind',['wrong_job','boolean_job','duplicate_entries'])
def test_nonexact_row_lineage_refuses_without_grant(monkeypatch,domain,kind):
 monkeypatch.setattr(gate,'qualify_rows',no_qualifier);r=row(domain)
 entry={'ingestion_job_id':JOB-1 if kind=='wrong_job'else True,'category':'county'}
 if kind=='duplicate_entries':entry={'ingestion_job_id':JOB,'category':'county'}
 if domain=='revenue_by_source':r.meta=[entry,entry]if kind=='duplicate_entries'else entry
 else:r.provenance=[entry,entry]if kind=='duplicate_entries'else entry
 with pytest.raises(SourceObservationUnavailable):gate.qualify_native_financial_rows(Session([state(domain)]),[r],domain=domain,context=ctx())
 assert r.publishable is True

@pytest.mark.parametrize('domain',DOMAINS3)
@pytest.mark.parametrize('reason',[None,gate.REASON])
def test_source_on_still_requires_verification_port_and_recovers_known_hold(monkeypatch,domain,reason):
 source_flag(monkeypatch,'true');r=row(domain,reason=reason);calls=[];verified(monkeypatch,domain,capture=calls);gate.qualify_native_financial_rows(Session([state(domain)]),[r],domain=domain,context=ctx());assert r.publishable is True;assert r.quarantine_reason is None;assert len(calls)==1

@pytest.mark.parametrize('domain',DOMAINS3)
def test_source_on_does_not_clear_operator_quarantine(monkeypatch,domain):
 source_flag(monkeypatch,'true');r=row(domain,reason='operator_hold');r.publishable=False;verified(monkeypatch,domain);gate.qualify_native_financial_rows(Session([state(domain)]),[r],domain=domain,context=ctx());assert r.publishable is False;assert r.quarantine_reason=='operator_hold'

@pytest.mark.parametrize('domain',DOMAINS3)
@pytest.mark.parametrize('kind',['status','value_bool','bytes_bool','source_failed','empty_cells'])
def test_source_on_bad_qualification_never_keeps_old_publishable(monkeypatch,domain,kind):
 source_flag(monkeypatch,'true');r=row(domain);cell={'status':'verified','value_checked':True,'document_bytes_checked':True}
 if kind=='status':cell['status']='unverified'
 elif kind=='value_bool':cell['value_checked']=1
 elif kind=='bytes_bool':cell['document_bytes_checked']='true'
 elif kind=='empty_cells':
  for measure in gate.TABLES[domain][1]:setattr(r,measure,None)
 verified(monkeypatch,domain,cell=cell);states=[state(domain,status=DocumentStatus.FAILED)]if kind=='source_failed'else [state(domain)];gate.qualify_native_financial_rows(Session(states),[r],domain=domain,context=ctx());assert r.publishable is False;assert r.quarantine_reason==gate.REASON

def test_unknown_domain_refuses_before_sql():
 with pytest.raises(KeyError):gate.qualify_native_financial_rows(ForbiddenSession(),ForbiddenRows(),domain='unknown',context=ctx())
