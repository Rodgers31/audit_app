# PR865 — independent direct shared-gate controls

**Scoped pass:130 controls normally and the same130 under true Python `-O`, zero failures/errors/skips. No confirmed finding.** This packet is separate from the original source-admission review and does not alter its sealed artifacts.

Reviewed shared gate SHA256: `28583346e4be248d0f831d2614d3665d9d4a30786c489e29255c7fbe96842d40`. The6617-entry candidate manifest is pinned by whole-file SHA256 `3a4a494bf7b7e4676a7f287b41024196d7516e56a786c03f87f9a0813a776e48` and mapping SHA256 `1780790d6e2921c3f2aa2ae232a78346b4979cc1d6aef9cc6fc414316ff0c9e4`. Eight assigned dependencies match before/after; see `INPUTS.json` and `SOURCE-AFTER.json`.

The actual gate runs with real mapped BudgetLine/RevenueBySource/Loan instances, the real `_lineage` implementation and official-URL check. Only the source-query result and the figure-qualification port are controlled fakes. No PostgreSQL or real SQL connection is used.

Executed outcomes:

- 27 source-OFF cases cover all three domains, absent/false/ambiguous flags and no/gate/operator quarantine reasons. Each exact current native row starts publishableTrue and endsFalse, even with financial generationtrue. The quarantine reason is preserved and the numeric qualifier is never called. One bounded source identity query is expected: this repair deliberately resolves exact current candidates before invalidation. The old valid-context source-OFF no-query assumption is not carried forward.
- 30 foreign-binding cases and three pending noncounty cases preserve unrelated verdicts. Missing sources, foreign publishers/URLs, invalid binding shapes/types, stale ingestion IDs and country mismatches cannot enter the changed native set. Mixed native/foreign batches clear only native bits. Duplicate object identity remains harmless.
- 28 malformed-context cases reach neither row iteration nor SQL in source-OFF or source-ON mode. Empty/over1000-row cohorts refuse before SQL. Nonexact row lineage raises rather than completing; missing context attributes can raise AttributeError. These are fail-closed controls, not a structured malformed-input API or transaction rollback proof.
- Source-ON positives still require the qualification port and preserve explicit operator quarantine. Verified current-source results can recover only no/gate-managed holds. Unverified cell status, nonliteral checked flags, failed source status and empty measure sets all withhold the inherited bit; empty cells cannot pass by vacuous all().

`CASE-LEDGER.json` contains260 executions with the same130 unique identities in each mode. Exact argv, output, exit and XML are retained as `normal.*` and `optimized.*`. Both runs passed on the first attempt; no failed attempts are omitted.

Execution used cached `pr863-python-patch-parity:local`, networknone, one CPU/768MiB/256PIDs and a read-only candidate. Source flags are changed only in isolated synthetic tests; generation/worker/provider actions are not invoked. No installs, credentials, project/candidate edits, production/provider calls, costs, activation or shared-container changes occurred. `CLEANUP.json` records zero remaining owned containers.

This is a direct gate verdict review. It does not certify real source/receipt qualification, PostgreSQL commit/rollback/locks, current readers, worker views or publication. Parent owns those actual PostgreSQL transitions and the baseline RED/GREEN proof. `RECEIPT.json` binds this bounded lane and its limits.
