"""Host stdlib only; private offline PostgreSQL fixture, no production namespace."""
from pathlib import Path
import secrets,subprocess,time,json,os
E=Path(__file__).resolve().parent;PG='pr865-standards-pg-20261031';ROLE='pr865_standards_20261031';IMAGE='pr863-python-patch-parity:local';DATA='/var/lib/postgresql/data/pr865_standards'
def run(args,label):
 r=subprocess.run(args,capture_output=True,text=True);(E/(label+'.txt')).write_text(r.stdout+r.stderr)
 if r.returncode:raise RuntimeError(label+' failed with exit'+str(r.returncode))
 return r.stdout
if any((E/n).exists() for n in ['pg.env','runtime.env']):raise RuntimeError('Refuse credential overwrite')
password=secrets.token_hex(24);pg={'POSTGRES_USER':ROLE,'POSTGRES_PASSWORD':password,'POSTGRES_DB':'b83_social_test','PGDATA':DATA};runtime={'DATABASE_URL':f'postgresql+psycopg2://{ROLE}:{password}@127.0.0.1:55412/b83_social_test','B83_SOCIAL_TEST_DB_URL':f'postgresql+psycopg2://{ROLE}:{password}@127.0.0.1:55412/b83_social_test','OWNED_ADMISSION_ROLE':ROLE,'OWNED_ADMISSION_DATA_DIRECTORY':DATA,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':'/case/backend:/case/backend/tests:/case/backend/tests/social:/evidence'}
for key in ['SEED_NATIVE_FINANCIAL_SOURCE_ADMISSION_ENABLED','SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','SOCIAL_GENERATION_HOOK_ENABLED','SOCIAL_REPORT_GENERATION_ENABLED','SOCIAL_NATIVE_ENABLED','SOCIAL_PUBLISHING_ENABLED','SOCIAL_WORKER_ENABLED','SOCIAL_WORKER_SUPERVISOR_ENABLED','SOCIAL_MEDIA_ENABLED','SOCIAL_UPLOADS_ENABLED','AUTO_SEEDER_ENABLED']:runtime[key]='false'
for name,values in [('pg.env',pg),('runtime.env',runtime)]:
 p=E/name;p.write_text(''.join(k+'='+v+'\n' for k,v in values.items()));p.chmod(0o600)
run(['docker','run','--pull','never','-d','--name',PG,'--label','codex.owner=pr865-standards-20261031','--network','none','--cpus','1','--memory','512m','--pids-limit','128','--tmpfs','/var/lib/postgresql/data:rw,size=512m','--env-file',str(E/'pg.env'),'postgres:17','-p','55412','-c','max_connections=40','-c','shared_buffers=32MB'],'pg-create')
for _ in range(60):
 r=subprocess.run(['docker','exec',PG,'pg_isready','-h','127.0.0.1','-p','55412','-U',ROLE,'-d','b83_social_test'],capture_output=True)
 if r.returncode==0:break
 time.sleep(.2)
else:raise RuntimeError('Own PG never ready')
run(['docker','run','--pull','never','--rm','--name','pr865-standards-migrate','--network','container:'+PG,'--cpus','1','--memory','768m','--pids-limit','256','--env-file',str(E/'runtime.env'),'-v',str(E.parent/'candidate')+':/case:ro','-w','/case/backend',IMAGE,'alembic','upgrade','head'],'migrate')
identity=json.loads(subprocess.check_output(['docker','inspect',PG],text=True))[0];(E/'FIXTURE.json').write_text(json.dumps({'name':PG,'id':identity['Id'],'role':ROLE,'database':'b83_social_test','data_directory':DATA,'namespace':identity['HostConfig']['NetworkMode'],'ports':identity['HostConfig']['PortBindings'],'tmpfs':identity['HostConfig']['Tmpfs'],'caps':{'cpu_nanos':identity['HostConfig']['NanoCpus'],'memory':identity['HostConfig']['Memory'],'pids':identity['HostConfig']['PidsLimit']}},indent=2)+'\n');print('Owned offline PG migrated; no host ports or credential values printed.')
