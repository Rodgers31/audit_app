from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
E=Path(__file__).resolve().parent
packet=json.loads((E/'ARTIFACTS.json').read_text())
for n,h in packet['files'].items():
 if hashlib.sha256((E/n).read_bytes()).hexdigest()!=h:raise SystemExit('Artifact mismatch: '+n)
ledger=json.loads((E/'CASE-LEDGER.json').read_text())
for run in ledger['runs']:
 cases=ET.parse(E/run['junit']).getroot().findall('.//testcase')
 if len(cases)!=47 or any(c.find(k) is not None for c in cases for k in ['failure','error','skipped']):raise SystemExit('Invalid final JUnit')
 actual={c.attrib.get('classname','')+'::'+c.attrib['name'] for c in cases}
 declared={c['id'] for c in ledger['cases'] if c['mode']==run['mode']}
 if actual!=declared or len(actual)!=47:raise SystemExit('Case ledger mismatch')
cf=ET.parse(E/'prior-counterfactual.xml').getroot().findall('.//testcase')
if len(cf)!=6 or not all(c.find('failure') is not None and c.find('error') is None and c.find('skipped') is None for c in cf):raise SystemExit('Invalid expected-negative control')
if len(ledger['cases'])!=94:raise SystemExit('Invalid ledger total')
print('PASS: '+str(len(packet['files']))+' artifact hashes; 47normal+47optimized passes; 6expected counterfactual failures')
