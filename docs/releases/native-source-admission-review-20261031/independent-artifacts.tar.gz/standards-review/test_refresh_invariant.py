"""Independent PG execution: verdict belongs to current written evidence, not a flag toggle.

All publisher-shaped payloads/jobs/receipts are owned software fixtures, not official facts.
"""
import copy
import json
import os
import threading
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from types import SimpleNamespace

import pytest
from sqlalchemy import create_engine, event, func, select, text
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm.attributes import flag_modified

from models import (BudgetLine, Country, DebtCategory, DocumentStatus, Entity, EntityType,
                    Extraction, IngestionJob, Loan, RevenueBySource, SourceDocument)
from seeding.native_financial_gate import qualify_native_financial_rows, REASON
from seeding.native_financial_observations import read_native_financial_observation
from seeding.native_report_authority import KEY
from seeding.source_observations import SourceObservationUnavailable, read_revenue_report_observation
from seeding.types import DomainRunContext
from social.generation.models import SourceCursor, SourceEvent
from social.models import SocialMediaAsset, SocialPost, SocialPostTarget, SocialPublication
from social.media.models import SocialMediaUpload
from test_native_financial_changes_postgres import ingest_revenue
from test_financial_copy_postgres import national_ingestion
import test_automatic_cohort_timeout_postgres as pending_fixture

FLAG = 'SEED_NATIVE_FINANCIAL_SOURCE_ADMISSION_ENABLED'
MODELS = {'national_budget': BudgetLine, 'revenue_by_source': RevenueBySource, 'pending_bills': Loan}


@pytest.fixture
def owned():
    url = make_url(os.environ['B83_SOCIAL_TEST_DB_URL'])
    if (url.host, url.port, url.database, url.username, bool(url.query)) != (
            '127.0.0.1', 55412, 'b83_social_test', os.environ['OWNED_ADMISSION_ROLE'], False):
        raise RuntimeError('Foreign test target refused before mutation')
    engine = create_engine(url.set(query={'hostaddr': '127.0.0.1'}), pool_size=4, max_overflow=0)
    with engine.begin() as db:
        identity = db.execute(text("SELECT current_database(),current_user,current_setting('data_directory'),inet_server_port()" )).one()
        if tuple(identity) != ('b83_social_test', os.environ['OWNED_ADMISSION_ROLE'], os.environ['OWNED_ADMISSION_DATA_DIRECTORY'], 55412):
            raise RuntimeError('Foreign live identity refused before mutation')
        if db.scalar(text('SELECT version_num FROM alembic_version')) != 'a756b20a0001':
            raise RuntimeError('Wrong isolated schema')
        tables = db.scalars(text("SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename LIKE 'social_%'" )).all()
        db.execute(text('TRUNCATE ' + ','.join('"' + t + '"' for t in tables) + ' CASCADE'))
        db.execute(text('TRUNCATE etl_dispatch_worker,etl_dispatch_commands,etl_dispatch_domains,seeding_domain_claims,ingestion_jobs,countries RESTART IDENTITY CASCADE'))
    factory = sessionmaker(bind=engine, expire_on_commit=False)
    with factory.begin() as db:
        country = Country(iso_code='KEN', name='Kenya', currency='KES', timezone='Africa/Nairobi', default_locale='en')
        db.add(country); db.flush()
        for name in ['Nairobi', 'Mombasa', 'Kisumu']:
            db.add(Entity(country_id=country.id, type=EntityType.COUNTY, canonical_name=name+' County', slug=name.lower()))
    try:
        yield factory, engine
    finally:
        engine.dispose()


def flags(monkeypatch, admitted):
    monkeypatch.setenv(FLAG, 'true' if admitted else 'false')
    for key in ['SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED', 'SOCIAL_GENERATION_HOOK_ENABLED', 'SOCIAL_REPORT_GENERATION_ENABLED']:
        monkeypatch.setenv(key, 'false')


def no_effects(factory):
    with factory() as db:
        for model in [SocialPost, SocialPublication, SocialPostTarget, SocialMediaAsset, SocialMediaUpload, SourceCursor, SourceEvent]:
            assert db.scalar(select(func.count()).select_from(model)) == 0, model.__tablename__


def ingest(factory, path, patch, domain, *, changed=False, admitted=True):
    if domain == 'revenue_by_source':
        job, _ = ingest_revenue(factory, path, patch, paye='561' if changed else '560', extra=b'<!-- independent write boundary -->')
    elif domain == 'national_budget':
        job = national_ingestion(factory, path, actual='1250000000.00' if changed else '1200000000.00')
    else:
        job = pending_fixture.ingest_cohort(factory, path, correction='all' if changed else None, expect_publishable=admitted)
    with factory() as db:
        ids = tuple(db.scalars(select(MODELS[domain].id).order_by(MODELS[domain].id)))
    assert ids
    return job, ids


def current(factory, domain, job, record):
    return read_native_financial_observation(factory, record_id=record, ingestion_id=job, domain=domain)


def rows_snapshot(factory, domain):
    with factory() as db:
        return {r.id: {a.key: copy.deepcopy(getattr(r, a.key)) for a in r.__mapper__.column_attrs}
                for r in db.scalars(select(MODELS[domain]))}


@pytest.mark.parametrize('domain', list(MODELS))
@pytest.mark.parametrize('changed', [False, True])
def test_real_refresh_replaces_all_row_verdicts_and_old_reader_authority(owned, tmp_path, monkeypatch, domain, changed):
    factory, _ = owned; flags(monkeypatch, True)
    old, ids = ingest(factory, tmp_path, monkeypatch, domain)
    first = [current(factory, domain, old, r) for r in (ids[0], ids[-1])]
    before = rows_snapshot(factory, domain)
    assert all(row['publishable'] is True for row in before.values())
    # A flag toggle alone performs no write and does not revoke qualified current facts.
    flags(monkeypatch, False)
    assert [current(factory, domain, old, r) for r in (ids[0], ids[-1])] == first
    new, new_ids = ingest(factory, tmp_path, monkeypatch, domain, changed=changed, admitted=False)
    assert new != old and new_ids == ids
    after = rows_snapshot(factory, domain)
    assert all(row['publishable'] is False for row in after.values())
    assert any(after[r] != before[r] for r in ids)
    for job in [old, new]:
        for record in (ids[0], ids[-1]):
            with pytest.raises(SourceObservationUnavailable): current(factory, domain, job, record)
    # Re-enabling the process flag alone cannot revive these rebound facts.
    flags(monkeypatch, True)
    for record in (ids[0], ids[-1]):
        with pytest.raises(SourceObservationUnavailable): current(factory, domain, new, record)
    recovered, recovered_ids = ingest(factory, tmp_path, monkeypatch, domain, changed=changed)
    assert recovered_ids == ids
    assert current(factory, domain, recovered, ids[0])['facts']
    no_effects(factory)


@pytest.mark.parametrize('domain', list(MODELS))
def test_failed_refresh_rolls_back_the_whole_written_authority(owned, tmp_path, monkeypatch, domain):
    import seeding.native_financial_gate as gate
    factory, _ = owned; flags(monkeypatch, True)
    job, ids = ingest(factory, tmp_path, monkeypatch, domain)
    before = rows_snapshot(factory, domain)
    observation = current(factory, domain, job, ids[0])
    with factory() as db:
        source_before = {r.id: copy.deepcopy(r.meta) for r in db.scalars(select(SourceDocument))}
        extraction_ids = tuple(db.scalars(select(Extraction.id).order_by(Extraction.id)))
    real = gate.qualify_native_financial_rows
    def failed(db, rows, **kwargs):
        real(db, rows, **kwargs); assert rows and all(r.publishable is False for r in rows)
        db.flush()
        raise RuntimeError('independent failure after invalidation and flush')
    with monkeypatch.context() as patch:
        flags(patch, False); patch.setattr(gate, 'qualify_native_financial_rows', failed)
        with pytest.raises(RuntimeError, match='independent failure after invalidation'):
            ingest(factory, tmp_path, patch, domain, changed=True, admitted=False)
    assert rows_snapshot(factory, domain) == before
    assert current(factory, domain, job, ids[0]) == observation
    with factory() as db:
        assert {r.id: r.meta for r in db.scalars(select(SourceDocument))} == source_before
        assert tuple(db.scalars(select(Extraction.id).order_by(Extraction.id))) == extraction_ids
    no_effects(factory)


@pytest.mark.parametrize('domain', list(MODELS))
def test_interleaved_reader_sees_old_atomic_state_then_closed_new_state(owned, tmp_path, monkeypatch, domain):
    import seeding.native_financial_gate as gate
    factory, _ = owned; flags(monkeypatch, True)
    job, ids = ingest(factory, tmp_path, monkeypatch, domain)
    before = current(factory, domain, job, ids[0]); flags(monkeypatch, False)
    reached, release = threading.Event(), threading.Event(); real = gate.qualify_native_financial_rows
    def paused(db, rows, **kwargs):
        real(db, rows, **kwargs); assert rows and all(r.publishable is False for r in rows)
        db.flush(); reached.set()
        if not release.wait(8): raise RuntimeError('Owned interleave control timed out')
    with monkeypatch.context() as patch:
        patch.setattr(gate, 'qualify_native_financial_rows', paused)
        with ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(ingest, factory, tmp_path, patch, domain, changed=True, admitted=False)
            try:
                assert reached.wait(8)
                assert current(factory, domain, job, ids[0]) == before
            finally:
                release.set()
            new, _ = future.result(timeout=10)
    for j in [job, new]:
        with pytest.raises(SourceObservationUnavailable): current(factory, domain, j, ids[0])
    no_effects(factory)


@pytest.mark.parametrize('domain', list(MODELS))
def test_actual_same_job_writer_replay_cannot_inherit_its_first_qualification(owned, tmp_path, monkeypatch, domain):
    import seeding.domains.national_budget.writer as national_writer
    import seeding.domains.revenue_by_source.writer as revenue_writer
    factory, _ = owned; flags(monkeypatch, True)
    target, name = ((national_writer, 'persist_national_budget_records') if domain == 'national_budget' else
                    (revenue_writer, 'persist_revenue_records') if domain == 'revenue_by_source' else
                    (pending_fixture, 'write_pending_bills'))
    real = getattr(target, name); calls = []
    def twice(db, *args, **kwargs):
        first = real(db, *args, **kwargs)
        assert all(r.publishable is True for r in db.scalars(select(MODELS[domain])))
        with monkeypatch.context() as patch:
            flags(patch, False)
            second = real(db, *args, **kwargs)
        calls.append((first, second))
        return second
    monkeypatch.setattr(target, name, twice)
    job, ids = ingest(factory, tmp_path, monkeypatch, domain, admitted=False)
    assert len(calls) == 1
    assert all(row['publishable'] is False for row in rows_snapshot(factory, domain).values())
    with pytest.raises(SourceObservationUnavailable): current(factory, domain, job, ids[0])
    no_effects(factory)


BAD_CONTEXTS = [(None, None), ('none-job', None), ('bool-true', True), ('bool-false', False),
                ('zero', 0), ('negative', -1), ('float', 1.0), ('string', '1')]
@pytest.mark.parametrize('kind,value', BAD_CONTEXTS, ids=[k or 'missing-context' for k,v in BAD_CONTEXTS])
def test_invalid_context_performs_no_query_or_verdict_mutation(owned, tmp_path, monkeypatch, kind, value):
    factory, engine = owned; flags(monkeypatch, True)
    job, record = ingest_revenue(factory, tmp_path, monkeypatch); flags(monkeypatch, False)
    with factory.begin() as db:
        row = db.get(RevenueBySource, record); before = (row.publishable, row.quarantine_reason); sql = []
        listener = lambda *a: sql.append(a[2]); event.listen(engine, 'before_cursor_execute', listener)
        try:
            context = None if kind is None else SimpleNamespace(dry_run=False, job_id=value)
            qualify_native_financial_rows(db, [row], domain='revenue_by_source', context=context)
        finally: event.remove(engine, 'before_cursor_execute', listener)
        assert not sql and (row.publishable, row.quarantine_reason) == before
    assert current(factory, 'revenue_by_source', job, record)['facts']; no_effects(factory)


@pytest.mark.parametrize('dry', [True, None, 0, 'false'])
def test_nonliteral_false_dry_run_never_mutates_qualified_row(owned, tmp_path, monkeypatch, dry):
    factory, _ = owned; flags(monkeypatch, True)
    job, record = ingest_revenue(factory, tmp_path, monkeypatch); flags(monkeypatch, False)
    with factory.begin() as db:
        row = db.get(RevenueBySource, record)
        qualify_native_financial_rows(db, [row], domain='revenue_by_source', context=SimpleNamespace(job_id=job, dry_run=dry))
        assert row.publishable is True
    assert current(factory, 'revenue_by_source', job, record)['facts']; no_effects(factory)


@pytest.mark.parametrize('mutation', ['foreign-publisher','foreign-url','no-binding','wrong-job','bool-job','bool-country','wrong-country'])
def test_invalid_binding_is_not_requalified_and_current_reader_refuses(owned, tmp_path, monkeypatch, mutation):
    factory, _ = owned; flags(monkeypatch, True)
    job, record = ingest_revenue(factory, tmp_path, monkeypatch); flags(monkeypatch, False)
    with factory.begin() as db:
        row = db.get(RevenueBySource, record); source = db.get(SourceDocument, row.source_document_id)
        meta = copy.deepcopy(source.meta)
        if mutation == 'foreign-publisher': source.publisher = 'Foreign publisher'
        elif mutation == 'foreign-url': source.url = 'https://unrelated.invalid/retained'
        elif mutation == 'no-binding': meta.pop(KEY)
        elif mutation == 'wrong-job': meta[KEY]['revenue_by_source']['ingestion_id'] = job+100
        elif mutation == 'bool-job': meta[KEY]['revenue_by_source']['ingestion_id'] = True
        elif mutation == 'bool-country': meta[KEY]['revenue_by_source']['country_id'] = True
        elif mutation == 'wrong-country': meta[KEY]['revenue_by_source']['country_id'] = source.country_id+100
        source.meta = meta; flag_modified(source, 'meta'); db.flush()
        qualify_native_financial_rows(db, [row], domain='revenue_by_source', context=DomainRunContext(None, False, job))
        assert row.publishable is True  # Unrelated/invalid binding is not an admission verdict.
    with pytest.raises(SourceObservationUnavailable): current(factory, 'revenue_by_source', job, record)
    no_effects(factory)


@pytest.mark.parametrize('lineage', [None, True, '1'])
def test_missing_or_malformed_lineage_refuses_without_blessing_evidence(owned, tmp_path, monkeypatch, lineage):
    factory, _ = owned; flags(monkeypatch, True)
    job, record = ingest_revenue(factory, tmp_path, monkeypatch); flags(monkeypatch, False)
    with factory.begin() as db:
        row = db.get(RevenueBySource, record); meta = copy.deepcopy(row.meta); meta['ingestion_job_id'] = lineage; row.meta = meta; flag_modified(row, 'meta')
        with pytest.raises(SourceObservationUnavailable):
            qualify_native_financial_rows(db, [row], domain='revenue_by_source', context=DomainRunContext(None, False, job))
    with pytest.raises(SourceObservationUnavailable): current(factory, 'revenue_by_source', job, record)
    no_effects(factory)


@pytest.mark.parametrize('mutation', ['stale-receipt','changed-value','archived','quarantine'])
def test_off_clears_matching_row_without_asking_bad_evidence_to_pass(owned, tmp_path, monkeypatch, mutation):
    import seeding.native_financial_gate as gate
    factory, _ = owned; flags(monkeypatch, True)
    job, record = ingest_revenue(factory, tmp_path, monkeypatch); flags(monkeypatch, False)
    def must_not_qualify(*a, **kw): raise AssertionError('OFF invalidation asked for a positive qualification')
    monkeypatch.setattr(gate, 'qualify_rows', must_not_qualify)
    with factory.begin() as db:
        row = db.get(RevenueBySource, record)
        if mutation == 'stale-receipt': db.get(Extraction, row.meta['source_evidence'][0]['receipt']['extraction_id']).extracted_json = {}
        elif mutation == 'changed-value': row.amount_billion_kes += 1
        elif mutation == 'archived': db.get(SourceDocument, row.source_document_id).status = DocumentStatus.ARCHIVED
        else: row.quarantine_reason = 'Operator HOLD: preserve exact text'
        db.flush(); gate.qualify_native_financial_rows(db, [row], domain='revenue_by_source', context=DomainRunContext(None, False, job))
        assert row.publishable is False
        if mutation == 'quarantine': assert row.quarantine_reason == 'Operator HOLD: preserve exact text'
    with pytest.raises(SourceObservationUnavailable): current(factory, 'revenue_by_source', job, record)
    no_effects(factory)


def test_noncounty_pending_scope_keeps_its_own_verdict_but_not_county_reader_authority(owned, tmp_path, monkeypatch):
    factory, _ = owned; flags(monkeypatch, True)
    job, ids = ingest(factory, tmp_path, monkeypatch, 'pending_bills'); flags(monkeypatch, False)
    with factory.begin() as db:
        original = db.get(Loan, ids[0]); country = db.scalar(select(Country.id))
        entity = Entity(country_id=country, type=EntityType.NATIONAL, canonical_name='Kenya', slug='kenya'); db.add(entity); db.flush()
        provenance = copy.deepcopy(original.provenance); provenance['category'] = 'national'
        unrelated = Loan(entity_id=entity.id, lender='Owned national pending scope', debt_category=DebtCategory.PENDING_BILLS,
            principal=Decimal('100'), outstanding=Decimal('100'), currency='KES', issue_date=original.issue_date, interest_rate=Decimal('0'), source_document_id=original.source_document_id,
            provenance=provenance, publishable=True, quarantine_reason='separate decision')
        db.add(unrelated); db.flush(); record = unrelated.id
        qualify_native_financial_rows(db, [unrelated, original], domain='pending_bills', context=DomainRunContext(None, False, job))
        assert unrelated.publishable is True and unrelated.quarantine_reason == 'separate decision'
        assert original.publishable is False
    with pytest.raises(SourceObservationUnavailable): current(factory, 'pending_bills', job, record)
    no_effects(factory)


@pytest.mark.parametrize('count', [0, 1001])
def test_duplicate_identity_inputs_are_deduplicated_before_the_ceiling(owned, tmp_path, monkeypatch, count):
    factory, _ = owned; flags(monkeypatch, True)
    job, record = ingest_revenue(factory, tmp_path, monkeypatch); flags(monkeypatch, False)
    with factory.begin() as db:
        row = db.get(RevenueBySource, record)
        qualify_native_financial_rows(db, (row for _ in range(count)), domain='revenue_by_source', context=DomainRunContext(None, False, job))
        assert row.publishable is (count == 0)
    no_effects(factory)


@pytest.mark.parametrize('count', [1000, 1001])
def test_distinct_cohort_ceiling_is_atomic(owned, tmp_path, monkeypatch, count):
    factory, _ = owned; flags(monkeypatch, True)
    job, record = ingest_revenue(factory, tmp_path, monkeypatch); flags(monkeypatch, False)
    with factory.begin() as db:
        original = db.get(RevenueBySource, record)
        rows = [RevenueBySource(fiscal_year='FY 2024/25', revenue_type='Owned bound '+str(n), category='tax',
            amount_billion_kes=Decimal('1'), source_document_id=original.source_document_id,
            meta=copy.deepcopy(original.meta), publishable=True) for n in range(count)]
        db.add_all(rows); db.flush()
        if count == 1001:
            with pytest.raises(ValueError, match='Bounded native financial cohort'):
                qualify_native_financial_rows(db, rows, domain='revenue_by_source', context=DomainRunContext(None, False, job))
            assert all(r.publishable is True for r in rows)
        else:
            qualify_native_financial_rows(db, rows, domain='revenue_by_source', context=DomainRunContext(None, False, job))
            assert all(r.publishable is False for r in rows)
    no_effects(factory)


def test_default_off_fresh_numeric_rows_preserve_report_only_contract(owned, tmp_path, monkeypatch):
    from seeding.generation_dispatch import dispatch_committed_generation
    factory, _ = owned; flags(monkeypatch, False); monkeypatch.delenv(FLAG)
    job, record = ingest_revenue(factory, tmp_path, monkeypatch)
    with factory() as db:
        row = db.get(RevenueBySource, record); report = db.get(SourceDocument, row.source_document_id).meta[KEY]['revenue_by_source']['extraction_id']
        assert row.publishable is False
    assert read_revenue_report_observation(factory, record_id=report, ingestion_id=job)['report']['published_on'] == '2025-07-10'
    with pytest.raises(SourceObservationUnavailable): current(factory, 'revenue_by_source', job, record)
    assert dispatch_committed_generation(factory, domain='revenue_by_source', ingestion_id=job, dry_run=False) is None
    no_effects(factory)
