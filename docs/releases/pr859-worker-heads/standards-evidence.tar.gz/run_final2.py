"""Exact capped offline test argv and child receipt, host orchestration only."""
from pathlib import Path
import subprocess,sys,json,time,hashlib
BASE=Path(__file__).resolve().parent
mode=sys.argv[1]
if mode not in ('normal','optimized'):raise ValueError('mode')
label='operator2-'+mode
operator=BASE.parent/'operator-final2.py'
if hashlib.sha256(operator.read_bytes()).hexdigest()!='4c401a7d403ce4ebaccd6a85ad5d8990b45cafbb100d11f5fe0a278511916253':raise ValueError('operator pin')
command=['docker','run','--pull','never','--rm','--name','standards-pr859-'+label,
    '--network','container:standards-pr859-pg','--cpus','1','--memory','2g','--pids-limit','256',
    '--env-file',str(BASE/'runtime.env'),'-v',str(BASE.parent/'candidate-1')+':/work:ro',
    '-v',str(BASE/'accepted-source')+':/accepted:ro','-v',str(BASE.parent)+':/operator:ro',
    '-v',str(BASE)+':/evidence','-w','/work/backend','admin-redesign-python-runtime:local','python']
if mode=='optimized':command.append('-O')
command+=['-m','pytest','-q','-p','no:cacheprovider','/evidence/test_operator_independent.py',
    '/evidence/test_worker_independent.py','/evidence/test_auto_seeder_guard.py','--junitxml=/evidence/'+label+'.xml']
target=BASE/(label+'.txt')
if target.exists():raise ValueError('refuse overwrite')
(BASE/(label+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
started=time.monotonic()
with target.open('w') as stream:result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
(BASE/(label+'-execution.json')).write_text(json.dumps({'child_exit_code':result.returncode,'elapsed_seconds':time.monotonic()-started,
    'operator_sha256':hashlib.sha256(operator.read_bytes()).hexdigest(),'command_file':label+'-command.json'},indent=2)+'\n')
print(json.dumps({'label':label,'child_exit_code':result.returncode}))
sys.exit(result.returncode)
