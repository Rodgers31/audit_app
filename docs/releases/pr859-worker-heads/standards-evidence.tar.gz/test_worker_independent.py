"""Independent mutated typed inputs on actual owner/private-worker digest ports."""
from copy import deepcopy
from uuid import uuid4
import pytest
from sqlalchemy import text,select
from sqlalchemy.orm.attributes import flag_modified
from models import IngestionJob,Extraction
from native_worker_fixture import restricted
from test_b83_generation_postgres import pg,no_publication
from test_audit_report_editions import persist_sequence
from seeding.native_report_observations import read_native_report_observation
from seeding.source_observations import SourceObservationUnavailable
from social.generation.worker_authority import capture_worker_authority,verify_worker_authority
from social.service import SocialError
from social.generation.contracts import SourceObservation

LOCKED='public.social_native_source_authority'
SNAPSHOT=LOCKED+'_snapshot'

def digest(engine,view,job,record,domain='audits'):
    assert view in (LOCKED,SNAPSHOT)
    with engine.begin() as conn:
        return conn.execute(text('SELECT authority_fingerprint FROM '+view+
            " WHERE source_kind='report' AND native_domain=:domain AND record_id=:record AND ingestion_id=:job"),
            {'domain':domain,'record':record,'job':job}).scalars().all()

@pytest.fixture
def current_audit(restricted,tmp_path):
    factory,owner,worker,role=restricted
    job,refused=persist_sequence(factory,tmp_path,[
        ('https://www.oagkenya.go.ke/standards-older.pdf',2025,'2025-07-10',False),
        ('https://www.oagkenya.go.ke/standards-current.pdf',2026,'2026-07-10',False)])
    assert not refused
    with factory() as db:
        meta=deepcopy(db.get(IngestionJob,job).meta)
        scope,record=next(iter(meta['native_report_series'].items()))
        old=next(v for v in meta['native_report_records']['audits'] if v!=record)
    source=SourceObservation.model_validate(read_native_report_observation(factory,record_id=record,ingestion_id=job,domain='audits')).model_dump(mode='json')
    with factory() as db:witness=capture_worker_authority(db,source)
    assert witness is not None
    with worker.begin() as conn:verify_worker_authority(conn,source,witness)
    return factory,owner,worker,role,job,scope,record,old,source,witness

def change_series(factory,job,value):
    with factory.begin() as db:
        row=db.get(IngestionJob,job);meta=deepcopy(row.meta)
        if value is ...:meta.pop('native_report_series',None)
        else:meta['native_report_series']=value
        row.meta=meta;flag_modified(row,'meta')

def retired(worker,source,witness):
    with worker.begin() as conn:
        with pytest.raises(SocialError,match='SOURCE_REVIEW_REQUIRED'):
            verify_worker_authority(conn,source,witness)

def test_selected_receipt_only_both_views_and_digest_only_permissions(current_audit):
    factory,owner,worker,_,job,_,record,old,source,witness=current_audit
    assert digest(owner,SNAPSHOT,job,record)==digest(worker,LOCKED,job,record)==[witness['fingerprint']]
    assert digest(owner,SNAPSHOT,job,old)==digest(worker,LOCKED,job,old)==[]
    for relation in (SNAPSHOT,'public.extractions','public.ingestion_jobs','public.source_documents'):
        with pytest.raises(Exception) as failure:
            with worker.begin() as conn:conn.execute(text('SELECT * FROM '+relation+' LIMIT 1'))
        assert failure.value.orig.pgcode=='42501'
    no_publication(factory)

@pytest.mark.parametrize('case',['missing','null','array','boolean','empty','null_head','boolean_head',
    'float_head','string_head','zero_head','negative_head','huge_head'])
def test_malformed_selected_head_is_absent_and_saved_witness_retires(current_audit,case):
    factory,owner,worker,_,job,scope,record,_,source,witness=current_audit
    bad={'missing':...,'null':None,'array':[],'boolean':True,'empty':{},
        'null_head':{scope:None},'boolean_head':{scope:True},'float_head':{scope:float(record)},
        'string_head':{scope:str(record)},'zero_head':{scope:0},'negative_head':{scope:-1},
        'huge_head':{scope:10**100}}[case]
    change_series(factory,job,bad)
    assert digest(owner,SNAPSHOT,job,record)==digest(worker,LOCKED,job,record)==[]
    retired(worker,source,witness);no_publication(factory)

@pytest.mark.parametrize('case',['empty','short','long','upper','newline','null','number','bool','array','object'])
def test_receipt_scope_is_typed_canonical_even_with_matching_job_key(current_audit,case):
    factory,owner,worker,_,job,scope,record,_,source,witness=current_audit
    bad={'empty':'','short':'a'*31,'long':'a'*33,'upper':scope.upper(),'newline':scope+'\n',
        'null':None,'number':7,'bool':True,'array':[scope],'object':{'scope':scope}}[case]
    with factory.begin() as db:
        ext=db.get(Extraction,record);raw=deepcopy(ext.extracted_json)
        raw['response_receipt']['observations'][0]['scope_key']=bad;ext.extracted_json=raw
        row=db.get(IngestionJob,job);meta=deepcopy(row.meta)
        meta['native_report_series']={bad if type(bad) is str else str(bad):record};row.meta=meta
    assert digest(owner,SNAPSHOT,job,record)==digest(worker,LOCKED,job,record)==[]
    retired(worker,source,witness);no_publication(factory)

def test_valid_head_change_retires_saved_witness(current_audit):
    factory,owner,worker,_,job,scope,record,old,source,witness=current_audit
    change_series(factory,job,{scope:old})
    assert digest(owner,SNAPSHOT,job,record)==digest(worker,LOCKED,job,record)==[]
    retired(worker,source,witness);no_publication(factory)

def test_entire_series_change_is_hashed_even_if_own_head_remains(current_audit):
    factory,owner,worker,_,job,scope,record,old,source,witness=current_audit
    change_series(factory,job,{scope:record,'f'*32:old})
    current=digest(owner,SNAPSHOT,job,record)
    assert len(current)==1 and current!=[witness['fingerprint']]
    assert digest(worker,LOCKED,job,record)==current
    retired(worker,source,witness);no_publication(factory)

def test_removed_record_membership_changes_digest_and_refuses_qualified_reader(current_audit):
    factory,owner,worker,_,job,_,record,old,source,witness=current_audit
    with factory.begin() as db:
        row=db.get(IngestionJob,job);meta=deepcopy(row.meta)
        meta['native_report_records']['audits']=[old];row.meta=meta
    assert digest(worker,LOCKED,job,record)!=[witness['fingerprint']]
    retired(worker,source,witness)
    with pytest.raises(SourceObservationUnavailable):
        read_native_report_observation(factory,record_id=record,ingestion_id=job,domain='audits')
    no_publication(factory)
