"""Actual owned old/new views and release artifact; no production main/DSN call."""
from contextlib import contextmanager
from copy import deepcopy
from uuid import uuid4
import runpy
import pytest
from sqlalchemy import text,event
from sqlalchemy.exc import IntegrityError
from native_worker_fixture import restricted
from test_b83_generation_postgres import pg
from social.worker.native_authority_schema import definition,install_native_authority
from social.worker.role_contract import _limits,verify_worker_role,install_worker_role,WorkerRoleError
from social.models import SocialControls
from test_domain_support import account

OP=runpy.run_path('/operator/operator-final2.py')
OLD=runpy.run_path('/accepted/backend/social/worker/native_authority_schema.py')['definition']
NAMES=OP['NAMES']

def state(owner):
    with owner.begin() as conn:
        _limits(conn)
        return [dict(r) for r in conn.execute(text('''SELECT c.relname,c.oid,c.relowner,c.relacl::text,
          c.reloptions,pg_get_viewdef(c.oid,true) AS definition,
          ARRAY(SELECT coalesce(a.attacl::text,'') FROM pg_attribute a WHERE a.attrelid=c.oid
            AND a.attnum>0 AND NOT a.attisdropped ORDER BY a.attnum) AS column_acl
          FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
          WHERE n.nspname='public' AND c.relname=ANY(:names) ORDER BY c.relname'''),{'names':list(NAMES)}).mappings()]

def replace(owner, build, *, selected=NAMES):
    with owner.begin() as conn:
        _limits(conn);conn.execute(text('SET LOCAL search_path=pg_catalog,public,pg_temp'))
        for name in selected:
            conn.exec_driver_sql('CREATE OR REPLACE VIEW public.'+name+' WITH (security_barrier=true) AS '+
                                 build(locked=not name.endswith('_snapshot')))

@pytest.fixture
def old_profile(restricted,monkeypatch):
    for key in OP['OFF']:monkeypatch.setenv(key,'false')
    factory,owner,worker,role=restricted
    replace(owner,OLD)
    with owner.begin() as conn:
        _limits(conn)
        assert {n:r['sha256'] for n,r in OP['rows'](conn).items()}==OP['PRIOR']
    return factory,owner,worker,role

@contextmanager
def trace(owner):
    statements=[]
    def record(conn,cursor,statement,parameters,context,executemany):statements.append(statement)
    event.listen(owner,'before_cursor_execute',record)
    try:yield statements
    finally:event.remove(owner,'before_cursor_execute',record)

def creates(statements):return [s for s in statements if s.lstrip().upper().startswith('CREATE OR REPLACE VIEW')]
def no_expansion(statements):
    assert not [s for s in statements if s.lstrip().upper().startswith(('INSERT ','UPDATE ','DELETE ','GRANT ','REVOKE ','ALTER ','DROP ','TRUNCATE '))]

def test_old_rehearsal_then_apply_then_new_noop_preserves_contract(old_profile):
    _,owner,worker,role=old_profile;before=state(owner)
    with trace(owner) as sql:result=OP['upgrade'](owner,role,dry_run=True)
    assert result['status']=='rehearsed' and result['before']!=result['after']
    assert state(owner)==before and len(creates(sql))==2
    no_expansion(sql)
    with trace(owner) as sql:result=OP['upgrade'](owner,role,dry_run=False)
    assert result['status']=='updated' and len(creates(sql))==2
    no_expansion(sql);after=state(owner)
    assert [{k:v for k,v in r.items() if k!='definition'} for r in before]==[{k:v for k,v in r.items() if k!='definition'} for r in after]
    verify_worker_role(worker,role)
    with trace(owner) as sql:result=OP['upgrade'](owner,role,dry_run=False)
    assert result['status']=='already_current' and not creates(sql)
    no_expansion(sql);assert state(owner)==after
    with worker.begin() as conn:
        with pytest.raises(Exception):conn.execute(text('SELECT * FROM public.social_native_source_authority_snapshot'))

@pytest.mark.parametrize('kind',['mixed','missing','unknown'])
def test_unsupported_pairs_refuse_before_any_replacement(old_profile,kind):
    _,owner,_,role=old_profile
    if kind=='mixed':replace(owner,definition,selected=[NAMES[0]])
    elif kind=='missing':
        with owner.begin() as conn:conn.execute(text('DROP VIEW public.'+NAMES[1]))
    else:
        with owner.begin() as conn:conn.execute(text('CREATE OR REPLACE VIEW public.'+NAMES[0]+" WITH (security_barrier=true) AS SELECT 'report'::text AS source_kind,'audits'::text AS native_domain,1::integer AS record_id,1::integer AS ingestion_id,repeat('a',64) AS authority_fingerprint"))
    before=state(owner)
    with trace(owner) as sql:
        with pytest.raises(Exception):OP['upgrade'](owner,role,dry_run=False)
    assert not creates(sql) and state(owner)==before

@pytest.mark.parametrize('kind',['public','snapshot_column','other_role'])
def test_acl_drift_is_preserved_and_refused_not_repaired(old_profile,kind):
    _,owner,_,role=old_profile;other='pr859_other_'+uuid4().hex
    with owner.begin() as conn:
        if kind=='other_role':
            conn.execute(text('CREATE ROLE '+other))
            conn.execute(text('GRANT SELECT ON public.'+NAMES[0]+' TO '+other))
        elif kind=='public':conn.execute(text('GRANT SELECT ON public.'+NAMES[0]+' TO PUBLIC'))
        else:conn.execute(text('GRANT SELECT(authority_fingerprint) ON public.'+NAMES[1]+' TO '+role))
    try:
        before=state(owner)
        with trace(owner) as sql:
            with pytest.raises(Exception):OP['upgrade'](owner,role,dry_run=False)
        assert state(owner)==before;no_expansion(sql)
    finally:
        if kind=='other_role':
            with owner.begin() as conn:conn.execute(text('DROP OWNED BY '+other));conn.execute(text('DROP ROLE '+other))

@pytest.mark.parametrize('field',['publishing_enabled','auto_approve_enabled','auto_schedule_enabled','auto_publish_enabled'])
def test_enabled_database_control_refuses_before_ddl(old_profile,field):
    factory,owner,_,role=old_profile
    before=state(owner)
    if field in {'auto_schedule_enabled','auto_publish_enabled'}:
        # The unchanged schema forbids these states before operator admission.
        with pytest.raises(IntegrityError,match='ck_social_controls_automation_off'):
            with factory.begin() as db:
                setattr(db.get(SocialControls,1),field,True);db.flush()
        assert state(owner)==before
        return
    with factory.begin() as db:setattr(db.get(SocialControls,1),field,True)
    with trace(owner) as sql:
        with pytest.raises(Exception):OP['upgrade'](owner,role,dry_run=False)
    assert not creates(sql) and state(owner)==before

def test_enabled_account_refuses_before_ddl(old_profile):
    factory,owner,_,role=old_profile
    with factory() as db:
        a=account(db);a.publishing_enabled=True;db.commit()
    before=state(owner)
    with trace(owner) as sql:
        with pytest.raises(Exception):OP['upgrade'](owner,role,dry_run=False)
    assert not creates(sql) and state(owner)==before

@pytest.mark.parametrize('value',['true','False','0','','false\n'])
def test_noncanonical_off_environment_refuses_without_ddl(old_profile,monkeypatch,value):
    _,owner,_,role=old_profile;monkeypatch.setenv(OP['OFF'][0],value);before=state(owner)
    with trace(owner) as sql:
        with pytest.raises(Exception):OP['upgrade'](owner,role,dry_run=False)
    assert not creates(sql) and state(owner)==before

@pytest.mark.parametrize('value',[None,0,1,'false',[],{}])
def test_direct_dry_run_requires_actual_boolean(old_profile,value):
    _,owner,_,role=old_profile;before=state(owner)
    with trace(owner) as sql:
        with pytest.raises(Exception):OP['upgrade'](owner,role,dry_run=value)
    assert not creates(sql) and state(owner)==before

def test_exception_after_first_replacement_rolls_back_the_pair(old_profile):
    _,owner,_,role=old_profile;before=state(owner);seen=[]
    def fail_second(conn,cursor,statement,parameters,context,executemany):
        if statement.lstrip().upper().startswith('CREATE OR REPLACE VIEW'):
            seen.append(statement)
            if len(seen)==2:raise RuntimeError('owned failure after first replacement')
    event.listen(owner,'before_cursor_execute',fail_second)
    try:
        with pytest.raises(RuntimeError,match='owned failure'):OP['upgrade'](owner,role,dry_run=False)
    finally:event.remove(owner,'before_cursor_execute',fail_second)
    assert len(seen)==2 and state(owner)==before

def test_contention_on_second_view_rolls_back_first_replacement(old_profile):
    _,owner,_,role=old_profile;before=state(owner)
    with owner.connect() as blocker:
        tx=blocker.begin();blocker.execute(text('LOCK TABLE public.'+NAMES[0]+' IN ACCESS SHARE MODE'))
        try:
            with trace(owner) as sql:
                with pytest.raises(Exception) as failure:OP['upgrade'](owner,role,dry_run=False)
            assert getattr(getattr(failure.value,'orig',None),'pgcode',None)=='55P03'
            assert len(creates(sql))==2
        finally:tx.rollback()
    assert state(owner)==before

@pytest.mark.parametrize('entry',['verify','ordinary','native'])
def test_old_views_never_pass_new_regular_install_or_verification(old_profile,entry):
    _,owner,worker,role=old_profile;before=state(owner)
    with pytest.raises(WorkerRoleError):
        if entry=='verify':verify_worker_role(worker,role)
        elif entry=='ordinary':install_worker_role(owner,role)
        else:install_native_authority(owner,role)
    assert state(owner)==before
