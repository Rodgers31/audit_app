"""Owned-PG lock/deparser behavior; no role/grant/worker or provider activity."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,json,hashlib
from sqlalchemy import create_engine,text
from social.worker.native_authority_schema import create_views
from social.worker.role_contract import _views,NATIVE_VIEW_SHA256,_limits

engine=create_engine(os.environ['DATABASE_URL'])
def hashes(conn):
    rows=conn.execute(text("SELECT c.relname,c.oid,c.relowner,c.relacl::text,pg_get_viewdef(c.oid,true) AS definition FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname IN ('social_native_source_authority','social_native_source_authority_snapshot') ORDER BY c.relname")).mappings().all()
    output=[]
    for row in rows:
        value=dict(row);definition=value['definition']
        for clause in ('FROM ','JOIN '):definition=definition.replace(clause+'public.',clause).replace(clause+'"public".',clause)
        value['normalized_sha256']=hashlib.sha256(definition.encode()).hexdigest()
        value['expected_sha256']=NATIVE_VIEW_SHA256[value['relname']]
        assert value['normalized_sha256']==value['expected_sha256']
        output.append(value)
    assert len(output)==2
    return output

try:
    with engine.begin() as conn:
        _limits(conn)
        conn.execute(text('SET LOCAL search_path=pg_catalog,public,pg_temp'))
        create_views(conn)
        conn.execute(text('SET LOCAL search_path=pg_catalog,pg_temp'))
        _views(conn,'public')
        before=hashes(conn)
        version=conn.scalar(text('SHOW server_version'))
    with engine.begin() as conn:
        _limits(conn)
        conn.execute(text('LOCK TABLE public.social_native_source_authority,public.social_native_source_authority_snapshot IN ACCESS SHARE MODE'))
        def competing_ddl():
            try:
                with engine.begin() as other:
                    other.execute(text("SET LOCAL lock_timeout='150ms'"))
                    other.exec_driver_sql('CREATE OR REPLACE VIEW public.social_native_source_authority WITH (security_barrier=true) AS '+before[0]['definition'])
            except Exception as exc:
                return getattr(getattr(exc,'orig',None),'pgcode',None)
            return 'unexpected_success'
        def ordinary_dml():
            with engine.connect() as other:
                tx=other.begin()
                try:
                    other.execute(text("SET LOCAL lock_timeout='150ms'"))
                    count=other.execute(text("INSERT INTO countries(iso_code,name,currency,timezone,default_locale) VALUES ('ZZZ','Owned lock probe','KES','Africa/Nairobi','en')")).rowcount
                    return count
                finally:tx.rollback()
        with ThreadPoolExecutor(max_workers=2) as pool:
            ddl_code=pool.submit(competing_ddl).result(timeout=5)
            dml_count=pool.submit(ordinary_dml).result(timeout=5)
        assert ddl_code=='55P03' and dml_count==1,(ddl_code,dml_count)
        locks=[dict(row) for row in conn.execute(text("SELECT n.nspname,c.relname,l.mode FROM pg_locks l JOIN pg_class c ON c.oid=l.relation JOIN pg_namespace n ON n.oid=c.relnamespace WHERE l.pid=pg_backend_pid() AND l.granted AND n.nspname='public' ORDER BY c.relname,l.mode")).mappings()]
    with engine.begin() as conn:
        _limits(conn);after=hashes(conn)
        assert before==after
        conn.execute(text('DROP VIEW public.social_native_source_authority,public.social_native_source_authority_snapshot'))
    result={'server_version':version,'before':before,'lock_query_supported':True,'held_public_locks':locks,'after_matches_before':True,'owned_views_removed':True,'competing_owner_ddl_sqlstate':ddl_code,'ordinary_owner_dml_allowed_then_rolled_back':dml_count==1}
    Path('/evidence/accepted-view-lock-profile.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'server_version':version,'lock_query_supported':True,'locked_relations':sorted(set(r['relname'] for r in locks)),'old_hashes_match_registry':True,'owned_views_removed':True,'competing_owner_ddl_sqlstate':ddl_code,'ordinary_owner_dml_allowed_then_rolled_back':dml_count==1,'competing_owner_ddl_sqlstate':ddl_code,'ordinary_owner_dml_allowed_then_rolled_back':dml_count==1}))
finally:engine.dispose()
