"""Stdlib reconciliation of executed receipts; not a runtime acceptance rerun."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
BASE=Path(__file__).resolve().parent
PARENT=BASE.parent
manifest=json.loads((PARENT/'candidate-1-manifest.json').read_text())
for path,sha in manifest.items():assert hashlib.sha256((PARENT/'candidate-1'/path).read_bytes()).hexdigest()==sha,path
mapping=hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert mapping=='d6a204b8f7982d91756c7624afcfee99daf317f1c438e79882d55fd29901d1dd'
operator_sha=hashlib.sha256((PARENT/'operator-final2.py').read_bytes()).hexdigest()
assert operator_sha=='4c401a7d403ce4ebaccd6a85ad5d8990b45cafbb100d11f5fe0a278511916253'
(BASE/'frozen1-after.json').write_text(json.dumps({'files':len(manifest),'mapping_sha256':mapping,'all_entries_match':True,'final_external_operator_sha256':operator_sha},indent=2)+'\n')

def junit(name):
    rows=list(ET.parse(BASE/name).iter('testcase'))
    assert rows and not any(row.find(tag) is not None for row in rows for tag in ('failure','error','skipped'))
    return [row.attrib['classname']+'::'+row.attrib['name'] for row in rows]
normal=junit('operator2-normal.xml');optimized=junit('operator2-optimized.xml')
for mode in ('normal','optimized'):
    execution=json.loads((BASE/('operator2-'+mode+'-execution.json')).read_text())
    assert type(execution['child_exit_code']) is int and execution['child_exit_code']==0 and execution['operator_sha256']==operator_sha
assert len(normal)==55 and sorted(normal)==sorted(optimized)
ledgers={}
for mode in ('normal','optimized'):
    data=json.loads((BASE/('reverse-final2-'+mode+'-ledger.json')).read_text())
    assert data['all_passed'] is True and len(data['stages'])==9 and data['operator_sha256']==operator_sha
    for stage in data['stages']:
        assert type(stage['child_exit_code']) is int and stage['child_exit_code']==0
        assert hashlib.sha256((BASE/stage['log']).read_bytes()).hexdigest()==stage['sha256']
    ledgers[mode]=data
cleanup=json.loads((BASE/'CLEANUP.json').read_text())
assert cleanup['container_absent'] is True and cleanup['credential_files_absent'] is True
lock=json.loads((BASE/'accepted-view-lock-profile.json').read_text())
assert lock['competing_owner_ddl_sqlstate']=='55P03' and lock['ordinary_owner_dml_allowed_then_rolled_back'] is True
case_ledger={'normal':[{'id':i,'outcome':'passed','junit':'operator2-normal.xml'} for i in normal],
    'optimized':[{'id':i,'outcome':'passed','junit':'operator2-optimized.xml'} for i in optimized],
    'reverse_runtime_stages':{mode:[{k:v for k,v in stage.items() if k!='argv'} for stage in data['stages']] for mode,data in ledgers.items()}}
(BASE/'CASE-LEDGER.json').write_text(json.dumps(case_ledger,indent=2)+'\n')
receipt={'verdict':'scoped_pass','app_candidate':'candidate-1','app_mapping_sha256':mapping,'app_files':len(manifest),
    'app_verified_before_after':True,'operator_final_sha256':operator_sha,
    'composite_note':'Frozen candidate1 app/SQL/test bytes plus the separately pinned final upgrade/restore release artifact; candidate1 archived original operator is superseded, not relabelled.',
    'pytest_cases_per_mode':55,'operator_cases_per_mode':29,'worker_cases_per_mode':26,
    'old_view_pins':{'locked':'921b807c9637ae9541cf63e74313a4816875afef3de92d42cf6fc25226b09f4a','snapshot':'f219c56c5f21622cfae0fe875e2020770859c90f2d1978625d21a40781aa6ba6'},
    'new_view_pins':{'locked':'95c130e2106639dcaa3519951bfa9baa49b52c7fdd677b0dbfe1f0e744b3975a','snapshot':'7549c1de87fb44bf1f00b1a9b0ca39b2859d8b1e9a3d898f9203ab4a496faf1e'},
    'fresh_process_upgrade_restore_stages_per_mode':9,'modes':['normal','optimized'],
    'lock_profile':'PostgreSQL17.11 AS locks protect both view identities and block competing owner DDL55P03; ordinary owner DML remains allowed and was rolled back.',
    'old_runtime_bridge':'old-runtime-contract-bridge-final2.json','cleanup':'CLEANUP.json',
    'limits':['All execution used owned cached capped offline Docker/PG; no provider/network/production calls, new service, package install or worker/consumer start.',
        'Only direct release functions execute locally. Production main TLS/Render/proc guards are reviewed but not invoked against a real service here.',
        'Digest views enforce freshness/selected scope; privileged readers remain the complete source-meaning gate. Whole-map changes may retain a raw row but retire its old witness.',
        'No source, product, permanent test, commit or deployment edits by this reviewer. Production execution and its fresh receipts remain coordinator-owned.'],
    'closed_operator_finding':'Missing AUTO_SEEDER_ENABLED was accepted despite production default-on; actual e243 red retained, final2 requires literalfalse beforeDB.',
    'harness_failures_preserved':'harness-errors.txt; initial normalization/setup/ORM comparison/optimized assertion mistakes are not acceptance credit.'}
report='''# PR859 independent Standards review

Scoped **PASS**: frozen app/SQL candidate1, 6,095 files, mapping SHA256 `d6a204b8f7982d91756c7624afcfee99daf317f1c438e79882d55fd29901d1dd`; all entries matched before/after. Final standalone operator SHA256 `4c401a7d403ce4ebaccd6a85ad5d8990b45cafbb100d11f5fe0a278511916253` is separately pinned; the archived earlier operator is not relabelled as final.

- **55 actual PostgreSQL pytest cases passed in normal and optimized Python**, with no skips/errors/failures: 29 forward-operator controls and 26 independent audit-worker attacks.
- **Nine fresh-runtime process stages passed per mode**: real old contract/bootstrap, new rehearsal/apply, wrong-new-app restore refusal, real old-runtime restore rehearsal/apply, wrong-old-app upgrade refusal, fresh new reupgrade, actual worker verification and fixture cleanup. Old worker DDL/hash modules are byte-identical to deployed `e1a0d6b`; no hash override or mocked app verifier was used. Source/social row fingerprints, view OIDs, owners and ACLs remain unchanged.
- Worker probes cover selected/unselected receipts in both views, saved-witness retirement, missing/malformed series, numeric strings/floats/bools/huge heads, malformed receipt scope types and canonical spelling, whole-map dependency changes and removed receipt membership. The restricted login cannot read snapshot/source tables. The privileged reader remains the source-meaning gate; raw digest rows are not a general qualification verdict.
- Operator probes prove paired rehearsal rollback, committed apply and no-op, mixed/missing/unknown refusal, foreign/PUBLIC/column ACL drift refusal without repair, off-state admission, direct boolean validation, injected failure after the first replacement, and actual contention on the second view restoring the original pair. Existing ordinary/native installers and verifier refuse old views under new app pins.
- On actual PostgreSQL17.11, access-share view locks block competing owner DDL (`55P03`) while ordinary owner DML remains permitted. No grant expansion is inferred from an effective inherited privilege.

No actionable finding remains in this scope. The observed predeploy off-state gap is fixed: the earlier operator accepted a missing `AUTO_SEEDER_ENABLED` even though production defaults it on; its actual one-case red committed the new views. Final operator2 requires literal `false`, and the same control now refuses before DDL. The production operation still requires the exact off-state/source/target/installed-hash readbacks listed in `INSTALL-INVENTORY.md`; this local review is not production acceptance. Every successful release operation requires off-state; deliberately enabled/malformed fixture states are refused. No provider, worker process, production write, product edit, permanent-test edit, commit or push was performed.

The first harness mistakes are retained without acceptance credit: a hash-normalizer typo; forbidden activation states rejected by the unchanged database constraint; an account helper's committing lifecycle; unnormalized source input; an ORM int/float JSON assignment that did not persist; and stage bare assertions that would disappear under `-O`. Final stage comparisons use explicit checks and both process modes were re-executed under `reverse-final2-*` labels. No production guard was weakened and no error was skipped.

Exact external controls are `test_operator_independent.py`, `test_worker_independent.py`, `probe_view_lock.py`, `reverse_stage.py` and `run_reverse_final2.py`; raw JUnit/stage logs, old-contract bridge and `CASE-LEDGER.json` reconcile every counted result. Capped runners use cached Python image `571e327e2fbe507713d267f6f15050d585a5bbb53b8ec2e3afc73db2996d6d2d`, CPU1/memory2GiB/PID256; own PG17 uses offline internal55412, memory1GiB/tmpfs512MiB/PID128, no host port. `CLEANUP.json` confirms its exact container and two throwaway credential env files are absent; root PG/node were untouched.

Replay in a fresh evidence directory using the pinned app/operator/old source and copied scripts, `prepare.py`, the recorded final Docker pytest argv, then `python3 run_reverse_final2.py normal` and `optimized`, and `cleanup.py`. The historical logs refuse overwrite. `SHA256SUMS` verifies artifact integrity; `seal.py` reconciles evidence only and is not an acceptance rerun. Production `main` TLS/Render/process checks were not invoked locally.
'''
(BASE/'REPORT.md').write_text(report)
excluded={'pg.env','runtime.env','RECEIPT.json','SHA256SUMS'}
receipt['artifacts']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(BASE.iterdir()) if p.is_file() and p.name not in excluded}
(BASE/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
sums={**receipt['artifacts'],'RECEIPT.json':hashlib.sha256((BASE/'RECEIPT.json').read_bytes()).hexdigest()}
(BASE/'SHA256SUMS').write_text(''.join(sha+'  '+name+'\n' for name,sha in sorted(sums.items())))
assert json.loads((BASE/'RECEIPT.json').read_text())==receipt
print(json.dumps({'verdict':'scoped_pass','pytest_cases_per_mode':55,'fresh_runtime_stages_per_mode':9,'app_mapping_sha256':mapping,'operator_sha256':operator_sha}))
