"""A production-default-on service needs an explicit false release hold."""
import json
from sqlalchemy import text
from test_operator_independent import OP,old_profile,state
from native_worker_fixture import restricted
from test_b83_generation_postgres import pg
from social.worker.role_contract import _limits

def test_auto_seeder_off_state_cannot_be_inferred_from_missing_raw_variable(old_profile,monkeypatch):
    _,owner,_,role=old_profile
    monkeypatch.setenv('ENVIRONMENT','production')
    monkeypatch.delenv('AUTO_SEEDER_ENABLED',raising=False)
    before=state(owner);error=None;status=None
    try:status=OP['upgrade'](owner,role,dry_run=False)['status']
    except RuntimeError as exc:error=str(exc)
    after=state(owner)
    with owner.begin() as conn:
        _limits(conn);pins={n:r['sha256'] for n,r in OP['rows'](conn).items()}
    print(json.dumps({'error':error,'status':status,'installed_pins':pins,'state_unchanged':after==before}))
    assert error=='PR859_VIEW_UPGRADE_REFUSED'
    assert after==before
