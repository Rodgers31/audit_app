"""One fresh process using its mounted actual app contract; no pin override."""
from pathlib import Path
import os,sys,json,runpy
from sqlalchemy import create_engine,text
from social.models import SocialControls
from social.worker.role_contract import _limits,_scope,install_worker_role,verify_worker_role,NATIVE_VIEW_SHA256,WorkerRoleError
from social.worker.native_authority_schema import install_native_authority

def check(value):
    if value is not True:raise RuntimeError('STANDARDS_REVERSE_STAGE_FAILED')

OP=runpy.run_path('/operator/operator-final2.py')
mode=sys.argv[1];role=os.environ['PR859_FIXTURE_ROLE'];_scope(role,'public')
engine=create_engine(os.environ['DATABASE_URL'],pool_size=2,max_overflow=0)
worker=create_engine(engine.url.set(username=role,password='inert-local-only'),pool_size=1,max_overflow=0)

def snapshot():
    with engine.begin() as conn:_limits(conn);return OP['rows'](conn)

def footprint():
    tables=['social_controls','social_accounts','social_posts','social_post_targets','social_publications',
        'social_media_assets','social_publish_attempts','source_documents','extractions','ingestion_jobs',
        'budget_lines','revenue_by_source','loans','countries','entities','fiscal_periods']
    with engine.begin() as conn:
        return {name:list(conn.execute(text('SELECT count(*),md5(coalesce(jsonb_agg(to_jsonb(t) ORDER BY id)::text,\'\')) FROM public.'+name+' t')).one()) for name in tables}

try:
    for key in OP['OFF']:check(os.getenv(key) in (None,'false'))
    check(os.getenv('AUTO_SEEDER_ENABLED')=='false')
    if mode=='bootstrap':
        check(NATIVE_VIEW_SHA256==OP['PRIOR'])
        with engine.begin() as conn:
            check(conn.scalar(text('SELECT count(*) FROM pg_roles WHERE rolname=:role'),{'role':role})==0)
            check(conn.scalar(text("SELECT to_regclass('public.social_native_source_authority')")) is None)
            conn.exec_driver_sql('CREATE ROLE '+role+" LOGIN PASSWORD 'inert-local-only' NOINHERIT NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS CONNECTION LIMIT 2")
        install_worker_role(engine,role);install_native_authority(engine,role);verify_worker_role(worker,role)
        after=snapshot();check({n:r['sha256'] for n,r in after.items()}==OP['PRIOR'])
        result={'stage':mode,'status':'passed','actual_app_pins':NATIVE_VIEW_SHA256,'after':after}
    elif mode=='cleanup':
        verify_worker_role(worker,role)
        with engine.begin() as conn:
            conn.exec_driver_sql('DROP VIEW public.social_native_source_authority,public.social_native_source_authority_snapshot')
            conn.exec_driver_sql('DROP OWNED BY '+role);conn.exec_driver_sql('DROP ROLE '+role)
        result={'stage':mode,'status':'passed','fixture_role_and_views_removed':True}
    else:
        before=snapshot();rows_before=footprint()
        restore=mode.startswith('reverse')
        wrong=mode.endswith('wrong_app')
        dry=mode.endswith('rehearse')
        function=OP['restore'] if restore else OP['upgrade']
        if wrong:
            try:function(engine,role,dry_run=False)
            except RuntimeError as exc:check(str(exc)=='PR859_VIEW_UPGRADE_REFUSED')
            else:raise AssertionError('Wrong actual app contract accepted')
            result={'stage':mode,'status':'passed','wrong_app_refused':True}
        else:
            response=function(engine,role,dry_run=dry)
            target=OP['PRIOR'] if restore else OP['CURRENT']
            check(NATIVE_VIEW_SHA256==target)
            actual=snapshot()
            if dry:check(actual==before)
            else:
                check({n:r['sha256'] for n,r in actual.items()}==target)
                verify_worker_role(worker,role)
            result={'stage':mode,'status':'passed','operator':response}
        after=snapshot();rows_after=footprint();check(rows_after==rows_before)
        if wrong:check(after==before)
        check(all({k:v for k,v in before[n].items() if k!='sha256'}=={k:v for k,v in after[n].items() if k!='sha256'} for n in OP['NAMES']))
        result.update(actual_app_pins=NATIVE_VIEW_SHA256,before=before,after=after,source_and_social_rows_unchanged=rows_after==rows_before)
    print(json.dumps(result))
finally:
    worker.dispose();engine.dispose()
