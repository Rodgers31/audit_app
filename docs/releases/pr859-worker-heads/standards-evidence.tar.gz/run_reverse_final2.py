"""Host-only fresh-runtime rollback/reupgrade orchestration, no Docker socket."""
from pathlib import Path
from uuid import uuid4
import subprocess,json,hashlib,sys
BASE=Path(__file__).resolve().parent
mode=sys.argv[1];assert mode in ('normal','optimized')
operator=BASE.parent/'operator-final2.py'
assert hashlib.sha256(operator.read_bytes()).hexdigest()=='4c401a7d403ce4ebaccd6a85ad5d8990b45cafbb100d11f5fe0a278511916253'
role='pr859_reverse_'+uuid4().hex
stages=[('bootstrap',False),('forward_rehearse',True),('forward_apply',True),
    ('reverse_wrong_app',True),('reverse_rehearse',False),('reverse_apply',False),
    ('forward_wrong_app',False),('forward_reapply',True),('cleanup',True)]
receipts=[]
for stage,new in stages:
    label='reverse-final2-'+mode+'-'+stage
    source=BASE.parent/'candidate-1' if new else BASE/'accepted-source'
    command=['docker','run','--pull','never','--rm','--name','standards-pr859-'+label,
        '--network','container:standards-pr859-pg','--cpus','1','--memory','2g','--pids-limit','256',
        '--env-file',str(BASE/'runtime.env'),'-e','PR859_FIXTURE_ROLE='+role,
        '-v',str(source)+':/work:ro','-v',str(BASE.parent)+':/operator:ro','-v',str(BASE)+':/evidence',
        '-w','/work/backend','admin-redesign-python-runtime:local','python']
    if mode=='optimized':command.append('-O')
    command+=['/evidence/reverse_stage.py',stage]
    target=BASE/(label+'.txt');assert not target.exists()
    result=subprocess.run(command,capture_output=True,text=True,timeout=60)
    target.write_text(result.stdout+result.stderr)
    assert result.returncode==0,(stage,result.returncode)
    data=json.loads(result.stdout);assert data['status']=='passed'
    receipts.append({'stage':stage,'source':'candidate-1' if new else 'accepted-source',
        'child_exit_code':result.returncode,'log':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
        'argv':command})
out=BASE/('reverse-final2-'+mode+'-ledger.json');assert not out.exists()
out.write_text(json.dumps({'stages':receipts,'operator_sha256':hashlib.sha256(operator.read_bytes()).hexdigest(),'mode':mode,'all_passed':True},indent=2)+'\n')
print(json.dumps({'mode':mode,'passed_stages':len(receipts),'fresh_runtime_processes':True}))
