"""Extra worker-SQL attacks, independent of the permanent regression cases."""
from copy import deepcopy
import importlib.util
from pathlib import Path
import re

from sqlalchemy import select,text
from sqlalchemy.orm.attributes import flag_modified
from models import Extraction,IngestionJob
from social.generation.worker_authority import capture_worker_authority,verify_worker_authority
from social.service import SocialError
import pytest
from test_audit_worker_series import audit_sources,restricted,pg,CURRENT,SNAPSHOT,fingerprint
from test_b83_generation_postgres import no_publication


def test_report_scope_json_types_and_unicode_refuse_both_sql_views(audit_sources):
    factory,owner,worker,_,job,_,head,_,source,witness,_,_=audit_sources
    with factory() as db:
        original=deepcopy(db.get(Extraction,head).extracted_json)
        original_meta=deepcopy(db.get(IngestionJob,job).meta)
    scopes=[None,True,11111111111111111111111111111111,[],{},'F'*32,'f'*64,'ｆ'*32]
    try:
        for scope in scopes:
            with factory.begin() as db:
                ext=db.get(Extraction,head);raw=deepcopy(original)
                raw['response_receipt']['observations'][0]['scope_key']=scope
                ext.extracted_json=raw;flag_modified(ext,'extracted_json')
                current=db.get(IngestionJob,job)
                current.meta={**original_meta,'native_report_series':{str(scope):head}}
                flag_modified(current,'meta')
            assert fingerprint(worker,CURRENT,head,job)==[],scope
            assert fingerprint(owner,SNAPSHOT,head,job)==[],scope
            with worker.begin() as conn:
                with pytest.raises(SocialError,match='SOURCE_REVIEW_REQUIRED'):
                    verify_worker_authority(conn,source,witness)
    finally:
        with factory.begin() as db:
            ext=db.get(Extraction,head);ext.extracted_json=original;flag_modified(ext,'extracted_json')
            current=db.get(IngestionJob,job);current.meta=original_meta;flag_modified(current,'meta')
    no_publication(factory)


def test_non_audit_sql_projection_tokens_are_unchanged():
    from social.worker import native_authority_schema as current
    spec=importlib.util.spec_from_file_location('owned_baseline_native_authority_schema',Path('/evidence/baseline_native_authority_schema.py'))
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    compact=lambda value:re.sub(r'\s+',' ',value).strip()
    for domain in ['national_budget','revenue_by_source','pending_bills']:
        for financial in [False,True]:
            for locked in [False,True]:
                assert compact(current._branch(domain,financial=financial,locked=locked))==compact(old._branch(domain,financial=financial,locked=locked)),(domain,financial,locked)


def test_real_qualified_financial_worker_fingerprint_is_unchanged_by_series_map(restricted,tmp_path,monkeypatch):
    from test_native_financial_changes_postgres import ingest_revenue,read
    factory,owner,worker,_=restricted
    job,record=ingest_revenue(factory,tmp_path,monkeypatch)
    source=read(factory,job,record)
    with factory.begin() as db:witness=capture_worker_authority(db,source)
    assert witness is not None
    query=text("SELECT authority_fingerprint FROM public.social_native_source_authority WHERE source_kind='financial' AND native_domain='revenue_by_source' AND record_id=:record AND ingestion_id=:job")
    with factory.begin() as db:
        current=db.get(IngestionJob,job)
        current.meta={**current.meta,'native_report_series':{**current.meta['native_report_series'],'f'*32:record}}
        flag_modified(current,'meta')
    with worker.begin() as conn:
        assert conn.execute(query,{'record':record,'job':job}).scalars().all()==[witness['fingerprint']]
        assert verify_worker_authority(conn,source,witness)is None
    no_publication(factory)
