from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent;C=P.parent/'candidate';REPO=Path('/Users/roger/.codex/worktrees/admin-social-release-check/audit_app');sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
full=json.loads((P/'full-input-manifest.json').read_text());projection=json.loads((P/'source-manifest.json').read_text());drift={'full_candidate':[],'projection':[],'checkout_projection':[]}
for name,h in full.items():
 if sha(C/name)!=h:drift['full_candidate'].append(name)
for name,h in projection.items():
 if sha(P/'source'/name)!=h:drift['projection'].append(name)
 if sha(REPO/name)!=h:drift['checkout_projection'].append(name)
if any(drift.values()):raise RuntimeError('Input drift '+repr(drift))
if sha(P.parent/'candidate-source-sha256.json')!='5c21428891c41e6016173f26a7e2ac9c668526e579543898efea0b928ee4f86b':raise RuntimeError('Manifest changed')
ledger=[];ids=[]
for label,mode in [('pg-normal','normal'),('pg-optimized','optimized')]:
 if json.loads((P/(label+'.exit.json')).read_text())['exit_code']!=0:raise RuntimeError('PG exit not0')
 nodes=ET.parse(P/(label+'.xml')).findall('.//testcase');caseids=[]
 if len(nodes)!=16:raise RuntimeError('Wrong PG count')
 for n in nodes:
  if any(n.find(t)is not None for t in ['failure','error','skipped']):raise RuntimeError('Unsuccessful PGcase')
  ident=(n.get('classname'),n.get('name'));caseids.append(ident);ledger.append({'mode':mode,'suite':ident[0],'name':ident[1],'outcome':'passed'})
 if len(set(caseids))!=16:raise RuntimeError('DuplicatePGcase')
 ids.append(set(caseids))
if ids[0]!=ids[1]:raise RuntimeError('PG inventories differ')
F=P/'flag-review';flag=json.loads((F/'RECEIPT.json').read_text())
if flag['results']!={'normal':130,'true_optimized':130,'failed':0,'errors':0,'skipped':0,'same_case_ids_each_mode':True}:raise RuntimeError('Flag lane not exact130both')
if flag['inputs']['manifest_mapping_sha256']!=json.loads((P/'input-pins.json').read_text())['full_mapping_sha256']:raise RuntimeError('Flag source mismatch')
for name,h in flag['artifact_sha256'].items():
 if sha(F/name)!=h:raise RuntimeError('Flag artifact drift '+name)
cleanup=json.loads((P/'CLEANUP.json').read_text());state=json.loads((P/'final-owned-state.json').read_text())['state']
if not cleanup['owned_pg_removed']or not cleanup['private_env_deleted']or cleanup['remaining_owned_containers']:raise RuntimeError('Cleanup incomplete')
if state['head']!='a756b20a0001'or any(state[k]!=0 for k in ['posts','revisions','publications','targets','attempts','cursors','events','owned_worker_roles']):raise RuntimeError('Unexpected final effects')
(P/'CASE-LEDGER.json').write_text(json.dumps({'postgres':ledger,'flag_cache_workflow_ledger':'flag-review/CASE-LEDGER.json','total_per_mode':146,'independent_per_mode':140,'repository_corroboration_per_mode':6,'mode_replays_not_unique_new_cases':True},indent=2))
(P/'SOURCE-AFTER.json').write_text(json.dumps({'full_files':len(full),'projection_files':len(projection),'drift':drift,'full_mapping_sha256':json.loads((P/'input-pins.json').read_text())['full_mapping_sha256']},indent=2))
files=['input-pins.json','full-input-manifest.json','source-manifest.json','SOURCE-AFTER.json','CASE-LEDGER.json','pg-start.command.json','pg-owner.json','migrate.command.json','migrate.txt','migrate.exit.json','pg-normal.command.json','pg-normal.txt','pg-normal.xml','pg-normal.exit.json','pg-optimized.command.json','pg-optimized.txt','pg-optimized.xml','pg-optimized.exit.json','test_source_only_worker.py','run_pg.py','final-owned-state.json','CLEANUP.json']
r={'verdict':'SCOPED PASS; no confirmed source-admission finding','full_source_mapping_sha256':json.loads((P/'input-pins.json').read_text())['full_mapping_sha256'],'source_entries':len(full),'execution_projection_entries':len(projection),'results':{'normal':146,'true_optimized':146,'independent_each':140,'repository_each':6,'failed':0,'errors':0,'skipped':0,'postgres_each':16,'flag_cache_workflow_each':130,'same_ids_each_mode':True},'postgres_scope':['Actual KRA creator→writer→fresh current reader→captured restricted worker witness without posts/cursors','Missing/forged/bool/stale witnesses refuse; actual private business-table SELECT denied42501','Unchanged and changed-value new-job reacquisition preserves exact record ID and new evidence, refuses old witness','Changed business/source/receipt/country/partial-job/fixture-job inputs refuse current reader and worker','Source-only global hook cannot open generation SessionFactory while financial generationfalse','Repository fourflag matrix/global hook/catalogue no-financial-date corroborated'], 'limits':['Owned publisher-shaped and retained catalogue fixtures, not live production adoption','No full genuine national/pending PDF parse in this lane; root owns genuine source-only replay','Cache tests stop at actual cache-boundary argument, no persisted-cache authority claim','Restricted SQL role/view proof is not a worker process or publication authorization','No generation/publishing/upload/provider/production activation or sharedPG access'], 'flag_child_receipt_sha256':sha(F/'RECEIPT.json'),'runtime':{'python_image':'pr863-python-patch-parity:local','image_id_observed':'sha256:1b4cc12668ffaa5bd5e5aa78bd96c053f8d0778651c040ad4a5d69ef305d983b','postgres_image_id_observed':'sha256:2d2b8998d31037bf721cfdf764d76ba74171b4fab3431b7f72c27c56ddbdf9e3','PGhead':'a756b20a0001','app_caps':'1CPU/768MiB/256PIDs','PGcaps':'1CPU/512MiB/256PIDs/tmpfs384MiB','network':'own PG networknone namespace/loopback55412; no host ports'},'cleanup':cleanup,'final_own_counts':state,'artifact_sha256':{name:sha(P/name)for name in files}}
(P/'FINAL-RECEIPT.json').write_text(json.dumps(r,indent=2));print(json.dumps({'verdict':r['verdict'],'results':r['results'],'source_drift':drift,'cleanup_complete':True},indent=2))
