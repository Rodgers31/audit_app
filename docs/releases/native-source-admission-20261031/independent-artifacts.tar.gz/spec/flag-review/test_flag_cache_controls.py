import json,os,re
from datetime import datetime,timedelta,timezone
from pathlib import Path
from types import SimpleNamespace
from uuid import UUID
import pytest,yaml
from seeding.native_financial_admission import SOURCE_ADMISSION_FLAG,source_admission_enabled
from seeding.native_financial_gate import qualify_native_financial_rows
from seeding.config import SeedingSettings

GEN='SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED'
class StrSubclass(str):pass
class LyingValue:
 def __eq__(self,other):return True
 def __str__(self):return 'true'
class Projection:
 def __init__(self,value):self.value=value
 def get(self,key):return self.value
class Boundary(Exception):pass
class ForbiddenSession:
 def execute(self,*args,**kwargs):raise AssertionError('DB accessed outside admission')
class ForbiddenRows:
 def __iter__(self):raise AssertionError('Rows consumed outside admission')
class ForbiddenContext:
 def __getattribute__(self,key):raise AssertionError('Context accessed before process admission')

@pytest.fixture(autouse=True)
def default_flags(monkeypatch):
 monkeypatch.delenv(SOURCE_ADMISSION_FLAG,raising=False);monkeypatch.setenv(GEN,'false');monkeypatch.setenv('SEED_PENDING_BILLS_AGING_ENABLED','false');monkeypatch.setenv('SEED_PENDING_BILLS_ASSEMBLY_AGING_ENABLED','false')

@pytest.mark.parametrize('raw',[None,'','false','TRUE','True',' true','true ','true\n','1','yes',True,False,1,0,1.0,float('nan'),float('inf'),[],{},StrSubclass('true'),LyingValue()])
def test_hostile_projection_values_never_admit(raw):
 assert source_admission_enabled({SOURCE_ADMISSION_FLAG:raw}) is False
 assert source_admission_enabled(Projection(raw)) is False

def test_projection_is_not_a_process_capability(monkeypatch):
 assert source_admission_enabled(Projection('true')) is True
 assert source_admission_enabled({SOURCE_ADMISSION_FLAG:'true'}) is True
 assert source_admission_enabled() is False
 monkeypatch.setenv(GEN,'true')
 qualify_native_financial_rows(ForbiddenSession(),ForbiddenRows(),domain='pending_bills',context=ForbiddenContext())
 assert source_admission_enabled() is False

def test_empty_projection_does_not_fall_back_to_process_true(monkeypatch):
 monkeypatch.setenv(SOURCE_ADMISSION_FLAG,'true');assert source_admission_enabled() is True;assert source_admission_enabled({}) is False

@pytest.mark.parametrize('source,generation',[(None,'true'),('false','true'),('TRUE','true'),(' true ','false'),('1','true')])
def test_no_process_source_admission_touches_neither_rows_nor_context_nor_db(monkeypatch,source,generation):
 if source is not None:monkeypatch.setenv(SOURCE_ADMISSION_FLAG,source)
 monkeypatch.setenv(GEN,generation)
 qualify_native_financial_rows(ForbiddenSession(),ForbiddenRows(),domain='pending_bills',context=ForbiddenContext())

@pytest.mark.parametrize('dry,job',[(True,23),(0,23),(None,23),('false',23),(False,True),(False,False),(False,23.0),(False,'23'),(False,0),(False,-1),(False,None),(False,StrSubclass('23'))])
def test_invalid_context_never_queries_or_consumes_rows(monkeypatch,dry,job):
 monkeypatch.setenv(SOURCE_ADMISSION_FLAG,'true');qualify_native_financial_rows(ForbiddenSession(),ForbiddenRows(),domain='pending_bills',context=SimpleNamespace(dry_run=dry,job_id=job))

@pytest.mark.parametrize('context',[None,SimpleNamespace(),SimpleNamespace(dry_run=False),SimpleNamespace(job_id=23)])
def test_absent_context_fields_fail_closed_before_rows_db(monkeypatch,context):
 monkeypatch.setenv(SOURCE_ADMISSION_FLAG,'true')
 try:qualify_native_financial_rows(ForbiddenSession(),ForbiddenRows(),domain='pending_bills',context=context)
 except AttributeError:pass

@pytest.mark.parametrize('domain',['national_budget','revenue_by_source','pending_bills'])
def test_valid_process_source_control_reaches_db_boundary_without_generation(monkeypatch,domain):
 monkeypatch.setenv(SOURCE_ADMISSION_FLAG,'true');monkeypatch.setenv(GEN,'false');calls=[]
 class Session:
  def execute(self,query):calls.append(query);raise Boundary('actual qualification query reached')
 with pytest.raises(Boundary):qualify_native_financial_rows(Session(),[SimpleNamespace(source_document_id=4)],domain=domain,context=SimpleNamespace(dry_run=False,job_id=23))
 assert len(calls)==1;assert os.environ[GEN]=='false'

def test_source_control_alone_does_not_touch_db_for_empty_rows(monkeypatch):
 monkeypatch.setenv(SOURCE_ADMISSION_FLAG,'true');qualify_native_financial_rows(ForbiddenSession(),[],domain='pending_bills',context=SimpleNamespace(dry_run=False,job_id=23))

def test_bounded_row_count_refuses_before_db(monkeypatch):
 monkeypatch.setenv(SOURCE_ADMISSION_FLAG,'true')
 with pytest.raises(ValueError,match='Bounded'):qualify_native_financial_rows(ForbiddenSession(),[object()for _ in range(1001)],domain='pending_bills',context=SimpleNamespace(dry_run=False,job_id=23))

def test_settings_projection_has_no_source_admission_field_or_grant(monkeypatch,tmp_path):
 settings=SeedingSettings(cache_path=tmp_path,native_financial_source_admission_enabled=True,source_admission_enabled=True)
 assert 'native_financial_source_admission_enabled'not in settings.model_fields
 assert 'source_admission_enabled'not in settings.model_dump()
 ctx=SimpleNamespace(dry_run=False,job_id=23,settings=settings,source_admission_enabled=True)
 monkeypatch.setenv(GEN,'true');qualify_native_financial_rows(ForbiddenSession(),ForbiddenRows(),domain='national_budget',context=ctx)
 assert source_admission_enabled() is False

SCOPES=[('valid',False,23),('dry',True,23),('zero_dry',0,23),('none_dry',None,23),('bool_job',False,True),('float_job',False,23.0),('str_job',False,'23'),('zero_job',False,0),('negative_job',False,-1),('none_job',False,None),('no_context',None,None)]
@pytest.mark.parametrize('domain',['national_budget','pending_bills'])
@pytest.mark.parametrize('source,generation',[('true','false'),(None,'true'),('false','true')])
@pytest.mark.parametrize('scope,dry,job',SCOPES)
def test_actual_cache_argument_requires_process_source_literal_live_context(monkeypatch,tmp_path,domain,source,generation,scope,dry,job):
 if source is not None:monkeypatch.setenv(SOURCE_ADMISSION_FLAG,source)
 monkeypatch.setenv(GEN,generation)
 import seeding.parse_cache as cache
 calls=[]
 def boundary(*a,**kw):calls.append(kw['enabled']);raise Boundary('actual cache boundary')
 monkeypatch.setattr(cache,'parse_with_cache',boundary)
 context=None if scope=='no_context'else SimpleNamespace(dry_run=dry,job_id=job)
 settings=SeedingSettings(cache_path=tmp_path,live_pdf_fetch_enabled=True,parse_cache_enabled=True)
 if domain=='national_budget':
  import seeding.pdf_download as download
  from seeding.domains.national_budget.fetcher import AnnualReport,_fetch_annual_sector_expenditure
  monkeypatch.setattr(download,'get_or_download_pdf',lambda *a,**kw:tmp_path/'owned.pdf')
  with pytest.raises(Boundary):_fetch_annual_sector_expenditure(object(),settings,AnnualReport('https://cob.go.ke/owned.pdf','FY 2025/26',2025),context=context)
 else:
  import seeding.cob_cbirr as download
  import seeding.pdf_parsers as parsers
  import seeding.domains.pending_bills.fetcher as pending
  monkeypatch.setattr(download,'download_cbirr',lambda *a,**kw:SimpleNamespace(path=tmp_path/'owned.pdf'))
  monkeypatch.setattr(parsers,'CbirrYearEndPayablesParser',lambda *a:SimpleNamespace(parse=lambda:[]))
  monkeypatch.setattr(pending,'year_end_cbirr_links',lambda *a:['https://cob.go.ke/owned.pdf'])
  monkeypatch.setattr(pending,'_has_aging_pointer',lambda *a:False)
  client=SimpleNamespace(get=lambda *a,**kw:SimpleNamespace(text='owned listing'))
  with pytest.raises(pending.CountyPayablesUnavailable)as exc:pending.fetch_county_payables_payload(client,settings,context=context)
  assert isinstance(exc.value.__cause__,Boundary)
 assert calls==[not(source=='true'and scope=='valid')]

@pytest.mark.parametrize('source',[None,'true'])
def test_pending_live_fetch_disabled_not_activated_by_source_flag(monkeypatch,tmp_path,source):
 if source:monkeypatch.setenv(SOURCE_ADMISSION_FLAG,source)
 import seeding.domains.pending_bills.fetcher as pending
 settings=SeedingSettings(cache_path=tmp_path,live_pdf_fetch_enabled=False)
 class Client:
  def get(self,*a,**k):raise AssertionError('source flag enabled disabled acquisition')
 assert pending.fetch_county_payables_payload(Client(),settings,context=SimpleNamespace(dry_run=False,job_id=23)) is None

def workflow_binding():
 d=yaml.safe_load(Path('/work/.github/workflows/seed.yml').read_text());job=d['jobs']['seed'];steps=[s for s in job['steps']if s.get('name')=='Seed planned domains'];assert len(steps)==1
 return {**d.get('env',{}),**job.get('env',{}),**steps[0].get('env',{})}
@pytest.mark.parametrize('value,enabled',[(None,False),('',False),('false',False),('TRUE',False),(' true ',False),('true',True)])
def test_actual_workflow_default_and_literal_variable_projection(monkeypatch,value,enabled):
 bound=workflow_binding();raw=bound[SOURCE_ADMISSION_FLAG];m=re.fullmatch(r"\$\{\{ vars\.([A-Z_]+) \|\| '([^']*)' \}\}",raw);assert m and m[1]==SOURCE_ADMISSION_FLAG and m[2]=='false'
 monkeypatch.setenv(SOURCE_ADMISSION_FLAG,value or m[2]);assert source_admission_enabled() is enabled

def admin_environment(monkeypatch):
 import admin_etl_qualification as q
 for key in q.DISABLED_FLAGS:monkeypatch.setenv(key,'false')
 monkeypatch.setenv('ADMIN_ETL_DISPATCH_SOURCES','opendata');monkeypatch.setenv('SEED_OPENDATA_INGESTION_ENABLED','true');monkeypatch.setenv('AUTO_SEEDER_ENABLED','false');monkeypatch.setenv('SEED_KNBS_RELEASE_DISCOVERY_ENABLED','false');monkeypatch.setenv('SOCIAL_GENERATION_HOOK_ENABLED','false')
 now=datetime(2026,10,31,12,tzinfo=timezone.utc);issued=now-timedelta(seconds=1);identity='00000000-0000-4000-8000-000000000001'
 monkeypatch.setenv(q.POLICY_ENV,json.dumps({'version':1,'generation':identity,'issued_at':issued.isoformat().replace('+00:00','Z'),'expires_at':(issued+timedelta(seconds=3600)).isoformat().replace('+00:00','Z')}))
 return q,now,identity
@pytest.mark.parametrize('raw',['true','TRUE',' true ','1',''])
def test_admin_qualification_rejects_source_admission_or_ambiguous_enabled_value(monkeypatch,raw):
 q,now,identity=admin_environment(monkeypatch);assert SOURCE_ADMISSION_FLAG in q.DISABLED_FLAGS;assert q.qualification(now).permits('opendata',True,UUID(identity),now)
 monkeypatch.setenv(SOURCE_ADMISSION_FLAG,raw)
 with pytest.raises(q.QualificationRefused):q.qualification(now)

def test_admin_absent_source_flag_defaults_disabled(monkeypatch):
 q,now,identity=admin_environment(monkeypatch);monkeypatch.delenv(SOURCE_ADMISSION_FLAG);assert q.qualification(now).permits('opendata',True,UUID(identity),now)
