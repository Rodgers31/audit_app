import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent
label,mode=sys.argv[1:]
cmd=['docker','run','--pull','never','--rm','--name','source-admission-spec-'+label,'--network','container:source-admission-spec-pg','--cpus','1','--memory','768m','--pids-limit','256','--env-file',str(P/'private-pg.env'),'-v',str(P/'source')+':/work:ro','-v',str(P)+':/evidence','-w','/work/backend','pr863-python-patch-parity:local','python']+(['-O']if mode=='optimized'else[])+['-m','pytest','-q','-p','no:cacheprovider','/evidence/test_source_only_worker.py','tests/social/test_source_admission_separation_postgres.py','--junitxml=/evidence/'+label+'.xml']
(P/(label+'.command.json')).write_text(json.dumps({'argv':cmd,'own_loopback_pg_only':True,'no_published_ports':True},indent=2));start=time.time()
with (P/(label+'.txt')).open('w')as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
(P/(label+'.exit.json')).write_text(json.dumps({'exit_code':r.returncode,'seconds':time.time()-start}));print(json.dumps({'label':label,'exit':r.returncode,'seconds':round(time.time()-start,3)}));raise SystemExit(r.returncode)
