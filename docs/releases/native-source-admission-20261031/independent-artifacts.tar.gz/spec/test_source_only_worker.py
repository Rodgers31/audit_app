"""Independent source-only writer/current-reader/restricted-witness controls.

Owned publisher-shaped source bodies; no draft, publication, worker or provider action.
"""
from copy import deepcopy
from decimal import Decimal
import pytest
from sqlalchemy import select,func,text
from models import RevenueBySource,SourceDocument,Extraction,IngestionJob,IngestionStatus,Country
from social.models import SocialPost,SocialPostRevision,SocialPublication,SocialPostTarget,SocialCommandReceipt,SocialControls
from social.generation.models import SourceCursor,SourceEvent
from social.generation.contracts import SourceObservation
from social.generation.worker_authority import capture_worker_authority,verify_worker_authority
from social.service import SocialError
from seeding.generation_dispatch import dispatch_committed_generation
from seeding.source_observations import read_revenue_financial_observation,SourceObservationUnavailable
from test_b83_generation_postgres import pg
from native_worker_fixture import restricted
from test_native_financial_changes_postgres import ingest_revenue


def source_only(monkeypatch):
    monkeypatch.setenv('SEED_NATIVE_FINANCIAL_SOURCE_ADMISSION_ENABLED','true')
    monkeypatch.setenv('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','false')
    monkeypatch.setenv('SOCIAL_GENERATION_HOOK_ENABLED','false')
    monkeypatch.setenv('SOCIAL_REPORT_GENERATION_ENABLED','false')


def current(factory,job,record):
    raw=read_revenue_financial_observation(factory,record_id=record,ingestion_id=job)
    return SourceObservation.model_validate(raw).model_dump(mode='json')


def no_generation(factory):
    with factory() as db:
        for model in [SocialPost,SocialPostRevision,SocialPublication,SocialPostTarget,SocialCommandReceipt,SourceCursor,SourceEvent]:
            assert db.scalar(select(func.count()).select_from(model))==0,model.__tablename__
        controls=db.get(SocialControls,1)
        assert controls is None or controls.publishing_enabled is False


def capture(factory,value):
    with factory.begin() as db:
        witness=capture_worker_authority(db,value)
    assert type(witness)is dict and witness['kind']=='financial'
    return witness


def test_source_only_creator_to_fresh_reader_and_restricted_witness_creates_no_delivery_authority(restricted,tmp_path,monkeypatch):
    factory,owner,worker,role=restricted;source_only(monkeypatch)
    job,record=ingest_revenue(factory,tmp_path,monkeypatch)
    with factory() as db:
        row=db.get(RevenueBySource,record)
        assert row.publishable is True and row.quarantine_reason is None
        assert row.amount_billion_kes==560
    value=current(factory,job,record)
    assert Decimal(value['facts'][0]['value'])==Decimal(560)
    witness=capture(factory,value)
    with worker.begin() as conn:
        assert verify_worker_authority(conn,value,witness)is None
    for bad in [None,{**witness,'fingerprint':'f'*64},{**witness,'record_id':True}]:
        with pytest.raises(SocialError,match='SOURCE_REVIEW_REQUIRED'):
            with worker.begin() as conn:verify_worker_authority(conn,value,bad)
    with pytest.raises(Exception) as denied:
        with worker.begin() as conn:conn.execute(text('SELECT * FROM revenue_by_source LIMIT 1'))
    assert denied.value.orig.pgcode=='42501'
    no_generation(factory)


@pytest.mark.parametrize('changed',[False,True],ids=['unchanged-reacquisition','new-meaning'])
def test_source_only_new_job_requalifies_without_cursor_or_draft_and_does_not_revive_old_witness(restricted,tmp_path,monkeypatch,changed):
    factory,owner,worker,role=restricted;source_only(monkeypatch)
    first,record=ingest_revenue(factory,tmp_path,monkeypatch)
    before=current(factory,first,record);old_witness=capture(factory,before)
    with worker.begin()as conn:assert verify_worker_authority(conn,before,old_witness)is None
    second,same_record=ingest_revenue(factory,tmp_path,monkeypatch,paye='561'if changed else'560',extra=b'<!-- owned reacquisition -->')
    assert second>first and same_record==record
    after=current(factory,second,record)
    assert after['ingestion_id']==str(second)
    assert Decimal(after['facts'][0]['value'])==Decimal(561 if changed else 560)
    with pytest.raises(SourceObservationUnavailable):current(factory,first,record)
    with pytest.raises(SocialError,match='SOURCE_REVIEW_REQUIRED'):
        with worker.begin()as conn:verify_worker_authority(conn,before,old_witness)
    fresh=capture(factory,after)
    with worker.begin()as conn:assert verify_worker_authority(conn,after,fresh)is None
    no_generation(factory)


@pytest.mark.parametrize('broken',['business-value','source-binding','receipt','country','partial-job','fixture-job'])
def test_true_source_admission_never_preserves_current_reader_or_worker_authority_after_input_change(restricted,tmp_path,monkeypatch,broken):
    factory,owner,worker,role=restricted;source_only(monkeypatch)
    job,record=ingest_revenue(factory,tmp_path,monkeypatch);value=current(factory,job,record);witness=capture(factory,value)
    with factory.begin()as db:
        row=db.get(RevenueBySource,record)
        if broken=='business-value':row.amount_billion_kes+=1
        elif broken=='source-binding':db.get(SourceDocument,row.source_document_id).meta={}
        elif broken=='receipt':db.get(Extraction,row.meta['source_evidence'][0]['receipt']['extraction_id']).extracted_json={}
        elif broken=='country':db.scalar(select(Country).where(Country.iso_code=='KEN')).iso_code='UGA'
        elif broken=='partial-job':db.get(IngestionJob,job).status=IngestionStatus.COMPLETED_WITH_ERRORS
        else:
            j=db.get(IngestionJob,job);j.meta={**j.meta,'source_mode':'fixture'}
    with pytest.raises(SourceObservationUnavailable):current(factory,job,record)
    with pytest.raises(SocialError,match='SOURCE_REVIEW_REQUIRED'):
        with worker.begin()as conn:verify_worker_authority(conn,value,witness)
    no_generation(factory)


def test_qualified_source_does_not_open_generation_factory_when_generation_is_off(pg,tmp_path,monkeypatch):
    factory,_=pg;source_only(monkeypatch);job,record=ingest_revenue(factory,tmp_path,monkeypatch)
    assert current(factory,job,record)['financial']['record_id']==record
    monkeypatch.setenv('SOCIAL_GENERATION_HOOK_ENABLED','true')
    called=[]
    def forbidden_factory():
        called.append(True);raise AssertionError('Source admission attempted to open generation database session')
    result=dispatch_committed_generation(forbidden_factory,domain='revenue_by_source',ingestion_id=job,dry_run=False)
    assert result['state']=='disabled'and result['reason']=='financial_environment_disabled'
    assert result['drafts_created']==result['processed']==0 and called==[]
    no_generation(factory)
