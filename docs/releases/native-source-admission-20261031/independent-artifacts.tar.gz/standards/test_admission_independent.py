"""Independent source-vs-generation boundaries; isolated guarded PG only."""
import copy,json,os,re,subprocess,sys
from datetime import datetime,timedelta,timezone
from uuid import uuid4
from pathlib import Path
import pytest,yaml
from sqlalchemy import create_engine,select,func,text
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker
from models import Country,Entity,EntityType,RevenueBySource,SourceDocument,IngestionJob,IngestionStatus,DocumentStatus,Extraction
from seeding.native_financial_admission import source_admission_enabled,SOURCE_ADMISSION_FLAG
from seeding.native_financial_gate import qualify_native_financial_rows
from seeding.native_report_authority import KEY
from seeding.types import DomainRunContext
from seeding.source_observations import read_revenue_financial_observation,SourceObservationUnavailable
from seeding.generation_dispatch import dispatch_committed_generation
from social.models import SocialPost,SocialPublication,SocialPostTarget,SocialMediaAsset
from social.media.models import SocialMediaUpload
from social.generation.models import SourceCursor,SourceEvent
from test_native_financial_changes_postgres import ingest_revenue

@pytest.fixture
def owned():
 raw=os.environ['B83_SOCIAL_TEST_DB_URL'];url=make_url(raw)
 if url.host!='127.0.0.1' or url.port!=55412 or url.database!='b83_social_test' or url.username!=os.environ['OWNED_ADMISSION_ROLE'] or url.query:raise RuntimeError('Foreign fixture target refused')
 engine=create_engine(url.set(query={'hostaddr':'127.0.0.1'}),pool_size=4,max_overflow=0)
 with engine.begin() as db:
  identity=db.execute(text("SELECT current_database(),current_user,current_setting('data_directory'),inet_server_port()" )).one()
  if tuple(identity)!=('b83_social_test',os.environ['OWNED_ADMISSION_ROLE'],os.environ['OWNED_ADMISSION_DATA_DIRECTORY'],55412):raise RuntimeError('Foreign live fixture identity refused before mutation')
  if db.scalar(text('SELECT version_num FROM alembic_version'))!='a756b20a0001':raise RuntimeError('Wrong fixture schema')
  tables=db.scalars(text("SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename LIKE 'social_%'" )).all()
  db.execute(text('TRUNCATE '+','.join('"'+t+'"' for t in tables)+' CASCADE'));db.execute(text('TRUNCATE etl_dispatch_worker,etl_dispatch_commands,etl_dispatch_domains,seeding_domain_claims,ingestion_jobs,countries RESTART IDENTITY CASCADE'))
 factory=sessionmaker(bind=engine,expire_on_commit=False)
 with factory.begin() as db:
  country=Country(iso_code='KEN',name='Kenya',currency='KES',timezone='Africa/Nairobi',default_locale='en');db.add(country);db.flush()
  for name,slug in [('Nairobi City County','nairobi'),('Mombasa County','mombasa'),('Kisumu County','kisumu')]:db.add(Entity(country_id=country.id,type=EntityType.COUNTY,canonical_name=name,slug=slug))
 try:yield factory
 finally:engine.dispose()

def no_effects(factory):
 with factory() as db:
  for model in [SocialPost,SocialPublication,SocialPostTarget,SocialMediaAsset,SocialMediaUpload,SourceCursor,SourceEvent]:assert db.scalar(select(func.count()).select_from(model))==0

def source_only(monkeypatch):
 monkeypatch.setenv(SOURCE_ADMISSION_FLAG,'true');monkeypatch.setenv('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','false');monkeypatch.setenv('SOCIAL_GENERATION_HOOK_ENABLED','false');monkeypatch.setenv('SOCIAL_REPORT_GENERATION_ENABLED','false')

@pytest.mark.parametrize('raw',[None,'false','true','TRUE',' true ','1',''])
def test_actual_workflow_binding_and_process_admission_are_independent(monkeypatch,raw):
 workflow=yaml.safe_load(Path('/case/.github/workflows/seed.yml').read_text());job=workflow['jobs']['seed'];steps=[s for s in job['steps'] if s.get('name')=='Seed planned domains'];assert len(steps)==1
 merged={**workflow.get('env',{}),**job.get('env',{}),**steps[0].get('env',{})}
 variables={'SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED':'true'}
 if raw is not None:variables[SOURCE_ADMISSION_FLAG]=raw
 for flag in [SOURCE_ADMISSION_FLAG,'SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED']:
  expression=merged[flag];match=re.fullmatch(r"\$\{\{ vars\.([A-Z_]+) \|\| '([^']*)' \}\}",expression);assert match is not None
  monkeypatch.setenv(flag,variables.get(match[1]) or match[2])
 assert source_admission_enabled() is (raw=='true');assert os.environ['SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED']=='true'

@pytest.mark.parametrize('raw',[None,'false','true','TRUE','1',''])
def test_ordinary_admin_qualification_cannot_ignore_source_admission(monkeypatch,raw):
 import admin_etl_qualification as q
 now=datetime.now(timezone.utc);policy={'version':1,'generation':str(uuid4()),'issued_at':now.isoformat().replace('+00:00','Z'),'expires_at':(now+timedelta(hours=1)).isoformat().replace('+00:00','Z')};monkeypatch.setenv(q.POLICY_ENV,json.dumps(policy))
 for k in q.DISABLED_FLAGS:monkeypatch.setenv(k,'false')
 for k,v in {'ADMIN_ETL_DISPATCH_SOURCES':'opendata','SEED_OPENDATA_INGESTION_ENABLED':'true','AUTO_SEEDER_ENABLED':'false','SOCIAL_GENERATION_HOOK_ENABLED':'false','SEED_KNBS_RELEASE_DISCOVERY_ENABLED':'false'}.items():monkeypatch.setenv(k,v)
 if raw is None:monkeypatch.delenv(SOURCE_ADMISSION_FLAG,raising=False)
 else:monkeypatch.setenv(SOURCE_ADMISSION_FLAG,raw)
 if raw in (None,'false'):assert q.qualification(now).generation.hex==policy['generation'].replace('-','')
 else:
  with pytest.raises(q.QualificationRefused):q.qualification(now)

@pytest.mark.parametrize('source,generation,expected',[(None,'true',False),('true','false',True),('TRUE','true',False)])
def test_fresh_process_defaults_do_not_borrow_generation_flag(source,generation,expected):
 env=dict(os.environ,SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED=generation)
 if source is None:env.pop(SOURCE_ADMISSION_FLAG,None)
 else:env[SOURCE_ADMISSION_FLAG]=source
 cmd=[sys.executable]+(['-O'] if sys.flags.optimize else [])+['-c','import json;from seeding.native_financial_admission import source_admission_enabled;from seeding.config import SeedingSettings;print(json.dumps(dict(admit=source_admission_enabled(),setting_fields=list(SeedingSettings.model_fields))))'];r=subprocess.run(cmd,env=env,capture_output=True,text=True,check=True);data=json.loads(r.stdout);assert data['admit'] is expected;assert SOURCE_ADMISSION_FLAG not in data['setting_fields']

def test_admission_is_prospective_then_sticky_for_an_already_verified_source(owned,tmp_path,monkeypatch):
 monkeypatch.delenv(SOURCE_ADMISSION_FLAG,raising=False);monkeypatch.setenv('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','true');old,record=ingest_revenue(owned,tmp_path,monkeypatch)
 with owned() as db:assert db.get(RevenueBySource,record).publishable is False
 source_only(monkeypatch)
 with pytest.raises(SourceObservationUnavailable):read_revenue_financial_observation(owned,record_id=record,ingestion_id=old)
 fresh,same=ingest_revenue(owned,tmp_path,monkeypatch);assert same==record
 value=read_revenue_financial_observation(owned,record_id=record,ingestion_id=fresh);assert value['facts'][0]['value']=='560.00'
 monkeypatch.setenv(SOURCE_ADMISSION_FLAG,'false');assert read_revenue_financial_observation(owned,record_id=record,ingestion_id=fresh)['financial']==value['financial'];no_effects(owned)

@pytest.mark.parametrize('mutation',['operator_hold','foreign_publisher','foreign_url','unavailable','receipt_missing','changed_value','foreign_country'])
def test_source_flag_never_promotes_unqualified_or_quarantined_rows(owned,tmp_path,monkeypatch,mutation):
 source_only(monkeypatch);job,record=ingest_revenue(owned,tmp_path,monkeypatch)
 with owned.begin() as db:
  row=db.get(RevenueBySource,record);source=db.get(SourceDocument,row.source_document_id);row.publishable=False;row.quarantine_reason=None
  if mutation=='operator_hold':row.quarantine_reason='owned_operator_hold'
  elif mutation=='foreign_publisher':source.publisher='National Treasury'
  elif mutation=='foreign_url':source.url='https://unrelated.example.invalid/source'
  elif mutation=='unavailable':source.status=DocumentStatus.ARCHIVED
  elif mutation=='changed_value':row.amount_billion_kes+=1
  elif mutation=='receipt_missing':db.get(Extraction,row.meta['source_evidence'][0]['receipt']['extraction_id']).extracted_json={}
  elif mutation=='foreign_country':
   foreign=Country(iso_code='UGA',name='Uganda',currency='UGX',timezone='Africa/Kampala',default_locale='en');db.add(foreign);db.flush();source.country_id=foreign.id;metadata=copy.deepcopy(source.meta);metadata[KEY]['revenue_by_source']['country_id']=foreign.id;source.meta=metadata
  db.flush();qualify_native_financial_rows(db,[row],domain='revenue_by_source',context=DomainRunContext(None,False,job));assert row.publishable is False
  if mutation=='operator_hold':assert row.quarantine_reason=='owned_operator_hold'
 with pytest.raises(SourceObservationUnavailable):read_revenue_financial_observation(owned,record_id=record,ingestion_id=job)
 no_effects(owned)

@pytest.mark.parametrize('state',['running','partial','fixture','wrong_domain'])
def test_current_job_contract_stays_closed_after_source_only_qualification(owned,tmp_path,monkeypatch,state):
 source_only(monkeypatch);job,record=ingest_revenue(owned,tmp_path,monkeypatch);assert read_revenue_financial_observation(owned,record_id=record,ingestion_id=job)['facts']
 with owned.begin() as db:
  row=db.get(IngestionJob,job)
  if state=='running':row.status=IngestionStatus.RUNNING
  elif state=='partial':row.status=IngestionStatus.COMPLETED_WITH_ERRORS
  elif state=='fixture':row.meta={**row.meta,'source_mode':'fixture'}
  else:row.domain='national_budget'
 with pytest.raises(SourceObservationUnavailable):read_revenue_financial_observation(owned,record_id=record,ingestion_id=job)
 no_effects(owned)

@pytest.mark.parametrize('raw',['true','false'])
def test_source_flag_cannot_open_financial_dispatch_without_its_generation_gate(owned,tmp_path,monkeypatch,raw):
 monkeypatch.setenv(SOURCE_ADMISSION_FLAG,raw);monkeypatch.setenv('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','false');monkeypatch.setenv('SOCIAL_GENERATION_HOOK_ENABLED','true');monkeypatch.setenv('SOCIAL_REPORT_GENERATION_ENABLED','false');job,_=ingest_revenue(owned,tmp_path,monkeypatch);result=dispatch_committed_generation(owned,domain='revenue_by_source',ingestion_id=job,dry_run=False,include_reports=False);assert result['state']=='disabled' and result['reason']=='financial_environment_disabled';assert result['processed']==result['drafts_created']==0;no_effects(owned)
