from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET
from datetime import datetime,timezone
E=Path(__file__).resolve().parent; source=E.parent/'candidate'
sha=lambda b:hashlib.sha256(b).hexdigest()
write=lambda name,value:(E/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
before=json.loads((E/'SOURCE-BEFORE.json').read_text())
files={name:sha((source/name).read_bytes()) for name in before['files']}
if files!=before['files']:raise SystemExit('Candidate source changed')
manifest=E.parent/'candidate-source-sha256.json'
if sha(manifest.read_bytes())!=before['candidate_manifest_sha256']:raise SystemExit('Candidate manifest changed')
write('SOURCE-AFTER.json',dict(before,verified_at=datetime.now(timezone.utc).isoformat(),unchanged=True))
rows=[];runs=[]
for mode in ['normal','optimized']:
 stem='independent-'+mode; root=ET.parse(E/(stem+'.xml')).getroot(); cases=root.findall('.//testcase')
 execution=json.loads((E/(stem+'-execution.json')).read_text())
 if execution['exit']!=0 or len(cases)!=30:raise SystemExit('Incomplete execution')
 for c in cases:
  if any(c.find(k) is not None for k in ['failure','error','skipped']):raise SystemExit('Nonpassed case')
  rows.append(dict(mode=mode,id=c.attrib.get('classname','')+'::'+c.attrib['name'],outcome='passed',junit=stem+'.xml'))
 runs.append(dict(mode=mode,passed=len(cases),failed=0,errors=0,skipped=0,exit=execution['exit'],seconds=execution['seconds'],junit=stem+'.xml',junit_sha256=sha((E/(stem+'.xml')).read_bytes())))
write('CASE-LEDGER.json',dict(source_mapping_sha256=before['mapping_sha256'],unique_cases=30,executions=60,runs=runs,cases=rows))
# Read the throwaway secret only to prove it did not enter retained artifacts.
pg_env=E/'pg.env'; runtime_env=E/'runtime.env'
secret=[line.partition('=')[2] for line in pg_env.read_text().splitlines() if line.startswith('POSTGRES_PASSWORD=')]
if len(secret)!=1 or not secret[0]:raise SystemExit('Cannot identify owned credential')
leaks=[]
for p in E.rglob('*'):
 if p.is_file() and p not in [pg_env,runtime_env] and secret[0].encode() in p.read_bytes():leaks.append(str(p.relative_to(E)))
if leaks:raise SystemExit('Credential found in retained artifacts: '+str(leaks))
fixture=json.loads((E/'FIXTURE.json').read_text());name=fixture['name']
r=subprocess.run(['docker','inspect',name],text=True,capture_output=True,check=True);live=json.loads(r.stdout)[0]
if live['Id']!=fixture['id'] or live['Config']['Labels'].get('codex.owner')!='native-admission-standards-20261031':raise SystemExit('Owned container mismatch')
if live['HostConfig']['NetworkMode']!='none' or live['HostConfig']['PortBindings']:raise SystemExit('Unexpected fixture network')
r=subprocess.run(['docker','rm','-f','-v',name],text=True,capture_output=True,check=True)
pg_env.unlink();runtime_env.unlink()
remaining=subprocess.run(['docker','ps','-a','--filter','name=^/native-admission-standards-','--format','{{.Names}}'],text=True,capture_output=True,check=True).stdout.splitlines()
if remaining:raise SystemExit('Owned containers remain: '+str(remaining))
if pg_env.exists() or runtime_env.exists():raise SystemExit('Credential files remain')
write('CLEANUP.json',dict(at=datetime.now(timezone.utc).isoformat(),owned_fixture=name,owned_fixture_id=fixture['id'],removed=True,remaining_owned_containers=remaining,removed_credential_files=['pg.env','runtime.env'],credential_file_absence_verified=True,retained_artifact_secret_scan='no matches',shared_resources_touched=False,command=['docker','rm','-f','-v',name]))
print(json.dumps(dict(source_files=len(files),mapping_sha256=before['mapping_sha256'],runs=runs,cleanup='complete')))
