from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
E=Path(__file__).resolve().parent
p=json.loads((E/'ARTIFACTS.json').read_text())
for n,h in p['files'].items():
 if hashlib.sha256((E/n).read_bytes()).hexdigest()!=h:raise SystemExit('Artifact mismatch: '+n)
ledger=json.loads((E/'CASE-LEDGER.json').read_text())
for run in ledger['runs']:
 cases=ET.parse(E/run['junit']).getroot().findall('.//testcase')
 if len(cases)!=30 or any(c.find(k) is not None for c in cases for k in ['failure','error','skipped']):raise SystemExit('Invalid JUnit')
if len(ledger['cases'])!=60:raise SystemExit('Invalid ledger')
print('PASS: '+str(len(p['files']))+' artifact hashes; 30 normal + 30 optimized passed, zero skips/errors/failures')
