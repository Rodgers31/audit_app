"""Offline stdlib artifact integrity only; this does not rerun application tests."""
import hashlib,json,pathlib,xml.etree.ElementTree as ET
E=pathlib.Path(__file__).resolve().parent
manifest=json.loads((E/'ARTIFACTS.json').read_text())
for relative,pin in manifest.items():
 p=E/relative
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=pin:raise SystemExit('Artifact missing/changed: '+relative)
ledger=json.loads((E/'CASE-LEDGER.json').read_text())
for row in ledger['cases']:
 if 'junit' not in row:continue
 cases=ET.parse(E/row['junit']).findall('.//testcase');matches=[c for c in cases if c.attrib.get('classname','')+'::'+c.attrib['name']==row['id']]
 if len(matches)!=1 or any(matches[0].find(n) is not None for n in ('failure','error','skipped')):raise SystemExit('JUnit evidence mismatch: '+row['id'])
a=json.loads((E/'SOURCE-SEALED-BEFORE.json').read_text());b=json.loads((E/'SOURCE-SEALED-AFTER.json').read_text())
if a['files']!=b['files'] or a['mapping_sha256']!=b['mapping_sha256']:raise SystemExit('Source before/after mismatch')
if hashlib.sha256(json.dumps(a['files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()!=a['mapping_sha256']:raise SystemExit('Source mapping checksum mismatch')
print('PASS: '+str(len(manifest))+' artifacts; '+str(len(ledger['cases']))+' final case records; source before/after identity. Integrity verification only.')
