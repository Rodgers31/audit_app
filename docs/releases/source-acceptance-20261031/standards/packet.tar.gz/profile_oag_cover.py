"""Actual retained OAG capture with one genuine body loaded, not both volumes."""
import argparse,hashlib,json,pathlib,resource,time
import httpx,pdfplumber
from seeding.native_report_authority import capture_pdf_report
from services.receipt_store import LocalReceiptStore
from services.response_receipts import capture_response
p=argparse.ArgumentParser();p.add_argument('kind',choices=['executives','assemblies']);a=p.parse_args();E=pathlib.Path('/evidence');P=pathlib.Path('/inputs');started=time.monotonic();log=(E/('cover-'+a.kind+'-progress.jsonl')).open('w')
def sample(stage,**kw):
 x={'stage':stage,'seconds':time.monotonic()-started,'rss_peak_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,**kw}
 for n in ['memory.current','memory.peak','memory.swap.current','memory.swap.peak']:
  f=pathlib.Path('/sys/fs/cgroup')/n
  if f.exists():x[n]=int(f.read_text())
 log.write(json.dumps(x)+'\n');log.flush();return x
meta=json.loads((P/f'oag-{a.kind}-2023-24.json').read_text());path=P/f'oag-{a.kind}-2023-24.pdf';body=path.read_bytes();assert len(body)==meta['bytes'] and hashlib.sha256(body).hexdigest()==meta['sha256'];sample('one_body_loaded',body_bytes=len(body))
store=LocalReceiptStore(E/('cover-'+a.kind+'-receipts'));response=httpx.Response(200,content=body,headers={'content-type':'application/pdf'},request=httpx.Request('GET',meta['url']));receipt=capture_response(response,store,source_kind='pdf');sample('acquisition_captured')
original=pdfplumber.page.Page.extract_text
def observed(self,*args,**kwargs):
 sample('before_extract',page=self.page_number)
 text=original(self,*args,**kwargs);sample('after_extract',page=self.page_number,characters=len(text or ''));return text
pdfplumber.page.Page.extract_text=observed
feedmeta=json.loads((P/'oag-feed-2023-24.json').read_text());feed=(P/'oag-feed-2023-24.xml').read_bytes();assert hashlib.sha256(feed).hexdigest()==feedmeta['sha256']
def loader(period):
 assert period=='FY 2023/24';return capture_response(httpx.Response(200,content=feed,headers={'content-type':'application/rss+xml'},request=httpx.Request('GET',feedmeta['url'])),store,source_kind='rss')
authority,reason=capture_pdf_report(path,receipt,domain='audits',catalogue_loader=loader);out=sample('capture_returned',accepted=authority is not None,reason=reason)
if authority is not None:
 assert authority.value['published_on'] is None and authority.value['evidence_kind']=='publisher_catalogue';out['report']=authority.value
(E/('cover-'+a.kind+'-profile.json')).write_text(json.dumps(out,indent=2)+'\n');log.close();print(json.dumps({k:v for k,v in out.items() if k!='report'},indent=2))
if authority is None:raise SystemExit(1)
