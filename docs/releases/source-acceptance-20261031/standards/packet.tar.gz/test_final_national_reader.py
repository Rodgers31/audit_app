"""Final-source read-only check of rows from the actual genuine producer run.
Must run before light controls reset this exclusively owned fixture.
"""
import os,json,sys
from pathlib import Path
from sqlalchemy import create_engine,select,text
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker
from models import BudgetLine,IngestionJob,IngestionStatus
from seeding.native_financial_observations import read_native_financial_observation
from test_source_acceptance_baseline import no_generation

def test_final_source_reader_rechecks_all_twenty_genuine_national_cells():
    url=make_url(os.environ['DATABASE_URL']);assert url.host=='127.0.0.1' and url.port==55412 and url.username=='standards_native802' and url.database=='b83_social_test' and not url.query
    engine=create_engine(url.set(query={'hostaddr':'127.0.0.1'}),pool_size=1,max_overflow=0);factory=sessionmaker(bind=engine,expire_on_commit=False)
    try:
        with factory() as db:
            assert db.execute(text('select current_database(),current_user,inet_server_port()')).one()==('b83_social_test','standards_native802',55412)
            job=db.scalar(select(IngestionJob).where(IngestionJob.domain=='national_budget').order_by(IngestionJob.id.desc()))
            assert job is not None and job.status==IngestionStatus.COMPLETED and job.meta['source_mode']=='live'
            ids=list(db.scalars(select(BudgetLine.id)));assert len(ids)==10;job_id=job.id
        facts=[]
        for record in ids:
            value=read_native_financial_observation(factory,record_id=record,ingestion_id=job_id,domain='national_budget')
            assert len(value['facts'])==2
            for fact in value['facts']:
                assert fact['published_on']=='2026-09-04' and fact['document_checksum']=='f99ec2997f13400d2fc1fb340154c9b91640591c6d1351415fc075b259a7c4b1'
                facts.append(fact)
        assert len(facts)==20;no_generation(factory)
        label='final-national-reader-optimized' if sys.flags.optimize else 'final-national-reader-normal';Path('/evidence',label+'.json').write_text(json.dumps({'facts_rechecked':len(facts),'records':len(ids),'generation_called':False,'all_operational_flags_false':True},indent=2)+'\n')
    finally:engine.dispose()
