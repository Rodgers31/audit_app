"""Actual fixed source producer at512MiB, own committed PG, no generation."""
import copy,hashlib,json,os,resource,sys,time
from datetime import datetime,timezone
from pathlib import Path
import httpx,pdfplumber
from sqlalchemy import select
from models import IngestionJob,IngestionStatus,BudgetLine
from seeding.config import SeedingSettings
from seeding.http_client import SeedingHttpClient
from seeding.types import DomainRunContext
from seeding.domains.national_budget import fetcher,parser,writer
from seeding.native_financial_gate import qualify_native_financial_rows
from seeding.native_financial_observations import read_native_financial_observation
from services.figure_qualification import qualify_rows
from services.receipt_store import LocalReceiptStore
from test_source_acceptance_baseline import factory,no_generation

PAGE='https://cob.go.ke/download/national-government-budget-implementation-review-report-fy-2025-2026/'
URL=PAGE+'?wpdmdl=16454'

def test_actual_genuine_national_source_fresh_cells_committed_reader_and_default_hold(factory,tmp_path,monkeypatch):
    primary=Path('/primary');pdf=(primary/'national-annual.pdf').read_bytes();post=(primary/'national-publisher.html').read_bytes()
    assert len(pdf)==15609728 and hashlib.sha256(pdf).hexdigest()=='f99ec2997f13400d2fc1fb340154c9b91640591c6d1351415fc075b259a7c4b1'
    assert hashlib.sha256(post).hexdigest()=='6f5d2afc27cbd98250453490e7e2ced6d7d17e663e4bf28d4d166538aafb2e9d'
    hashes={};original=pdfplumber.page.Page.extract_text
    def measured(self,*a,**k):
        value=original(self,*a,**k);hashes.setdefault(self.page_number,hashlib.sha256((value or '').encode()).hexdigest());return value
    monkeypatch.setattr(pdfplumber.page.Page,'extract_text',measured)
    def transport(req):
        if str(req.url)==URL:return httpx.Response(200,content=pdf,headers={'content-type':'application/pdf'})
        if str(req.url)==PAGE:return httpx.Response(200,content=post,headers={'content-type':'text/html'})
        raise AssertionError('Unexpected local source URL: '+str(req.url))
    settings=SeedingSettings(_env_file=None,cache_path=tmp_path/'cache',http_cache_enabled=False,rate_limit='1000/sec');settings.cache_path.mkdir()
    started=time.monotonic()
    with factory.begin() as db:
        job=IngestionJob(domain='national_budget',status=IngestionStatus.RUNNING,dry_run=False,started_at=datetime.now(timezone.utc),errors=[],meta={'source_mode':'live'});db.add(job);db.flush();job_id=job.id;context=DomainRunContext(None,False,job_id)
        with SeedingHttpClient(settings,client=httpx.Client(transport=httpx.MockTransport(transport)),receipt_store=LocalReceiptStore(tmp_path/'receipts')) as client:
            data,status=fetcher._fetch_annual_sector_expenditure(client,settings,fetcher.AnnualReport(URL,'FY 2025/26',2025),session=db,context=context)
        producer_seconds=time.monotonic()-started
        assert len(data)==10 and status.startswith('promoted'),(len(data),status)
        stats=writer.persist_national_budget_records(db,parser.parse_national_budget_payload(data),settings,context);assert not stats.errors,stats.errors
        rows=list(db.scalars(select(BudgetLine)));assert len(rows)==10
        q=qualify_rows(db,'budget_lines',rows)
        assert all(q[r.id][m]['status']=='verified' for r in rows for m in ('allocated_amount','actual_spent'))
        assert all(r.publishable is False for r in rows),'Ordinary OFF numeric admission changed'
        # Explicit lower-level fixture-only eligibility, not operational gen.
        # Hook/publishing/uploads/workers remain false throughout.
        with monkeypatch.context() as local:
            local.setenv('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','true')
            qualify_native_financial_rows(db,rows,domain='national_budget',context=context)
        assert all(r.publishable is True for r in rows)
        ids=[r.id for r in rows];job.status=IngestionStatus.COMPLETED;job.finished_at=datetime.now(timezone.utc)
    facts=[]
    for record in ids:
        value=read_native_financial_observation(factory,record_id=record,ingestion_id=job_id,domain='national_budget')
        assert len(value['facts'])==2
        for fact in value['facts']:
            assert fact['published_on']=='2026-09-04' and fact['document_url']==URL and fact['document_checksum']==hashlib.sha256(pdf).hexdigest()
            facts.append(fact)
    reference=json.loads(Path('/work/backend/tests/fixtures/cob/ngbirr_fy2025_26_annual_pages.json').read_text())
    assert len(hashes)==426 and all(hashlib.sha256(t.encode()).hexdigest()==hashes[int(k)] for k,t in reference['pages'].items())
    prototype=json.loads(Path('/evidence/prototype-national-profile.json').read_text())
    values=[{'category':r['category'],'allocated_amount':str(r['allocated_amount']),'actual_spent':str(r['actual_spent'])} for r in data]
    assert values==prototype['cells']
    no_generation(factory)
    result={'scope':'Genuine retained PDF/post contents; owned local source acquisition/job/PG; no generation',
        'source_sha256':hashlib.sha256(pdf).hexdigest(),'actual_product_function':True,'page_count':len(hashes),'reference_pages_matching':len(reference['pages']),
        'verified_financial_cells':len(facts),'producer_seconds':producer_seconds,'whole_case_seconds':time.monotonic()-started,'rss_peak_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'cgroup_memory_peak_bytes':int(Path('/sys/fs/cgroup/memory.peak').read_text()),'ordinary_off_rows_initially_held':10,'fixture_only_lower_eligibility':True,'dispatch_called':False,
        'all_operational_flags_false_at_exit':True,'cells':values}
    label='actual-national-optimized' if sys.flags.optimize else 'actual-national-normal';Path('/evidence',label+'.json').write_text(json.dumps(result,indent=2)+'\n')
