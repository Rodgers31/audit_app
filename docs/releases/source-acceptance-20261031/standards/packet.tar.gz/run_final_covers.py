import argparse,json,pathlib,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--optimized',action='store_true');a=p.parse_args();e=pathlib.Path(__file__).resolve().parent
for stem in ['oag-executives-2022-23','oag-assemblies-2022-23','oag-executives-2023-24','oag-assemblies-2023-24','oag-executives-2024-25','oag-assemblies-2024-25','national']:
 label='final-cover-'+stem+('-optimized' if a.optimized else '-normal');name='native802-standards-'+label
 cmd=['docker','run','--pull','never','--name',name,'--network','none','--cpus','1','--memory','512m','--pids-limit','256','-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONPATH=/work/backend','-e','DATABASE_URL=sqlite:////tmp/inert.sqlite']
 for k in ['SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','SOCIAL_GENERATION_HOOK_ENABLED','SOCIAL_PUBLISHING_ENABLED','SOCIAL_UPLOADS_ENABLED','SOCIAL_MEDIA_ENABLED','SOCIAL_WORKER_ENABLED','SOCIAL_WORKER_SUPERVISOR_ENABLED','AUTO_SEEDER_ENABLED']:cmd+=['-e',k+'=false']
 cmd+=['-v',str(e/'candidate-final')+':/work:ro','-v',str(e)+':/evidence','-v',str(e.parent)+':/inputs:ro','-v',str(e.parent.parent/'native-source-acceptance-20261030')+':/primary:ro','-w','/work/backend','admin-redesign-python-runtime:local','python']
 if a.optimized:cmd+=['-O']
 cmd+=['/evidence/profile_final_cover.py',stem]
 if a.optimized:cmd+=['--optimized']
 (e/(label+'-command.json')).write_text(json.dumps(cmd,indent=2)+'\n');start=time.monotonic()
 with (e/(label+'.stdout')).open('wb') as out,(e/(label+'.stderr')).open('wb') as err:r=subprocess.run(cmd,stdout=out,stderr=err)
 x=json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0];receipt={'exit':r.returncode,'seconds':time.monotonic()-start,'state':{k:x['State'][k] for k in ['Status','ExitCode','OOMKilled','StartedAt','FinishedAt']},'caps':{k:x['HostConfig'][k] for k in ['Memory','MemorySwap','NanoCpus','PidsLimit','NetworkMode']}};(e/(label+'-execution.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(stem,json.dumps(receipt),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
