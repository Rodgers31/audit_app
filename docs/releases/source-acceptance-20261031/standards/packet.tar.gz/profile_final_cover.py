"""Actual final helper+capture, genuine retained inputs, no live I/O."""
import argparse, hashlib, json, pathlib, resource, time
import httpx
from seeding import native_report_cover
from seeding.native_report_authority import capture_pdf_report
from services.receipt_store import LocalReceiptStore
from services.response_receipts import capture_response
p = argparse.ArgumentParser()
p.add_argument('stem')
p.add_argument('--optimized', action='store_true')
a = p.parse_args()
E = pathlib.Path('/evidence')
P = pathlib.Path('/inputs')
OLD = pathlib.Path('/primary')
label = 'final-cover-' + a.stem + ('-optimized' if a.optimized else '-normal')
start = time.monotonic()
log = (E / (label + '-progress.jsonl')).open('w')

def sample(stage, **kw):
    x = {'stage': stage, 'seconds': time.monotonic() - start, 'rss_peak_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, **kw}
    for n in ['memory.current', 'memory.peak', 'memory.swap.current', 'memory.swap.peak']:
        f = pathlib.Path('/sys/fs/cgroup') / n
        if f.exists():
            x[n] = int(f.read_text())
    log.write(json.dumps(x) + '\n')
    log.flush()
    return x
national = a.stem == 'national'
domain = 'national_budget' if national else 'audits'
store = LocalReceiptStore(E / (label + '-receipts'))
if national:
    path = OLD / 'national-annual.pdf'
    url = 'https://cob.go.ke/download/national-government-budget-implementation-review-report-fy-2025-2026/?wpdmdl=16454'
    expected = 'f99ec2997f13400d2fc1fb340154c9b91640591c6d1351415fc075b259a7c4b1'
else:
    path = P / (a.stem + '.pdf')
    meta = json.loads((P / (a.stem + '.json')).read_text())
    url = meta['url']
    expected = meta['sha256']
body = path.read_bytes()
if not hashlib.sha256(body).hexdigest() == expected:
    raise AssertionError()
sample('one_body_loaded', sha256=expected, body_bytes=len(body))
receipt = capture_response(httpx.Response(200, content=body, headers={'content-type': 'application/pdf'}, request=httpx.Request('GET', url)), store, source_kind='pdf')
sample('acquisition_captured')
original = native_report_cover.extract_cover_texts
observed = []

def capture_texts(data):
    texts = original(data)
    observed.extend(texts)
    sample('cover_text_returned', pages=len(texts))
    return texts
native_report_cover.extract_cover_texts = capture_texts
if national:
    puburl = url.split('?')[0]
    pub = (OLD / 'national-publisher.html').read_bytes()
    if not hashlib.sha256(pub).hexdigest() == '6f5d2afc27cbd98250453490e7e2ced6d7d17e663e4bf28d4d166538aafb2e9d':
        raise AssertionError()
    kwargs = {'publisher_receipt': capture_response(httpx.Response(200, content=pub, headers={'content-type': 'text/html'}, request=httpx.Request('GET', puburl)), store, source_kind='html')}
else:
    edition = a.stem[-7:]
    feedname = {'2022-23': 'oag-feed-2022-2023', '2023-24': 'oag-feed-2023-24', '2024-25': 'oag-feed-2024-25'}[edition]
    fm = json.loads((P / (feedname + '.json')).read_text())
    feed = (P / (feedname + '.xml')).read_bytes()
    if not hashlib.sha256(feed).hexdigest() == fm['sha256']:
        raise AssertionError()

    def loader(period):
        if not period == 'FY ' + edition.replace('-', '/'):
            raise AssertionError()
        return capture_response(httpx.Response(200, content=feed, headers={'content-type': 'application/rss+xml'}, request=httpx.Request('GET', fm['url'])), store, source_kind='rss')
    kwargs = {'catalogue_loader': loader}
(authority, reason) = capture_pdf_report(path, receipt, domain=domain, **kwargs)
if national:
    reference = json.loads((E / 'prototype-national-profile.json').read_text())['page_hashes']
    if not all((hashlib.sha256(t.encode()).hexdigest() == reference[str(n)] for (n, t) in observed)):
        raise AssertionError()
else:
    edition = a.stem[-7:]
    refname = 'oag-cover-texts.json' if edition == '2024-25' else 'oag-cover-texts-' + edition + '.json'
    reference = json.loads((P / refname).read_text())
    key = a.stem.split('-')[1] if edition == '2022-23' else a.stem
    raw = reference[key]
    texts = [v['text'] if isinstance(v, dict) else v for v in raw]
    if not [t for (_, t) in observed] == texts:
        raise AssertionError()
expected_accept = national or a.stem[-7:] != '2024-25'
if not (authority is not None) == expected_accept:
    raise AssertionError((a.stem, reason))
if authority is not None:
    if not authority.value['published_on'] == ('2026-09-04' if national else None):
        raise AssertionError()
    if not national:
        if not authority.value['evidence_kind'] == 'publisher_catalogue':
            raise AssertionError()
        if not authority.value['entity'].endswith('County ' + a.stem.split('-')[1].title()):
            raise AssertionError()
result = sample('capture_returned', accepted=authority is not None, reason=reason, source_sha256=expected, cover_parity=True, cover_hashes={str(n): hashlib.sha256(t.encode()).hexdigest() for (n, t) in observed}, authority=authority.value if authority else None)
(E / (label + '-profile.json')).write_text(json.dumps(result, indent=2) + '\n')
log.close()
print(json.dumps({k: v for (k, v) in result.items() if k != 'authority'}, indent=2))
