"""Genuine source resource experiment. Prototype is external, never product code."""
import argparse,hashlib,json,os,pathlib,resource,time
import pdfplumber
p=argparse.ArgumentParser();p.add_argument('--prototype',action='store_true');args=p.parse_args()
E=pathlib.Path('/evidence');PRIMARY=pathlib.Path('/primary');pdf=PRIMARY/'national-annual.pdf'
assert pdf.stat().st_size==15609728 and hashlib.sha256(pdf.read_bytes()).hexdigest()=='f99ec2997f13400d2fc1fb340154c9b91640591c6d1351415fc075b259a7c4b1'
mode='prototype' if args.prototype else 'baseline';log=(E/(mode+'-page-progress.jsonl')).open('w');started=time.monotonic();active=False;page_hashes={}
original=pdfplumber.page.Page.extract_text

def text(self,*a,**kw):
    value=original(self,*a,**kw)
    if active:
        state={'page':self.page_number,'sha256':hashlib.sha256((value or '').encode()).hexdigest(),'characters':len(value or ''),'rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'elapsed':time.monotonic()-started}
        for name in ['memory.current','memory.peak']:
            f=pathlib.Path('/sys/fs/cgroup')/name
            if f.exists():state[name]=int(f.read_text())
        log.write(json.dumps(state)+'\n');log.flush();page_hashes[self.page_number]=state['sha256']
    return value
pdfplumber.page.Page.extract_text=text
from seeding.domains.national_budget import fetcher

def close_pages(path):
    global active
    result=[];active=True
    try:
        with pdfplumber.open(path) as doc:
            for number,page in enumerate(doc.pages,1):
                try:result.append({'page':number,'text':page.extract_text() or ''})
                finally:page.close()
        return result
    finally:active=False

if args.prototype:
    import httpx
    from seeding.config import SeedingSettings
    from seeding.http_client import SeedingHttpClient
    from services.receipt_store import LocalReceiptStore
    from services.response_receipts import receipt_is_sealed
    fetcher._extract_page_texts=close_pages
    page_url='https://cob.go.ke/download/national-government-budget-implementation-review-report-fy-2025-2026/'
    pdf_url=page_url+'?wpdmdl=16454';post=(PRIMARY/'national-publisher.html').read_bytes();assert hashlib.sha256(post).hexdigest()=='6f5d2afc27cbd98250453490e7e2ced6d7d17e663e4bf28d4d166538aafb2e9d'
    def transport(req):
        if str(req.url)==pdf_url:return httpx.Response(200,content=pdf.read_bytes(),headers={'content-type':'application/pdf'})
        if str(req.url)==page_url:return httpx.Response(200,content=post,headers={'content-type':'text/html'})
        raise AssertionError('Unexpected local source request: '+str(req.url))
    settings=SeedingSettings(_env_file=None,cache_path=E/'prototype-cache',http_cache_enabled=False,rate_limit='1000/sec');settings.cache_path.mkdir(exist_ok=True)
    with SeedingHttpClient(settings,client=httpx.Client(transport=httpx.MockTransport(transport)),receipt_store=LocalReceiptStore(E/'prototype-receipts')) as client:
        rows,status=fetcher._fetch_annual_sector_expenditure(client,settings,fetcher.AnnualReport(pdf_url,'FY 2025/26',2025))
    assert len(rows)==10 and status.startswith('promoted'),(status,len(rows))
    values=[{'category':r['category'],'allocated_amount':str(r['allocated_amount']),'actual_spent':str(r['actual_spent'])} for r in rows]
    assert all(receipt_is_sealed(item['_response_receipt']) for r in rows for item in r['provenance_extra']['source_evidence'])
    assert all(r['provenance_extra']['_native_report_authority'].value['published_on']=='2026-09-04' for r in rows)
    out={'kind':'external page.close prototype through actual source producer','status':status,'cells':values,'all20_cells_have_sealed_current_acquisition':True}
else:
    active=True
    rows=fetcher._extract_page_texts(pdf);active=False
    out={'kind':'actual unchanged baseline _extract_page_texts','pages':len(rows)}
log.close();out.update(pages=len(page_hashes),page_hashes=page_hashes,seconds=time.monotonic()-started,peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,financial_flag=os.environ.get('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED'))
for name in ['memory.current','memory.peak']:
    f=pathlib.Path('/sys/fs/cgroup')/name
    if f.exists():out[name]=int(f.read_text())
(E/(mode+'-national-profile.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='page_hashes'},indent=2))
