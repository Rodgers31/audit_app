"""Independent current source contracts; no generation dispatch or publication.
Genuine bodies are retained; all clocks/jobs/transports/DBs are owned fixtures.
"""
import copy,gzip,hashlib,json,os
from contextlib import contextmanager
from datetime import datetime,timezone
from decimal import Decimal
from pathlib import Path
import httpx,pytest
from sqlalchemy import create_engine,select,func,text
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker
from models import Country,IngestionJob,IngestionStatus,RevenueBySource,SourceDocument
from seeding.config import SeedingSettings
from seeding.types import DomainRunContext
from seeding.domains.revenue_by_source import fetcher,parser,writer
from seeding.native_financial_gate import qualify_native_financial_rows
from seeding.native_financial_observations import read_native_financial_observation
from seeding.source_observations import SourceObservationUnavailable,read_native_report_record_ids,read_revenue_report_observation
from services.figure_qualification import qualify_rows
from services.receipt_store import LocalReceiptStore
from social.models import SocialPost,SocialPublication,SocialMediaAsset
from social.media.models import SocialMediaUpload
from social.generation.models import SourceCursor,SourceEvent

PRIMARY=Path('/primary');FIXTURES=Path('/work/backend/tests/fixtures/kra')
PRESS='https://www.kra.go.ke/news-center/press-release/2235-kra-grows-revenue-by-6-8-despite-tough-economic-environment-4'
DASH='https://www.kra.go.ke/annual-revenue-performance-fy-2025-2026'
CATALOGUE='https://www.kra.go.ke/component/search/?searchphrase=all&searchword=KRA+performance'


def genuine_article():
    body=(PRIMARY/'kra-annual-release.html').read_bytes()
    assert len(body)==119603 and hashlib.sha256(body).hexdigest()=='ad35dcb5175af4dd26a8707dede239a879c8af0c885f325d3b6cf1cdbc47dce3'
    return body
class Press:
    def __init__(self,tmp,body=None):self.receipt_store=LocalReceiptStore(tmp);self.body=genuine_article() if body is None else body
    def get(self,url,**kw):
        assert url==PRESS
        return httpx.Response(200,content=self.body,headers={'content-type':'text/html'},request=httpx.Request('GET',url))

@pytest.mark.parametrize('hint',[None,'FY 2025/26'])
def test_genuine_historical_article_scope_date_and_all_five_cells(tmp_path,hint):
    release=fetcher._read_release(Press(tmp_path/'bytes'),PRESS,hint)
    assert release.fiscal_year=='FY 2024/25'
    assert release.native_report_authority.value['published_on']=='2025-07-10'
    assert all(release.heads[h].raw_amount is not None for h in ('PAYE','VAT','Excise Duty','Corporation Tax','Customs & Import Duty'))
    assert Decimal(release.heads['PAYE'].raw_amount)==Decimal('560963000000')

@pytest.mark.parametrize('bad',['date_absent','quarter_scope','response_substitution'])
def test_modified_article_cannot_lend_missing_scope_or_date_authority(tmp_path,bad):
    body=genuine_article()
    if bad=='date_absent':
        assert b'10/07/2025' in body;body=body.replace(b'10/07/2025',b'July 2025')
        release=fetcher._read_release(Press(tmp_path/'bytes',body),PRESS,None)
        assert release is not None and release.native_report_authority is None
        assert release.heads['PAYE'].raw_amount is None
    elif bad=='quarter_scope':
        from bs4 import BeautifulSoup
        soup=BeautifulSoup(body,'html.parser')
        paragraph=next(p for p in soup.select('.blog-content p') if '560.963' in p.get_text(' ',strip=True))
        paragraph.append(' These collections cover Q1 only.')
        release=fetcher._read_release(Press(tmp_path/'bytes',str(soup).encode()),PRESS,None)
        assert release is not None and release.heads['PAYE'].raw_amount is None
    else:
        response=httpx.Response(200,content=body,headers={'content-type':'text/html'},request=httpx.Request('GET',PRESS+'?other=1'))
        assert fetcher._read_release(Press(tmp_path/'bytes'),PRESS,None,response=response) is None

@pytest.mark.parametrize('domain',['national_budget','revenue_by_source'])
def test_default_off_gate_and_dispatch_do_not_touch_rows_or_open_factory(monkeypatch,domain):
    monkeypatch.setenv('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','false')
    monkeypatch.setenv('SOCIAL_GENERATION_HOOK_ENABLED','false')
    class Explodes:
        def __getattr__(self,name):raise AssertionError('Unexpected gate/factory access: '+name)
        def __call__(self,*a,**k):raise AssertionError('Unexpected DB factory access')
    row=type('Row',(),dict(publishable=False,quarantine_reason='held'))()
    qualify_native_financial_rows(Explodes(),[row],domain=domain,context=DomainRunContext(None,False,1))
    assert row.publishable is False and row.quarantine_reason=='held'
    from seeding.generation_dispatch import dispatch_committed_generation,dispatch_committed_report_generation
    assert dispatch_committed_generation(Explodes(),domain=domain,ingestion_id=1,dry_run=False) is None
    assert dispatch_committed_report_generation(Explodes(),domain=domain,ingestion_id=1,dry_run=False) is None

@pytest.fixture(scope='module')
def factory():
    url=make_url(os.environ['DATABASE_URL'])
    assert url.drivername=='postgresql+psycopg2' and url.host=='127.0.0.1' and url.port==55412
    assert url.username=='standards_native802' and url.database=='b83_social_test' and not url.query
    engine=create_engine(url.set(query={'hostaddr':'127.0.0.1'}),pool_size=1,max_overflow=0)
    with engine.connect() as db:
        identity=db.execute(text("select current_database(),current_user,inet_server_port(),current_setting('data_directory')")).one()
        assert identity==('b83_social_test','standards_native802',55412,'/var/lib/postgresql/data')
    # This namespace is exclusively owned and identity-guarded above.
    # Reset only its source fixture between independent pytest processes.
    with engine.begin() as db:db.execute(text('TRUNCATE revenue_by_source, extractions, source_documents, ingestion_jobs RESTART IDENTITY CASCADE'))
    make=sessionmaker(bind=engine,expire_on_commit=False)
    with make.begin() as db:
        if db.scalar(select(Country.id).where(Country.iso_code=='KEN')) is None:db.add(Country(iso_code='KEN',name='Kenya',currency='KES',timezone='Africa/Nairobi',default_locale='en'))
    yield make
    engine.dispose()


def no_generation(factory):
    with factory() as db:
        for model in (SourceCursor,SourceEvent,SocialPost,SocialPublication,SocialMediaAsset,SocialMediaUpload):
            assert db.scalar(select(func.count()).select_from(model))==0,model.__name__
    for key in ('SOCIAL_GENERATION_HOOK_ENABLED','SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','SOCIAL_PUBLISHING_ENABLED','SOCIAL_UPLOADS_ENABLED','SOCIAL_WORKER_ENABLED'):
        assert os.environ[key]=='false',key


def ingest_press(factory,tmp,monkeypatch,*,fixture_admission=False):
    settings=SeedingSettings(_env_file=None)
    with factory.begin() as db:
        job=IngestionJob(domain='revenue_by_source',status=IngestionStatus.RUNNING,dry_run=False,started_at=datetime.now(timezone.utc),errors=[],meta={'source_mode':'live'});db.add(job);db.flush();job_id=job.id
        release=fetcher._read_release(Press(tmp/'bytes'),PRESS,None)
        monkeypatch.setattr(fetcher,'discover_kra_releases',lambda *a:([release],release.fiscal_year,release.url))
        payload,status=fetcher._apply_kra_live([],Press(tmp/'bytes'),settings);assert status.startswith('promoted')
        stats=writer.persist_revenue_records(db,parser.parse_revenue_payload(payload),settings,DomainRunContext(None,False,job_id));assert not stats.errors,stats.errors
        rows=list(db.scalars(select(RevenueBySource).where(RevenueBySource.source_document_id.in_(select(SourceDocument.id).where(SourceDocument.url==PRESS)))))
        current=[r for r in rows if r.meta.get('ingestion_job_id')==job_id and r.meta.get('source_evidence')]
        q=qualify_rows(db,'revenue_by_source',current)
        assert len(current)==5 and all(q[r.id]['amount_billion_kes']['status']=='verified' for r in current)
        if fixture_admission:
            # Isolated lower-level eligibility experiment only. No dispatch,
            # worker, publication or operational process is started.
            with monkeypatch.context() as local:
                local.setenv('SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED','true')
                qualify_native_financial_rows(db,current,domain='revenue_by_source',context=DomainRunContext(None,False,job_id))
        record=next(r.id for r in current if r.revenue_type=='PAYE')
        job.status=IngestionStatus.COMPLETED;job.finished_at=datetime.now(timezone.utc)
    return job_id,record

def test_genuine_kra_ordinary_off_writer_leaves_numeric_admission_held(factory,tmp_path,monkeypatch):
    job,record=ingest_press(factory,tmp_path,monkeypatch)
    with factory() as db:assert db.get(RevenueBySource,record).publishable is False
    with pytest.raises(SourceObservationUnavailable,match='Publishable actual'):
        read_native_financial_observation(factory,record_id=record,ingestion_id=job,domain='revenue_by_source')
    no_generation(factory)

def test_genuine_kra_fixture_admission_exact_reader_and_current_job_boundaries(factory,tmp_path,monkeypatch):
    job,record=ingest_press(factory,tmp_path,monkeypatch,fixture_admission=True)
    observation=read_native_financial_observation(factory,record_id=record,ingestion_id=job,domain='revenue_by_source')
    fact=observation['facts'][0]
    assert fact['period']=='FY 2024/25' and fact['published_on']=='2025-07-10' and fact['document_url']==PRESS
    assert Decimal(fact['value'])==Decimal('561') and fact['scale']=='billions'
    with factory.begin() as db:
        now=datetime.now(timezone.utc);db.add(IngestionJob(domain='revenue_by_source',status=IngestionStatus.COMPLETED,dry_run=False,started_at=now,finished_at=now,errors=[],meta={'source_mode':'fixture'}))
    assert read_native_financial_observation(factory,record_id=record,ingestion_id=job,domain='revenue_by_source')['facts'][0]==fact
    with factory.begin() as db:
        now=datetime.now(timezone.utc);db.add(IngestionJob(domain='revenue_by_source',status=IngestionStatus.COMPLETED_WITH_ERRORS,dry_run=False,started_at=now,finished_at=now,errors=['controlled source gap'],meta={'source_mode':'partial'}))
    with pytest.raises(SourceObservationUnavailable,match='Current report authority'):
        read_native_financial_observation(factory,record_id=record,ingestion_id=job,domain='revenue_by_source')
    no_generation(factory)

class CurrentCatalogue:
    def __init__(self,tmp):
        self.receipt_store=LocalReceiptStore(tmp);self.receipts={}
        self.wrapper=gzip.decompress((FIXTURES/'fy2025_26_wrapper_2026-10-27.html.gz').read_bytes())
        self.catalogue=gzip.decompress((FIXTURES/'catalogue_2026-10-27.html.gz').read_bytes())
        assert hashlib.sha256(self.wrapper).hexdigest()=='ad995d6a60db6388011520a4f26c29e37c4cee057f2db7d6af7f1483b213395f'
        assert hashlib.sha256(self.catalogue).hexdigest()=='3d7c5eb4dfb10bfb3ede591eb547db1a6e19d883982b4eed766782cfb801176b'
    def get(self,url,**kw):
        if url==DASH:body=self.wrapper
        elif url=='https://krarevenue2526testingdashboard.bolt.host':body=(FIXTURES/'fy2025_26_dashboard_shell.html').read_bytes()
        elif url.startswith('https://krarevenue2526testingdashboard.bolt.host/assets/'):body=gzip.decompress((FIXTURES/'fy2025_26_dashboard_bundle.js.gz').read_bytes())
        else:return httpx.Response(404,request=httpx.Request('GET',url))
        return httpx.Response(200,content=body,headers={'content-type':'text/html'},request=httpx.Request('GET',url))
    def download_to_file(self,url,path,**kw):
        from services.response_receipts import capture_response
        assert url==CATALOGUE;path.write_bytes(self.catalogue)
        self.receipts[url]=capture_response(httpx.Response(200,content=self.catalogue,headers={'content-type':'text/html'},request=httpx.Request('GET',url)),self.receipt_store)
    def download_receipt(self,url):return self.receipts[url]

def test_current_retained_kra_catalogue_is_availability_not_financial_date(factory,tmp_path):
    client=CurrentCatalogue(tmp_path/'bytes');settings=SeedingSettings(_env_file=None,kra_revenue_url=DASH)
    with factory.begin() as db:
        job=IngestionJob(domain='revenue_by_source',status=IngestionStatus.RUNNING,dry_run=False,started_at=datetime.now(timezone.utc),errors=[],meta={'source_mode':'live'});db.add(job);db.flush();job_id=job.id
        payload,status=fetcher._apply_kra_live([],client,settings);assert status.startswith('promoted'),status
        stats=writer.persist_revenue_records(db,parser.parse_revenue_payload(payload),settings,DomainRunContext(None,False,job_id));assert not stats.errors,stats.errors
        row=db.scalar(select(RevenueBySource).where(RevenueBySource.fiscal_year=='FY 2025/26',RevenueBySource.revenue_type=='PAYE'));record=row.id
        q=qualify_rows(db,'revenue_by_source',[row])[record]['amount_billion_kes']
        assert q['status']=='qualified' and q['reason']=='embedded_publisher_chain_not_checked'
        # Hostile negative: even a wrongly opened row flag must not borrow a
        # catalogue date. This is not a positive financial authority claim.
        row.publishable=True;job.status=IngestionStatus.COMPLETED;job.finished_at=datetime.now(timezone.utc)
    ids=read_native_report_record_ids(factory,ingestion_id=job_id,domain='revenue_by_source');assert len(ids)==1
    report=read_revenue_report_observation(factory,record_id=ids[0],ingestion_id=job_id)['report']
    assert report['published_on'] is None and report['catalogued_on']=='2026-07-08' and report['evidence_kind']=='publisher_catalogue'
    with pytest.raises(SourceObservationUnavailable,match='Publisher publication date unavailable'):
        read_native_financial_observation(factory,record_id=record,ingestion_id=job_id,domain='revenue_by_source')
    no_generation(factory)
