import hashlib,json,pathlib
from seeding.domains.national_budget.fetcher import AnnualReport,build_expenditure_records
from seeding.domains.national_budget.sector_expenditure import parse_sector_expenditure
E=pathlib.Path('/evidence');p=pathlib.Path('/work/backend/tests/fixtures/cob/ngbirr_fy2025_26_annual_pages.json');reference=json.loads(p.read_text());actual=json.loads((E/'prototype-national-profile.json').read_text());pdf=pathlib.Path('/primary/national-annual.pdf')
assert hashlib.md5(pdf.read_bytes()).hexdigest()==reference['md5']
assert actual['pages']==reference['page_count']==426
for number,text in reference['pages'].items():assert hashlib.sha256(text.encode()).hexdigest()==actual['page_hashes'][number],number
parsed=parse_sector_expenditure({int(k):v for k,v in reference['pages'].items()});report=AnnualReport(reference['source_url'],'FY 2025/26',2025);rows=build_expenditure_records(parsed,report)
expected=[{'category':r['category'],'allocated_amount':str(r['allocated_amount']),'actual_spent':str(r['actual_spent'])} for r in rows]
assert len(expected)==10 and expected==actual['cells']
proof={'source_fixture_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'fixture_pdf_md5':reference['md5'],'fixture_page_count':reference['page_count'],'retained_reference_pages_compared':len(reference['pages']),'all_reference_page_text_hashes_match':True,'accepted_sectors_compared':len(expected),'financial_cells_compared':2*len(expected),'all20_financial_values_match':True,'baseline_prefix_pages_also_match':113}
(E/'REFERENCE-PARITY.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
