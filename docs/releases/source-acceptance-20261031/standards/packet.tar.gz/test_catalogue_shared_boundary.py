"""Shared dispatcher/typed consumer isolation, using retained KRA contents."""
import copy
from datetime import datetime,timezone
import httpx,pytest
from test_source_acceptance_baseline import CurrentCatalogue,DASH,CATALOGUE
from services.response_receipts import capture_response
from seeding.kra_report_catalogue import capture_catalogue_report
from seeding.native_report_authority import validate_catalogue
from social.generation.contracts import CataloguedNativeReportEvidence,NativeReportEvidence,SourceObservation

def catalogue(tmp_path):
    client=CurrentCatalogue(tmp_path/'bytes');w=capture_response(client.get(DASH),client.receipt_store);c=capture_response(httpx.Response(200,content=client.catalogue,headers={'content-type':'text/html'},request=httpx.Request('GET',CATALOGUE)),client.receipt_store)
    authority,reason=capture_catalogue_report(w,c,fiscal_year='FY 2025/26');assert authority is not None,reason
    v=authority.value;now=datetime.now(timezone.utc).isoformat()
    report=dict(native_domain='revenue_by_source',scope_key=v['scope_key'],entity_id=1,source_record_id=1,authority_fingerprint='a'*64,entity=v['entity'],period=v['period'],period_start=v['period_start'],period_end=v['period_end'],source_document_id=1,document_url=v['document_url'],document_checksum=v['document_checksum'],publisher='Kenya Revenue Authority',published_on=None,catalogued_on=v['catalogued_on'],catalogue_url=v['catalogue_url'],evidence_kind='publisher_catalogue',retrieved_at=now,verified_at=now,canonical_url='https://www.auditgava.com/budget',locator=v['locator'],publication_extraction_id=1,qualification_extraction_id=1)
    observation=dict(source_type='kra',source_key='kra:native:revenue_by_source:1:annual-revenue',evidence_version=1,ingestion_id='1',category='dataset_availability',title='KRA report availability',committed=True,fixture=False,quarantined=False,publishable=True,report=report)
    return authority,observation

def test_existing_kra_catalogue_dispatch_and_typed_availability_unchanged(tmp_path):
    authority,value=catalogue(tmp_path);validate_catalogue(authority.value,authority.receipt)
    assert SourceObservation.model_validate(value).report.published_on is None
    with pytest.raises(ValueError):NativeReportEvidence.model_validate(value['report'])

@pytest.mark.parametrize('domain',['national_budget','audits'])
def test_kra_catalogue_cannot_cross_dispatch_or_typed_native_domain(tmp_path,domain):
    authority,value=catalogue(tmp_path);changed=copy.deepcopy(authority.value);changed['domain']=domain
    with pytest.raises((ValueError,KeyError)):validate_catalogue(changed,authority.receipt)
    value['report']['native_domain']=domain
    with pytest.raises(ValueError):SourceObservation.model_validate(value)

@pytest.mark.parametrize('change',[{'published_on':'2026-07-08'},{'institution':'executives'}])
def test_oag_extension_cannot_turn_kra_catalogue_into_publication_authority(tmp_path,change):
    _,value=catalogue(tmp_path);value['report'].update(change)
    with pytest.raises(ValueError):SourceObservation.model_validate(value)
