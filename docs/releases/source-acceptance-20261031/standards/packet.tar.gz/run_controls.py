import argparse,json,pathlib,subprocess
p=argparse.ArgumentParser();p.add_argument('--optimized',action='store_true');a=p.parse_args();e=pathlib.Path(__file__).resolve().parent;label='controls-optimized' if a.optimized else 'controls-normal'
cmd=['docker','run','--pull','never','--rm','--name','native802-standards-'+label,'--network','container:native802-standards-pg-20261031','--cpus','1','--memory','1g','--pids-limit','256','--env-file',str(e/'runtime.env'),'-e','PYTHONPATH=/work/backend:/work/backend/tests:/work/backend/tests/social:/evidence','-v',str(e/'baseline')+':/work:ro','-v',str(e)+':/evidence','-v',str(e.parent.parent/'native-source-acceptance-20261030')+':/primary:ro','-w','/work/backend','admin-redesign-python-runtime:local','python']
if a.optimized:cmd+=['-O']
cmd+=['-m','pytest','-q','-p','no:cacheprovider','/evidence/test_source_acceptance_baseline.py','--junitxml=/evidence/'+label+'.xml'];(e/(label+'-command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
with (e/(label+'.txt')).open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(e/(label+'-exit.json')).write_text(json.dumps({'exit_code':r.returncode})+'\n');raise SystemExit(r.returncode)
