"""Independent cover-only engine parity, bounded traversal and fail-closed inputs."""
from io import BytesIO
import hashlib
import pytest
import pdfplumber
from seeding import native_report_cover as cover
from seeding.native_report_authority import capture_pdf_report
from test_oag_combined_catalogue import input_pair
from test_native_publisher_metadata import pdf_document

@pytest.mark.parametrize('body',[b'',b'not a PDF',b'%PDF-1.4\ntruncated'])
def test_missing_or_malformed_cover_never_returns_authoritative_text(body):
    with pytest.raises(Exception):cover.extract_cover_texts(body)

def test_final_text_only_engine_preserves_all_existing_text_order_and_page_numbers():
    body=pdf_document(['NATIONAL GOVERNMENT BUDGET IMPLEMENTATION REVIEW REPORT FY 2025/2026','Amount KES 12,345.67; A B C','Publication date: 4 September 2026','OUTSIDE COVER'])
    with pdfplumber.open(BytesIO(body)) as original:
        expected=[(i,p.extract_text() or '') for i,p in enumerate(original.pages[:3],1)]
    assert cover.extract_cover_texts(body)==expected

def test_capture_refuses_path_receipt_body_disagreement(tmp_path):
    path,source,feed=input_pair(tmp_path);path.write_bytes(path.read_bytes()+b'changed')
    result,reason=capture_pdf_report(path,source,domain='audits',publisher_receipt=feed)
    assert result is None and reason=='native_report_date_or_scope_unavailable'

def test_fourth_raw_page_is_never_requested_and_all_selected_pages_close(monkeypatch):
    calls=[];closed=[];holder=[]
    class Doc:
        rsrcmgr=None;laparams=None;doc=object()
        def __init__(self,stream):holder.append(stream)
        def flush_cache(self):calls.append('flush')
    def raw_pages(doc):
        for i in range(3):calls.append(i);yield object()
        raise AssertionError('Fourth physical page traversal')
    class Page:
        height=10
        def __init__(self,pdf,raw,page_number,initial_doctop):self.n=page_number
        def extract_text(self):return str(self.n)
        def close(self):closed.append(self.n)
    monkeypatch.setattr(cover,'PDF',Doc);monkeypatch.setattr(cover.PDFPage,'create_pages',raw_pages);monkeypatch.setattr(cover,'_CoverPage',Page)
    assert cover.extract_cover_texts(b'owned')==[(1,'1'),(2,'2'),(3,'3')]
    assert calls==[0,1,2,'flush'] and closed==[1,2,3] and holder[0].closed

@pytest.mark.parametrize('failure',['oversize','extract'])
def test_failure_closes_selected_page_pdf_cache_and_owned_stream(monkeypatch,failure):
    closed=[];holder=[];flushed=[]
    class Doc:
        rsrcmgr=None;laparams=None;doc=object()
        def __init__(self,stream):holder.append(stream)
        def flush_cache(self):flushed.append(True)
    class Page:
        height=10
        def __init__(self,*a,**kw):pass
        def extract_text(self):
            if failure=='extract':raise ValueError('Owned extraction failure')
            return 'x'*100001
        def close(self):closed.append(True)
    monkeypatch.setattr(cover,'PDF',Doc);monkeypatch.setattr(cover.PDFPage,'create_pages',lambda doc:iter([object()]));monkeypatch.setattr(cover,'_CoverPage',Page)
    with pytest.raises(ValueError):cover.extract_cover_texts(b'owned')
    assert closed==[True] and flushed==[True] and holder[0].closed
