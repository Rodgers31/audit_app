"""Independent lifecycle fakes and real-glyph parity for native cover extraction."""
from io import BytesIO
import zlib
import pytest
import pdfplumber
from pdfplumber.utils.exceptions import PdfminerException
from seeding import native_report_cover as cover


def owned_pdf(texts, mode='text'):
    image=zlib.compress(bytes([255,0,0,0,255,0,0,0,255,255,255,255]))
    form=b'BT /F1 9 Tf 0 10 Td (FORM LETTERS) Tj ET'
    objects=[b'<< /Type /Catalog /Pages 2 0 R >>',b'',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
        b'<< /Type /XObject /Subtype /Image /Width 2 /Height 2 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length '+str(len(image)).encode()+b' >>\nstream\n'+image+b'\nendstream',
        b'<< /Type /XObject /Subtype /Form /BBox [0 0 200 30] /Resources << /Font << /F1 3 0 R >> >> /Length '+str(len(form)).encode()+b' >>\nstream\n'+form+b'\nendstream']
    kids=[]
    for text in texts:
        page=len(objects)+1;content=page+1;kids.append(page)
        objects.append(f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 850] /Resources << /Font << /F1 3 0 R >> /XObject << /Im0 4 0 R /Fm0 5 0 R >> >> /Contents {content} 0 R >>'.encode())
        lines=[]
        if mode=='vector':lines.append('q 0.5 w 0 0 1 RG 10 700 400 20 re S 0.5 0.7 0.3 rg 20 600 m 200 650 l 250 620 l h f Q')
        if mode=='image':lines.append('q 20 0 0 20 10 700 cm /Im0 Do Q')
        if mode=='form':lines.append('q 1 0 0 1 30 730 cm /Fm0 Do Q')
        for index,line in enumerate(text.splitlines()):
            escaped=line.replace('\\','\\\\').replace('(','\\(').replace(')','\\)')
            lines.append(f'BT /F1 10 Tf 12 {800-index*18} Td ({escaped}) Tj ET')
        stream='\n'.join(lines).encode('cp1252')
        objects.append(b'<< /Length '+str(len(stream)).encode()+b' >>\nstream\n'+stream+b'\nendstream')
    objects[1]=('<< /Type /Pages /Kids ['+' '.join(f'{n} 0 R'for n in kids)+f'] /Count {len(kids)} >>').encode()
    body=bytearray(b'%PDF-1.4\n');offsets=[0]
    for number,obj in enumerate(objects,1):
        offsets.append(len(body));body.extend(f'{number} 0 obj\n'.encode()+obj+b'\nendobj\n')
    xref=len(body);body.extend(f'xref\n0 {len(offsets)}\n0000000000 65535 f \n'.encode())
    for offset in offsets[1:]:body.extend(f'{offset:010d} 00000 n \n'.encode())
    body.extend(f'trailer\n<< /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'.encode())
    return bytes(body)


def standard(body):
    with pdfplumber.open(BytesIO(body),pages=[1,2,3])as pdf:
        return [(page.page_number,page.extract_text()or'')for page in pdf.pages]


@pytest.mark.parametrize('mode',['text','vector','image','form'])
def test_owned_real_pdf_glyph_parity(mode):
    body=owned_pdf(['Exact county title & figures 1,234.5','Publisher\'s second page','Third page'],mode)
    before=standard(body)
    after=cover.extract_cover_texts(body)
    assert after==before and len(after)==3
    assert 'Exact county title' in after[0][1]
    if mode=='form':assert 'FORM LETTERS' in after[0][1]


def test_actual_iterator_never_advances_to_fourth_page(monkeypatch):
    body=owned_pdf(['First','Second','Third','FOURTH MUST NOT READ'])
    expected=standard(body);create=cover.PDFPage.create_pages;seen=[]
    def bounded(doc):
        for index,page in enumerate(create(doc),1):
            seen.append(index)
            if index>3:raise AssertionError('Raw fourth page advanced')
            yield page
    monkeypatch.setattr(cover.PDFPage,'create_pages',bounded)
    assert cover.extract_cover_texts(body)==expected
    assert seen==[1,2,3]


@pytest.mark.parametrize('case',['normal','early-eof','empty-eof','extract-error','text-bounds','text-boundary','raw-error','pdf-init-error'])
def test_page_and_stream_lifecycle_with_owned_fakes(monkeypatch,case):
    held=set();closed=[];streams=[];events=[];advances=[]
    class SpyStream(BytesIO):
        def __init__(self,data):super().__init__(data);streams.append(self)
        def close(self):events.append('stream-close');super().close()
    class PDF:
        def __init__(self,stream):
            self.stream=stream;self.doc=object()
            if case=='pdf-init-error':raise RuntimeError('Owned constructor failure')
        def flush_cache(self):
            assert not held and not self.stream.closed
            events.append('flush')
    class RawPages:
        def __init__(self):self.index=0
        def __iter__(self):return self
        def __next__(self):
            assert not held,'Prior selected page remains held'
            self.index+=1;advances.append(self.index)
            if self.index>3:raise AssertionError('Raw fourth advancement')
            if case=='empty-eof' or case=='early-eof' and self.index>2:raise StopIteration
            if case=='raw-error' and self.index==2:raise RuntimeError('Owned raw parser failure')
            return self.index
    class Page:
        height=10
        def __init__(self,pdf,raw,*,page_number,initial_doctop):
            assert not held;self.number=page_number;held.add(self.number)
        def extract_text(self):
            if case=='extract-error' and self.number==2:raise RuntimeError('Owned text parser failure')
            if case=='text-bounds' and self.number==2:return 'x'*100001
            if case=='text-boundary':return 'x'*100000
            return 'page'+str(self.number)
        def close(self):held.remove(self.number);closed.append(self.number);events.append('page-close')
    monkeypatch.setattr(cover,'BytesIO',SpyStream)
    monkeypatch.setattr(cover,'PDF',PDF)
    monkeypatch.setattr(cover,'_CoverPage',Page)
    monkeypatch.setattr(cover.PDFPage,'create_pages',lambda doc:RawPages())
    errors=case in('extract-error','text-bounds','raw-error','pdf-init-error')
    if errors:
        with pytest.raises((RuntimeError,ValueError,PdfminerException)):cover.extract_cover_texts(b'owned')
    else:
        result=cover.extract_cover_texts(b'owned')
        expected=0 if case=='empty-eof'else 2 if case=='early-eof'else 3
        assert len(result)==expected
    expected_closed=[]if case in('empty-eof','pdf-init-error')else[1]if case=='raw-error'else[1,2]if case in('extract-error','text-bounds','early-eof')else[1,2,3]
    assert closed==expected_closed and not held
    assert len(streams)==1 and streams[0].closed
    assert 'flush'in events if case!='pdf-init-error'else'flush'not in events
    assert events[-1]=='stream-close'
