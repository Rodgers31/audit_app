# #802 candidate3 — independent cover helper review

No finding in the bounded cover-helper review. New helper controls passed **13/13 normal and 13/13 true Python `-O`**. The unchanged stored-catalogue suite passed **48/48 normal and 48/48 true `-O`** on candidate3. All four child exits are integer zero with no failures/errors/skips. These are 61 distinct pytest cases and 122 executions; the genuine-document comparison below is separately recorded.

The 13 new cases comprise eight explicitly mocked lifecycle cases, four actual owned-PDF glyph comparisons, and one actual raw-page iterator trap. Lifecycle fakes verify selected-page close before the next raw page, stream close on normal/early/empty EOF, extraction failure, raw parser failure, PDF-constructor failure and text bounds; exactly 100,000 characters remain admitted,100,001 refuse. They test the real helper's control flow with fake PDF/page objects, not real glyph parsing under failure. The actual four-page trap never advances the fourth raw page. Actual pdfplumber parses the owned plain text, vector artwork, bitmap and text-bearing Form XObject PDFs; the new helper returns identical numbered text to standard pdfplumber for all four, including text inside the Form.

One genuine FY2023/24 executive volume (34,055,119 bytes, SHA256 `bf36d9e65b7403f9ce66eaf32890834f546ca3674c331a2d5f734f9e68c59bcd`) was independently parsed twice in capped offline containers. Standard pdfplumber under 1 GiB and the helper under 512 MiB both exited 0 and returned **exactly identical first-three numbered text strings**, lengths `[551, 241, 102]`. Individual page hashes and full results are retained in `GENUINE-PARITY.json` and the two process folders.

| Genuine executable path | RAM/swap cap | cgroup peak bytes | Process max RSS KiB | Measured read/extraction seconds |
| --- | --- | ---: | ---: | ---: |
| Standard pdfplumber selected 3 pages | 1 GiB / 1 GiB | 1073741824 | 1048976 | 12.137 |
| New cover helper | 512 MiB / 512 MiB | 162336768 | 149300 | 8.485 |

The standard run reached its cgroup memory cap but completed; no 512 MiB standard OOM was repeated. These are observed measurements for this exact document, not a universal memory/performance guarantee. Genuine bytes were mounted read-only and matched their existing acquisition receipt. This establishes glyph parity, not a new source acquisition or report qualification.

Candidate3 snapshot: 1476 files, mapping SHA256 `de915683c25278cbd3d36cefed09b2ee909856c16ffa05ae3dad2541c6e78085`. Entire source rehashed unchanged after execution. `native_report_cover.py` SHA256 `e45eeb82288293d991138c811756a93cfffc7d5474a9033fa8197976ba1addff`. The stored suite's source file is identical to candidate2; its 48 cases executed again. Source pins/delta/readbacks, scripts, exact commands, XML/logs/integer exits, per-case outputs and memory/text receipts are pinned by `FINAL-RECEIPT.json`.

Execution used only cached local Python runtime, owned ephemeral `--rm --network none --cpus 1 --pids-limit 256` containers, source read-only, RAM/swap caps as recorded and all four social flags false. No product edits, PG/shared containers, provider/network/production/paid/hosted actions, installs or worker activation. No persistent resources or real credentials created. No setup failure or skipped execution is credited.

Limits: fake lifecycle checks are distinguished from actual owned/genuine PDF parsing. Parent owns the cover-conflict/RSS matrix, current producer/retained/database/worker proof and all other genuine volume qualifications. No claim here that all nine volumes qualify.
