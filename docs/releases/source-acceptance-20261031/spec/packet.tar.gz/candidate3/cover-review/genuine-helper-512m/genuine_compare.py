from pathlib import Path
from io import BytesIO
import sys,json,time,resource,hashlib
import pdfplumber
from seeding.native_report_cover import extract_cover_texts
mode=sys.argv[1]
start=time.monotonic();body=Path('/genuine/cover.pdf').read_bytes()
if mode=='standard':
    with pdfplumber.open(BytesIO(body),pages=[1,2,3])as pdf:
        pages=[]
        for page in pdf.pages:
            pages.append((page.page_number,page.extract_text()or''))
            page.close()
else:pages=extract_cover_texts(body)
if len(pages)!=3:raise RuntimeError('Expected three genuine cover pages')
result={'mode':mode,'pdf_sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body),'pages':pages,'page_text_sha256':[hashlib.sha256(text.encode()).hexdigest()for number,text in pages],'text_lengths':[len(text)for number,text in pages],'ru_maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'seconds':time.monotonic()-start}
try:result['cgroup_memory_peak_bytes']=int(Path('/sys/fs/cgroup/memory.peak').read_text())
except OSError:pass
Path('/evidence/result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='pages'}))
