"""Independent stored OAG catalogue shape/clock checks; no PG/network."""
from copy import deepcopy
from datetime import datetime,timedelta,timezone
from pathlib import Path
import json
import httpx
import pytest
from services.response_receipts import capture_response,receipt_is_sealed
from services.receipt_store import LocalReceiptStore
from seeding.native_report_authority import capture_pdf_report,validate_catalogue,digest
from seeding.oag_report_catalogue import validate_stored_catalogue,scope_fields,_entry_time,PAIR_SECONDS

FEED='https://www.oagkenya.go.ke/document-category/2023-2024-county-government-audit-reports/feed/'
URLS={'executives':'https://www.oagkenya.go.ke/wp-content/uploads/2025/02/GREEN-BOOK-EXECUTIVES-2024-FINAL-5.3.2025-SIGNED.pdf','assemblies':'https://www.oagkenya.go.ke/wp-content/uploads/2025/02/GREEN-BOOK-ASSEMBLIES-2024-FINAL-01-April-2025-KLB.pdf'}
BAD=(ValueError,TypeError,KeyError,AttributeError,OverflowError)

def pdf_bytes(texts):
    # A valid xref PDF, parsed by real pdfplumber; no parser monkeypatch.
    objects=[b'<< /Type /Catalog /Pages 2 0 R >>',b'',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>']
    kids=[]
    for page in texts:
        page_id=len(objects)+1;stream_id=page_id+1;kids.append(page_id)
        objects.append(f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 850] /Resources << /Font << /F1 3 0 R >> >> /Contents {stream_id} 0 R >>'.encode())
        lines=[]
        for index,line in enumerate(page.splitlines()):
            escaped=line.replace('\\','\\\\').replace('(','\\(').replace(')','\\)')
            lines.append(f'BT /F1 8 Tf 12 {800-index*18} Td ({escaped}) Tj ET')
        stream='\n'.join(lines).encode()
        objects.append(b'<< /Length '+str(len(stream)).encode()+b' >>\nstream\n'+stream+b'\nendstream')
    objects[1]=('<< /Type /Pages /Kids ['+' '.join(f'{n} 0 R' for n in kids)+f'] /Count {len(kids)} >>').encode()
    body=bytearray(b'%PDF-1.4\n');offsets=[0]
    for number,obj in enumerate(objects,1):
        offsets.append(len(body));body.extend(f'{number} 0 obj\n'.encode()+obj+b'\nendobj\n')
    xref=len(body);body.extend(f'xref\n0 {len(offsets)}\n0000000000 65535 f \n'.encode())
    for offset in offsets[1:]:body.extend(f'{offset:010d} 00000 n \n'.encode())
    body.extend(f'trailer\n<< /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'.encode())
    return bytes(body)


def mint(tmp_path,kind='executives'):
    cover="AUDITOR-GENERAL'S REPORT ON THE COUNTY GOVERNMENTS FOR THE YEAR 2023-2024 "+('VOLUME 1 - COUNTY EXECUTIVES'if kind=='executives'else'VOLUME II: COUNTY ASSEMBLIES')
    body=pdf_bytes([cover]);path=tmp_path/'volume.pdf';path.write_bytes(body)
    rss=Path('/evidence/oag-feed.xml').read_bytes();store=LocalReceiptStore(tmp_path/'receipts')
    def acquired(body,url,mime,source):
        return capture_response(httpx.Response(200,content=body,headers={'content-type':mime},request=httpx.Request('GET',url)),store,source_kind=source)
    source=acquired(body,URLS[kind],'application/pdf','pdf');feed=acquired(rss,FEED,'application/rss+xml','rss')
    proof,reason=capture_pdf_report(path,source,domain='audits',publisher_receipt=feed)
    assert proof is not None and reason is None,(proof,reason)
    return proof,source,feed,path


def record(name,**value):
    Path('/evidence/'+name+'.json').write_text(json.dumps(value,indent=2,default=str)+'\n')


@pytest.mark.parametrize('kind',['executives','assemblies'])
def test_actual_mint_then_stored_validate(tmp_path,kind):
    proof,pdf,feed,path=mint(tmp_path,kind)
    start=datetime.fromisoformat(pdf['acquired_at'])-timedelta(seconds=1)
    finish=datetime.fromisoformat(feed['byte_check']['checked_at'])+timedelta(seconds=1)
    assert receipt_is_sealed(proof.receipt) and receipt_is_sealed(proof.publisher_receipt)
    assert proof._snapshot==digest(proof.value)
    assert validate_stored_catalogue(proof.value,proof.receipt,started=start,finished=finish)is None
    assert validate_catalogue(proof.value,proof.receipt,started=start,finished=finish)is None
    assert proof.value['published_on']is None and proof.value['catalogued_on']=='2025-02-21'
    record('positive-'+kind,value=proof.value)


MUTATIONS={
 'domain':('domain','revenue_by_source'),'publication-day':('published_on','2025-02-21'),
 'kind':('evidence_kind','publication'),'scope-key':('scope_key','wrong'),
 'period-start':('period_start','2022-07-01'),'period':('period','FY 2023/2024'),
 'institution':('catalogue_authority.institution','assemblies'),'volume-bool':('catalogue_authority.volume',True),
 'cover-bool':('catalogue_authority.cover_page',True),'cover-zero':('catalogue_authority.cover_page',0),
 'checksum':('catalogue_authority.document_checksum','a'*64),'guid-bool':('catalogue_authority.entry_guid',True),
 'timestamp-null':('catalogue_authority.entry_timestamp',None),'title-null':('catalogue_authority.title',None),
 'catalogue-day':('catalogued_on','2025-02-22'),'status-bool':('catalogue_authority.receipt.status',True),
 'bytes-bool':('catalogue_authority.receipt.byte_size',True),'no-observations':('catalogue_authority.receipt.observations',[]),
 'request-extra':('catalogue_authority.receipt.request',{'method':'GET','url':FEED,'extra':'unreviewed'}),
 'digest-uppercase':('catalogue_authority.receipt.digest','A'*64),
}


@pytest.mark.parametrize('case',list(MUTATIONS))
def test_stored_metadata_mutation_refuses(tmp_path,case):
    proof,pdf,feed,path=mint(tmp_path);value=deepcopy(proof.value)
    field,bad=MUTATIONS[case];parts=field.split('.');target=value
    for part in parts[:-1]:target=target[part]
    target[parts[-1]]=bad
    with pytest.raises(BAD)as exc:validate_stored_catalogue(value,proof.receipt)
    record('mutation-'+case,exception=type(exc.value).__name__,message=str(exc.value))


@pytest.mark.parametrize('period,kind',[(None,'executives'),(True,'executives'),('FY 2023/2024','executives'),('FY 2023/25','executives'),('FY 2023/24',True),('FY 2023/24','county')])
def test_direct_scope_shape_refuses(period,kind):
    with pytest.raises(BAD):scope_fields(period,kind)


@pytest.mark.parametrize('raw',[None,True,'Fri, 21 Feb 25 05:51:28 +0000','Mon, 21 Feb 2025 05:51:28 +0000','Fri, 21 Feb 2025 05:51:28','Fri, 31 Feb 2025 05:51:28 +0000','Fri, 21 Feb 2025 05:51:28 -0000','fri, 21 Feb 2025 05:51:28 +0000'])
def test_direct_timestamp_shape_refuses(raw):
    with pytest.raises(BAD):_entry_time(raw)


@pytest.mark.parametrize('case',['pair-900','pair-901','checked-before','rss-naive','entry-after-original','job-start-after','job-finish-before','retained-current-pair'])
def test_stored_chronology_and_job_bounds(tmp_path,case):
    proof,pdf,feed,path=mint(tmp_path);value=deepcopy(proof.value);source=deepcopy(dict(proof.receipt));r=value['catalogue_authority']['receipt']
    acquired=datetime.fromisoformat(r['acquired_at']);checked=datetime.fromisoformat(r['byte_check']['checked_at'])
    start=acquired-timedelta(seconds=1);finish=checked+timedelta(seconds=1);expected=case in('pair-900','retained-current-pair')
    if case in('pair-900','pair-901'):
        source['acquired_at']=(acquired-timedelta(seconds=900 if case=='pair-900'else 901)).isoformat()
    elif case=='checked-before':r['byte_check']['checked_at']=(acquired-timedelta(seconds=1)).isoformat()
    elif case=='rss-naive':r['acquired_at']=acquired.replace(tzinfo=None).isoformat()
    elif case=='entry-after-original':source['acquired_at']='2024-07-01T00:00:00+00:00'
    elif case=='job-start-after':start=acquired+timedelta(microseconds=1)
    elif case=='job-finish-before':finish=checked-timedelta(microseconds=1)
    else:
        source['acquired_at']='2025-02-22T00:00:00+00:00'
        source['retained_pdf_validation']={'validated_at':acquired.isoformat()}
    if expected:
        assert validate_stored_catalogue(value,source,started=start,finished=finish)is None
        record('clock-'+case,passed=True)
    else:
        with pytest.raises(BAD)as exc:validate_stored_catalogue(value,source,started=start,finished=finish)
        record('clock-'+case,exception=type(exc.value).__name__,message=str(exc.value))


@pytest.mark.parametrize('case',['serialized-feed','mutated-feed','mutated-manifest'])
def test_sealed_capability_and_json_boundaries(tmp_path,case):
    proof,pdf,feed,path=mint(tmp_path)
    if case=='serialized-feed':
        assert capture_pdf_report(path,pdf,domain='audits',publisher_receipt=dict(feed))[0]is None
    elif case=='mutated-feed':
        changed=deepcopy(proof.publisher_receipt);changed['status']=True
        assert not receipt_is_sealed(changed)
    else:
        changed=deepcopy(proof.publisher_receipt);changed['observations'][0]['catalogued_on']='2025-02-22'
        assert not receipt_is_sealed(changed)


def test_native_integration_rejects_missing_catalogue_context(tmp_path):
    proof,pdf,feed,path=mint(tmp_path);value=deepcopy(proof.value);value['catalogue_authority']=None
    with pytest.raises(BAD):validate_catalogue(value,proof.receipt)
