"""
Thin client for the Supabase Auth Admin REST API.

We deliberately don't take a dependency on ``supabase-py`` for this —
the admin endpoints we need are a handful of simple REST calls and
the project doesn't otherwise use the SDK. ``httpx`` is already a
transitive dep of FastAPI, so this is zero-cost.

Auth model
----------
Every call sends two headers: ``apikey`` and
``Authorization: Bearer <key>``. Both must be the **service role key**
(not the anon key). Supabase will accept either header on its own in
some endpoints and both in others; sending both keeps things uniform.

The service role key bypasses RLS and can read/modify any user, so it
must NEVER be exposed to the browser. It is read from the environment
on first use and cached in a module-level variable.
"""

from __future__ import annotations

import os
import re
from typing import Any, List, Optional
from urllib.parse import quote
from uuid import UUID

import httpx

_ENV_URL = "SUPABASE_URL"
_ENV_SERVICE_KEY = "SUPABASE_SERVICE_ROLE_KEY"
_UUID_TEXT = re.compile(r"(?:[0-9a-f]{32}|[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})", re.I)


class SupabaseAdminError(RuntimeError):
    """Safe status-only diagnostic shared by legacy and active providers.

    The second argument remains accepted for import/caller compatibility, but
    is never rendered or retained. ``body`` is always None; no trusted consumer
    of raw provider diagnostics exists in the repository.
    """

    def __init__(self, status_code: int, body: Any):
        if type(status_code) is not int or not 100 <= status_code <= 599:
            status_code = 502
        super().__init__(f"Supabase admin API returned {status_code}")
        self.status_code = status_code
        self.body = None


def _config() -> tuple[str, str]:
    url = os.getenv(_ENV_URL)
    key = os.getenv(_ENV_SERVICE_KEY)
    if not url or not key:
        raise SupabaseAdminError(
            500,
            f"{_ENV_URL} and {_ENV_SERVICE_KEY} must both be set",
        )
    try:
        httpx.URL(url)
        key.encode("ascii")
    except (httpx.InvalidURL, UnicodeError):
        raise SupabaseAdminError(500, None) from None
    return url.rstrip("/"), key


def _headers() -> dict:
    _, key = _config()
    return {
        "apikey": key,
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
    }


def _admin_url(path: str) -> str:
    base, _ = _config()
    return f"{base}/auth/v1/admin{path}"


def _rest_url(path: str) -> str:
    base, _ = _config()
    return f"{base}/rest/v1{path}"


def _request(method: str, path: str, **kwargs) -> dict:
    """Make an authenticated request to /auth/v1/admin and unwrap the JSON."""
    return _raw_request(method, _admin_url(path), **kwargs)


def _raw_request(method: str, url: str, *, headers=None, **kwargs):
    """Make an authenticated request to an arbitrary URL and unwrap.

    Returns the parsed JSON body, or ``{}`` for empty/204 responses.
    Lists come through as lists. Raises ``SupabaseAdminError`` on
    any non-2xx response. Per-call headers are merged case-insensitively;
    service-role authentication always takes precedence.
    """
    if "auth" in kwargs:
        # HTTPX applies auth after headers and could replace Authorization.
        raise SupabaseAdminError(400, "Per-call authentication is not supported")
    try:
        request_headers = httpx.Headers()
        for name, value in httpx.Headers(headers).multi_items():
            # Assignment collapses case variants into one header (including Prefer).
            request_headers[name] = value
    except (ValueError, TypeError):
        raise SupabaseAdminError(400, None) from None
    # Per-call options must never replace the service-role credentials.
    request_headers.update(_headers())
    try:
        with httpx.Client(timeout=15.0) as client:
            resp = client.request(method, url, headers=request_headers, **kwargs)
    except httpx.HTTPError:
        raise SupabaseAdminError(503, None) from None
    except httpx.InvalidURL:
        raise SupabaseAdminError(500, None) from None
    if not 200 <= resp.status_code < 300:
        raise SupabaseAdminError(resp.status_code, None)
    if resp.status_code == 204 or not resp.content:
        return {}
    try:
        return resp.json()
    except (ValueError, RecursionError):
        raise SupabaseAdminError(502, None) from None


# ── Public API ──────────────────────────────────────────────────────────


def list_users(*, page: int = 1, per_page: int = 50) -> dict:
    """List Supabase auth users. Returns the raw {users: [...], aud, ...} payload."""
    return _request("GET", "/users", params={"page": page, "per_page": per_page})


def get_user(user_id: str) -> dict:
    """Fetch a single user by Supabase UUID."""
    return _request("GET", f"/users/{user_id}")


def update_user(user_id: str, body: dict) -> dict:
    """
    Update a user. Body fields supported by Supabase include
    ``email``, ``password``, ``email_confirm``, ``ban_duration``,
    ``app_metadata``, ``user_metadata``. Pass only the fields you
    intend to change.
    """
    return _request("PUT", f"/users/{user_id}", json=body)


def delete_user(user_id: str) -> dict:
    """Permanently delete a user. The associated ``profiles`` row
    cascades via the FK + ON DELETE CASCADE that Supabase sets up
    by default in its starter migrations."""
    return _request("DELETE", f"/users/{user_id}")


def generate_recovery_link(email: str, redirect_to: Optional[str] = None) -> dict:
    """
    Generate a password-recovery link for ``email``. Useful for the
    "send the user a reset email on their behalf" admin action.

    Returns the raw response which includes ``action_link`` (the URL
    the user would click in the email) and ``email_otp`` etc. We
    return the whole thing so callers can decide what to do — but
    the typical UX is to let Supabase email it: pass
    ``redirect_to`` and Supabase fires the email automatically.
    """
    body: dict = {"type": "recovery", "email": email}
    if redirect_to:
        body["redirect_to"] = redirect_to
    return _request("POST", "/generate_link", json=body)


# ── Profiles (REST against /rest/v1) ────────────────────────────────────
#
# ``profiles`` lives in the same Supabase project as auth.users, NOT in
# the FastAPI data DB. Querying via REST + service role keeps things on
# the right side of the project boundary.


def get_profile(user_id: str) -> Optional[dict]:
    """Fetch a matching UUID profile; only an empty row array means missing."""
    identity = _profile_identity(user_id, status_code=400)
    rows = _read_profiles({identity}, f"eq.{identity}")
    return rows[0] if rows else None


def get_profiles(user_ids: List[str]) -> List[dict]:
    """Read UUID profiles, preserving provider order and allowing missing IDs.

    Duplicate requested UUIDs are queried once. Duplicate, unrequested or
    invalid provider identities reject the entire response, never a subset.
    """
    if not isinstance(user_ids, list):
        raise SupabaseAdminError(400, None)
    identities = list(dict.fromkeys(_profile_identity(uid, status_code=400) for uid in user_ids))
    if not identities:
        return []
    return _read_profiles(set(identities), f"in.({','.join(identities)})")


def _profile_identity(value: str, *, status_code: int) -> str:
    if not isinstance(value, str) or len(value) > 45:
        raise SupabaseAdminError(status_code, None)
    # UUID() alone also strips unmatched braces and misplaced urn/uuid tags.
    if value.lower().startswith("urn:uuid:"):
        value = value[9:]
    elif value.startswith("{") and value.endswith("}"):
        value = value[1:-1]
    if not _UUID_TEXT.fullmatch(value):
        raise SupabaseAdminError(status_code, None)
    return str(UUID(value))


def _read_profiles(identities: set[str], id_filter: str) -> List[dict]:
    rows = _raw_request(
        "GET", _rest_url("/profiles"),
        params={"select": "id,email,display_name,roles,created_at", "id": id_filter},
    )
    if not isinstance(rows, list):
        raise SupabaseAdminError(502, None)
    seen = set()
    for row in rows:
        if not isinstance(row, dict):
            raise SupabaseAdminError(502, None)
        identity = _profile_identity(row.get("id"), status_code=502)
        if identity not in identities or identity in seen:
            raise SupabaseAdminError(502, None)
        if any(key in row for key in ("error", "errors", "error_code")) or any(
            key in row and row[key] is not True for key in ("ok", "success")
        ):
            raise SupabaseAdminError(502, None)
        seen.add(identity)
    return rows


def update_profile_roles(user_id: str, roles: List[str]) -> dict:
    """Set roles and return one provider row matching the requested id/roles.

    An empty result retains the missing-profile 404 contract. An absent,
    malformed or mismatched representation cannot confirm the mutation (502).
    """
    try:
        rows = _raw_request(
            "PATCH",
            _rest_url(f"/profiles?id=eq.{user_id}"),
            json={"roles": roles},
            headers={"Prefer": "return=representation"},
        )
    except ValueError:
        raise SupabaseAdminError(502, None) from None
    if isinstance(rows, list) and not rows:
        raise SupabaseAdminError(404, f"No profile with id={user_id}")
    if not isinstance(rows, list) or len(rows) != 1 or not isinstance(rows[0], dict):
        raise SupabaseAdminError(502, None)
    row = rows[0]
    if row.get("id") != user_id or not isinstance(row.get("roles"), list) or row["roles"] != roles:
        raise SupabaseAdminError(502, None)
    if any(key in row for key in ("error", "errors", "error_code")) or any(
        key in row and row[key] is not True for key in ("ok", "success")
    ):
        raise SupabaseAdminError(502, None)
    return row


def count_profiles(
    column: Optional[str] = None,
    op: Optional[str] = None,
    value: Optional[str] = None,
) -> int:
    """
    Count rows in ``profiles``, optionally filtered.

    To filter, pass ``column``/``op``/``value`` (e.g.
    ``column="roles", op="cs", value="{admin}"`` for "rows whose roles
    array contains admin", or ``column="created_at", op="gte",
    value="2026-04-25"``). The value is URL-encoded — callers must
    NOT pre-encode. Without those args, returns the unfiltered count.

    The count comes back via PostgREST's ``Content-Range`` header
    when ``Prefer: count=exact`` is set. We use GET with
    ``Range: 0-0`` rather than HEAD because (a) some Supabase
    deployments don't propagate the count headers correctly on HEAD
    responses, and (b) ``Range: 0-0`` keeps the body to a single
    row so the bandwidth cost is negligible.
    """
    base, _ = _config()
    url = _rest_url("/profiles?select=id")
    if column and op and value is not None:
        # Encode the value but leave the operator and column alone —
        # those have no special chars in practice and PostgREST is
        # picky about the ``op.value`` format.
        url += f"&{column}={op}.{quote(value, safe='')}"

    request_headers = {
        **_headers(),
        "Prefer": "count=exact",
        "Range": "0-0",
    }
    try:
        with httpx.Client(timeout=15.0) as client:
            resp = client.get(url, headers=request_headers)
    except httpx.HTTPError:
        raise SupabaseAdminError(503, None) from None
    if not 200 <= resp.status_code < 300:
        raise SupabaseAdminError(resp.status_code, None)
    cr = resp.headers.get("content-range") or ""
    if "/" in cr:
        try:
            return int(cr.split("/", 1)[1])
        except ValueError:
            pass
    return 0
