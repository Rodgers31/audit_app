"""Detect typed public-finance figures throughout the source tree.

The regression gate also inventories exact reviewed pre-existing sites from
Round 9, with their use context, reasons and linked followups. Raw detection
still returns those sites. A green gate means no unreviewed site or context
drift; 47 existing typed-finance sites remain unresolved under #301 and #424.

On 2026-09-07, ``apis/data_driven_analytics.py`` — and its byte-identical twin
``analysis/data_driven_analytics.py`` (md5 ``e0713a40054986c9c0ca51d99c4f406c``)
— opened with the claim that it "reads from actual extracted data files instead
of hard-coded values", and then returned this::

    current_debt = {
        "total_debt": 11500000000000,       # 11.5T KES (verified online)
        "verification_status": "manually_verified",
    }
    external_percentage = 60.0              # Typical for Kenya
    "debt_to_gdp_ratio": 70.2,              # Updated calculation

    def _calculate_debt_trend(self) -> Dict[str, int]:
        return {"2020": 7400000000000, "2021": 8200000000000,
                "2022": 9100000000000, "2023": 10200000000000,
                "2024": 11500000000000}

A function called ``_calculate_debt_trend`` that calculates nothing, five typed
constants, and a split that is ``total * 0.6`` / ``total * 0.4``. Every point of
that series disagrees with ``backend/seeding/real_data/debt_timeline.json``,
which carries CBK figures cited to the PDF page — including the sign of the
2023→2024 move, which CBK records as a *fall* (11,139.7 → 10,925.3 Bn) and the
module drew as a rise. The 60% external share is on the wrong side of the
majority: CBK puts 2024 external at 46.3%, and the repo's own loan register at
47.4% on outstanding (5,276 of 11,140 Bn) or 47.6% on principal (5,326 of
11,190 Bn), summing all 13 rows of ``national_debt.json`` both ways. Read one
column while quoting the other and the difference looks like an addition slip;
the register carries both, and they differ on 7 of its 13 rows — rows 1, 2, 3,
5, 6, 7 and 8. (This said 8 until issue #193 recounted it. Row 4,
``Multilateral (Other — EIB, IFAD, IFC)``, is 95.0 Bn in both columns and was
counted as differing. The totals and shares above are unaffected and were
right.)
``outstanding`` is the basis the repo publishes on — ``backend/main.py:369``,
``:492``, ``:2462``, ``:4428`` and ``test_debt_total_double_count.py:117`` all
sum ``outstanding``, falling back to ``principal`` only where it is absent —
and it is the like-for-like comparator, CBK's figure being a stock outstanding.
The choice does not matter to the point: both are below half, and the module
said 60%.

Beside them, ministry "execution rates" were ``abs(hash(ministry)) % 25``
arithmetic, labelled ``"data_derivation": "calculated_from_actual_budget_data"``
— a number that changes on every server restart, because ``hash()`` on a ``str``
is salted per process.

NOTE FOR ANYONE TEMPTED TO TEST THE INSTABILITY DIRECTLY: do not. This guard
keys on the literal in the source, which is seed-independent, and the rule
about ``hash()`` itself now lives in
``test_no_published_figure_from_hash_or_clock.py`` (issue #193). The reason is
that ``hash()`` is stable *within* a process whatever the seed, so a
run-it-twice test in one interpreter finds these values rock steady even while
the defect is live, and a runner that pinned ``PYTHONHASHSEED`` would freeze
them across processes too. (This note previously said pytest pins that variable.
It does not here — ``pytest-randomly`` is not installed and
``os.environ.get("PYTHONHASHSEED")`` is ``None`` under this runner. The
conclusion was right for the weaker reason.)

THE RULE. A module anywhere in the tree may not
publish a numeric literal under a name that denotes a measured public-finance quantity — a debt,
a budget, a revenue, an allocation, a ratio, a rate, a share, a score. If the
figure is measured, it comes from the data; if it is typed, it is invented. This
holds however the literal is dressed: bare (``"total_debt": 11500000000000``),
arithmetic on typed factors (``revenue_target = national_budget * 0.75``), or
buried in a clamp (``min(95, max(60, 75 + (h % 25) - 12))``) — the whole value
expression is scanned, because #178/#179 were exactly the case where published
figures turned out to be arithmetic rather than measurement.

Separately, a dict mapping four-digit years to numbers is a hand-typed time
series and is barred on its own, whatever key it hangs under. That is the shape
``_calculate_debt_trend`` used, and no key name was involved.

``apis/`` AND ``analysis/`` ARE BOTH SCANNED, deliberately. The two copies are byte-identical;
a guard over ``apis/`` alone would go green on cleaning one of them while the
invented debt series stayed in the repo under ``analysis/``.

Both original modules still exist and are scanned; six methods were removed
from them. The detector keeps biting on the pattern wherever it reappears.
Round 9's reviewed inventory changes the regression gate's acceptance to no
unreviewed drift, while preserving the raw findings and unresolved followups.

WHAT IS NOT A FIGURE, and why each exemption is safe:

* ``0`` and ``0.0`` — an absence or an accumulator seed, not an invented
  measurement. The zero case has its own rule already:
  ``local/no-zero-fallback-on-published-figure`` (7b5d366).
* ``1`` and ``100`` — an identity and a percentage base.
* integer powers of ten from 1000 up, and floating powers only as arithmetic
  factors/divisors — unit conversion (``/ 1_000_000_000`` to
  billions). 11500000000000 is not one; 1000000000 is.
* schema precision, query limits, comparison operands and constants used
  exclusively as direct comparison thresholds — structure, not measurement.
* slice bounds (``rankings[:5]``) and the ``ndigits`` of ``round(x, 2)`` — list
  length and display precision are structure, not quantity.

EXTENDED TO ``extractors/`` 2026-09-07 (issue #193). It ships:
``etl/Dockerfile:20`` copies the repo root, ``extractors/`` included, into the
published ETL image. (The web image carries none of the three roots:
``backend/Dockerfile.prod`` builds from ``backend/``.) It caught 21 figures in
``extractors/government/comprehensive_government_extractor.py`` — a national
database typed in whole, including a debt block repeating #188's defects
independently (10.2T, 67.8% of GDP, a 59.8% external share) and a
``transparency_score: 95`` sitting in the same dict as genuinely counted
reports, unable to disagree with them.

A NUMBER THAT LOOKS THE SAME AND IS NOT.
``extractors/county/official_county_budget_extractor.py:45+`` holds 55 numeric
literals in a dict of named counties and is REFERENCE DATA — KNBS 2019 census
populations with official county codes. It draws no findings here, and the
reason is worth keeping: the rule fires on a literal under a label that names a
measured public-finance quantity, and ``population`` and ``code`` are neither.
Do not add ``population`` to ``SUBJECTS`` to make the sweep feel thorough; it
would turn a census into a defect. What separates it from the figures above is
not the shape of the literal but whether anybody measured it, and the census
was measured.

ESCAPE HATCH, following ``local/no-zero-fallback-on-published-figure``
(7b5d366) and the county guard beside this file: a suppression must carry a
written reason. Put

    # figure-literal-ok: <where this number comes from>

on the line the value opens, or the line above it. The reason is the point — a
figure with a source is not invented, and writing the source down is the whole
difference.
"""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

import pytest

from tests._repo_tree import REPO_ROOT, python_modules, rel as _rel
from tests._guard_suppression import suppressed

# Shared traversal includes new roots and fails on parse errors.
SCANNED_ROOTS = (REPO_ROOT,)

# A label names a measured public-finance quantity if it mentions what the
# figure is ABOUT ...
SUBJECTS = (
    "debt",
    "budget",
    "revenue",
    "expenditure",
    "allocation",
    "gdp",
    "deficit",
    "surplus",
    "funds",
    "disbursement",
    "arrears",
    "tax",
    "borrowing",
    "repayment",
    "transfers",
)
# ... or HOW it was measured.
MEASURES = (
    "execution_rate",
    "collection_rate",
    "performance_score",
    "transparency_score",
    "percentage",
    "_ratio",
    "_share",
)

EXEMPT_VALUES = {0, 1, 100}

SUPPRESSION = "figure-literal-ok:"


def _is_unit_conversion(value: int | float) -> bool:
    """True for an exact power of ten from 1000 up (``/ 1_000_000_000``)."""
    if isinstance(value, bool) or not isinstance(value, int) or value < 1000:
        return False
    digits = str(int(value))
    return digits[0] == "1" and set(digits[1:]) <= {"0"}


def _is_figure(value: object) -> bool:
    """True if this literal is a quantity someone could have measured."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    if value in EXEMPT_VALUES:
        return False
    return not _is_unit_conversion(value)


def _names_a_measured_quantity(label: str) -> bool:
    lowered = label.lower()
    return any(t in lowered for t in SUBJECTS) or any(t in lowered for t in MEASURES)


def _structural_literals(tree: ast.AST) -> set[int]:
    """Literal nodes that carry structure, not quantity.

    Slice bounds say how long a list is. ``round(x, 2)`` says how it is
    printed. Neither asserts anything about public money.
    """
    ids: set[int] = set()
    nodes = tuple(ast.walk(tree))
    parents = {
        id(child): parent
        for parent in nodes
        for child in ast.iter_child_nodes(parent)
    }
    # Preserve the existing whole-module name-use rule, including uses in
    # nested scopes. Index it once instead of walking every node for each
    # assignment; coverage tracing made that quadratic scan costly in CI.
    loads_by_name: dict[str, list[ast.Name]] = {}
    for node in nodes:
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
            loads_by_name.setdefault(node.id, []).append(node)
    for assignment in nodes:
        if isinstance(assignment, ast.Assign) and len(assignment.targets) == 1:
            target, value = assignment.targets[0], assignment.value
        elif isinstance(assignment, ast.AnnAssign):
            target, value = assignment.target, assignment.value
        else:
            continue
        if not isinstance(target, ast.Name) or value is None:
            continue
        uses = loads_by_name.get(target.id, [])
        if (
            isinstance(value, ast.Constant)
            and type(value.value) in (int, float)
            and uses
            and all(isinstance(parents.get(id(n)), ast.Compare) for n in uses)
        ):
            ids.update(id(n) for n in ast.walk(value))
    for node in nodes:
        # Indices, annotations/schema declarations and query/window arguments
        # describe structure. Clamp/coercion/get defaults can create figures.
        if isinstance(node, ast.Compare):
            ids.update(
                id(n)
                for n in [node.left, *node.comparators]
                if isinstance(n, ast.Constant)
            )
        elif isinstance(node, ast.Subscript):
            ids.update(id(n) for n in ast.walk(node.slice))
        elif isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Div, ast.Mult)):
            for operand in (
                (node.right,)
                if isinstance(node.op, ast.Div)
                else (node.left, node.right)
            ):
                if (
                    isinstance(operand, ast.Constant)
                    and isinstance(operand.value, float)
                    and operand.value.is_integer()
                    and _is_unit_conversion(int(operand.value))
                ):
                    ids.add(id(operand))
        elif isinstance(node, ast.Call):
            name = (
                node.func.id
                if isinstance(node.func, ast.Name)
                else getattr(node.func, "attr", "")
            )
            if name in {
                "Column",
                "Numeric",
                "String",
                "Float",
                "Integer",
                "mapped_column",
                "limit",
                "offset",
                "group",
                "datetime",
                "timedelta",
            }:
                for arg in [
                    *node.args,
                    *(
                        kw.value
                        for kw in node.keywords
                        if kw.arg not in {"default", "server_default"}
                    ),
                ]:
                    ids.update(id(n) for n in ast.walk(arg))
    for node in nodes:
        if isinstance(node, ast.Slice):
            for part in (node.lower, node.upper, node.step):
                if part is not None:
                    ids.update(id(n) for n in ast.walk(part))
        elif (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "round"
        ):
            for arg in node.args[1:]:
                ids.update(id(n) for n in ast.walk(arg))
            for kw in node.keywords:
                if kw.arg == "ndigits":
                    ids.update(id(n) for n in ast.walk(kw.value))
    return ids


def _labelled_values(tree: ast.AST) -> list[tuple[str, ast.AST]]:
    """Every value in the module paired with the name it is published under."""
    pairs: list[tuple[str, ast.AST]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Dict):
            for key, value in zip(node.keys, node.values):
                if isinstance(key, ast.Constant) and isinstance(key.value, str):
                    pairs.append((key.value, value))
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    pairs.append((target.id, node.value))
                elif isinstance(target, ast.Attribute):
                    pairs.append((target.attr, node.value))
        elif isinstance(node, ast.AnnAssign) and node.value is not None:
            if isinstance(node.target, ast.Name):
                pairs.append((node.target.id, node.value))
        elif isinstance(node, ast.keyword) and node.arg:
            pairs.append((node.arg, node.value))
    return pairs


def _year_keys(node: ast.Dict) -> list[str] | None:
    """The dict's keys as year strings, or None if they are not all years."""
    if not node.keys:
        return None
    years: list[str] = []
    for key in node.keys:
        if not isinstance(key, ast.Constant) or not isinstance(key.value, (str, int)):
            return None
        text = str(key.value)
        if not (len(text) == 4 and text.isdigit() and 1900 <= int(text) <= 2100):
            return None
        years.append(text)
    return years


def find_invented_figures(source: str, where: str = "<source>") -> list[str]:
    """Every typed-in public-finance figure in ``source``.

    Returns human-readable descriptions, one per offending value. Empty list
    means clean. This is the detector; the tests below are thin wrappers around
    it — one over the real tree, one over the block that was deleted, one over
    code that must stay legal.
    """
    tree = ast.parse(source, filename=where)
    structural = _structural_literals(tree)
    lines = source.splitlines()
    findings: list[str] = []

    # A container is not a second publication site for every leaf. Its
    # string-keyed children and any year series are scanned independently.
    labelled = [
        (label, value)
        for label, value in _labelled_values(tree)
        if not isinstance(value, ast.Dict)
    ]
    sites = [v for label, v in labelled if _names_a_measured_quantity(label)] + [
        n for n in ast.walk(tree) if isinstance(n, ast.Dict) and _year_keys(n)
    ]
    suppressed_values = [v for v in sites if suppressed(lines, v, SUPPRESSION, sites)]
    suppressed_ids = {id(n) for v in suppressed_values for n in ast.walk(v)}
    for label, value in labelled:
        if not _names_a_measured_quantity(label):
            continue
        literals = [
            node.value
            for node in ast.walk(value)
            if isinstance(node, ast.Constant)
            and _is_figure(node.value)
            and id(node) not in structural
            and id(node) not in suppressed_ids
        ]
        if not literals:
            continue
        if suppressed(lines, value, SUPPRESSION, sites):
            continue
        findings.append(
            f"{where}:{value.lineno}: {label!r} is published from typed-in "
            f"numbers {literals}. Nothing measured it. Serve a sourced figure "
            f"or serve nothing."
        )

    for node in ast.walk(tree):
        if not isinstance(node, ast.Dict):
            continue
        years = _year_keys(node)
        if not years:
            continue
        series = [
            v.value
            for v in node.values
            if isinstance(v, ast.Constant) and _is_figure(v.value)
        ]
        if len(series) < 3:
            continue
        if suppressed(lines, node, SUPPRESSION, sites):
            continue
        findings.append(
            f"{where}:{node.lineno}: a hand-typed time series "
            f"{years[0]}–{years[-1]} {series}. A year-by-year curve nobody "
            f"measured is a claim about every year in it."
        )

    return findings


SCANNED_MODULES = python_modules()


# Modules that carry this defect and are NOT this change's to fix. Each entry
# is a ratchet, not a pardon: the count is pinned, so adding a figure fails,
# and ``test_quarantined_modules_still_carry_their_figures`` fails if a file is
# cleaned without being taken off this list — so the list cannot rot into a
# blanket exemption. Nothing goes in here without a reason a person signed.
#
# Empty since issue #198. Its one entry held
# ``extractors/county/enhanced_county_extractor.py`` at 20 findings, all of
# them inside ``generate_mock_comprehensive_county_data``; that method was
# withdrawn and the file now goes through the sweep below like any other.
QUARANTINE: dict[str, tuple[int, str]] = {}

# Round 9's whole-tree expansion exposed pre-existing sites outside the former
# traversal. Keep RAW detection intact. This regression inventory records
# reviewed contextual values and unresolved typed finance separately, with a
# reason and tracking issue for every site. Passing the gate means no drift;
# it does not certify these existing observations as sourced or resolved.
# Pin the entire module AST as context: a literal gaining a caller, publication
# use, or fallback branch within that module must be reviewed again. Formatting and
# ordinary comments may change, but a changed suppression changes raw findings.
REVIEWED_FIGURE_INVENTORY = json.loads(
    Path(__file__)
    .with_name("financial_literal_reviewed_inventory.json")
    .read_text(encoding="utf-8")
)


def _context_ast_dump(node):
    """Freeze the reviewed Python 3.13 format across Python 3.12/3.13.

    ast.dump changed its default empty-list rendering in 3.13. These pins
    describe parsed source, so omit empty structural fields explicitly while
    retaining node types, field order, scalar values and every nonempty child.
    A literal None remains Constant(value=None); an empty list remains List.
    Locations are excluded, as in the original include_attributes=False pins.
    """
    if isinstance(node, ast.AST):
        fields = []
        for name, value in ast.iter_fields(node):
            if value is None and getattr(type(node), name, ...) is None:
                continue
            if isinstance(value, list) and not value:
                continue
            fields.append(f"{name}={_context_ast_dump(value)}")
        return f"{type(node).__name__}({', '.join(fields)})"
    if isinstance(node, list):
        return f"[{', '.join(_context_ast_dump(value) for value in node)}]"
    return repr(node)


def _assert_reviewed_figure_source(source, relative_path, entry, findings=None):
    digest = hashlib.sha256(
        _context_ast_dump(ast.parse(source)).encode("utf-8")
    ).hexdigest()
    assert digest == entry["ast_sha256"], (
        f"{relative_path}: reviewed figure use context changed. Re-review each "
        "site; do not refresh the inventory merely to obtain a green gate."
    )
    sites = entry["sites"]
    assert sites, f"{relative_path}: an empty inventory entry is stale"
    for site in sites:
        assert site["reason"].strip(), f"{relative_path}: site has no review reason"
        assert site["disposition"] in {
            "reviewed contextual value",
            "unresolved typed finance",
        }, f"{relative_path}: site has no reviewed disposition"
        assert (
            site["tracking"].startswith(
                "https://github.com/Rodgers31/audit_app/issues/"
            )
            and site["tracking"].rsplit("/", 1)[-1].isdigit()
        ), f"{relative_path}: site has no tracking issue"
    if findings is None:
        findings = find_invented_figures(source, relative_path)
    signatures = [finding.split(": ", 1)[1] for finding in findings]
    assert signatures == [site["signature"] for site in sites], (
        f"{relative_path}: raw figure sites changed. Retire resolved entries; "
        "review additions, changed values and changed suppressions.\n"
        + "\n".join(findings)
    )


def test_reviewed_figure_inventory_still_has_every_owned_module():
    scanned = {_rel(path) for path in SCANNED_MODULES}
    for relative_path in REVIEWED_FIGURE_INVENTORY:
        assert relative_path in scanned, (
            f"{relative_path}: reviewed module was deleted or left the scan. "
            "Retire its exact inventory instead of silently exempting a path."
        )


def test_the_scanned_directories_are_where_we_think_they_are():
    """Anti-vacuity: an empty sweep must never read as a pass.

    Skip a root that has been removed entirely — deleting it is a legitimate
    outcome and the owner's call — but fail if a root exists and the scan finds
    nothing in it, and fail if every root has vanished at once.
    """
    surviving = [root for root in SCANNED_ROOTS if root.is_dir()]
    if not surviving:
        pytest.fail("repository source root is absent")
    for root in surviving:
        assert python_modules(
            root
        ), f"{root.name}/ exists but holds no .py files — its scan would be vacuous"
    assert SCANNED_MODULES, "no modules collected — the sweep would be silent"


def test_the_detector_catches_the_payload_it_was_written_for():
    """Positive control. Proves raw detection remains active.

    This is the block removed from ``apis/data_driven_analytics.py:50-92`` and
    its twin under ``analysis/``. If the detector ever stops flagging it, the
    scan over the real tree is worthless and this test says so.
    """
    known_bad = """
def get_current_national_debt(self):
    current_debt = {
        "total_debt": 11500000000000,
        "source": "Official online sources (late 2024/early 2025)",
        "verification_status": "manually_verified",
    }
    external_percentage = 60.0
    total = current_debt["total_debt"]
    current_debt.update({
        "debt_breakdown": {
            "external_debt": int(total * external_percentage / 100),
            "domestic_debt": int(total * (100 - external_percentage) / 100),
        },
        "debt_to_gdp_ratio": 70.2,
        "trend_analysis": self._calculate_debt_trend(),
    })
    return current_debt


def _calculate_debt_trend(self):
    return {
        "2020": 7400000000000,
        "2021": 8200000000000,
        "2022": 9100000000000,
        "2023": 10200000000000,
        "2024": 11500000000000,
    }
"""
    findings = find_invented_figures(known_bad, "known_bad.py")
    blob = "\n".join(findings)
    assert "'total_debt'" in blob, f"the 11.5T headline slipped through: {findings}"
    assert (
        "'external_percentage'" in blob
    ), f"the 60/40 split slipped through: {findings}"
    assert "'debt_to_gdp_ratio'" in blob, f"the 70.2 ratio slipped through: {findings}"
    assert (
        "hand-typed time series" in blob
    ), f"the 2020–2024 curve slipped through: {findings}"

    # Renaming the key must not get past it — the series is the claim.
    renamed = known_bad.replace("total_debt", "headline_number").replace(
        "debt_to_gdp_ratio", "ratio_a"
    )
    assert find_invented_figures(
        renamed, "renamed.py"
    ), "renaming every key defeated the guard"

    # The randomised ministry figures: literals buried inside a clamp.
    hashed = """
ministry_performance[ministry] = {
    "execution_rate": min(95, max(60, 75 + (ministry_hash % 25) - 12)),
    "performance_score": min(100, max(50, 70 + (ministry_hash % 30) - 15)),
    "data_derivation": "calculated_from_actual_budget_data",
}
"""
    hashed_findings = find_invented_figures(hashed, "hashed.py")
    assert any(
        "execution_rate" in f for f in hashed_findings
    ), f"a figure wrapped in min()/max() got through: {hashed_findings}"
    assert any(
        "performance_score" in f for f in hashed_findings
    ), f"a figure wrapped in min()/max() got through: {hashed_findings}"

    # Arithmetic on typed factors — the #178/#179 shape.
    arithmetic = """
collection_rate = 87.5
revenue_target = national_budget * 0.75
revenue_breakdown = {"tax_revenue": actual_revenue * 0.80}
"""
    arithmetic_findings = find_invented_figures(arithmetic, "arithmetic.py")
    flagged = {f.split("'")[1] for f in arithmetic_findings}
    assert flagged == {
        "collection_rate",
        "revenue_target",
        "tax_revenue",
    }, f"typed factors are still typed figures: {arithmetic_findings}"


def test_the_detector_leaves_measured_code_alone():
    """Negative control. Reading a figure out of the data must stay legal."""
    measured = """
total_debt = sum(row["outstanding"] for row in loans)
debt_to_gdp_ratio = total_debt / gdp
budget_2025 = county_info.get("budget_2025", 0)
total_budget = 0
for county in counties:
    total_budget += county["budget_2025"]
budget_allocation_billions = ministry["budget_allocation"] / 1000000000
top_budget = rankings.get("by_budget_size", [])[:5]
average_missing_ratio = round(sum(ratios) / len(ratios), 2)
"""
    assert not find_invented_figures(measured, "measured.py"), find_invented_figures(
        measured, "measured.py"
    )

    # A figure that carries its source in writing is not invented.
    sourced = """
debt = {
    # figure-literal-ok: CBK Statistical Bulletin Dec 2025, Table 4.1.3 (PDF p.56)
    "total_debt": 10925300000000,
}
"""
    assert not find_invented_figures(
        sourced, "sourced.py"
    ), "a suppression with a written reason must be honoured"

    # ... but a bare suppression with no reason is not a source.
    unreasoned = sourced.replace(
        "# figure-literal-ok: CBK Statistical Bulletin Dec 2025, "
        "Table 4.1.3 (PDF p.56)",
        "# figure-literal-ok:",
    )
    assert find_invented_figures(
        unreasoned, "unreasoned.py"
    ), "an empty suppression bought silence for free"


def _assert_quarantined_figure_module(relative_path: str, expected: int, reason: str):
    """The reverse ratchet. A quarantine that outlives its debt is a lie.

    Clean one of these files and this fails, telling you to delete its entry.
    Add a figure to one and it fails too. Either way the list stays honest
    about how much is still owed.
    """
    module = REPO_ROOT / relative_path
    if not module.is_file():
        pytest.fail(
            f"{relative_path} is gone but is still quarantined. Delete its "
            f"QUARANTINE entry. It was held for: {reason}"
        )
    findings = find_invented_figures(module.read_text(encoding="utf-8"), relative_path)
    assert len(findings) == expected, "\n".join(
        [
            f"{relative_path} was quarantined with {expected} known figure(s) "
            f"and now has {len(findings)}.",
            f"  held because: {reason}",
            "  If you cleaned it, delete its QUARANTINE entry. If you added to "
            "it, do not.",
            *findings,
        ]
    )


def test_quarantined_modules_still_carry_their_figures():
    for path, (count, reason) in sorted(QUARANTINE.items()):
        _assert_quarantined_figure_module(path, count, reason)


@pytest.mark.parametrize(
    "module",
    [m for m in SCANNED_MODULES if _rel(m) not in QUARANTINE],
    ids=[_rel(m) for m in SCANNED_MODULES if _rel(m) not in QUARANTINE] or ["none"],
)
def test_no_module_adds_an_unreviewed_invented_figure(module: Path):
    source = module.read_text(encoding="utf-8")
    relative_path = _rel(module)
    findings = find_invented_figures(source, relative_path)
    if relative_path in REVIEWED_FIGURE_INVENTORY:
        _assert_reviewed_figure_source(
            source, relative_path, REVIEWED_FIGURE_INVENTORY[relative_path], findings
        )
        return
    assert not findings, "\n".join(
        ["invented public-finance figures found:", *findings]
    )
