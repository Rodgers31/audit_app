"""Independent read-only review runner; each database is exclusively reviewer owned."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import traceback
from uuid import uuid4

ROOT = Path('/Users/roger/.codex/worktrees/batch10-etl-mappings/audit_app')
OUT = Path(__file__).resolve().parent
BACKEND = ROOT / 'backend'
BASE = 'f6c31e271297eece52f34102dc40a1e2ed7069a8'
RUN = uuid4().hex
RESULT = OUT / ('receipt-' + RUN + '.json')
SOURCES = ['backend/admin_etl_dispatch.py', 'backend/admin_etl_dispatch_adapter.py',
 'backend/admin_etl_dispatch_worker.py', 'backend/models.py', 'backend/seeding/exclusion.py',
 'backend/alembic/versions/e554b10a0001_bounded_dispatch_mappings.py',
 'backend/tests/test_batch10_etl_mappings.py', 'backend/tests/test_batch10_etl_mappings_migration.py',
 'backend/tests/test_batch10_etl_mappings_process.py',
 'backend/tests/batch10_etl_mappings_fixture/owned_postgres.py',
 'backend/tests/batch10_etl_mappings_fixture/sitecustomize.py',
 'backend/seeding/cli.py', 'backend/seeding/registries.py', 'backend/seeding/config.py',
 'docs/admin/implementation/batch10-mappings-evidence/CONTRACT.md']

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True, timeout=15)

def identity():
    return {'head': git('rev-parse', 'HEAD').strip(), 'tree': git('rev-parse', 'HEAD^{tree}').strip(),
            'diff_sha256': hashlib.sha256(git('diff', BASE).encode()).hexdigest(),
            'sources': {p: digest(ROOT / p) for p in SOURCES},
            'status': git('status', '--porcelain')}

record = {'run': RUN, 'command': sys.argv, 'generator_sha256': digest(Path(__file__)),
          'start': identity(), 'started_at': time.time(), 'runtime': sys.version,
          'platform': platform.platform(), 'results': [], 'databases': []}
os.environ['PYTHON_DOTENV_DISABLED'] = '1'
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['DATABASE_URL'] = 'postgresql+psycopg2://batch10_mappings:batch10-inert-local@127.0.0.1:55522/postgres'
for name in list(os.environ):
    if name.startswith('PG'):
        raise RuntimeError('Unexpected ambient PostgreSQL redirect')
os.environ['SEED_STORAGE_PATH'] = str(OUT / RUN / 'storage')
os.environ['SEED_CACHE_PATH'] = str(OUT / RUN / 'cache')
os.environ['SEED_LOG_PATH'] = str(OUT / RUN / 'seed.jsonl')
sys.path[:0] = [str(BACKEND / 'tests'), str(BACKEND)]
from sqlalchemy import create_engine, text
from sqlalchemy.engine import make_url
import sqlalchemy
import pytest
record['sqlalchemy'] = sqlalchemy.__version__
admin = create_engine(os.environ['DATABASE_URL'], isolation_level='AUTOCOMMIT')
active = []

def owned_db():
    name = 'batch10_mappings_standards_' + uuid4().hex
    with admin.connect() as c:
        c.execute(text('CREATE DATABASE "' + name + '"'))
    url = make_url(os.environ['DATABASE_URL']).set(database=name).render_as_string(hide_password=False)
    record['databases'].append({'name': name, 'created': True, 'cleanup': False})
    active.append(name)
    return name, url

def drop(name):
    with admin.connect() as c:
        connections = c.scalar(text('SELECT count(*) FROM pg_stat_activity WHERE datname=:name'), {'name':name})
        if connections != 0:
            raise RuntimeError('Reviewer database retains connections: ' + name)
        c.execute(text('DROP DATABASE "' + name + '"'))
    active.remove(name)
    next(d for d in record['databases'] if d['name'] == name)['cleanup'] = True

def migrate(url, operation, target):
    env = {'PATH': os.environ['PATH'], 'DATABASE_URL': url, 'PYTHON_DOTENV_DISABLED': '1',
           'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': str(BACKEND)}
    command = [sys.executable, '-m', 'alembic', operation, target]
    result = subprocess.run(command, cwd=BACKEND, env=env, capture_output=True, text=True, timeout=90)
    path = OUT / RUN / ('migration-' + uuid4().hex + '.log')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as f:
        f.write('COMMAND: ' + repr(command) + '\n' + result.stdout + result.stderr)
    record.setdefault('migration_commands', []).append({'command':command, 'database':make_url(url).database,
        'exit_code':result.returncode, 'log':str(path), 'sha256':digest(path)})
    return result

def case(label, call):
    start = time.monotonic()
    try:
        call()
    except BaseException:
        record['results'].append({'id':label, 'verdict':'FAILED', 'seconds':time.monotonic()-start, 'traceback':traceback.format_exc()})
        print('FAILED', label, flush=True)
        print(traceback.format_exc(), flush=True)
        return
    record['results'].append({'id':label, 'verdict':'PASSED', 'seconds':time.monotonic()-start})
    print('PASSED', label, flush=True)

try:
    name, url = owned_db()
    os.environ['DATABASE_URL'] = url
    result = migrate(url, 'upgrade', 'head')
    if result.returncode:
        raise RuntimeError(result.stderr)
    import test_batch10_etl_mappings as tests
    import test_batch10_etl_mappings_migration as migrations
    def with_pg(call):
        with pytest.MonkeyPatch.context() as mp:
            fixture = tests.pg.__wrapped__(mp, url)
            pg = next(fixture)
            try:
                call(pg, mp)
            finally:
                fixture.close()
    for source, domain in tests.MAPPINGS.items():
        for dry in (False, True):
            case(f'real_cli[{source},{dry}]', lambda s=source,d=domain,v=dry: with_pg(lambda pg,mp: tests.test_mapping_runs_real_cli_and_correlates_terminal_receipt(pg,s,d,v)))
        for mutation in ('token','generation','command','domain','missing_owner','missing_domain','job'):
            case(f'wrong_claim[{source},{mutation}]', lambda s=source,m=mutation: with_pg(lambda pg,mp: tests.test_wrong_claim_or_job_retains_exact_owner_without_success(pg,s,m)))
        case(f'native_retained_row[{source}]', lambda s=source: with_pg(lambda pg,mp: tests.test_native_admission_honors_retained_dispatch_row_without_shared_claim(pg,s)))
        case(f'concurrent_claimers[{source}]', lambda s=source: with_pg(lambda pg,mp: tests.test_two_claimers_and_native_owner_serialize_exact_domain(pg,s)))
        case(f'lost_ack[{source}]', lambda s=source: with_pg(lambda pg,mp: tests.test_mapping_lost_ack_recovers_one_actor_audit_and_same_intent(pg,mp,s)))
        case(f'auth_default_off[{source}]', lambda s=source: with_pg(lambda pg,mp: tests.test_each_mapping_auth_generation_and_default_off_refuse_no_effect(pg,mp,s)))
    for label,func in [('readiness',tests.test_capabilities_match_each_registered_handler),
                       ('allowlist',tests.test_default_source_selection_and_invalid_shapes),
                       ('handler_loss',tests.test_handler_loss_heartbeat_updates_only_its_capability)]:
        case(label, lambda f=func: with_pg(lambda pg,mp: f(pg,mp)))
    case('independent_progress', lambda: with_pg(lambda pg,mp: tests.test_independent_domains_progress_around_retained_owner(pg)))
    for source in ('treasury','cob','knbs'):
        case(f'source_domain_refusal[{source}]', lambda s=source: with_pg(lambda pg,mp: tests.test_source_domain_database_mismatch_refuses_atomic_acceptance(pg,mp,s)))
    if os.getenv('STANDARDS_IMPORT_CONTROL') == 'true':
        def healthy_ignores_unrelated_import(pg, mp):
            import importlib
            client, factory, engine = pg
            original = importlib.import_module
            def unrelated_broken(name, *args, **kwargs):
                if name == 'seeding.domains.economic_indicators':
                    raise RuntimeError('Reviewer inert unrelated-domain import failure')
                return original(name, *args, **kwargs)
            mp.setattr(importlib, 'import_module', unrelated_broken)
            generation = tests.register_worker(factory)
            capabilities = client.get('/api/v1/admin/etl/dispatch', headers=tests.AUTH).json()
            assert capabilities['sources']['treasury']['available'] is True
            accepted = tests.post(client, generation, 'treasury')
            assert accepted.status_code == 202
            owned = tests.claim(factory, generation)
            result = tests.execute(factory, engine, *owned, generation)
            assert result == 0, 'Advertised healthy mapping failed because of unrelated import: adapter exit=' + str(result)
            assert tests.finish(factory, generation, *owned, result) is True
            with engine.connect() as c:
                assert c.scalar(text('SELECT count(*) FROM batch10_effects')) == 1
        case('healthy_mapping_ignores_unrelated_import', lambda: with_pg(healthy_ignores_unrelated_import))
    # Every migration control gets its own new reviewer database, never an author target.
    for func in (migrations.test_complete_chain_and_empty_round_trip_preserves_private_schema,
                 migrations.test_upgrade_refuses_ready_worker_preserves_old_oag_history,
                 migrations.test_schema_enforces_all_source_domain_pairs_and_downgrade_retains_history):
        child_name, child_url = owned_db()
        engine = create_engine(child_url)
        try:
            case(func.__name__, lambda f=func: f((engine, lambda op,target: migrate(child_url,op,target))))
        finally:
            engine.dispose()
            drop(child_name)
    import database
    database.engine.dispose()
    drop(name)
finally:
    admin.dispose()
    record['end'] = identity()
    record['ended_at'] = time.time()
    record['generator_end_sha256'] = digest(Path(__file__))
    record['source_stable'] = record['start'] == record['end']
    record['remaining_databases'] = active
    with RESULT.open('x') as f:
        json.dump(record, f, indent=2)
    print('RECEIPT', RESULT, flush=True)

if active or not record['source_stable'] or any(r['verdict'] != 'PASSED' for r in record['results']):
    raise SystemExit(1)
