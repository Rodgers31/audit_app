# Independent Standards review — substantive code

**PASS for the frozen substantive code.** No hard documented-standard violations and no actionable Fowler smell findings. The actual committed package still requires a final readback.

Reviewed `git diff f6c31e271297eece52f34102dc40a1e2ed7069a8`, the new mapping tests/fixture/migration, `backend/pytest.ini`, the Batch 8 ownership contract and relevant worker/native/legacy handoffs. No applicable AGENTS.md, CLAUDE.md, CONTRIBUTING, coding-standard document or ADR was found. The full twelve-smell baseline was applied as judgement, excluding tooling-enforced formatting.

The mapping, durable readiness and exact claim/domain checks preserve the documented ownership rules: Batch 8 requires CLI entry to re-prove “the exact claim (kind `dispatch`, domain, command)” and permits “No expiry-based reclaim, deletion or unblock tool.” The additive migration keeps history/private tables, refuses a ready worker and refuses downgrade over new mapping history.

Independent execution reproduced the adversarial readiness defect: an advertised healthy Treasury command failed solely because an unrelated domain import raised. Its retained red has **62 passed / 1 failed**, with the intended diagnostic. The same independent control passes after the bounded adapter loader repair. The loader and CLI session globals restore in `finally`; the real native CLI remains the orchestrator.

Final substantive current and minimum-runtime replays each executed **71 passed**, zero failures/errors/skips/xfails: all 67 repository mapping controls, all 3 migration controls and the independent import control. Real PostgreSQL covered positive/dry-run receipts, safe refusals, exact-owner retention, barrier-thread concurrency, idempotent audit recovery, complete migration-chain/RLS/grants/history and successor admission. Each run retained stable source/generator/HEAD/tree/diff identities and removed four exclusively owned databases after zero-connection checks.

These were in-process real API → worker claim → adapter → native CLI controls. Dedicated supervisor/process death, production pooler, browser, hosted and deployed acceptance were not executed by this reviewer. Details and inventories are in `execution-manifest-code.json`; exact executed generators, consumed sources and raw logs are archived beside it.
