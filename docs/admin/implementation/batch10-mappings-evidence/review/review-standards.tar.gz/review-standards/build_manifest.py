"""Read back exact independent execution archives and logs; no checkout writes."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
RUNS = {'initial-current.log': ('SCOPED_BASELINE', 0),
        'unrelated-import-red.log': ('BEHAVIORAL_RED', 1),
        'repaired-current.log': ('SCOPED_REPAIR_GREEN', 0),
        'final-code-current.log': ('SUBSTANTIVE_CURRENT_ACCEPTANCE', 0),
        'final-code-minimum.log': ('SUBSTANTIVE_MINIMUM_ACCEPTANCE', 0)}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

manifest = {'schema': 1, 'generated_by': str(Path(__file__)), 'generator_sha256': sha(Path(__file__)), 'runs': []}
for log, (purpose, exit_code) in RUNS.items():
    logpath = ROOT / log
    match = re.findall(r'^RECEIPT (.+)$', logpath.read_text(), re.M)
    if len(match) != 1:
        raise ValueError('Expected one receipt in ' + log)
    receipt = Path(match[0])
    data = json.loads(receipt.read_text())
    archive = ROOT / ('archive-' + data['run'])
    if sha(archive / 'executed-generator.py') != data['generator_sha256']:
        raise ValueError('Executed generator mismatch: ' + log)
    for source, expected in data['start']['sources'].items():
        if sha(archive / source) != expected:
            raise ValueError('Archived source mismatch: ' + source)
    if data['start'] != data['end'] or not data['source_stable']:
        raise ValueError('Source drift: ' + log)
    if data['generator_sha256'] != data['generator_end_sha256']:
        raise ValueError('Generator drift: ' + log)
    if data['remaining_databases'] or not all(d['cleanup'] for d in data['databases']):
        raise ValueError('Owned resources retained: ' + log)
    passes = sum(r['verdict'] == 'PASSED' for r in data['results'])
    failures = len(data['results']) - passes
    if failures != (1 if purpose == 'BEHAVIORAL_RED' else 0):
        raise ValueError('Unexpected check counts: ' + log)
    manifest['runs'].append({'purpose': purpose, 'command': data['command'],
        'explicit_environment': {'PYTHON_DOTENV_DISABLED':'1','PYTHONDONTWRITEBYTECODE':'1',
            'STANDARDS_IMPORT_CONTROL': 'true' if any(r['id']=='healthy_mapping_ignores_unrelated_import' for r in data['results']) else None,
            'STANDARDS_REPAIR_CONTROLS':'true' if any('job_claim' in r['id'] for r in data['results']) else None},
        'exit_code': exit_code, 'receipt': receipt.name, 'receipt_sha256':sha(receipt),
        'raw_log':log, 'raw_log_sha256':sha(logpath), 'source_archive':archive.name,
        'executed_generator_sha256':data['generator_sha256'], 'head':data['start']['head'],
        'tree':data['start']['tree'], 'diff_sha256':data['start']['diff_sha256'],
        'source_sha256':data['start']['sources'], 'runtime':data['runtime'],
        'sqlalchemy':data['sqlalchemy'], 'platform':data['platform'], 'passed':passes,
        'failed':failures, 'error':0,'skipped':0,'xfailed':0, 'inventory':[r['id'] for r in data['results']],
        'databases':data['databases'], 'unexecuted':['dedicated supervisor/process death controls',
            'production transaction pooler','admin browser journeys','hosted workflows','deployed acceptance']})
target = ROOT / 'execution-manifest-code.json'
with target.open('x') as f:
    json.dump(manifest, f, indent=2)
print(json.dumps({'manifest':str(target),'runs':len(manifest['runs']),'verdict':'PASSED'}))
