"""Independent hostile-state executions against real dispatch/CLI orchestration."""
import importlib
import json
import os
from pathlib import Path
import socket
from types import SimpleNamespace
from uuid import UUID, uuid4

import pytest
from sqlalchemy import create_engine, select, text
from sqlalchemy.orm import Session, sessionmaker

# Explicit transport fence before application imports; only review DB is reachable.
_original_connect = socket.socket.connect
def _owned_connect(sock, address):
    if not isinstance(address, tuple) or address[:2] != ('127.0.0.1', 55522):
        raise RuntimeError('Unowned transport refused')
    return _original_connect(sock, address)
socket.socket.connect = _owned_connect
assert os.environ['PYTHON_DOTENV_DISABLED'] == '1'
assert '/batch10_mappings_adversarial_' in os.environ['DATABASE_URL']

import database
from admin_etl_dispatch import TriggerBody, accept, capability, mapped, selected_sources
import admin_etl_dispatch_adapter as adapter
from admin_etl_dispatch_worker import claim, finish, heartbeat, register_worker
from models import EtlDispatchCommand, EtlDispatchDomain, EtlDispatchWorker, IngestionJob, SeedingDomainClaim
from seeding.exclusion import DomainExecution, DomainOwnershipError, dispatch_scope, enter_domain
from seeding.registries import REGISTRY, load_builtin_domains
from seeding.types import DomainRunResult

MAPPINGS = {'oag':'audits','treasury':'fiscal_summary','cob':'counties_budget','knbs':'population'}
ACTOR = SimpleNamespace(id='adversarial-admin', email='adversarial@example.invalid')

@pytest.fixture
def pg(monkeypatch):
    engine = create_engine(os.environ['DATABASE_URL'])
    factory = sessionmaker(bind=engine)
    # This UUID-named database is owned exclusively by this reviewer.
    with engine.begin() as c:
        assert c.scalar(text('SELECT current_database()')).startswith('batch10_mappings_adversarial_')
        c.execute(text('TRUNCATE seeding_domain_claims, etl_dispatch_domains, etl_dispatch_commands, etl_dispatch_worker, admin_audit_log, ingestion_jobs RESTART IDENTITY CASCADE'))
        c.execute(text('CREATE TABLE IF NOT EXISTS adversarial_effects(domain text, job_id integer)'))
        c.execute(text('TRUNCATE adversarial_effects'))
    monkeypatch.setenv('ADMIN_ETL_DISPATCH_ENABLED','true')
    monkeypatch.setenv('ADMIN_ETL_DISPATCH_SOURCES',','.join(MAPPINGS))
    monkeypatch.setattr(database,'SessionLocal',factory)
    load_builtin_domains()
    def handler(domain):
        def run(session, settings, context):
            session.execute(text('INSERT INTO adversarial_effects VALUES (:d,:j)'), {'d':domain,'j':context.job_id})
            return DomainRunResult(domain=domain,dry_run=context.dry_run,items_processed=1,items_created=1)
        return run
    monkeypatch.setattr(REGISTRY,'_handlers',{d:handler(d) for d in MAPPINGS.values()})
    try:
        yield factory, engine
    finally:
        engine.dispose()

def accepted(factory,generation,source,dry_run=False):
    with factory() as db:
        return accept(db,ACTOR,source,TriggerBody(dry_run=dry_run,dispatch_generation=str(generation)),str(uuid4())).command.id

def counters(engine):
    with engine.connect() as c:
        return {'effects':c.scalar(text('SELECT count(*) FROM adversarial_effects')),
            'jobs':c.scalar(text('SELECT count(*) FROM ingestion_jobs')),
            'audit':c.scalar(text('SELECT count(*) FROM admin_audit_log')),
            'completed':c.scalar(text("SELECT count(*) FROM etl_dispatch_commands WHERE status='completed'"))}

def exact_owner(factory,command_id,token,domain,allow_missing=False):
    with factory() as db:
        command=db.get(EtlDispatchCommand,command_id)
        row=db.get(EtlDispatchDomain,domain)
        ownership=db.get(SeedingDomainClaim,token)
        assert command.status != 'completed'
        assert row is None if allow_missing else row.command_id==command_id
        assert ownership is None or ownership.released_at is None

@pytest.mark.parametrize('source',MAPPINGS)
@pytest.mark.parametrize('dry_run',[False,True])
def test_positive_control_real_native_cli(pg,source,dry_run):
    factory,engine=pg
    generation=register_worker(factory)
    identity=accepted(factory,generation,source,dry_run)
    owned=claim(factory,generation)
    assert owned[0]==identity
    assert adapter.execute(factory,engine,*owned,generation)==0
    assert finish(factory,generation,*owned,0) is True
    assert counters(engine)['effects']==(0 if dry_run else 1)
    with factory() as db:
        assert db.get(EtlDispatchCommand,identity).status=='completed'
        assert db.get(SeedingDomainClaim,owned[1]).released_at is not None

@pytest.mark.parametrize('source',MAPPINGS)
@pytest.mark.parametrize('target',['missing_domain','missing_owner','domain_token','domain_command','ownership_domain','ownership_command','worker_generation','worker_expired','command_token','command_generation','command_started'])
def test_adapter_wrong_durable_state_refuses_effect(pg,source,target):
    factory,engine=pg
    generation=register_worker(factory)
    identity=accepted(factory,generation,source)
    owned=claim(factory,generation)
    with engine.begin() as c:
        values={'id':identity,'token':owned[1],'other':uuid4(),'d':MAPPINGS[source]}
        mutations={
            'missing_domain':('DELETE FROM etl_dispatch_domains WHERE domain=:d',values),
            'missing_owner':('DELETE FROM seeding_domain_claims WHERE id=:token',values),
            'domain_token':('UPDATE etl_dispatch_domains SET claim_token=:other WHERE domain=:d',values),
            'ownership_domain':("UPDATE seeding_domain_claims SET domain='unrelated' WHERE id=:token",values),
            'worker_generation':('UPDATE etl_dispatch_worker SET generation=:other',values),
            'worker_expired':("UPDATE etl_dispatch_worker SET last_seen_at=clock_timestamp()-interval '2 seconds',expires_at=clock_timestamp()-interval '1 second'",values),
            'command_token':('UPDATE etl_dispatch_commands SET claim_token=:other WHERE id=:id',values),
            'command_generation':('UPDATE etl_dispatch_commands SET generation=:other WHERE id=:id',values),
            'command_started':('UPDATE etl_dispatch_commands SET execution_started=true WHERE id=:id',values)}
        if target in ('domain_command','ownership_command'):
            other=accepted(factory,generation,source)
            values['other']=other
            query=('UPDATE etl_dispatch_domains SET command_id=:other WHERE domain=:d' if target=='domain_command' else 'UPDATE seeding_domain_claims SET command_id=:other WHERE id=:token')
        else:
            query,values=mutations[target]
        c.execute(text(query),values)
    assert adapter.execute(factory,engine,*owned,generation)==1
    assert counters(engine)['effects']==0
    assert counters(engine)['jobs']==0
    # Unentered exact claim may be safely failed/released only if every identity remains exact.
    result=finish(factory,generation,*owned,0)
    with factory() as db:
        command=db.get(EtlDispatchCommand,identity)
        assert command.status!='completed'
        if target in ('missing_domain','missing_owner','domain_token','domain_command','ownership_domain','ownership_command','worker_generation','worker_expired','command_token','command_generation'):
            ownership=db.get(SeedingDomainClaim,owned[1])
            assert ownership is None or ownership.released_at is None
        else:
            assert result is True and command.status=='failed'

@pytest.mark.parametrize('source',MAPPINGS)
@pytest.mark.parametrize('target',['job_domain','job_dry_run','job_token','job_command','job_claim','job_count_negative','job_count_null','job_errors_nonlist','job_errors_present','job_finished_missing','job_finish_before_start','owner_job','owner_domain','owner_command','owner_missing'])
def test_terminal_mutations_never_certify_completed_or_release(pg,source,target):
    factory,engine=pg
    generation=register_worker(factory)
    identity=accepted(factory,generation,source)
    owned=claim(factory,generation)
    assert adapter.execute(factory,engine,*owned,generation)==0
    with factory() as db:
        job_id=db.get(SeedingDomainClaim,owned[1]).job_id
    with engine.begin() as c:
        p={'job':job_id,'token':owned[1],'other':str(uuid4())}
        sql={
            'job_domain':"UPDATE ingestion_jobs SET domain='unrelated' WHERE id=:job",
            'job_dry_run':"UPDATE ingestion_jobs SET dry_run=true WHERE id=:job",
            'job_token':"UPDATE ingestion_jobs SET metadata=jsonb_set(metadata,'{dispatch_claim_token}',to_jsonb(CAST(:other AS text))) WHERE id=:job",
            'job_command':"UPDATE ingestion_jobs SET metadata=jsonb_set(metadata,'{dispatch_command_id}',to_jsonb(CAST(:other AS text))) WHERE id=:job",
            'job_claim':"UPDATE ingestion_jobs SET metadata=jsonb_set(metadata,'{seeding_claim_id}',to_jsonb(CAST(:other AS text))) WHERE id=:job",
            'job_count_negative':"UPDATE ingestion_jobs SET items_created=-1 WHERE id=:job",
            'job_count_null':"UPDATE ingestion_jobs SET items_created=NULL WHERE id=:job",
            'job_errors_nonlist':"UPDATE ingestion_jobs SET errors='{}'::jsonb WHERE id=:job",
            'job_errors_present':"UPDATE ingestion_jobs SET errors='[\"private detail\"]'::jsonb WHERE id=:job",
            'job_finished_missing':"UPDATE ingestion_jobs SET finished_at=NULL WHERE id=:job",
            'job_finish_before_start':"UPDATE ingestion_jobs SET finished_at=started_at-interval '1 second' WHERE id=:job",
            'owner_job':"UPDATE seeding_domain_claims SET job_id=:other WHERE id=:token",
            'owner_domain':"UPDATE seeding_domain_claims SET domain='unrelated' WHERE id=:token",
            'owner_command':"UPDATE seeding_domain_claims SET command_id=:other WHERE id=:token",
            'owner_missing':"DELETE FROM seeding_domain_claims WHERE id=:token"}[target]
        if target=='job_count_null':
            # Real storage rejects this malformed state; keep it a storage control.
            with pytest.raises(Exception):
                with c.begin_nested():c.execute(text(sql),p)
            return
        if target=='owner_job':
            c.execute(text("INSERT INTO ingestion_jobs(domain,status,dry_run,started_at,finished_at,items_processed,items_created,items_updated,errors,metadata) VALUES ('unrelated','COMPLETED',false,now(),now(),0,0,0,'[]','{}')"))
            p['other']=c.scalar(text('SELECT max(id) FROM ingestion_jobs'))
        elif target=='owner_command':
            p['other']=accepted(factory,generation,source)
        c.execute(text(sql),p)
    result=finish(factory,generation,*owned,0)
    with factory() as db:
        command=db.get(EtlDispatchCommand,identity)
        ownership=db.get(SeedingDomainClaim,owned[1])
        print(json.dumps({'attack':target,'source':source,'finish':result,'status':command.status,'released':None if ownership is None else str(ownership.released_at)}))
        assert result is False
        assert command.status!='completed'
        assert ownership is None or ownership.released_at is None

@pytest.mark.parametrize('source',MAPPINGS)
def test_missing_handler_stale_durable_readiness_refuses_runtime(pg,source,monkeypatch):
    factory,engine=pg
    generation=register_worker(factory)
    identity=accepted(factory,generation,source)
    owned=claim(factory,generation)
    monkeypatch.delitem(REGISTRY._handlers,MAPPINGS[source])
    assert adapter.execute(factory,engine,*owned,generation)==1
    assert counters(engine)['effects']==0
    assert finish(factory,generation,*owned,1) is True
    with factory() as db:
        assert db.get(EtlDispatchCommand,identity).status=='failed'
    assert heartbeat(factory,generation) is True
    with factory() as db:
        assert capability(db).sources[source].available is False

@pytest.mark.parametrize('source',MAPPINGS)
@pytest.mark.parametrize('mutation',['source_mismatch','source_unsupported'])
def test_corrupted_mapping_refuses_claim_adapter_and_native_scope(pg,source,mutation):
    factory,engine=pg
    generation=register_worker(factory)
    identity=accepted(factory,generation,source)
    with engine.begin() as c:
        # Confirm production mapping constraint prevents this state first.
        with pytest.raises(Exception):
            with c.begin_nested():
                c.execute(text("UPDATE etl_dispatch_commands SET source='cra' WHERE id=:id"),{'id':identity})
        c.execute(text('ALTER TABLE etl_dispatch_commands DROP CONSTRAINT ck_etl_dispatch_mapping'))
    try:
        with engine.begin() as c:
            c.execute(text('UPDATE etl_dispatch_commands SET source=:s WHERE id=:id'),{'s': 'cra' if mutation=='source_unsupported' else next(s for s in MAPPINGS if s!=source),'id':identity})
        assert claim(factory,generation) is None
        with engine.begin() as c:
            c.execute(text('UPDATE etl_dispatch_commands SET source=:s WHERE id=:id'),{'s':source,'id':identity})
        owned=claim(factory,generation)
        with engine.begin() as c:
            c.execute(text('UPDATE etl_dispatch_commands SET source=:s WHERE id=:id'),{'s':'cra' if mutation=='source_unsupported' else next(s for s in MAPPINGS if s!=source),'id':identity})
        assert adapter.execute(factory,engine,*owned,generation)==1
        assert finish(factory,generation,*owned,0) is False
        # Direct real native entry receives an otherwise valid execution object.
        with engine.begin() as c:
            c.execute(text('UPDATE etl_dispatch_commands SET execution_started=true WHERE id=:id'),{'id':identity})
        scope=DomainExecution(factory,MAPPINGS[source],owned[1],identity,generation)
        scope.open()
        try:
            with dispatch_scope(scope), pytest.raises(DomainOwnershipError,match='scope invalid'):
                enter_domain(factory,MAPPINGS[source],False)
        finally:scope.close()
        assert counters(engine)['effects']==0
        exact_owner(factory,*owned,MAPPINGS[source])
    finally:
        with engine.begin() as c:
            c.execute(text('UPDATE etl_dispatch_commands SET source=:s WHERE id=:id'),{'s':source,'id':identity})
            c.execute(text("ALTER TABLE etl_dispatch_commands ADD CONSTRAINT ck_etl_dispatch_mapping CHECK ((source='oag' AND domain='audits') OR (source='treasury' AND domain='fiscal_summary') OR (source='cob' AND domain='counties_budget') OR (source='knbs' AND domain='population'))"))

@pytest.mark.parametrize('source',MAPPINGS)
@pytest.mark.parametrize('mutation',['wrong_generation','wrong_domain','wrong_engine','wrong_class','already_entered','entry_nonce','wrong_dry_run','integer_dry_run','unstarted'])
def test_forged_native_scope_never_enters(pg,source,mutation):
    factory,engine=pg
    generation=register_worker(factory)
    identity=accepted(factory,generation,source)
    owned=claim(factory,generation)
    if mutation!='unstarted':
        with engine.begin() as c:c.execute(text('UPDATE etl_dispatch_commands SET execution_started=true WHERE id=:id'),{'id':identity})
    scope=DomainExecution(factory,MAPPINGS[source],owned[1],identity,generation)
    scope.open()
    other_engine=None
    try:
        dry_run=False
        if mutation=='wrong_generation':scope.generation=uuid4()
        elif mutation=='wrong_domain':scope.domain='unrelated'
        elif mutation=='wrong_engine':
            other_engine=create_engine(os.environ['DATABASE_URL']);scope.engine=other_engine
        elif mutation=='wrong_class':scope=SimpleNamespace(**scope.__dict__)
        elif mutation=='already_entered':scope.entered=True
        elif mutation=='entry_nonce':scope.entry=uuid4()
        elif mutation=='wrong_dry_run':dry_run=True
        elif mutation=='integer_dry_run':dry_run=0
        with dispatch_scope(scope), pytest.raises(DomainOwnershipError,match='scope invalid'):
            enter_domain(factory,MAPPINGS[source],dry_run)
    finally:
        # wrong_class exposes connection only; close that owned lock directly.
        if type(scope) is DomainExecution:scope.close()
        elif scope.connection is not None:scope.connection.rollback();scope.connection.close()
        if other_engine:other_engine.dispose()
    with factory() as db:
        owner=db.get(SeedingDomainClaim,owned[1]);assert owner.entered_at is None and owner.released_at is None
    assert counters(engine)['effects']==0

@pytest.mark.parametrize('broken',['population','audits','national_debt'])
def test_import_failure_does_not_disable_healthy_advertised_treasury(pg,monkeypatch,broken):
    factory,engine=pg
    original=importlib.import_module
    def fail_one(name,*args,**kwargs):
        if name=='seeding.domains.'+broken:
            raise RuntimeError('Independent inert domain import failure')
        return original(name,*args,**kwargs)
    monkeypatch.setattr(importlib,'import_module',fail_one)
    generation=register_worker(factory)
    with factory() as db:
        caps=capability(db)
        assert caps.sources['treasury'].available is True
        if broken=='population':assert caps.sources['knbs'].available is False
        if broken=='audits':assert caps.sources['oag'].available is False
    identity=accepted(factory,generation,'treasury')
    owned=claim(factory,generation)
    exit_code=adapter.execute(factory,engine,*owned,generation)
    final_result=finish(factory,generation,*owned,exit_code)
    with factory() as db:
        final_status=db.get(EtlDispatchCommand,identity).status
    print(json.dumps({'broken_import':broken,'treasury_capability':True,'adapter_exit':exit_code,'finish':final_result,'final_status':final_status,**counters(engine)}))
    assert exit_code==0, 'Healthy advertised mapping blocked by unrelated domain import failure'
    assert final_status=='completed'
    assert counters(engine)['effects']==1
