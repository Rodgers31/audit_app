"""Verify a completed independent-review record, including actual JUnit verdict."""
import argparse,hashlib,json,sys
from pathlib import Path
import xml.etree.ElementTree as ET

def h(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def require(value,diagnostic):
    if not value:raise ValueError(diagnostic)
def verify(run,current=False):
    run=Path(run).resolve()
    rec=json.loads((run/'manifest.json').read_text())
    require(rec['generator_sha256']==h(Path(rec['generated_by'])),'generator hash mismatch')
    require(rec['test_generator_sha256']==h(Path(rec['test_generator'])),'test generator hash mismatch')
    require(rec['cleanup_exit']==0,'owned resource cleanup failed')
    require(len(rec['outputs'])>0,'output inventory empty')
    for name,expected in rec['outputs'].items():
        path=run/name
        require(path.parent==run and path.is_file(),'output absent/escaped: '+name)
        require(h(path)==expected,'output hash mismatch: '+name)
    before=json.loads((run/'source-before.json').read_text())
    after=json.loads((run/'source-after.json').read_text())
    require(len(before)>0,'source inventory empty')
    diff={p:{'before':v,'after':after.get(p)} for p,v in before.items() if after.get(p)!=v}
    require(diff==rec['source_drift'],'source drift record mismatch')
    require(set(before)==set(after),'source inventory identity mismatch')
    junit=ET.parse(run/'junit.xml').getroot()
    suites=list(junit.iter('testsuite'))
    totals={key:sum(int(s.attrib.get(key,'0')) for s in suites) for key in ['tests','failures','errors','skipped']}
    require(totals['tests']>0,'zero executed tests')
    expected_exit=1 if totals['failures'] or totals['errors'] else 0
    require(rec['child_exit']==expected_exit,'child verdict contradicts JUnit')
    expected_verdict='FAIL' if expected_exit or diff else 'PASS'
    require(rec['verification_verdict']==expected_verdict,'verification verdict contradicts recorded execution')
    for cmd in rec['commands']:
        require(h(run/cmd['log'])==cmd['log_sha256'],'command log identity mismatch')
    require(rec['identity']['head']=='f6c31e271297eece52f34102dc40a1e2ed7069a8' or len(rec['identity']['head'])==40,'invalid source HEAD')
    if current:
        target=Path(rec['target'])
        for name,digest in before.items():
            require((target/name).is_file() and h(target/name)==digest,'current source differs: '+name)
    return {'record_valid':True,'behavior_verdict':expected_verdict,'counts':totals,'current_source_checked':current,'source_inventory_count':len(before)}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('run');parser.add_argument('--current-source',action='store_true');args=parser.parse_args()
    try:
        result=verify(args.run,args.current_source)
        print(json.dumps(result));return 0
    except Exception as e:
        print(json.dumps({'record_valid':False,'reason':str(e)}));return 1
if __name__=='__main__':sys.exit(main())
