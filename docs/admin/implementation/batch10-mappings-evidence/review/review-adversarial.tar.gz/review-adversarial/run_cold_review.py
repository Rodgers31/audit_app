"""Exclusive reviewer DB/provenance wrapper; immutable fresh result directories."""
import hashlib,json,os,platform,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
from uuid import uuid4
ROOT=Path(__file__).resolve().parent
SOURCE=Path('/Users/roger/.codex/worktrees/batch10-etl-mappings/audit_app')
BACKEND=SOURCE/'backend'
NAME='batch10_mappings_adversarial_'+uuid4().hex
OUT=ROOT/('run-'+uuid4().hex)
OUT.mkdir()
URL='postgresql+psycopg2://batch10_mappings:batch10-inert-local@127.0.0.1:55522/'+NAME
ENV={'PATH':'/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin','PYTHONPATH':str(BACKEND),'PYTHONDONTWRITEBYTECODE':'1','PYTHON_DOTENV_DISABLED':'1','DATABASE_URL':URL,'SEED_STORAGE_PATH':str(OUT/'storage'),'SEED_CACHE_PATH':str(OUT/'cache'),'SEED_LOG_PATH':str(OUT/'seed.jsonl')}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=SOURCE,text=True).strip()
paths=set(p for p in SOURCE.rglob('*.py') if not any(x in p.parts for x in ['node_modules','.git','.venv','venv']))
paths |= set(p for p in (BACKEND/'tests/batch10_etl_mappings_fixture').rglob('*') if p.is_file())
paths |= set(p for p in (SOURCE/'docs/admin/implementation/batch10-mappings-evidence').rglob('*') if p.is_file())
paths |= {BACKEND/'alembic.ini'}
before={str(p.relative_to(SOURCE)):sha(p) for p in sorted(paths)}
identity={'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--short'),'diff_sha256':hashlib.sha256(git('diff','f6c31e271297eece52f34102dc40a1e2ed7069a8').encode()).hexdigest()}
(OUT/'source-before.json').write_text(json.dumps(before,indent=2))
(OUT/'diff.patch').write_text(git('diff','f6c31e271297eece52f34102dc40a1e2ed7069a8'))
records=[]
def run(args,filename,cwd=None,env=None,timeout=120):
    start=datetime.now(timezone.utc).isoformat()
    with (OUT/filename).open('xb') as f:
        result=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    records.append({'command':args,'cwd':str(cwd) if cwd else None,'start':start,'end':datetime.now(timezone.utc).isoformat(),'exit':result.returncode,'log':filename,'log_sha256':sha(OUT/filename)})
    return result.returncode
cleanup=None
try:
    assert run(['docker','inspect','--format','{{.Id}} {{.Name}} {{.Config.Image}} {{json .NetworkSettings.Ports}}','batch10-mappings-postgres'],'container.txt')==0
    assert run(['docker','exec','batch10-mappings-postgres','psql','-U','batch10_mappings','-d','postgres','-v','ON_ERROR_STOP=1','-c','CREATE DATABASE '+NAME],'create-db.txt')==0
    assert run([sys.executable,'-c',"from alembic.config import Config;from alembic import command;command.upgrade(Config('alembic.ini'),'head')"],'migrate.txt',BACKEND,ENV)==0
    assert run([sys.executable,'-c',"import platform,sqlalchemy,psycopg2;from sqlalchemy import create_engine,text;e=create_engine(__import__('os').environ['DATABASE_URL']);print(platform.platform(),platform.python_version(),sqlalchemy.__version__,psycopg2.__version__);print(e.connect().execute(text('SELECT current_database(),current_user,version()')).one())"],'runtime.txt',BACKEND,ENV)==0
    args=[sys.executable,'-m','pytest',str(ROOT/'test_cold_import.py'),'-vv','-s','--tb=short','-p','no:cacheprovider','--basetemp',str(OUT/'pytest-temp'),'--junitxml',str(OUT/'junit.xml')]
    if len(sys.argv)>1:args.extend(sys.argv[1:])
    child_exit=run(args,'pytest.txt',BACKEND,ENV,timeout=300)
finally:
    cleanup=run(['docker','exec','batch10-mappings-postgres','psql','-U','batch10_mappings','-d','postgres','-v','ON_ERROR_STOP=1','-c','DROP DATABASE IF EXISTS '+NAME+' WITH (FORCE)'],'drop-db.txt')
    after={str(p.relative_to(SOURCE)):sha(p) if p.exists() else None for p in sorted(paths)}
    drift={p:{'before':h,'after':after.get(p)} for p,h in before.items() if after.get(p)!=h}
    (OUT/'source-after.json').write_text(json.dumps(after,indent=2))
    receipt={'generated_by':str(Path(__file__)),'generator_sha256':sha(Path(__file__)),'test_generator':str(ROOT/'test_cold_import.py'),'test_generator_sha256':sha(ROOT/'test_cold_import.py'),'generated_at':datetime.now(timezone.utc).isoformat(),'target':str(SOURCE),'identity':identity,'runtime':{'python':sys.version,'platform':platform.platform()},'database':NAME,'owned_container':'batch10-mappings-postgres','container_owned_by_author':True,'commands':records,'child_exit':locals().get('child_exit'),'cleanup_exit':cleanup,'source_drift':drift,'verification_verdict':'FAIL' if drift or cleanup or locals().get('child_exit') else 'PASS','outputs':{p.name:sha(p) for p in OUT.iterdir() if p.is_file()}}
    with (OUT/'manifest.json').open('x') as f:json.dump(receipt,f,indent=2)
    read=json.loads((OUT/'manifest.json').read_text())
    assert read['generator_sha256']==sha(Path(__file__)) and read['verification_verdict']==receipt['verification_verdict']
    print(json.dumps({'output':str(OUT),'child_exit':locals().get('child_exit'),'drift':list(drift),'cleanup_exit':cleanup}))
