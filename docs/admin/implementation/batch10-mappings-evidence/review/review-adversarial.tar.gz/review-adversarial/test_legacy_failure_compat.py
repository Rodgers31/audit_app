"""Bounded historical OAG failure exception must never become completion or affect another source."""
import json
from uuid import uuid4
import pytest
from sqlalchemy import text
from test_adversarial import pg, accepted, MAPPINGS
from admin_etl_dispatch_worker import register_worker, claim, finish
from admin_etl_dispatch_adapter import execute
from models import EtlDispatchCommand, SeedingDomainClaim

@pytest.mark.parametrize('source',MAPPINGS)
@pytest.mark.parametrize('status',['COMPLETED','FAILED','COMPLETED_WITH_ERRORS'])
@pytest.mark.parametrize('mutation',['absent','null','wrong'])
def test_legacy_missing_vs_conflicting_job_claim(pg,source,status,mutation):
    factory,engine=pg
    generation=register_worker(factory)
    identity=accepted(factory,generation,source)
    owned=claim(factory,generation)
    assert execute(factory,engine,*owned,generation)==0
    with factory() as db:job=db.get(SeedingDomainClaim,owned[1]).job_id
    with engine.begin() as c:
        c.execute(text('UPDATE ingestion_jobs SET status=:status WHERE id=:job'),{'status':status,'job':job})
        if mutation=='absent':query="UPDATE ingestion_jobs SET metadata=metadata-'seeding_claim_id' WHERE id=:job"
        elif mutation=='null':query="UPDATE ingestion_jobs SET metadata=jsonb_set(metadata,'{seeding_claim_id}','null'::jsonb) WHERE id=:job"
        else:query="UPDATE ingestion_jobs SET metadata=jsonb_set(metadata,'{seeding_claim_id}',to_jsonb(CAST(:wrong AS text))) WHERE id=:job"
        c.execute(text(query),{'job':job,'wrong':str(uuid4())})
    returned=finish(factory,generation,*owned,0)
    expected=(source=='oag' and mutation=='absent' and status!='COMPLETED')
    with factory() as db:
        command=db.get(EtlDispatchCommand,identity)
        owner=db.get(SeedingDomainClaim,owned[1])
        print(json.dumps({'source':source,'status':status,'mutation':mutation,'finish':returned,'command_status':command.status,'owner_released':owner.released_at is not None}))
        assert returned is expected
        assert command.status!='completed'
        assert (owner.released_at is not None) is expected
        if expected:assert command.status=='failed'
