"""Honest readiness policy when an actual shared native CLI prerequisite is absent."""
import importlib.abc
import json
import sys
from uuid import uuid4
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
import supabase_auth
from routers import etl_admin
from test_adversarial import pg, accepted, counters
from admin_etl_dispatch import capability
from admin_etl_dispatch_worker import register_worker, claim
from admin_etl_dispatch_adapter import execute
from models import EtlDispatchCommand

@pytest.mark.parametrize('error',[RuntimeError,ModuleNotFoundError])
def test_cold_shared_prerequisite_refuses_every_source_acceptance(pg,error,monkeypatch):
    factory,engine=pg
    monkeypatch.setattr(supabase_auth,'_decode_supabase_jwt',lambda token:{'sub':'adversarial-admin'})
    monkeypatch.setattr(supabase_auth,'_fetch_roles',lambda uid:('adversarial@example.invalid',['admin']))
    app=FastAPI();app.include_router(etl_admin.router)
    client=TestClient(app)
    prefix='seeding.domains.audits'
    cached={key:value for key,value in sys.modules.items() if key==prefix or key.startswith(prefix+'.')}
    import seeding.domains
    old_attribute=vars(seeding.domains).get('audits')
    for key in cached:sys.modules.pop(key)
    vars(seeding.domains).pop('audits',None)
    class BrokenAuditPackage(importlib.abc.MetaPathFinder):
        def find_spec(self,fullname,path=None,target=None):
            if fullname==prefix or fullname.startswith(prefix+'.'):
                raise error('Independent inert cold audits import failure')
            return None
    blocker=BrokenAuditPackage();sys.meta_path.insert(0,blocker)
    try:
        generation=register_worker(factory)
        with factory() as db:caps=capability(db)
        assert caps.available is False
        assert caps.generation is None and caps.worker.status=='unavailable'
        assert not any(v.available for v in caps.sources.values())
        refused={}
        for source in caps.sources:
            response=client.post('/api/v1/admin/etl/trigger/'+source,
                headers={'Authorization':'Bearer adversarial-admin','Idempotency-Key':str(uuid4())},
                json={'dry_run':False,'dispatch_generation':str(generation)})
            refused[source]=response.status_code
            assert response.status_code==503,response.text
            assert response.headers['cache-control']=='private, no-store'
            assert response.headers['vary']=='Authorization'
            assert 'cold audits' not in response.text and 'RuntimeError' not in response.text
        public=client.get('/api/v1/admin/etl/dispatch',headers={'Authorization':'Bearer adversarial-admin'})
        assert public.status_code==200 and public.json()['available'] is False
        assert not any(s['available'] for s in public.json()['sources'].values())
        assert claim(factory,generation) is None
        assert execute(factory,engine,uuid4(),uuid4(),generation)==1
        with factory() as db:assert db.query(EtlDispatchCommand).count()==0
        counts=counters(engine)
        assert counts=={'effects':0,'jobs':0,'audit':0,'completed':0}
        print(json.dumps({'import_error':error.__name__,'available':caps.available,'refused':refused,**counts}))
    finally:
        client.close()
        sys.meta_path.remove(blocker)
        for key in list(sys.modules):
            if key==prefix or key.startswith(prefix+'.'):sys.modules.pop(key)
        sys.modules.update(cached)
        if old_attribute is not None:seeding.domains.audits=old_attribute
