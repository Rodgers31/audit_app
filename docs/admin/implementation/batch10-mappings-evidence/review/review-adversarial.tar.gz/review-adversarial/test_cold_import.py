"""Cold import state: unavailable audit package also blocks Python from-import."""
import importlib.abc
import json
import sys
import pytest
from test_adversarial import pg, accepted, counters, MAPPINGS
from admin_etl_dispatch import capability
from admin_etl_dispatch_worker import register_worker, claim, finish
from admin_etl_dispatch_adapter import execute
from models import EtlDispatchCommand

@pytest.mark.parametrize('error',[RuntimeError,ModuleNotFoundError])
def test_cold_unavailable_audits_cannot_leave_treasury_falsely_ready(pg,error):
    factory,engine=pg
    # Remove only the audits subtree to reproduce a package that failed to load
    # in a fresh worker/adapter. Retained handlers stay inert; no product changes.
    prefix='seeding.domains.audits'
    cached={key:value for key,value in sys.modules.items() if key==prefix or key.startswith(prefix+'.')}
    import seeding.domains
    old_attribute=vars(seeding.domains).get('audits')
    for key in cached:sys.modules.pop(key)
    vars(seeding.domains).pop('audits',None)
    class BrokenAuditPackage(importlib.abc.MetaPathFinder):
        def find_spec(self,fullname,path=None,target=None):
            if fullname==prefix or fullname.startswith(prefix+'.'):
                raise error('Independent inert cold audits import failure')
            return None
    blocker=BrokenAuditPackage();sys.meta_path.insert(0,blocker)
    try:
        generation=register_worker(factory)
        with factory() as db:
            caps=capability(db)
            assert caps.sources['treasury'].available is True
            assert caps.sources['oag'].available is False
        identity=accepted(factory,generation,'treasury')
        owned=claim(factory,generation)
        code=execute(factory,engine,*owned,generation)
        finished=finish(factory,generation,*owned,code)
        with factory() as db:status=db.get(EtlDispatchCommand,identity).status
        print(json.dumps({'import_error':error.__name__,'treasury_ready':True,'oag_ready':False,'adapter_exit':code,'finish':finished,'status':status,**counters(engine)}))
        assert code==0,'Unconditional audits.scope import defeats bounded Treasury readiness'
        assert status=='completed'
    finally:
        sys.meta_path.remove(blocker)
        for key in list(sys.modules):
            if key==prefix or key.startswith(prefix+'.'):sys.modules.pop(key)
        sys.modules.update(cached)
        if old_attribute is not None:seeding.domains.audits=old_attribute
