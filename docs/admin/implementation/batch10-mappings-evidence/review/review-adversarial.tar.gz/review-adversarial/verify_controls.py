"""Execute normal/-O integrity refusal controls without touching retained evidence."""
import hashlib,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
from uuid import uuid4
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'run-83d1e383cbfa46f79f55aef64af4a4c8'
OUT=ROOT/('verifier-controls-'+uuid4().hex);OUT.mkdir()
records=[]
for optimized in [False,True]:
    args=[sys.executable]+(['-O'] if optimized else [])+[str(ROOT/'verify_review.py')]
    p=subprocess.run(args+[str(SOURCE)],capture_output=True,text=True,timeout=20)
    if p.returncode!=0:raise RuntimeError('valid historical record refused: '+p.stdout)
    records.append({'optimized':optimized,'case':'historical_failed_record','exit':p.returncode,'output':p.stdout.strip()})
    for attack in ['verdict','output','source_inventory']:
        copied=OUT/('copy-'+attack+('-optimized' if optimized else '-normal'));copied.mkdir()
        # Only immutable top-level files are consumed by the verifier.
        for original in SOURCE.iterdir():
            if original.is_file():shutil.copyfile(original,copied/original.name)
        if attack=='verdict':
            path=copied/'manifest.json';rec=json.loads(path.read_text());rec['verification_verdict']='PASS';path.write_text(json.dumps(rec))
        elif attack=='output':
            with (copied/'pytest.txt').open('a') as f:f.write('adversarial output tampering\n')
        else:
            path=copied/'source-after.json';rec=json.loads(path.read_text());rec[next(iter(rec))]='0'*64;path.write_text(json.dumps(rec))
        p=subprocess.run(args+[str(copied)],capture_output=True,text=True,timeout=20)
        if p.returncode!=1:raise RuntimeError('tampered record certified: '+p.stdout)
        records.append({'optimized':optimized,'case':attack,'exit':p.returncode,'output':p.stdout.strip()})
receipt={'generated_by':str(Path(__file__)),'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'verifier_sha256':hashlib.sha256((ROOT/'verify_review.py').read_bytes()).hexdigest(),'tested_record':str(SOURCE),'record_sha256':hashlib.sha256((SOURCE/'manifest.json').read_bytes()).hexdigest(),'controls':records,'verdict':'PASS'}
with (OUT/'receipt.json').open('x') as f:json.dump(receipt,f,indent=2)
check=json.loads((OUT/'receipt.json').read_text())
if check['generator_sha256']!=receipt['generator_sha256'] or check['verdict']!='PASS':raise RuntimeError('receipt readback mismatch')
print(json.dumps({'output':str(OUT),'controls':len(records),'verdict':'PASS'}))
