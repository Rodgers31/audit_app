import importlib.abc
import sys
from uuid import UUID
from test_batch10_etl_mappings import pg, mapping_url, post, AUTH

def test_healthy_treasury_runs_when_audit_package_import_fails(pg, monkeypatch):
    from admin_etl_dispatch_worker import register_worker, claim
    from admin_etl_dispatch_adapter import execute
    client, factory, engine = pg
    for name in tuple(sys.modules):
        if name == 'seeding.domains.audits' or name.startswith('seeding.domains.audits.'):
            monkeypatch.delitem(sys.modules, name)
    class MissingAuditPackage(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path, target=None):
            if fullname == 'seeding.domains.audits' or fullname.startswith('seeding.domains.audits.'):
                raise ImportError('inert actual audit package import failure')
    monkeypatch.setattr(sys, 'meta_path', [MissingAuditPackage(), *sys.meta_path])
    generation = register_worker(factory)
    capability = client.get('/api/v1/admin/etl/dispatch', headers=AUTH).json()
    assert capability['sources']['treasury']['available'] is True
    assert capability['sources']['oag']['available'] is False
    accepted = post(client,generation,'treasury')
    assert accepted.status_code == 202, accepted.text
    owned=claim(factory,generation)
    assert owned[0]==UUID(accepted.json()['command']['id'])
    result=execute(factory,engine,*owned,generation)
    assert result==0, 'unconditional audits.scope import defeated advertised healthy Treasury mapping'
