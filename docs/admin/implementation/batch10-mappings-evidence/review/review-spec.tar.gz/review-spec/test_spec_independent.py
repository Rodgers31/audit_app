from uuid import UUID
from sqlalchemy import text
from test_batch10_etl_mappings import pg, mapping_url, post, AUTH

def test_healthy_mapping_runs_despite_other_mapping_import_failure(pg, monkeypatch):
    import importlib
    from seeding.registries import REGISTRY
    from admin_etl_dispatch_worker import register_worker, claim, finish
    from admin_etl_dispatch_adapter import execute
    client, factory, engine = pg
    original = importlib.import_module
    def import_with_missing_domain(name, *args, **kwargs):
        if name == 'seeding.domains.population':
            raise RuntimeError('inert population import failure')
        return original(name, *args, **kwargs)
    monkeypatch.delitem(REGISTRY._handlers, 'population')
    monkeypatch.setattr(importlib, 'import_module', import_with_missing_domain)
    generation = register_worker(factory)
    capability = client.get('/api/v1/admin/etl/dispatch', headers=AUTH).json()
    assert capability['sources']['treasury']['available'] is True
    assert capability['sources']['knbs']['available'] is False
    accepted = post(client, generation, 'treasury')
    assert accepted.status_code == 202, accepted.text
    owned = claim(factory, generation)
    assert owned[0] == UUID(accepted.json()['command']['id'])
    result = execute(factory, engine, *owned, generation)
    assert result == 0, 'advertised healthy treasury refused because unrelated population import broke real CLI'
    assert finish(factory, generation, *owned, result)
    with engine.connect() as c:
        assert c.scalar(text('SELECT count(*) FROM batch10_effects')) == 1
