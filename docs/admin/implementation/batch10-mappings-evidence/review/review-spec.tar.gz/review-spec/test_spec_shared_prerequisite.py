import importlib.abc
import sys
from sqlalchemy import text
from test_batch10_etl_mappings import pg, mapping_url, post, AUTH

def test_capability_refuses_when_real_cli_shared_scope_is_unimportable(pg, monkeypatch):
    from admin_etl_dispatch_worker import register_worker
    client, factory, engine = pg
    for name in tuple(sys.modules):
        if name == 'seeding.domains.audits' or name.startswith('seeding.domains.audits.'):
            monkeypatch.delitem(sys.modules, name)
    class MissingAuditPackage(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path, target=None):
            if fullname == 'seeding.domains.audits' or fullname.startswith('seeding.domains.audits.'):
                raise ImportError('inert actual audit package import failure')
    monkeypatch.setattr(sys, 'meta_path', [MissingAuditPackage(), *sys.meta_path])
    generation = register_worker(factory)
    capability = client.get('/api/v1/admin/etl/dispatch', headers=AUTH).json()
    assert capability['available'] is False, 'real CLI shared prerequisite unavailable but execution advertised ready'
    assert all(entry['available'] is False for entry in capability['sources'].values())
    for source in ('oag', 'treasury', 'cob', 'knbs'):
        response=post(client,generation,source)
        assert response.status_code==503, response.text
        assert 'ImportError' not in response.text and 'inert actual' not in response.text
        assert response.headers['cache-control']=='private, no-store'
    with engine.connect() as c:
        for name in ('etl_dispatch_commands','admin_audit_log','ingestion_jobs','batch10_effects'):
            assert c.scalar(text('SELECT count(*) FROM '+name))==0
