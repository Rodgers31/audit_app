from pathlib import Path
import hashlib,json
here=Path(__file__).resolve()
record={'generated_by':str(here),'generator_sha256':hashlib.sha256(here.read_bytes()).hexdigest(),'classification':'setup failure; no behavior executed','original_command':'/Users/roger/.codex/worktrees/batch10-etl-mappings/venv/bin/python '+str(here.parent/'run_spec.py'),'original_exit':127,'original_raw_tool_output':'zsh:102: no such file or directory: /Users/roger/.codex/worktrees/batch10-etl-mappings/venv/bin/python\n','subsequent_correction':'Used author external evidence runtime; no installation or checkout write','original_tool_chunk_id':'043d47'}
p=here.parent/'setup-attempt-missing-runtime.json'
with p.open('x') as f:json.dump(record,f,indent=2)
if json.loads(p.read_text())!=record:raise RuntimeError('receipt mismatch')
