import os
import pytest

@pytest.hookimpl(tryfirst=True)
def pytest_fixture_setup(fixturedef, request):
    if fixturedef.argname == 'mapping_url':
        value = os.environ['SPEC_MAPPING_URL']
        fixturedef.cached_result = (value, fixturedef.cache_key(request), None)
        return value
