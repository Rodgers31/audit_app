from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve(); OUT=HERE.parent
names=['run-fad3ffbf-57ce-46df-a15c-0312ec7ee230','run-92757f6b-450b-42d9-b134-5e55929a62b5','run-d2f2e387-f124-4661-b5ce-479d313fdcc8','run-35ca12e7-b7ae-411f-858d-17cfdcee3855']
records=[json.loads((OUT/n/'receipt.json').read_text()) for n in names]
for r in records:
 if not r['source_unchanged'] or r['verdict']!='passed':raise RuntimeError('unverified control cannot accept')
 for c in r['commands']:
  p=Path(c['log'])
  if c['exit']!=0 or hashlib.sha256(p.read_bytes()).hexdigest()!=c['log_sha256']:raise RuntimeError('invalid child/output')
 p=Path(r['generated_by'])
 if hashlib.sha256(p.read_bytes()).hexdigest()!=r['generator_sha256']:raise RuntimeError('orphaned generator')
DEST=OUT/'prepublication';DEST.mkdir()
report='''# Spec review — repaired candidate, before publication

**No unresolved scoped Spec defects in the frozen candidate.** The requirement “available source capabilities must match runtime readiness/real mapping” exposed two real readiness mismatches. The first independent red showed unrelated population import failure defeating advertised healthy Treasury execution. The bounded adapter loader now runs the real CLI for only the validated domain. A second cold-import red showed that `audits.scope` is a real shared CLI prerequisite. Readiness now verifies the actual CLI/config/scope imports and disables every source when this common prerequisite fails; missing registry handlers still disable only their own source. Both exact behavioral refusal/execution controls now pass.

**Mappings are bounded and honest.** Treasury→fiscal_summary includes Treasury/CoB/CBK; CoB→counties_budget excludes national budget and pending bills; KNBS→population includes KNBS census plus World Bank national series and explicitly lists Extraction/file/cache persistence. Existing frontend capability rendering derives this scope from API reasons. No financial handlers, publication policy, default-off activation, or workflow settings changed.

**The parent remains partial.** The assignment permits unavailable mappings “Where a source has no supported real native entrypoint.” OpenData and CRA remain unavailable with specific reasons and prerequisite #602. They are not implemented mapping successes. Deployed operator/admin acceptance, activation, and every-writer production gate #583 remain unexecuted coordinator requirements; #554 stays open.

Independent current and minimum execution: 117 repository mapping cases plus the independent loader control (118 passed), then the precise shared-prerequisite refusal control (1 passed), on each runtime; zero failures/errors/skips/xfails. Each run used a fresh full-chain-migrated UUID PostgreSQL database, real API/worker/adapter/native CLI orchestration with inert handlers, and exact owned cleanup. This includes all 48 tag-shape/status cases. OAG compatibility admits only absent legacy tags on failed/error receipts with exact durable owner/job/acknowledgment proofs; explicit null/empty/wrong tags always refuse, and completed/new-domain receipts require the exact tag.

Unexecuted independently: process death/restart cohort, role/RLS adversarial cohort, browser, hosted/production acceptance, and final published-package replay. The final evidence corpus/commit still needs its scheduled recheck.
'''
p=DEST/'SPEC.md'
with p.open('x') as f:f.write(report)
manifest={'generated_by':str(HERE),'generator_sha256':hashlib.sha256(HERE.read_bytes()).hexdigest(),'report_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'verdict':'No unresolved scoped Spec defects; prepublication only','runs':[{'receipt':str(OUT/n/'receipt.json'),'receipt_sha256':hashlib.sha256((OUT/n/'receipt.json').read_bytes()).hexdigest(),'runtime':r['runtime'],'sqlalchemy':r['sqlalchemy'],'source_head':r['before']['HEAD'],'source_tree':r['before']['tree'],'diff_sha256':r['before']['diff_sha256'],'cleanup':r['cleanup']} for n,r in zip(names,records)],'historical_reports':[str(OUT/'SPEC.md')],'history_classification':'Original reds, failed setup, and earlier repair pass receipts remain unchanged and historical; current acceptance binds only the four listed executed runs.'}
p=DEST/'manifest.json'
with p.open('x') as f:json.dump(manifest,f,indent=2)
if json.loads(p.read_text())!=manifest:raise RuntimeError('manifest readback failed')
print(str(DEST/'SPEC.md'))
print([(r['runtime'].split()[0],r['sqlalchemy']) for r in records])
