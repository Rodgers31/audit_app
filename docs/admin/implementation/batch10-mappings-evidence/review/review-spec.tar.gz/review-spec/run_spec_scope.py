import hashlib, json, os, pathlib, platform, subprocess, sys, time
from uuid import uuid4
OUT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('/Users/roger/.codex/worktrees/batch10-etl-mappings/audit_app')
BACKEND = REPO/'backend'
BASE = 'f6c31e271297eece52f34102dc40a1e2ed7069a8'
RUN = 'run-'+str(uuid4())
DEST = OUT/RUN
DEST.mkdir()
DATABASE = 'batch10_mappings_spec_'+uuid4().hex
URL = 'postgresql+psycopg2://batch10_mappings:batch10-inert-local@127.0.0.1:55522/'+DATABASE
CONTROL = 'postgresql+psycopg2://batch10_mappings:batch10-inert-local@127.0.0.1:55522/postgres'
ENV = {'PATH':os.environ['PATH'], 'DATABASE_URL':URL, 'SPEC_MAPPING_URL':URL, 'PYTHON_DOTENV_DISABLED':'1', 'PYTHONDONTWRITEBYTECODE':'1', 'PYTHONPATH':os.pathsep.join([str(OUT),str(BACKEND/'tests'),str(BACKEND)]), 'SEED_STORAGE_PATH':str(DEST/'storage'), 'SEED_CACHE_PATH':str(DEST/'cache'), 'SEED_LOG_PATH':str(DEST/'seed.jsonl')}
def git(*args):
    return subprocess.check_output(['git',*args],cwd=REPO,text=True).strip()
paths = list(BACKEND.rglob('*.py')) + [BACKEND/'alembic.ini'] + list((REPO/'docs/admin/implementation/batch10-mappings-evidence').rglob('*'))
paths = [p for p in paths if p.is_file() and '.pytest_cache' not in p.parts and '__pycache__' not in p.parts]
def snapshot():
    return {'HEAD':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain=v1'),'diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff',BASE],cwd=REPO)).hexdigest(),'sources':{str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None for p in paths}}
record={'generated_by':str(pathlib.Path(__file__).resolve()),'generator_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'helpers':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [OUT/'spec_fixture_plugin.py',OUT/'test_spec_shared_scope.py']},'runtime':sys.version,'platform':platform.platform(),'started':time.time(),'database':DATABASE,'before':snapshot(),'commands':[]}
from sqlalchemy import create_engine, text, __version__
record['sqlalchemy']=__version__
control=create_engine(CONTROL,isolation_level='AUTOCOMMIT')
created=False
try:
    with control.connect() as c:
        identity=c.execute(text('SELECT current_database(),current_user,version()')).one()
        if identity[:2] != ('postgres','batch10_mappings'): raise RuntimeError('wrong fixture identity')
        record['server']=list(identity)
        c.execute(text('CREATE DATABASE "'+DATABASE+'"'))
        created=True
    commands=[('migration',[sys.executable,'-c',"from alembic.config import Config; from alembic import command; command.upgrade(Config('alembic.ini'),'head')"]),('cohort',[sys.executable,'-m','pytest','-p','spec_fixture_plugin','-p','no:cacheprovider','--basetemp',str(DEST/'tmp'),'--junitxml',str(DEST/'junit.xml'),str(OUT/'test_spec_shared_scope.py'),'-vv'])]
    for name,command in commands:
        log=DEST/(name+'.log')
        with log.open('xb') as output:
            child=subprocess.run(command,cwd=BACKEND,env=ENV,stdout=output,stderr=subprocess.STDOUT,timeout=120)
        record['commands'].append({'name':name,'command':command,'exit':child.returncode,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
        if name == 'migration' and child.returncode: break
finally:
    if created:
        with control.connect() as c:
            sessions=c.scalar(text('SELECT count(*) FROM pg_stat_activity WHERE datname=:d'),{'d':DATABASE})
            record['remaining_sessions_before_drop']=sessions
            if sessions: raise RuntimeError('child DB sessions still alive')
            c.execute(text('DROP DATABASE "'+DATABASE+'"'))
            if c.scalar(text('SELECT count(*) FROM pg_database WHERE datname=:d'),{'d':DATABASE}):raise RuntimeError('cleanup not complete')
            record['cleanup']='exact owned database dropped'
    control.dispose()
    record['after']=snapshot();record['finished']=time.time()
    record['source_unchanged']=record['before']==record['after']
    record['verdict']='passed' if record['source_unchanged'] and all(c['exit']==0 for c in record['commands']) else 'failed'
    receipt=DEST/'receipt.json'
    with receipt.open('x') as f:json.dump(record,f,indent=2)
    if json.loads(receipt.read_text())!=record:raise RuntimeError('receipt readback failed')
print(str(DEST))
print(record['verdict'])
