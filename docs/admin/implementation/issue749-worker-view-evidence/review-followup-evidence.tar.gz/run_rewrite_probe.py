"""Replay exact collected fixture on final source; all engines intercepted."""
from pathlib import Path
import os,sys,subprocess,json
r=Path(__file__).resolve().parent;c=Path('/Users/roger/.codex/worktrees/batch14-release/audit_app');records=[]
for optimized in (False,True):
 for mode in ('positive','wrong_database','wrong_schema','publishing_on'):
  label='final-'+mode+('-optimized' if optimized else '-normal');result=r/(label+'.json')
  env={'PATH':os.environ['PATH'],'PYTHONPATH':str(r)+':'+str(c/'backend')+':'+str(c/'backend/tests/social'),'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','B17_REVIEW_MODE':mode,'B17_REVIEW_RESULT':str(result),'B17_REPORT_ROLE_TEST_DB_URL':'postgresql+psycopg2://postgres@127.0.0.1:55439/b17_view_clean'}
  argv=[sys.executable]+(['-O'] if optimized else [])+['-m','pytest','-p','no:cacheprovider','-p','rewrite_probe_plugin','--confcutdir=backend/tests','backend/tests/social/test_report_authority_historical_schema.py::test_actual_login_accepts_reviewed_view_without_financial_access','-q','--tb=short']
  p=subprocess.run(argv,cwd=c,env=env,capture_output=True,text=True,timeout=30);(r/(label+'.log')).write_text(p.stdout+p.stderr);observed=json.loads(result.read_text())
  if not observed['fixture_assert_rewritten']:raise RuntimeError('ASSERT_REWRITE_NOT_ACTIVE')
  ok=(p.returncode==0 and observed['install_calls']==1 and observed['verify_calls']==2) if mode=='positive' else (p.returncode==1 and observed['install_calls']==0 and observed['verify_calls']==0)
  records.append({'mode':mode,'optimized':optimized,'argv':argv,'exit_code':p.returncode,'result':observed,'passed':ok})
  if not ok:raise RuntimeError(records[-1])
(r/'assert-rewrite-proof-final.json').write_text(json.dumps({'scope':'Exact collected final fixture with fake-only engines and actual default pytest rewriting','passed':len(records),'total':len(records),'records':records},indent=2)+'\n')
print(json.dumps({'passed':len(records),'total':len(records),'classification':'Inline optimization-removes-asserts claim REFUTED on final source'}))
