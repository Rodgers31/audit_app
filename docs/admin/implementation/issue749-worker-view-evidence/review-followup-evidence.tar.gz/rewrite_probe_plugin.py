"""Fake every engine at test setup; execute actual collected fixture/test bytes."""
import atexit,dis,hashlib,json,os,sys
from pathlib import Path
r={'mode':os.environ['B17_REVIEW_MODE'],'optimized':bool(sys.flags.optimize),'install_calls':0,'verify_calls':0,'queries':[],'engine_disposes':0}
class Denied(Exception):
 def __init__(self):self.orig=type('Original',(),{'pgcode':'42501'})()
class Conn:
 def __init__(self,worker):self.worker=worker
 def __enter__(self):return self
 def __exit__(self,*args):pass
 def scalar(self,q):
  q=str(q);r['queries'].append(q)
  if 'current_database' in q:return 'incorrect_database' if r['mode']=='wrong_database' else 'b17_view_clean'
  if 'version_num' in q:return 'wrong_revision' if r['mode']=='wrong_schema' else 'e621b17a0001'
  if 'publishing_enabled' in q:return r['mode']=='publishing_on'
  raise RuntimeError('UNEXPECTED_FAKE_SCALAR')
 def execute(self,q):
  q=str(q);r['queries'].append(q)
  if q=='SELECT * FROM social_report_source_authority':return []
  raise Denied()
class Engine:
 def __init__(self,worker):self.worker=worker
 def begin(self):return Conn(self.worker)
 def dispose(self):r['engine_disposes']+=1

def pytest_runtest_setup(item):
 m=item.module
 if m.__name__!='test_report_authority_historical_schema':raise RuntimeError('WRONG_TARGET_MODULE')
 body=m.historical_report_role.__wrapped__
 r['fixture_assert_rewritten']='@pytest_ar' in body.__code__.co_names
 r['source_sha256']=hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()
 m.create_engine=lambda *args,**kwargs:Engine(False)
 m.create_worker_engine=lambda *args,**kwargs:Engine(True)
 def install(*args,**kwargs):r['install_calls']+=1
 def verify(*args,**kwargs):r['verify_calls']+=1
 m.install_worker_role=install;m.verify_worker_role=verify
atexit.register(lambda:Path(os.environ['B17_REVIEW_RESULT']).write_text(json.dumps(r,indent=2)+'\n'))
