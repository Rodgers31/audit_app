"""Minimum cached runtime, exact loopback proxy, only owned fixture databases."""
import hashlib,json,os,platform,socket,socketserver,threading,subprocess,sys
from pathlib import Path
import sqlalchemy,pytest
ROOT=Path('/Users/roger/.codex/worktrees/batch14-release/audit_app');OUT=Path('/evidence')
if sys.version_info[:2]!=(3,12) or sqlalchemy.__version__!='2.0.23':raise RuntimeError('WRONG_MINIMUM_RUNTIME')
(OUT/'versions.json').write_text(json.dumps({'python':sys.version,'sqlalchemy':sqlalchemy.__version__,'pytest':pytest.__version__,'entry_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
class Forward(socketserver.BaseRequestHandler):
 def handle(self):
  with socket.create_connection(('127.0.0.1',5432)) as upstream:
   def pump(source,destination):
    try:
     while data:=source.recv(65536):destination.sendall(data)
    except OSError:pass
    finally:
     try:destination.shutdown(socket.SHUT_WR)
     except OSError:pass
   t=threading.Thread(target=pump,args=(self.request,upstream),daemon=True);t.start();pump(upstream,self.request);t.join(5)
class Proxy(socketserver.ThreadingTCPServer):
 allow_reuse_address=True;daemon_threads=True
results=[]
with Proxy(('127.0.0.1',55439),Forward) as server:
 t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
 try:
  for optimized in (False,True):
   for kind in ('clean','historical'):
    label=kind+('-optimized' if optimized else '-normal');env=dict(os.environ);env['B17_REPORT_ROLE_TEST_DB_URL']='postgresql+psycopg2://postgres@127.0.0.1:55439/b17_view_'+kind
    argv=[sys.executable]+(['-O'] if optimized else [])+['-B','-m','pytest','-p','no:cacheprovider','--confcutdir=backend/tests','backend/tests/social/test_report_authority_historical_schema.py','-q','--tb=short','--junitxml='+str(OUT/(label+'.xml')),'--basetemp=/tmp/'+label]
    with (OUT/(label+'.log')).open('xb') as log:p=subprocess.run(argv,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    results.append({'argv':argv,'exit_code':p.returncode,'label':label})
    if p.returncode:raise RuntimeError('FORMAL_MINIMUM_FAILED:'+label)
  for optimized in (False,True):
   label='cpu-'+('optimized' if optimized else 'normal')
   argv=[sys.executable]+(['-O'] if optimized else [])+['-B','-m','pytest','-p','no:cacheprovider','--confcutdir=backend/tests','backend/tests/social/test_report_authority_view_contract.py','backend/tests/social/test_platform_worker_role_contract.py','-q','--tb=short','--junitxml='+str(OUT/(label+'.xml')),'--basetemp=/tmp/'+label]
   with (OUT/(label+'.log')).open('xb') as log:p=subprocess.run(argv,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=120)
   results.append({'argv':argv,'exit_code':p.returncode,'label':label})
   if p.returncode:raise RuntimeError('CPU_MINIMUM_FAILED:'+label)
 finally:
  server.shutdown();t.join(5)
  (OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
