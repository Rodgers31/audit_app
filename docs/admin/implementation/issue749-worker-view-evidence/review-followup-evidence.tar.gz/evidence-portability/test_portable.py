import ast,fcntl,hashlib,json,os,pathlib,subprocess,sys,tempfile,unittest
from unittest.mock import patch
ROOT=pathlib.Path('/Users/roger/.codex/worktrees/batch14-release/audit_app')
SCRIPT=ROOT/'docs/admin/implementation/issue749-worker-view-evidence/replay_owned_views.py'
class Portable(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='b17-portable-cpu-');self.addCleanup(self.tmp.cleanup)
  self.out=pathlib.Path(self.tmp.name);self.lock=self.out/'shared.lock';self.lock.touch()
 def run_cli(self,*argv,env=None):
  return subprocess.run([sys.executable,*(['-O'] if not __debug__ else []),str(SCRIPT),*argv],text=True,capture_output=True,env=env,timeout=10)
 def args(self,path=None):return ['--output',str(path or self.out/'fresh'),'--heavy-lock',str(self.lock)]
 def test_check_input_success_has_no_output_side_effect(self):
  p=self.run_cli(*self.args(),'--check-inputs');self.assertEqual(p.returncode,0,p.stderr)
  self.assertEqual(json.loads(p.stdout)['status'],'INPUTS_VALID_NO_EXECUTION');self.assertFalse((self.out/'fresh').exists())
 def test_reject_existing_output_preserves_bytes(self):
  dest=self.out/'existing';dest.mkdir();(dest/'marker').write_text('retain')
  p=self.run_cli(*self.args(dest),'--check-inputs');self.assertNotEqual(p.returncode,0);self.assertEqual((dest/'marker').read_text(),'retain')
 def test_reject_output_inside_checkout(self):
  p=self.run_cli(*self.args(SCRIPT.parent/'unwanted-output'),'--check-inputs');self.assertNotEqual(p.returncode,0);self.assertIn('OUTPUT_MUST_BE_OUTSIDE_CHECKOUT',p.stderr)
 def test_reject_checkout_ancestor_output(self):
  p=self.run_cli(*self.args(ROOT.parent),'--check-inputs');self.assertNotEqual(p.returncode,0)
 def test_reject_missing_lock(self):
  p=self.run_cli('--output',str(self.out/'fresh'),'--heavy-lock',str(self.out/'absent'),'--check-inputs');self.assertNotEqual(p.returncode,0)
 def test_reject_unknown_remote_dsn_argument(self):
  p=self.run_cli(*self.args(),'--database-url','postgresql://remote.invalid/db');self.assertNotEqual(p.returncode,0);self.assertIn('unrecognized arguments',p.stderr)
 def test_reject_check_inputs_child_combination(self):
  p=self.run_cli(*self.args(),'--check-inputs','--child');self.assertNotEqual(p.returncode,0);self.assertIn('cannot be combined',p.stderr)
 def test_reject_direct_child_before_any_database(self):
  dest=self.out/'child';dest.mkdir()
  env={'PATH':os.environ['PATH']}
  p=self.run_cli(*self.args(dest),'--child',env=env);self.assertNotEqual(p.returncode,0);self.assertIn('CHILD_REQUIRES_OWNED_CONTAINER',p.stderr)
 def test_missing_image_is_explicit_prerequisite_never_pull(self):
  fake=self.out/'docker';trace=self.out/'docker-calls';fake.write_text('#!'+sys.executable+'\nimport pathlib,sys\npathlib.Path('+repr(str(trace))+').write_text(" ".join(sys.argv[1:]))\nraise SystemExit(1)\n');fake.chmod(0o700)
  p=self.run_cli(*self.args(),env={'PATH':str(self.out)})
  self.assertEqual(p.returncode,77,p.stderr);self.assertIn('SKIP_PREREQUISITE',p.stdout)
  self.assertEqual(trace.read_text(),'image inspect public.ecr.aws/docker/library/postgres@sha256:2d2b8998d31037bf721cfdf764d76ba74171b4fab3431b7f72c27c56ddbdf9e3')
  self.assertFalse((self.out/'fresh').exists())
 def test_source_snapshot_changes_when_actual_source_bytes_change(self):
  # Execute the actual snapshot function against an inert controlled source tree.
  tree=ast.parse(SCRIPT.read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='source_snapshot')
  fake=self.out/'repo';(fake/'backend').mkdir(parents=True);source=fake/'backend/code.py';source.write_text('a=1\n')
  ns={'CHECKOUT':fake,'subprocess':subprocess,'hashlib':hashlib};exec(compile(ast.Module(body=[node],type_ignores=[]),str(SCRIPT),'exec'),ns)
  with patch.object(subprocess,'check_output',return_value='backend/code.py\n'):
   before=ns['source_snapshot']();source.write_text('a=2\n');after=ns['source_snapshot']()
  self.assertNotEqual(before,after)
 def test_archive_bytes_match_preserved_original_manifest(self):
  folder=SCRIPT.parent;original=json.loads((folder/'artifact-sha256.historical.json').read_text())
  for name,digest in original.items():
   path=folder/('README.historical.md' if name=='README.md' else name)
   self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),digest,name)
 def fake_docker(self,body):
  fake=self.out/'docker';fake.write_text('#!'+sys.executable+'\n'+body);fake.chmod(0o700)
  return {'PATH':str(self.out)+os.pathsep+os.environ['PATH']}
 def test_busy_shared_lock_never_starts_or_creates_output(self):
  env=self.fake_docker('raise SystemExit(0)\n')
  with self.lock.open('r+') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
   p=self.run_cli(*self.args(),env=env)
  self.assertNotEqual(p.returncode,0);self.assertIn('HEAVY_SLOT_BUSY_NO_START',p.stderr);self.assertFalse((self.out/'fresh').exists())
 def test_container_start_failure_removes_only_created_owned_fixture(self):
  trace=self.out/'calls.json'
  body='import json,pathlib,sys\np=pathlib.Path('+repr(str(trace))+')\nc=json.loads(p.read_text()) if p.exists() else []\nc.append(sys.argv[1:]);p.write_text(json.dumps(c))\na=sys.argv[1:]\nif a[0]=="create":print("a"*64)\nraise SystemExit(1 if a[0] in {"start","inspect"} else 0)\n'
  p=self.run_cli(*self.args(),env=self.fake_docker(body));self.assertNotEqual(p.returncode,0)
  calls=json.loads(trace.read_text());self.assertEqual([a[0] for a in calls],['image','create','start','rm','ps'])
  names=[a[-1] for a in calls if a[0] in {'start','rm','inspect'}];self.assertEqual(len(set(names)),1);self.assertTrue(names[0].startswith('b17-portable-view-'))
  self.assertEqual(json.loads((self.out/'fresh/cleanup.json').read_text()),{'status':'VERIFIED','container_absent':True,'tmpfs_removed':True,'successful_exact_id_listing_empty':True})
  self.assertFalse((self.out/'fresh/result.json').exists())
 def test_cleanup_daemon_error_never_certifies_absence(self):
  body='import sys\na=sys.argv[1:]\nif a[0]=="create":print("a"*64)\nif a[0] in {"start","inspect","ps"}:print("Docker daemon unavailable",file=sys.stderr);raise SystemExit(1)\n'
  p=self.run_cli(*self.args(),env=self.fake_docker(body));self.assertNotEqual(p.returncode,0)
  receipt=json.loads((self.out/'fresh/cleanup.json').read_text())
  self.assertIsNone(receipt['container_absent']);self.assertIsNone(receipt['tmpfs_removed']);self.assertEqual(receipt['status'],'UNVERIFIED')
  self.assertFalse((self.out/'fresh/result.json').exists())
 def test_child_wrong_port_ownership_refuses_before_database(self):
  dest=self.out/'child';dest.mkdir();(dest/'owner.json').write_text(json.dumps({'container_id':'a'*64,'nonce':'inert','controller_sha256':hashlib.sha256(SCRIPT.read_bytes()).hexdigest()}))
  info=[{'Id':'a'*64,'Config':{'Labels':{'auditgava.issue749':'inert'}},'HostConfig':{'PortBindings':{'5432/tcp':[{'HostIp':'0.0.0.0','HostPort':'55439'}]},'Tmpfs':{'/var/lib/postgresql/data':''}}}]
  env=self.fake_docker('print('+repr(json.dumps(info))+')\n');env['B17_PORTABLE_OWNED_CONTAINER']='b17-portable-view-fake'
  p=self.run_cli(*self.args(dest),'--child',env=env)
  self.assertNotEqual(p.returncode,0);self.assertIn('CHILD_CONTAINER_OWNERSHIP_MISMATCH',p.stderr)
if __name__=='__main__':unittest.main(verbosity=2)
