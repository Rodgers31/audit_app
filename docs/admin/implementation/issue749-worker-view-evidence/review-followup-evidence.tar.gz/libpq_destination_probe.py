"""No database: inert ephemeral loopback TCP listener, no server auth request."""
import json,socket,threading,os,psycopg2
from pathlib import Path
results=[]
for explicit in (False,True):
 with socket.socket() as listener:
  listener.bind(('127.0.0.1',0));listener.listen();listener.settimeout(2)
  port=listener.getsockname()[1];seen=[]
  def accept():
   try:
    conn,peer=listener.accept()
    with conn:seen.append(True)
   except socket.timeout:pass
  t=threading.Thread(target=accept);t.start()
  envvalue=os.environ.get('PGHOSTADDR');os.environ['PGHOSTADDR']='127.0.0.1'
  try:
   kwargs={'host':'127.0.0.2','port':port,'user':'inert_probe','dbname':'inert_probe','connect_timeout':1,'sslmode':'disable'}
   if explicit:kwargs['hostaddr']='127.0.0.2'
   try:psycopg2.connect(**kwargs)
   except psycopg2.OperationalError:pass
  finally:
   if envvalue is None:os.environ.pop('PGHOSTADDR',None)
   else:os.environ['PGHOSTADDR']=envvalue
   t.join(3)
  if bool(seen)==explicit:raise RuntimeError('LIBPQ_OVERRIDE_PROBE_FAILED')
  results.append({'explicit_hostaddr':explicit,'nominal_host':'127.0.0.2','inert_environment_hostaddr':'127.0.0.1','inert_alternate_listener_contacted':bool(seen),'real_database_or_credentials_used':False})
Path(__file__).with_suffix('.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'result':'PGHOSTADDR overrides nominal host; explicit hostaddr prevents override','cases':results}))
