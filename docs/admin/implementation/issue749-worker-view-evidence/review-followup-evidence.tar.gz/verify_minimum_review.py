"""Owned cached PG17 replay of documented prebaseline physical column order."""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,subprocess,sys,time,traceback
ROOT=Path(__file__).resolve().parent
CHECKOUT=Path('/Users/roger/.codex/worktrees/batch14-release/audit_app')
BACKEND=CHECKOUT/'backend'
OUT=ROOT/'minimum-final-review'
OUT.mkdir(exist_ok=True)
LOCK=ROOT.parent.parent/'HEAVY_TEST.lock'
if '--child' in sys.argv:
 from sqlalchemy import create_engine,text
 from sqlalchemy.orm import Session
 sys.path[:0]=[str(BACKEND)]
 from social.worker import role_contract as rc
 from social.models import SocialControls
 record={}
 production=json.loads((ROOT.parent/'production-view-diagnostic.json').read_text())
 for kind in ('clean','historical'):
  url='postgresql+psycopg2://postgres@127.0.0.1:55439/b17_view_'+kind
  env={'PATH':os.environ['PATH'],'PYTHONPATH':str(BACKEND),'DATABASE_URL':url}
  def upgrade(target):
   p=subprocess.run([sys.executable,'-m','alembic','upgrade',target],cwd=BACKEND,env=env,capture_output=True,text=True,timeout=90)
   (OUT/(kind+'-'+target+'.log')).write_text(p.stdout+p.stderr)
   if p.returncode:raise RuntimeError('MIGRATION_FAILED:'+kind+':'+target)
  upgrade('21d0394c1d6b')
  e=create_engine(url,pool_size=2,max_overflow=0)
  if kind=='historical':
   with e.begin() as c:
    if c.scalar(text('SELECT count(*) FROM budget_lines'))!=0:raise RuntimeError('NONEMPTY_REORDER_REFUSED')
    c.execute(text('ALTER TABLE budget_lines DROP COLUMN source_hash'))
    c.execute(text('ALTER TABLE budget_lines ADD COLUMN validation_warnings jsonb'))
    c.execute(text('ALTER TABLE budget_lines ADD COLUMN source_hash varchar(64)'))
    c.execute(text('ALTER TABLE budget_lines ADD COLUMN confidence_score numeric(3,2)'))
  upgrade('e621b17a0001')
  with Session(e) as db:db.add(SocialControls(id=1,publishing_enabled=False));db.commit()
  observed={}
  with e.begin() as c:
   observed['server_version']=c.scalar(text('SHOW server_version'))
   observed['columns']=list(c.scalars(text("SELECT attname FROM pg_attribute WHERE attrelid='budget_lines'::regclass AND attnum>0 AND NOT attisdropped ORDER BY attnum")))
   observed['views']=[]
   for name in rc.REPORT_VIEW_SHA256:
    definition=c.scalar(text('SELECT pg_get_viewdef(to_regclass(:name),true)'),{'name':name})
    for clause in ('FROM ','JOIN '):definition=definition.replace(clause+'"public".',clause).replace(clause+'public.',clause)
    digest=hashlib.sha256(definition.encode()).hexdigest()
    observed['views'].append(dict(name=name,definition=definition,digest=digest,expected=rc.REPORT_VIEW_SHA256[name]))
   try:rc._views(c,'public');observed['views_guard']='PASS'
   except rc.WorkerRoleError:observed['views_guard']='REFUSED'
  role='b17_view_'+kind
  with e.begin() as c:c.execute(text('CREATE ROLE '+role+' LOGIN NOINHERIT NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS CONNECTION LIMIT 2'))
  try:rc.install_worker_role(e,role);observed['install']='PASS'
  except rc.WorkerRoleError:observed['install']='REFUSED'
  worker=create_engine(e.url.set(username=role),pool_size=1,max_overflow=0)
  frames=[]
  def trace(frame,event,arg):
   if event=='exception' and frame.f_code.co_filename.endswith('role_contract.py') and isinstance(arg[1],rc.WorkerRoleError):frames.append({'function':frame.f_code.co_name,'line':frame.f_lineno})
   return trace
  sys.settrace(trace)
  try:rc.verify_worker_role(worker,role);observed['verify']='PASS'
  except rc.WorkerRoleError:observed['verify']='REFUSED'
  finally:sys.settrace(None)
  observed['failure_frames']=frames
  worker.dispose();e.dispose();record[kind]=observed
  (OUT/'partial.json').write_text(json.dumps(record,indent=2)+'\n')
 if any(record[k][gate]!='PASS' for k in ('clean','historical') for gate in ('views_guard','install','verify')):raise RuntimeError('GREEN_CONTROL_FAILED')
 wanted={v['relname']:v['normalized_sha256'] for v in production['views']}
 if {x['name']:x['digest'] for x in record['historical']['views']}!=wanted:raise RuntimeError('PRODUCTION_HASH_NOT_REPRODUCED')
 record['result']='ACCEPTS_EXACT_REVIEWED_CLEAN_AND_HISTORICAL_SCHEMAS'
 image='sha256:fdf77fbd6b0e7a0e4ab205cc98e4ce2f0bbbd73f60b1876c3fb3d7c032a13650'
 floor=Path('/Users/roger/.cache/uv/archive-v0/oBp-RAK809E42Chi')
 sdk=Path('/Users/roger/.codex/visualizations/2026/10/13/01a13546-5f5a-7973-925e-a8a2c3aedb7c/ENGINEERING_BATCH_14/media/runtime/lib/python3.13/site-packages')
 required=[floor/'sqlalchemy',floor/'SQLAlchemy-2.0.23.dist-info']+[sdk/x for x in ('boto3','botocore','jmespath','s3transfer','dateutil','urllib3','six.py','dotenv')]
 if not all(p.exists() for p in required):raise RuntimeError('MINIMUM_CACHE_PREREQUISITE_MISSING_NO_INSTALL')
 subprocess.run(['docker','image','inspect',image],check=True,stdout=subprocess.DEVNULL)
 client='b17-historical-minimum-'+str(os.getpid());output=OUT/'client';output.mkdir()
 env={'PYTHONDONTWRITEBYTECODE':'1','PYTHON_DOTENV_DISABLED':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONPATH':'/overlay:'+str(BACKEND)+':'+str(BACKEND/'tests')+':'+str(BACKEND/'tests/social'),'DATABASE_URL':'postgresql+psycopg2://inert:inert@127.0.0.1:1/inert','TESTING':'true','APP_ENV':'test'}
 for flag in ('SOCIAL_NATIVE_ENABLED','SOCIAL_MEDIA_ENABLED','SOCIAL_GENERATION_HOOK_ENABLED','SOCIAL_REPORT_GENERATION_ENABLED','SOCIAL_POLICY_AUTOMATION_ENABLED'):env[flag]='false'
 argv=['docker','run','--pull=never','--rm','--name',client,'--network','container:'+os.environ['B17_OWNED_PG_NAME'],'--read-only','--memory','1536m','--cpus','2','--tmpfs','/tmp:rw,nosuid,nodev,size=128m','--mount',f'type=bind,src={CHECKOUT},dst={CHECKOUT},readonly','--mount',f'type=bind,src={output},dst=/evidence','--mount',f'type=bind,src={ROOT/"minimum_review_entry.py"},dst=/entry.py,readonly','--workdir',str(CHECKOUT)]
 argv+=['--mount',f'type=bind,src={floor/"sqlalchemy"},dst=/usr/local/lib/python3.12/site-packages/sqlalchemy,readonly','--mount',f'type=bind,src={floor/"SQLAlchemy-2.0.23.dist-info"},dst=/usr/local/lib/python3.12/site-packages/sqlalchemy-2.0.54.dist-info,readonly']
 for package in ('boto3','botocore','jmespath','s3transfer','dateutil','urllib3','six.py','dotenv'):argv+=['--mount',f'type=bind,src={sdk/package},dst=/overlay/{package},readonly']
 for k,v in env.items():argv+=['-e',k+'='+v]
 argv+=['--entrypoint','python',image,'-B','/entry.py']
 (OUT/'minimum-start.json').write_text(json.dumps({'argv':argv,'env':env,'entry_sha256':hashlib.sha256((ROOT/'minimum_review_entry.py').read_bytes()).hexdigest()},indent=2)+'\n')
 try:
  p=subprocess.run(argv,capture_output=True,text=True,timeout=240);(OUT/'minimum-controller.log').write_text(p.stdout+p.stderr)
  if p.returncode:raise RuntimeError('MINIMUM_CLIENT_FAILED')
 finally:
  if subprocess.check_output(['docker','ps','-aq','--filter','name=^/'+client+'$'],text=True).strip():subprocess.run(['docker','rm','-f',client],check=True,capture_output=True)
  if subprocess.check_output(['docker','ps','-aq','--filter','name=^/'+client+'$'],text=True).strip():raise RuntimeError('MINIMUM_CLIENT_REMAINS')
 record['formal_tests']=json.loads((output/'results.json').read_text())
 record['minimum_client_absent']=True
 (OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'result':record['result'],'clean':{k:v for k,v in record['clean'].items() if k not in ('views','columns')},'historical':{k:v for k,v in record['historical'].items() if k not in ('views','columns')}}));raise SystemExit
with LOCK.open('a+') as lock:
 deadline=time.monotonic()+600
 while True:
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
  except BlockingIOError:
   if time.monotonic()>deadline:raise RuntimeError('HEAVY_SLOT_BUSY_NO_START')
   time.sleep(1)
 name='b17-historical-view-'+str(os.getpid());owned=False
 run=lambda argv,**kw:subprocess.run(argv,check=True,timeout=30,**kw)
 try:
  argv=['docker','run','-d','--pull=never','--name',name,'--memory=256m','--cpus=1','--pids-limit=100','-p','127.0.0.1:55439:5432','--tmpfs','/var/lib/postgresql/data','-e','POSTGRES_USER=postgres','-e','POSTGRES_HOST_AUTH_METHOD=trust','postgres@sha256:2d2b8998d31037bf721cfdf764d76ba74171b4fab3431b7f72c27c56ddbdf9e3']
  p=run(argv,capture_output=True,text=True);owned=True
  (OUT/'owner.json').write_text(json.dumps({'argv':argv,'container_id':p.stdout.strip(),'pid':os.getpid(),'controller_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
  for _ in range(80):
   if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=5).returncode==0:break
   time.sleep(.2)
  else:raise RuntimeError('PG_NOT_READY')
  for kind in ('clean','historical'):run(['docker','exec',name,'createdb','-U','postgres','b17_view_'+kind],capture_output=True,text=True)
  p=subprocess.run([sys.executable,str(Path(__file__)),'--child'],env={'PATH':os.environ['PATH'],'B17_OWNED_PG_NAME':name},capture_output=True,text=True,timeout=480)
  (OUT/'child.log').write_text(p.stdout+p.stderr);print(p.stdout+p.stderr)
  if p.returncode:raise RuntimeError('CHILD_FAILED')
 finally:
  if owned:
   run(['docker','rm','-fv',name],capture_output=True,text=True)
   absent=subprocess.run(['docker','inspect',name],capture_output=True,timeout=10).returncode!=0
   (OUT/'cleanup.json').write_text(json.dumps({'container_absent':absent,'tmpfs_removed':True},indent=2)+'\n')
   if not absent:raise RuntimeError('OWNED_CLEANUP_FAILED')
