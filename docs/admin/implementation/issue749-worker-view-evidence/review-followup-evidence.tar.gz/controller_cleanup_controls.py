"""Execute exact portable-controller cleanup AST with fake-only Docker adapter."""
from pathlib import Path
import ast,hashlib,json,tempfile,subprocess
SOURCE=Path('/Users/roger/.codex/worktrees/batch14-release/audit_app/docs/admin/implementation/issue749-worker-view-evidence/replay_owned_views.py')
source=SOURCE.read_text();tree=ast.parse(source)
candidates=[n for n in ast.walk(tree) if isinstance(n,ast.Try) and n.finalbody and 'OWNED_CONTAINER_STILL_PRESENT' in ast.get_source_segment(source,n)]
outer=[n for n in candidates if any(isinstance(x,ast.If) and isinstance(x.test,ast.Name) and x.test.id=='owned' for x in n.finalbody)]
if len(outer)!=1:raise RuntimeError('EXACT_CLEANUP_NOT_FOUND')
fn=ast.FunctionDef(name='execute_cleanup',args=ast.arguments(posonlyargs=[],args=[],kwonlyargs=[],kw_defaults=[],defaults=[]),body=outer[0].finalbody,decorator_list=[])
code=compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'exact-portable-cleanup','exec');results=[]
for mode in ('positive_empty','daemon_error','removal_error','container_still_present'):
 with tempfile.TemporaryDirectory(prefix='b17-offline-cleanup-') as tmp:
  out=Path(tmp);(out/'owner.json').write_text(json.dumps({'container_id':'inert-exact-container-id'}));calls=[]
  def run(argv,**kw):
   calls.append(argv)
   if mode=='removal_error' and argv[1]=='rm':raise subprocess.CalledProcessError(1,argv)
   if mode=='daemon_error' and argv[1]=='ps':raise subprocess.CalledProcessError(1,argv)
   return type('Result',(),{'stdout':'inert-exact-container-id\n' if mode=='container_still_present' and argv[1]=='ps' else ''})()
  ns={'owned':True,'run':run,'name':'inert-owned-name','OUT':out,'json':json};exec(code,ns)
  try:ns['execute_cleanup']();refused=False
  except Exception:refused=True
  observed=json.loads((out/'cleanup.json').read_text())
  expected=mode!='positive_empty'
  if refused!=expected or observed['status']!=('UNVERIFIED' if expected else 'VERIFIED'):raise RuntimeError('FALSE_CLEANUP_VERDICT')
  if any(argv[1]=='ps' and argv[2:]!=['-a','--no-trunc','--filter','id=inert-exact-container-id','--format','{{.ID}}'] for argv in calls):raise RuntimeError('NOT_EXACT_ID_LISTING')
  results.append({'mode':mode,'refused':refused,'cleanup':observed,'calls':calls})
Path(__file__).with_suffix('.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'scope':'Exact final cleanup AST, fake Docker, temporary local evidence only','controls':results,'passed':len(results),'total':len(results)},indent=2)+'\n')
print(json.dumps({'passed':len(results),'total':len(results)}))
