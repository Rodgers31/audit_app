import hashlib,json,pathlib,subprocess,zipfile,os
ROOT=pathlib.Path('/Users/roger/.codex/worktrees/batch10-dependency-remediation/audit_app')
OUT=pathlib.Path('/Users/roger/.codex/visualizations/2026/10/10/01a123ab-8b43-7830-9262-8f05ab1b8a60/batch10-dependencies/reviews/spec')
E=ROOT/'docs/admin/implementation/batch10-dependencies-evidence'
SPEC=pathlib.Path('/Users/roger/.codex/visualizations/2026/10/03/01a1034a-4799-7f72-a9d1-28c8cfbea53f/BATCH_10_SESSIONS')
BASE='f6c31e271297eece52f34102dc40a1e2ed7069a8'
sha=lambda data:hashlib.sha256(data).hexdigest()
container=json.loads((OUT/'container-inputs-before.stdout').read_bytes())
manifest=json.loads((E/'evidence-v1.manifest.json').read_bytes())
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',BASE,'frontend'],cwd=ROOT).decode().splitlines()
with zipfile.ZipFile(E/'evidence-v1.zip') as z:
    external_specs={n:sha((SPEC/n).read_bytes())==sha(z.read('spec/'+n)) for n in ('SPEC.md','ISSUE_494_LAUNCH.json')}
    parity={p:sha(subprocess.check_output(['git','show',BASE+':'+p],cwd=ROOT))==sha((ROOT/p).read_bytes()) for p in tracked}
    container_parity={p:container['work']['files'][p]==sha(subprocess.check_output(['git','show',BASE+':'+p],cwd=ROOT)) for p in tracked}
    model=json.loads(z.read('observations/model-manifest.json'))
    model_parity={p:container['models']['/models/'+p]==v for p,v in model.items()}
    native_parity=container['inputNativeSha256']==sha(z.read('generators/native-controls.mjs'))==sha((E/'native-controls.mjs').read_bytes())
    records={name:json.loads(z.read('raw/'+name+'.json')) for name in manifest['records']}
    histories={name:{k:r.get(k) for k in ('command','cwd','exit','verification_exit','source_stable','generator_sha256','resolved_environment')} for name,r in records.items()}
    deltas=json.loads(z.read('observations/candidate-deltas.json'))
    counts={n:{'changed':len(v['changed']),'deleted':len(v['deleted']),'templates':sum(p.endswith(('.tsx','.ts','.jsx','.html')) for p in v['changed'])} for n,v in deltas.items()}
    lock0=json.loads(z.read('source/frontend/package-lock.json'))['packages']
    locks={}
    for n in ('tailwind-upgrade','tailwind-upgrade-fresh-resolution'):
        lock1=json.loads(z.read('candidates/'+n+'/frontend/package-lock.json'))['packages']
        changed=[p for p in set(lock0)|set(lock1) if lock0.get(p)!=lock1.get(p)]
        production=[p for p,v in lock0.items() if p and not v.get('dev')]
        locks[n]={'changed_records':len(changed),'baseline_production_records':len(production),'changed_production_records':sum(p in changed for p in production)}
    audits={}
    for n in ('baseline-audit-full','baseline-audit-production','linux-audit-full','linux-audit-production','candidate-official-audit','candidate-supported-audit'):
        a=json.loads(z.read('raw/'+n+'.stdout'))
        audits[n]={'counts':a['metadata']['vulnerabilities'],'roots':[v['name'] for v in a['vulnerabilities'].values() if any(isinstance(p,dict) for p in v['via'])]}
    retained=OUT/'retained'
    retained.mkdir(exist_ok=False)
    selected=('candidate-config-only-css','candidate-official-upgrade-corrected','candidate-official-fresh-tree','candidate-supported-tree','baseline-callers-corrected','css-render-positive','css-render-negative','advisory-braces','advisory-sprintf','mac-preview-browser','linux-preview-browser')
    for n in selected:
        for suffix in ('.json','.stdout','.stderr'):
            (retained/(n+suffix)).write_bytes(z.read('raw/'+n+suffix))
    result={'external_spec_bytes_match_archive':external_specs,'host_frontend_bytes_equal_base':all(parity.values()),'frontend_file_count':len(parity),'container_frontend_bytes_equal_base':all(container_parity.values()),'model_cache_bytes_match_archive':model_parity,'native_generator_bytes_match_archive':native_parity,'candidate_counts':counts,'candidate_lock_deltas':locks,'audits':audits,'all_raw_records':histories,'final_verification_present_in_frozen_head':subprocess.run(['git','cat-file','-e','041ad89:docs/admin/implementation/FINAL_VERIFICATION.md'],cwd=ROOT,capture_output=True).returncode==0,'final_verification_external_present':(OUT.parent.parent/'FINAL_VERIFICATION.md').exists()}
    print(json.dumps(result,indent=2))
    if not all(external_specs.values()) or not all(parity.values()) or not all(container_parity.values()) or not all(model_parity.values()) or not native_parity:
        raise RuntimeError('identity mismatch')
