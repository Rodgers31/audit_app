import hashlib, json, os, pathlib, subprocess, sys, time, zipfile
ROOT = pathlib.Path('/Users/roger/.codex/worktrees/batch10-dependency-remediation/audit_app')
OUT = pathlib.Path('/Users/roger/.codex/visualizations/2026/10/10/01a123ab-8b43-7830-9262-8f05ab1b8a60/batch10-dependencies/reviews/spec')
EVIDENCE = ROOT / 'docs/admin/implementation/batch10-dependencies-evidence'
BASE = 'f6c31e271297eece52f34102dc40a1e2ed7069a8'
HEAD = '041ad89a0a170b4029beb5d9597b55bf934eff7e'
CONTAINER = 'batch10-dependencies-linux-494-01a123ab'
CONTAINER_ID = 'f8dbb60d64beda8c9aa0763614947b681195ca2e6fcf9960ef37e1272a56fd9b'
def digest(data): return hashlib.sha256(data).hexdigest()
def source():
    def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT)
    paths = git('ls-files', '-z').decode().split('\0')
    return {'head':git('rev-parse','HEAD').decode().strip(), 'tree':git('rev-parse','HEAD^{tree}').decode().strip(), 'status':git('status','--porcelain').decode(), 'tracked_sha256':{p:digest((ROOT/p).read_bytes()) if (ROOT/p).is_file() else None for p in paths if p}}
BEFORE=source()
if BEFORE['head'] != HEAD: raise RuntimeError('frozen HEAD mismatch')
ENV=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(OUT/'tmp'))
GEN=digest(pathlib.Path(__file__).read_bytes())
COUNTS=[]
def run(name,args,timeout=900):
    destinations=[OUT/(name+s) for s in ('.stdout','.stderr','.json')]
    if any(p.exists() for p in destinations): raise RuntimeError('exclusive output collision: '+name)
    started=time.time()
    try:
        result=subprocess.run(args,cwd=ROOT,env=ENV,capture_output=True,timeout=timeout)
        stdout,stderr,code,error=result.stdout,result.stderr,result.returncode,None
    except subprocess.TimeoutExpired as exc:
        stdout,stderr,code,error=exc.stdout or b'',exc.stderr or b'',None,'timeout'
    identity=source()
    record={'command':args,'cwd':str(ROOT),'started_at_unix':started,'ended_at_unix':time.time(),'exit':code,'error':error,'generator':str(pathlib.Path(__file__)),'generator_sha256':GEN,'python':sys.version,'consumed_head':BEFORE['head'],'consumed_tree':BEFORE['tree'],'host_source_stable':BEFORE==identity,'stdout_sha256':digest(stdout),'stderr_sha256':digest(stderr),'environment_changes':{k:ENV[k] for k in ('PYTHONDONTWRITEBYTECODE','TMPDIR')}}
    for path,data in zip(destinations,(stdout,stderr,(json.dumps(record,indent=2)+'\n').encode())):
        with path.open('xb') as h: h.write(data)
    COUNTS.append({'name':name,'exit':code,'error':error,'source_stable':record['host_source_stable']})
    print(json.dumps(COUNTS[-1]),flush=True)
    return stdout
with zipfile.ZipFile(EVIDENCE/'evidence-v1.zip') as packet:
    archive_identity={'archive_sha256':digest((EVIDENCE/'evidence-v1.zip').read_bytes()),'manifest_sha256':digest((EVIDENCE/'evidence-v1.manifest.json').read_bytes()),'source_members':{name:digest(packet.read(name)) for name in packet.namelist() if name.startswith(('source/','generators/','spec/'))},'model_manifest':json.loads(packet.read('observations/model-manifest.json'))}
(OUT/'inputs.json').write_text(json.dumps({'source_before':BEFORE,'archive':archive_identity,'expected_container_id':CONTAINER_ID},indent=2)+'\n')
run('frozen-diff',['git','diff',BASE+'...'+HEAD])
run('frozen-commits',['git','log',BASE+'..'+HEAD,'--oneline'])
inspect=json.loads(run('container-inspect',['docker','inspect',CONTAINER]))[0]
if inspect['Id'] != CONTAINER_ID: raise RuntimeError('owned container identity mismatch')
node_identity=r'''const fs=require('fs'),crypto=require('crypto'),cp=require('child_process');const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');function git(...args){return cp.execFileSync('git',args,{cwd:'/work'}).toString()}const paths=git('ls-files','-z').split('\0').filter(Boolean);function inventory(root){let result={};function walk(p){for(const e of fs.readdirSync(p,{withFileTypes:true})){const f=p+'/'+e.name;if(e.isDirectory())walk(f);else if(e.isFile())result[f]=sha(f)}}walk(root);return result}console.log(JSON.stringify({work:{head:git('rev-parse','HEAD').trim(),tree:git('rev-parse','HEAD^{tree}').trim(),status:git('status','--porcelain'),files:Object.fromEntries(paths.map(p=>[p,sha('/work/'+p)]))},models:inventory('/models'),ownedmodels:inventory('/ownedmodels'),runtime:{node:process.version,platform:process.platform,arch:process.arch},inputNativeSha256:sha('/input/docs/admin/implementation/batch10-dependencies-evidence/native-controls.mjs')}))'''
container_before=run('container-inputs-before',['docker','exec',CONTAINER,'node','-e',node_identity])
run('published-packet-optimized',['python3','-O',str(EVIDENCE/'verify_bundle.py'),str(EVIDENCE/'evidence-v1.zip'),str(EVIDENCE/'evidence-v1.manifest.json')])
run('published-bundle-controls-optimized',['python3','-O',str(EVIDENCE/'test_bundle.py'),str(EVIDENCE/'evidence-v1.zip'),str(EVIDENCE/'evidence-v1.manifest.json')])
run('recorder-controls-optimized',['python3','-O',str(EVIDENCE/'test_recorder.py')])
run('linux-native-controls',['docker','exec','-e','NATIVE_VERIFY_CACHE_DIR=/models','-e','BATCH10_BUILDER_MODELS=/ownedmodels',CONTAINER,'node','/input/docs/admin/implementation/batch10-dependencies-evidence/native-controls.mjs','/work/frontend'])
container_after=run('container-inputs-after',['docker','exec',CONTAINER,'node','-e',node_identity])
AFTER=source()
(OUT/'final-identity.json').write_text(json.dumps({'source_after':AFTER,'host_source_stable':BEFORE==AFTER,'container_inputs_stable':container_before==container_after,'commands':COUNTS,'generator_sha256':GEN},indent=2)+'\n')
print(json.dumps({'host_source_stable':BEFORE==AFTER,'container_inputs_stable':container_before==container_after,'all_commands_passed':all(x['exit']==0 for x in COUNTS)}),flush=True)
