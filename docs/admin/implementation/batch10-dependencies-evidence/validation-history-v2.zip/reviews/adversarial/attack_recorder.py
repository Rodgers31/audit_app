#!/usr/bin/env python3
import contextlib, hashlib, importlib.util, io, json, os, shutil, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ORIGINAL=ROOT/'original'
WORK=ROOT/'recorder-cases';WORK.mkdir(exist_ok=True)
RESULTS=[]
REL=Path('docs/admin/implementation/batch10-dependencies-evidence/run.py')

def sha(b):return hashlib.sha256(b).hexdigest()

def setup(name):
    folder=WORK/name;folder.mkdir()
    repo=folder/'repo'; runner=repo/REL;runner.parent.mkdir(parents=True)
    runner.write_bytes((ORIGINAL/'run.py').read_bytes())
    (repo/'source.py').write_text('VALUE = "original"\n')
    (repo/'.gitignore').write_text('__pycache__/\nignored/\n')
    out=folder/'raw';out.mkdir()
    for args in [['git','init','-q'],['git','add','.'],['git','-c','user.name=adversarial-fixture','-c','user.email=adversarial-fixture@example.invalid','commit','-qm','disposable fixture']]:
        subprocess.run(args,cwd=repo,check=True,capture_output=True)
    return folder,repo,runner,out

def execute(name,code='print("actual child positive control")',prepare=None,args=None,cwd_kind=None,direct=None,meaning='must reject'):
    folder,repo,runner,out=setup(name)
    candidate=folder/'candidate';candidate.mkdir();(candidate/'input.txt').write_text('original')
    if prepare:prepare(folder,repo,out,candidate)
    childcwd=candidate if cwd_kind=='candidate' else repo
    if cwd_kind=='missing':childcwd=folder/'absent'
    environment=dict(os.environ,BATCH10_DEPENDENCIES_OUTPUT=str(out))
    command=[sys.executable,'-O',str(runner),'control',str(childcwd),sys.executable,'-c',code] if args is None else [sys.executable,'-O',str(runner)]+args(folder,repo,out,candidate)
    result={'name':name,'meaning':meaning,'generator_start_sha256':sha(runner.read_bytes()),'command':command,'cwd':str(repo),'environment':{'BATCH10_DEPENDENCIES_OUTPUT':str(out)}}
    (folder/'payload.py').write_text(code+'\n')
    if direct:
        prior=dict(os.environ);os.environ.update(environment)
        spec=importlib.util.spec_from_file_location('recorder_'+name.replace('-','_'),runner)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        previousargv=sys.argv;sys.argv=command[2:]
        if direct=='invalid-name-none':sys.argv[1]=None
        if direct=='invalid-cwd-none':sys.argv[2]=None
        if direct=='invalid-command-none':sys.argv[3]=None
        if direct=='invalid-out-none':module.OUT=None
        stdout=io.StringIO();stderr=io.StringIO()
        try:
            with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):value=module.main()
            result.update(direct_call='main()',return_value=value,exit=value,success=value==0)
        except Exception as e:result.update(direct_call='main()',error_type=type(e).__name__,error=str(e),exit=1,success=False)
        finally:
            sys.argv=previousargv;os.environ.clear();os.environ.update(prior)
        output,errors=stdout.getvalue().encode(),stderr.getvalue().encode()
    else:
        p=subprocess.run(command,cwd=repo,env=environment,capture_output=True,timeout=35)
        output,errors=p.stdout,p.stderr;result.update(exit=p.returncode,success=p.returncode==0)
    (folder/'runner.stdout').write_bytes(output);(folder/'runner.stderr').write_bytes(errors)
    result['stdout_sha256']=sha(output);result['stderr_sha256']=sha(errors)
    if (out/'control.json').exists():
        receipt=json.loads((out/'control.json').read_bytes());result['receipt']={k:receipt[k] for k in ['exit','signal','error','verification_exit','source_stable','generator_sha256']}
    result['fixture_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
    result['fixture_tree']=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True).strip()
    result['fixture_after_status']=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)
    (folder/'result.json').write_text(json.dumps(result,indent=2)+'\n');RESULTS.append(result)
    (ROOT/'recorder-results.json').write_text(json.dumps(RESULTS,indent=2)+'\n');print(json.dumps(result),flush=True)

if __name__=='__main__':
    execute('positive',meaning='must pass actual child with stable source')
    execute('failed-child','raise SystemExit(7)')
    execute('signalled-child','import os,signal;os.kill(os.getpid(),signal.SIGTERM)')
    execute('missing-cwd',cwd_kind='missing')
    execute('missing-output',prepare=lambda f,r,o,c:o.rmdir())
    execute('output-is-file',prepare=lambda f,r,o,c:(o.rmdir(),o.write_text('file')))
    for extension in ['json','stdout','stderr']:
        execute('output-existing-'+extension,prepare=lambda f,r,o,c,e=extension:(o/('control.'+e)).write_text('retained output'))
        execute('output-dangling-symlink-'+extension,prepare=lambda f,r,o,c,e=extension:(o/('control.'+e)).symlink_to(f/'absent'))
    execute('missing-command',args=lambda f,r,o,c:['control',str(r)])
    execute('missing-name',args=lambda f,r,o,c:['',str(r),sys.executable,'-c','print("bad")'])
    execute('traversal-name',args=lambda f,r,o,c:['../control',str(r),sys.executable,'-c','print("bad")'])
    execute('missing-executable',args=lambda f,r,o,c:['control',str(r),str(f/'absent-command')])
    execute('source-added','from pathlib import Path;Path("added.py").write_text("mutation")')
    execute('source-modified','from pathlib import Path;Path("source.py").write_text("mutation")')
    execute('source-deleted','from pathlib import Path;Path("source.py").unlink()')
    execute('generator-modified','from pathlib import Path;p=Path("docs/admin/implementation/batch10-dependencies-evidence/run.py");p.write_text(p.read_text()+"\\n# modified\\n")')
    execute('generator-deleted','from pathlib import Path;Path("docs/admin/implementation/batch10-dependencies-evidence/run.py").unlink()')
    execute('input-added','from pathlib import Path;Path("added.txt").write_text("mutation")',cwd_kind='candidate')
    execute('input-modified','from pathlib import Path;Path("input.txt").write_text("mutation")',cwd_kind='candidate')
    execute('input-deleted','from pathlib import Path;Path("input.txt").unlink()',cwd_kind='candidate')
    execute('output-collision-created-by-child',f'from pathlib import Path;import os;Path(os.environ["BATCH10_DEPENDENCIES_OUTPUT"],"control.stdout").write_text("malicious output")')
    execute('source-transient-mutation','from pathlib import Path;p=Path("source.py");saved=p.read_bytes();p.write_text("VALUE = \\"mutated\\"\\n");print(p.read_text());p.write_bytes(saved)',meaning='snapshot limitation: transient mutation reverted before final inventory')
    execute('inherited-output-used','from pathlib import Path;import os;print(Path(os.environ["BATCH10_DEPENDENCIES_OUTPUT"]).parent.joinpath("artifact.json").read_text())',prepare=lambda f,r,o,c:(f/'artifact.json').write_text('{"success": false}'),meaning='recorder captures child exit; child artifact semantics require separate verifier')
    execute('child-prints-truthy-failure','print({"success":False,"error":"failed"})',meaning='recorder captures process status, not arbitrary child stdout semantics')
    execute('direct-positive',direct='valid',meaning='must pass direct main() positive control')
    execute('direct-failed-child','raise SystemExit(7)',direct='valid')
    for kind in ['invalid-name-none','invalid-cwd-none','invalid-command-none','invalid-out-none']:execute('direct-'+kind,direct=kind)
