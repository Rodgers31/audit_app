print("fake generator")
