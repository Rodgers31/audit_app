#!/usr/bin/env python3
import copy, hashlib, importlib.util, json, math, os, struct, subprocess, sys, time, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ORIGINAL=ROOT/'original'
ARCHIVE=ORIGINAL/'evidence-v1.zip'
MANIFEST=ORIGINAL/'evidence-v1.manifest.json'
BASE=json.loads(MANIFEST.read_bytes())
MODULE=ORIGINAL/'verify_bundle.py'
spec=importlib.util.spec_from_file_location('review_verifier', MODULE)
verify_module=importlib.util.module_from_spec(spec); spec.loader.exec_module(verify_module)
RESULTS=[]
WORK=ROOT/'bundle-cases';WORK.mkdir(exist_ok=True)

def sha(b): return hashlib.sha256(b).hexdigest()

def execute(name, archive=ARCHIVE, manifest=MANIFEST, meaning='must reject', cli=False):
    folder=WORK/name;folder.mkdir(exist_ok=True)
    result={'name':name,'archive':str(archive),'manifest':str(manifest),'meaning':meaning}
    try:
        value=verify_module.verify(archive, manifest)
        result.update(success=True,returned=value)
    except Exception as e:
        result.update(success=False,error_type=type(e).__name__,error=str(e))
    if cli:
        args=[sys.executable,'-O',str(MODULE),str(archive),str(manifest)]
        p=subprocess.run(args,capture_output=True,timeout=40)
        (folder/'cli.stdout').write_bytes(p.stdout);(folder/'cli.stderr').write_bytes(p.stderr)
        result['cli']={'command':args,'cwd':str(Path.cwd()),'exit':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)}
    (folder/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    RESULTS.append(result);print(json.dumps(result),flush=True)
    (ROOT/'bundle-results.json').write_text(json.dumps(RESULTS,indent=2)+'\n')
    return result

def manifest_case(name, transform=None, raw=None, meaning='must reject', cli=False):
    folder=WORK/name;folder.mkdir(exist_ok=True)
    m=copy.deepcopy(BASE)
    if transform: transform(m)
    p=folder/'manifest.json'
    p.write_bytes(raw if raw is not None else json.dumps(m).encode())
    return execute(name,manifest=p,meaning=meaning,cli=cli)

BYTES=None

def packet_case(name, changes=None, deletes=(), extra=None, transform=None, record=None, meaning='semantic validation boundary; trusted manifest also updated', cli=True):
    global BYTES
    if BYTES is None:
        with zipfile.ZipFile(ARCHIVE) as z: BYTES={n:z.read(n) for n in z.namelist()}
    folder=WORK/name;folder.mkdir(exist_ok=True)
    changed=changes or {}
    m=copy.deepcopy(BASE)
    for n in deletes: m['files'].pop(n,None)
    with zipfile.ZipFile(folder/'packet.zip','x',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
        for n,b in BYTES.items():
            if n not in deletes:
                z.writestr(n,changed.get(n,b)); m['files'][n]=sha(changed.get(n,b))
        for n,b in (extra or {}).items(): z.writestr(n,b);m['files'][n]=sha(b)
    m['archive_sha256']=sha((folder/'packet.zip').read_bytes())
    if record:
        record_name,fields=record
        m['records'][record_name].update({k:v for k,v in fields.items() if k in ('exit','verification_exit','source_stable','generator_sha256')})
    if transform: transform(m)
    (folder/'changes.json').write_text(json.dumps({'changed':list(changed),'deleted':list(deletes),'extra':list(extra or {}),'record_expected_update':record},indent=2)+'\n')
    p=folder/'manifest.json';p.write_text(json.dumps(m,indent=2)+'\n')
    return execute(name,folder/'packet.zip',p,meaning=meaning,cli=cli)


def record_case(name,fields, meaning='must reject inconsistent or malformed record'):
    global BYTES
    if BYTES is None:
        with zipfile.ZipFile(ARCHIVE) as z: BYTES={n:z.read(n) for n in z.namelist()}
    n='raw/baseline-install.json';r=json.loads(BYTES[n]);r.update(fields)
    return packet_case(name,{n:json.dumps(r).encode()},record=('baseline-install',fields),meaning=meaning)

if __name__=='__main__':
    execute('baseline-direct',cli=True,meaning='must pass original frozen published bytes')
    execute('archive-absent',WORK/'missing.zip',cli=True)
    execute('manifest-absent',manifest=WORK/'missing.json',cli=True)
    empty=WORK/'empty.zip';empty.write_bytes(b'');execute('archive-empty',empty,cli=True)
    for name,raw in [('empty',b''),('unparseable',b'{broken'),('null',b'null'),('array',b'[]'),('empty-object',b'{}')]:
        manifest_case('manifest-'+name,raw=raw,cli=True)
    for name,value in [('unknown',2),('bool-true',True),('bool-false',False),('float-one',1.0),('nan',float('nan')),('inf',float('inf')),('negative-inf',float('-inf')),('zero',0),('negative',-1),('none',None)]:
        manifest_case('manifest-schema-'+name,lambda m,v=value:m.update(schema=v),cli=True)
    for key in ['files','records']:
        for name,v in [('empty-dict',{}),('empty-list',[]),('none',None)]:manifest_case('manifest-'+key+'-'+name,lambda m,k=key,v=v:m.update({k:v}))
    manifest_case('manifest-required-record-removed',lambda m:m['records'].pop('linux-native'),cli=True)
    manifest_case('manifest-record-expected-null',lambda m:m['records'].update({'baseline-install':None}),cli=True)
    manifest_case('manifest-record-expected-bool-exit',lambda m:m['records']['baseline-install'].update(exit=False),meaning='manifest expected field must match exact integer exit type',cli=True)
    manifest_case('manifest-base-wrong',lambda m:m.update(base='0'*40),cli=True)
    manifest_case('manifest-tree-wrong',lambda m:m.update(base_tree='0'*40),cli=True)
    manifest_case('manifest-archive-hash-wrong',lambda m:m.update(archive_sha256='0'*64),cli=True)
    manifest_case('manifest-member-hash-wrong',lambda m:m['files'].update({'outputs/baseline.css':'0'*64}),cli=True)
    packet_case('record-json-missing',deletes=['raw/baseline-install.json'],meaning='must reject required record absence')
    packet_case('record-json-empty',{'raw/baseline-install.json':b''},meaning='must reject required record empty')
    packet_case('record-json-object-empty',{'raw/baseline-install.json':b'{}'},meaning='must reject required record malformed')
    packet_case('record-stream-missing',deletes=['raw/baseline-install.stdout'],meaning='must reject required stream absence')
    packet_case('record-stream-empty-wrong-digest',{'raw/baseline-install.stdout':b''},meaning='must reject required stream changed')
    for name,v in [('bool-false',False),('bool-true',True),('nan',float('nan')),('inf',float('inf')),('negative-inf',float('-inf')),('none',None),('negative',-1),('zero-float',0.0)]:
        record_case('record-exit-'+name,{'exit':v})
    record_case('record-failed-child-green',{'exit':7})
    record_case('record-error-truthy-failure',{'error':{'success':False,'reason':'failed'}})
    record_case('record-error-empty-string',{'error':''})
    record_case('record-error-bool-false',{'error':False})
    record_case('record-error-empty-dict',{'error':{}})
    record_case('record-signal-failed-green',{'signal':9},meaning='must reject exit 0 paired with termination signal 9')
    record_case('record-source-head-wrong',{'source_before':dict(head='0'*40,tree=BASE['base_tree']),'source_after':dict(head='0'*40,tree=BASE['base_tree'])})
    record_case('record-source-tree-wrong',{'source_before':dict(head=BASE['base'],tree='0'*40),'source_after':dict(head=BASE['base'],tree='0'*40)})
    record_case('record-source-inventory-empty',{'source_before':dict(head=BASE['base'],tree=BASE['base_tree'],status='',files={}),'source_after':dict(head=BASE['base'],tree=BASE['base_tree'],status='',files={})},meaning='missing source inventory; trusted manifest also updated')
    record_case('record-command-empty',{'command':[]},meaning='missing command provenance; trusted manifest also updated')
    record_case('record-command-null',{'command':None},meaning='missing command provenance; trusted manifest also updated')
    record_case('record-generator-unknown',{'generator_sha256':'0'*64})
    packet_case('generator-bytes-changed',{'generators/historical/run-v1.py':b'print("fake generator")\n'},meaning='must reject actual generator hash absent')
    packet_case('unsafe-archive-member',extra={'../outside.txt':b'unsafe'},meaning='must reject traversal member')
    # Explicit Jest contradictory failure and numeric schema controls.
    with zipfile.ZipFile(ARCHIVE) as z:
        jest=json.loads(z.read('outputs/mac-jest.json'))
        index=json.loads(z.read('outputs/mac-builder-index.json'))
        audit=json.loads(z.read('raw/baseline-audit-production.stdout'))
    for name,changes in [('jest-truthy-failed',{'success':False,'wasInterrupted':True,'numRuntimeErrorTestSuites':1}),('jest-results-empty',{'testResults':[]}),('jest-failed-counter-bool',{'numFailedTestSuites':False,'numFailedTests':False}),('jest-counter-float',{'numPassedTestSuites':147.0,'numPassedTests':2077.0}),('jest-counter-nan',{'numPassedTests':float('nan')}),('jest-total-negative',{'numTotalTestSuites':-1,'numTotalTests':-1})]:
        value=copy.deepcopy(jest);value.update(changes)
        packet_case(name,{'outputs/mac-jest.json':json.dumps(value).encode()},meaning='Jest malformed or contradictory results; trusted manifest also updated')
    value=copy.deepcopy(audit);value['metadata']['vulnerabilities']['total']=False
    r=json.loads(BYTES['raw/baseline-audit-production.json']);raw=json.dumps(value).encode();r['stdout_sha256']=sha(raw)
    packet_case('audit-total-bool',{'raw/baseline-audit-production.stdout':raw,'raw/baseline-audit-production.json':json.dumps(r).encode()},meaning='audit bool where integer total expected; trusted manifest also updated')
    value=copy.deepcopy(index);value['count']=True
    packet_case('builder-count-bool',{'outputs/mac-builder-index.json':json.dumps(value).encode()},meaning='must reject builder bool count')
    packet_case('builder-nan-vector',{'outputs/mac-builder.bin':struct.pack('<f',float('nan'))+BYTES['outputs/mac-builder.bin'][4:]},meaning='must reject NaN builder vector')
    packet_case('builder-zero-vectors',{'outputs/mac-builder.bin':bytes(len(BYTES['outputs/mac-builder.bin']))},meaning='must reject nonnormalized builder vectors')
    # No claim of original authentication when trusted manifest and source are replaced together.
    packet_case('source-and-trusted-manifest-replaced',{'source/frontend/package.json':b'{}'},meaning='outside original authentication boundary: attacker replaced committed trusted manifest')
    # Programmatic parameter guards, without argparse or CLI.
    for a,m in [(None,MANIFEST),(ARCHIVE,None),(None,None),([],MANIFEST),(ARCHIVE,{})]:
        execute('direct-parameters-'+str(len(RESULTS)),a,m)
