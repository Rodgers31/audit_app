"""Standards-review receipts; writes only inside this owned external directory."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/roger/.codex/worktrees/batch10-dependency-remediation/audit_app')
BASE = 'f6c31e271297eece52f34102dc40a1e2ed7069a8'
HEAD = '041ad89a0a170b4029beb5d9597b55bf934eff7e'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()

def identity():
    names = git('diff', '--name-only', BASE + '...' + HEAD).splitlines()
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain'),
            'reviewed_files': {name: sha((ROOT / name).read_bytes()) for name in names},
            'frontend_manifest_sha256': sha((ROOT / 'frontend/package.json').read_bytes()),
            'frontend_lock_sha256': sha((ROOT / 'frontend/package-lock.json').read_bytes())}

name, *command = sys.argv[1:]
before = identity()
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(OUT / 'tmp'))
result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True)
after = identity()
record = {'command': command, 'cwd': str(ROOT), 'started_at': start,
          'ended_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'exit': result.returncode, 'before': before, 'after': after,
          'source_stable': before == after,
          'review_capture_sha256': sha(Path(__file__).read_bytes()),
          'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr),
          'environment_overrides': {'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': str(OUT / 'tmp')}}
for suffix, data in (('.stdout', result.stdout), ('.stderr', result.stderr),
                     ('.json', (json.dumps(record, indent=2) + '\n').encode())):
    (OUT / 'raw' / (name + suffix)).open('xb').write(data)
print(json.dumps({'name': name, 'exit': result.returncode, 'source_stable': before == after,
                  'stdout': result.stdout.decode(errors='replace'),
                  'stderr': result.stderr.decode(errors='replace')}))
sys.exit(result.returncode)
