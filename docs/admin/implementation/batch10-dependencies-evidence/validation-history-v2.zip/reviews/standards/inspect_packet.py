"""Read every retained member and check archive/canonical/candidate boundaries."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path('/Users/roger/.codex/worktrees/batch10-dependency-remediation/audit_app')
EVIDENCE = ROOT / 'docs/admin/implementation/batch10-dependencies-evidence'
BASE = 'f6c31e271297eece52f34102dc40a1e2ed7069a8'

def sha(data):
    return hashlib.sha256(data).hexdigest()

manifest_bytes = (EVIDENCE / 'evidence-v1.manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
summary = {'manifest_sha256': sha(manifest_bytes), 'members': {}, 'records': {},
           'canonical_comparison': {}, 'generator_comparison': {}, 'candidates': {}}
with zipfile.ZipFile(EVIDENCE / 'evidence-v1.zip') as packet:
    names = packet.namelist()
    for name in names:
        data = packet.read(name)
        assert sha(data) == manifest['files'][name]
        parsed = False
        if name.endswith('.json'):
            json.loads(data)
            parsed = True
        summary['members'][name] = {'bytes': len(data), 'sha256': sha(data), 'json_parsed': parsed}
        if name.startswith('generators/'):
            relative = name.removeprefix('generators/').replace('historical/', 'historical-generators/', 1)
            target = EVIDENCE / relative
            summary['generator_comparison'][name] = target.is_file() and data == target.read_bytes()
            assert summary['generator_comparison'][name]
        if name.startswith('source/frontend/'):
            relative = name.removeprefix('source/')
            accepted = subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=ROOT)
            summary['canonical_comparison'][name] = data == accepted == (ROOT / relative).read_bytes()
            assert summary['canonical_comparison'][name]
    for name in sorted(manifest['records']):
        record = json.loads(packet.read('raw/' + name + '.json'))
        summary['records'][name] = {key: record.get(key) for key in
            ('command', 'cwd', 'exit', 'verification_exit', 'source_stable', 'generator_sha256', 'runtime')}
        generator_path = record['generated_by']
        start_hash = record['source_before']['files'].get(generator_path)
        summary['records'][name]['starting_inventory_generator_sha256'] = start_hash
        summary['records'][name]['generator_matches_start_inventory'] = start_hash == record['generator_sha256']
        for stream in ('stdout', 'stderr'):
            data = packet.read('raw/' + name + '.' + stream)
            assert sha(data) == record[stream + '_sha256']
    deltas = json.loads(packet.read('observations/candidate-deltas.json'))
    for name, changes in deltas.items():
        actual = {n.removeprefix('candidates/' + name + '/') for n in names if n.startswith('candidates/' + name + '/')}
        assert actual == set(changes['changed'])
        assert actual.isdisjoint(changes['deleted'])
        assert len(actual) + len(changes['deleted']) == manifest['candidate_change_counts'][name]
        templates = [n for n in actual if n.endswith(('.tsx', '.jsx', '.ts', '.js')) and '/postcss.' not in n]
        summary['candidates'][name] = {'changed': len(actual), 'deleted': changes['deleted'], 'templates': len(templates)}
    summary['spec'] = packet.read('spec/SPEC.md').decode()
    summary['issue'] = json.loads(packet.read('spec/ISSUE_494_LAUNCH.json'))
    summary['member_counts_by_boundary'] = dict(Counter(n.split('/')[0] for n in names))
    summary['total_uncompressed_bytes_read'] = sum(v['bytes'] for v in summary['members'].values())
    summary['records_with_starting_generator_mismatch'] = [n for n,r in summary['records'].items() if not r['generator_matches_start_inventory']]
print(json.dumps(summary, indent=2))
