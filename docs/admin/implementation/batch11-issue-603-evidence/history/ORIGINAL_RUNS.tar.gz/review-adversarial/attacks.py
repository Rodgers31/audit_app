"""Independent PostgreSQL adversarial controls; only the source is borrowed."""
import contextlib
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import socket
import sys
import traceback
from uuid import uuid4

from sqlalchemy import create_engine, event, text
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker
import sqlalchemy

target = make_url(os.environ['DATABASE_URL'])
if not (target.host == '127.0.0.1' and target.port == 55540
        and target.username == 'batch11_bootstrap' and target.password == 'inert-local'
        and target.database == 'batch11-bootstrap-adversarial-603'):
    raise RuntimeError('Unowned target')
connect = socket.socket.connect
def local_only(sock, address):
    if not isinstance(address, tuple) or address[:2] != ('127.0.0.1', 55540):
        raise RuntimeError('Provider transport blocked')
    return connect(sock, address)
socket.socket.connect = local_only

from models import Base, IngestionJob, IngestionStatus, SeedingDomainClaim
from seeding import exclusion as ex

results = []
admin = create_engine(target, connect_args={'connect_timeout': 5})
@contextlib.contextmanager
def fixture():
    schema = 'adversarial_' + uuid4().hex
    with admin.begin() as db:
        db.execute(text(f'CREATE SCHEMA "{schema}"'))
    eng = create_engine(target.update_query_dict({'options': '-csearch_path=' + schema}),
        connect_args={'connect_timeout': 5})
    try:
        Base.metadata.create_all(eng)
        yield eng, sessionmaker(bind=eng)
    finally:
        eng.dispose()
        with admin.begin() as db:
            db.execute(text(f'DROP SCHEMA "{schema}" CASCADE'))

def snapshot(eng):
    with eng.connect() as db:
        return [list(map(str,row)) for row in db.execute(text('SELECT * FROM seeding_domain_claims ORDER BY domain'))]

def active(eng):
    with eng.connect() as db:
        return db.scalar(text('SELECT count(*) FROM seeding_domain_claims WHERE released_at IS NULL'))

def job(factory, group, **kw):
    values = dict(domain=group.receipt_domain, status=IngestionStatus.COMPLETED,
        dry_run=False, started_at=datetime.now(timezone.utc), finished_at=datetime.now(timezone.utc),
        meta={'seeding_claim_ids': group.claim_ids}, errors=[], items_processed=0,
        items_created=0, items_updated=0)
    values.update(kw)
    with factory.begin() as db:
        value = IngestionJob(**values)
        db.add(value)
        db.flush()
        return value.id

def checked(name, fn):
    print('BEGIN_CASE', name, flush=True)
    try:
        detail = fn()
        result = dict(identity=name, verdict='PASS', detail=detail)
    except BaseException as error:
        traceback.print_exc()
        result = dict(identity=name, verdict='FAIL', exception=type(error).__name__, error=str(error))
    results.append(result)
    print('CASE_RESULT',json.dumps(result),flush=True)

def expect_rejection(eng, group, job_id):
    before = snapshot(eng)
    try:
        group.acknowledge(job_id)
    except BaseException as error:
        if snapshot(eng) != before:
            raise AssertionError('Refusal changed committed ownership') from error
        return type(error).__name__ + ': ' + str(error)
    raise AssertionError('False success: acknowledgement returned; active=' + str(active(eng)))

def malformed_inputs():
    with fixture() as (eng, factory):
        values = [None, (), [], {}, (None,), (True,), ('',), ('a','a'), ('a'*101,), (float('nan'),)]
        count = 0
        for domains in values:
            try:
                group = ex.enter_domains(factory, domains, 'a')
            except BaseException:
                count += 1
            else:
                group.close()
                raise AssertionError('Malformed set admitted: ' + repr(domains))
            if snapshot(eng):
                raise AssertionError('Malformed set committed claims')
        for receipt_domain in [None, [], {}, True, float('inf'), 'outside']:
            try:
                group = ex.enter_domains(factory, ('a','b'), receipt_domain)
            except BaseException:
                count += 1
            else:
                group.close()
                raise AssertionError('Malformed receipt_domain admitted')
            if snapshot(eng):
                raise AssertionError('Malformed receipt domain committed claims')
        return {'rejected': count, 'committed_claims':len(snapshot(eng))}

checked('malformed_set_and_receipt_domain', malformed_inputs)

def receipt_control(mutator):
    with fixture() as (eng,factory):
        group = ex.enter_domains(factory, ('bootstrap_reference_data','audits'), 'bootstrap_reference_data')
        try:
            kwargs = mutator(group)
            job_id = job(factory,group,**kwargs)
            result = expect_rejection(eng,group,job_id)
            if not group.continuous():
                raise AssertionError('Invalid receipt ended continuity')
            valid = job(factory,group)
            group.acknowledge(valid)
            if active(eng) != 0:
                raise AssertionError('Valid follow-up receipt not released')
            return {'refusal':result,'followup_released':True}
        finally:
            group.close()

for name,mutator in [
    ('missing_claim_map',lambda g:{'meta':{}}),
    ('null_metadata',lambda g:{'meta':None}),
    ('wrong_receipt_domain',lambda g:{'domain':'audits'}),
    ('dry_run',lambda g:{'dry_run':True}),
    ('failed_terminal',lambda g:{'status':IngestionStatus.FAILED}),
    ('completed_with_errors',lambda g:{'status':IngestionStatus.COMPLETED_WITH_ERRORS}),
    ('errors_on_completed',lambda g:{'errors':['failure']}),
    ('boolean_counter',lambda g:{'items_processed':-1}),
    ('stale_before_acquisition',lambda g:{'started_at':datetime.now(timezone.utc)-timedelta(days=1)}),
    ('future_finish',lambda g:{'finished_at':datetime.now(timezone.utc)+timedelta(hours=2)}),
    ('claim_map_wrong_values',lambda g:{'meta':{'seeding_claim_ids':{'audits':True,'bootstrap_reference_data':1}}}),
    ('claim_map_extra_key',lambda g:{'meta':{'seeding_claim_ids':{**g.claim_ids,'other':'forged'}}}),
]:
    checked('receipt_' + name, lambda mutator=mutator:receipt_control(mutator))

def identity_controls():
    with fixture() as (eng,factory):
        group=ex.enter_domains(factory,('bootstrap_reference_data','audits'),'bootstrap_reference_data')
        try:
            valid=job(factory,group)
            refusals=[]
            for value in [None, True, False, 0, -1, 1.0, float('nan'), float('inf'), str(valid), valid+100]:
                refusals.append(expect_rejection(eng,group,value))
            group.acknowledge(valid)
            if active(eng)!=0:
                raise AssertionError('Valid identity did not release')
            return {'refusals':len(refusals),'active':active(eng)}
        finally:
            group.close()
checked('malformed_job_identifiers_then_valid',identity_controls)

def retained_and_untagged(kind):
    with fixture() as (eng,factory):
        if kind=='retained':
            previous=ex.enter_domain(factory,'audits',False)
            previous.close()
        else:
            metadata={} if kind=='untagged' else {'seeding_claim_id':'not-a-valid-uuid'}
            with factory.begin() as db:
                db.add(IngestionJob(domain='audits',status=IngestionStatus.RUNNING,dry_run=False,
                    started_at=datetime.now(timezone.utc)-timedelta(days=365),meta=metadata))
        before=snapshot(eng)
        try:
            group=ex.enter_domains(factory,('bootstrap_reference_data','audits'),'bootstrap_reference_data')
        except ex.DomainOwnershipError as error:
            if snapshot(eng)!=before:
                raise AssertionError('Refused admission left partial claims')
            return {'refusal':str(error),'claims':len(before)}
        group.close()
        raise AssertionError('Uncertain owner admitted')
for kind in ('retained','untagged','malformed_tag'):
    checked('admission_' + kind,lambda kind=kind:retained_and_untagged(kind))

def member_loss(fault):
    with fixture() as (eng,factory):
        group=ex.enter_domains(factory,('bootstrap_reference_data','audits'),'bootstrap_reference_data')
        try:
            receipt=job(factory,group)
            if fault=='removed':
                with factory.begin() as db:
                    db.delete(db.get(SeedingDomainClaim,group.members['audits'].identity))
            elif fault=='nonce':
                group.members['audits'].entry=uuid4()
            elif fault=='member_lock':
                group.guard.connection.execute(text('SELECT pg_advisory_unlock_all()'))
                # transaction locks cannot be cleared by unlock_all: release the transaction instead.
                group.guard.connection.rollback()
            elif fault=='backend_after_proof':
                original=group.continuous
                def terminate():
                    ok=original()
                    with eng.begin() as db:
                        if db.scalar(text('SELECT pg_terminate_backend(:pid)'),{'pid':group.guard.pid}) is not True:
                            raise RuntimeError('Termination setup failed')
                    return ok
                group.continuous=terminate
            result=expect_rejection(eng,group,receipt)
            return {'refusal':result,'active':active(eng)}
        finally:
            group.close()
for fault in ('removed','nonce','member_lock','backend_after_proof'):
    checked('member_' + fault,lambda fault=fault:member_loss(fault))

def partial_refusal():
    with fixture() as (eng,factory):
        previous=ex.enter_domain(factory,'zz-owner',False)
        previous.close()
        before=snapshot(eng)
        try:
            group=ex.enter_domains(factory,('aa-free','zz-owner'),'aa-free')
        except ex.DomainOwnershipError as error:
            if snapshot(eng)!=before:
                raise AssertionError('Partial claim set committed')
            return {'refusal':str(error),'claims':len(before)}
        group.close()
        raise AssertionError('Retained final member did not refuse')
checked('partial_set_reservation_rollback',partial_refusal)

def schema_failure():
    with fixture() as (eng,factory):
        with eng.begin() as db:
            db.execute(text('DROP INDEX uq_seeding_active_domain'))
        try:
            group=ex.enter_domains(factory,('bootstrap_reference_data','audits'),'bootstrap_reference_data')
        except ex.DomainOwnershipError as error:
            if snapshot(eng):
                raise AssertionError('Invalid arbiter committed claims')
            return {'refusal':str(error),'claims':0}
        group.close()
        raise AssertionError('Missing unique index admitted')
checked('missing_active_unique_arbiter',schema_failure)

def trigger_release(mode):
    with fixture() as (eng,factory):
        group=ex.enter_domains(factory,('bootstrap_reference_data','audits'),'bootstrap_reference_data')
        try:
            receipt=job(factory,group)
            with eng.begin() as db:
                if mode=='suppress_all':
                    body='RETURN NULL;'
                elif mode=='suppress_member':
                    body="IF NEW.domain = 'audits' THEN RETURN NULL; END IF; RETURN NEW;"
                else:
                    body='NEW.released_at := NULL; RETURN NEW;'
                db.execute(text('CREATE FUNCTION hostile_release() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN ' + body + ' END $$'))
                db.execute(text('CREATE TRIGGER hostile_release BEFORE UPDATE ON seeding_domain_claims FOR EACH ROW EXECUTE FUNCTION hostile_release()'))
            result=expect_rejection(eng,group,receipt)
            return {'refusal':result,'active':active(eng)}
        finally:
            group.close()
for mode in ('suppress_all','suppress_member','alter_release'):
    checked('database_trigger_' + mode,lambda mode=mode:trigger_release(mode))

def backend_during_update():
    with fixture() as (eng,factory):
        group=ex.enter_domains(factory,('bootstrap_reference_data','audits'),'bootstrap_reference_data')
        observer=create_engine(eng.url,connect_args={'connect_timeout':5})
        fired=[]
        def terminate_before_update(conn,cursor,statement,parameters,context,executemany):
            if statement.startswith('UPDATE seeding_domain_claims') and not fired:
                with observer.begin() as db:
                    if db.scalar(text('SELECT pg_terminate_backend(:pid)'),{'pid':group.guard.pid}) is not True:
                        raise RuntimeError('Owned backend termination failed')
                fired.append(True)
        event.listen(eng,'before_cursor_execute',terminate_before_update)
        try:
            receipt=job(factory,group)
            result=expect_rejection(eng,group,receipt)
            if not fired:
                raise AssertionError('Termination did not execute during UPDATE')
            return {'refusal':result,'active':active(eng),'fired':True}
        finally:
            event.remove(eng,'before_cursor_execute',terminate_before_update)
            group.close()
            observer.dispose()
checked('backend_loss_during_release_update',backend_during_update)

admin.dispose()
receipt={'generated_by':Path(__file__).name,'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'runtime':sys.version,'sqlalchemy':sqlalchemy.__version__,'platform':platform.platform(),
    'cases':results,'counts':{v:sum(r['verdict']==v for r in results) for v in ('PASS','FAIL')},
    'verdict':'PASS' if all(r['verdict']=='PASS' for r in results) else 'FAIL'}
out=Path(sys.argv[1])
with out.open('x') as handle:
    json.dump(receipt,handle,indent=2)
readback=json.loads(out.read_text())
if readback['generator_sha256'] != receipt['generator_sha256'] or readback['verdict'] != receipt['verdict']:
    raise RuntimeError('Receipt readback mismatch')
print('FINAL_RESULT',json.dumps(receipt['counts']),receipt['verdict'],flush=True)
sys.exit(0 if receipt['verdict']=='PASS' else 1)
