"""Own exactly one PostgreSQL instance and bind independent execution records."""
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
from uuid import uuid4

ROOT=Path('/Users/roger/.codex/worktrees/batch11-bootstrap-admission/audit_app')
OUT=Path(__file__).parent
RUNTIME_ROOT=Path('/Users/roger/.codex/visualizations/2026/10/10/01a123ab-83d1-77f1-86c1-cead165c4704/batch10-readiness-owned')
RUNTIMES={'current':RUNTIME_ROOT/'venv/bin/python','minimum':RUNTIME_ROOT/'min312-venv/bin/python'}
IMAGE='public.ecr.aws/docker/library/postgres@sha256:67f41722b7a8cbdb868a44a4995c846eddfdc2973bccb291ce937dce88ad5675'
NAME='batch11-bootstrap-adversarial-603-'+uuid4().hex[:10]
NETWORK=NAME+'-network'
VOLUME=NAME+'-volume'
LABEL='audit.owner=batch11-603-independent-adversarial'
ENDPOINT=next(p for p in (Path('/var/run/docker.sock'),Path('/Users/roger/.docker/run/docker.sock')) if p.exists())
SAFE_PATH='/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
URL='postgresql+psycopg2://batch11_bootstrap:inert-local@127.0.0.1:55540/batch11-bootstrap-adversarial-603'
resource={'name':NAME,'network':NETWORK,'volume':VOLUME,'image':IMAGE,'port':55540,'label':LABEL,'commands':[]}
def exclusive(path,value):
    with path.open('x') as handle:
        json.dump(value,handle,indent=2)
    if json.loads(path.read_text())!=value:
        raise RuntimeError('Record readback mismatch')
def docker(*args,check=True):
    cmd=['docker','--host','unix://'+str(ENDPOINT),*args]
    value=subprocess.run(cmd,env={'PATH':SAFE_PATH},capture_output=True,text=True,timeout=30)
    resource['commands'].append({'command':cmd,'exit':value.returncode,'stdout':value.stdout,'stderr':value.stderr})
    if check and value.returncode:
        raise RuntimeError('Docker setup/cleanup failed: '+str(args[:2])+value.stderr)
    return value
def source():
    def git(*args):
        return subprocess.check_output(['git',*args],cwd=ROOT,text=True,env={'PATH':SAFE_PATH})
    files=git('ls-files','backend').splitlines()
    files += ['backend/tests/batch11_bootstrap_fixture/probe.py',
        'backend/tests/batch11_bootstrap_fixture/sitecustomize.py',
        'backend/tests/batch11_bootstrap_fixture/postgres.py',
        'backend/tests/test_batch11_bootstrap_admission.py']
    return {'head':git('rev-parse','HEAD').strip(),'tree':git('rev-parse','HEAD^{tree}').strip(),
        'status':git('status','--porcelain'),'tracked_backend':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sorted(set(files))},
        'generators':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),OUT/'attacks.py')}}
def run(name, runtime, entry, args, extra_env=None, timeout=120):
    before=source()
    command=[str(runtime),str(entry),*args]
    env={'PATH':SAFE_PATH,'DATABASE_URL':URL,'PYTHONPATH':str(ROOT/'backend'),
        'PYTHON_DOTENV_DISABLED':'1','PYTHONDONTWRITEBYTECODE':'1','JWT_SECRET_KEY':'inert-bootstrap-key',
        'AUTO_SEEDER_ENABLED':'false','AUTO_WARMUP_ENABLED':'false','ENVIRONMENT':'test',
        'SEED_STORAGE_PATH':str(OUT/(name+'-cache'))}
    if extra_env:
        env.update(extra_env)
    began=time.time()
    child=subprocess.Popen(command,cwd=ROOT/'backend',env=env,stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,text=True,start_new_session=True)
    timed_out=False
    try:
        output,_=child.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out=True
        os.killpg(child.pid,signal.SIGKILL)
        output,_=child.communicate(timeout=10)
    after=source()
    log=OUT/(name+'.log')
    with log.open('x') as handle:
        handle.write(output)
    record={'generated_by':Path(__file__).name,'generator_sha256':before['generators'][Path(__file__).name],
        'command':command,'child_exit':child.returncode,'timed_out':timed_out,'started_unix':began,
        'duration_seconds':time.time()-began,'source_before':before,'source_after':after,
        'source_stable':before==after,'allowlisted_environment':env,'output':log.name,
        'output_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    exclusive(OUT/(name+'-execution.json'),record)
    print('EXECUTED',name,'exit',child.returncode,'source_stable',record['source_stable'],flush=True)
    return output,record

network_id=volume_id=container_id=None
try:
    with socket.socket() as probe:
        probe.bind(('127.0.0.1',55540))
    resource['port_verified_free']=True
    image=json.loads(docker('image','inspect',IMAGE).stdout)[0]
    server=json.loads(docker('version','--format','{{json .Server}}').stdout)
    if IMAGE not in image['RepoDigests'] or image['Os']!=server['Os'] or image['Architecture']!=server['Arch']:
        raise RuntimeError('Image/platform prerequisite mismatch')
    resource.update(image_id=image['Id'],server=server)
    network_id=docker('network','create','--internal','--label',LABEL,NETWORK).stdout.strip()
    volume_id=docker('volume','create','--label',LABEL,VOLUME).stdout.strip()
    container_id=docker('run','--pull=never','-d','--name',NAME,'--network',NETWORK,'--label',LABEL,
        '-p','127.0.0.1:55540:5432','-v',VOLUME+':/var/lib/postgresql/data',
        '-e','POSTGRES_USER=batch11_bootstrap','-e','POSTGRES_PASSWORD=inert-local',
        '-e','POSTGRES_DB=batch11-bootstrap-adversarial-603',IMAGE).stdout.strip()
    resource.update(container_id=container_id,network_id=network_id,volume_id=volume_id)
    state=json.loads(docker('inspect',container_id).stdout)[0]
    if state['Name']!='/'+NAME or state['Config']['Labels'].get('audit.owner')!=LABEL.split('=',1)[1]:
        raise RuntimeError('Container ownership mismatch')
    deadline=time.monotonic()+30
    while docker('exec',container_id,'pg_isready','-h','127.0.0.1','-U','batch11_bootstrap',check=False).returncode:
        if time.monotonic()>deadline:
            raise RuntimeError('Postgres startup prerequisite timeout')
        time.sleep(.1)
    for label,runtime in RUNTIMES.items():
        run(label+'-attacks',runtime,OUT/'attacks.py',[str(OUT/(label+'-attacks.json'))])
    # Replay actual CLI/startup process seam with independent schemas on our DB.
    from sqlalchemy import create_engine,text
    from sqlalchemy.engine import make_url
    admin=create_engine(URL)
    try:
        for label,runtime in RUNTIMES.items():
            for mode in ('retained_fresh','retained_stale','untagged','active_ready','race','race_force','schema_failure','query_failure','completed'):
                schema='independent_'+uuid4().hex
                with admin.begin() as db:
                    db.execute(text(f'CREATE SCHEMA "{schema}"'))
                try:
                    schema_url=make_url(URL).update_query_dict({'options':'-csearch_path='+schema}).render_as_string(hide_password=False)
                    output,record=run(label+'-startup-'+mode,runtime,ROOT/'backend/tests/batch11_bootstrap_fixture/probe.py',[mode],
                        {'DATABASE_URL':schema_url,'BATCH11_BOOTSTRAP_INERT':'1',
                        'PYTHONPATH':str(ROOT/'backend/tests/batch11_bootstrap_fixture')+':'+str(ROOT/'backend')},timeout=60)
                    lines=[json.loads(v.removeprefix('ADMISSION_RESULT ')) for v in output.splitlines() if v.startswith('ADMISSION_RESULT ')]
                    result={'identity':label+'-startup-'+mode,'verdict':'SETUP_FAILURE','source_stable':record['source_stable']}
                    if record['child_exit']==0 and not record['timed_out'] and len(lines)==1:
                        value=lines[0]
                        passed=(value['ready'] is True and value['startup_effects']==['scheduler'] and value['after']['tables']['entities']==48) if mode=='completed' else (
                            value['before']==value['after'] and value['startup_effects']==[] and value['ready'] is (mode=='active_ready'))
                        result.update(verdict='PASS' if passed else 'FAIL',ready=value['ready'],effects=value['startup_effects'],
                            reason=value['reason'],writer_exit=value['writer_exit'])
                    exclusive(OUT/(label+'-startup-'+mode+'-verdict.json'),result)
                    print('PROCESS_CASE',json.dumps(result),flush=True)
                finally:
                    with admin.begin() as db:
                        db.execute(text(f'DROP SCHEMA "{schema}" CASCADE'))
    finally:
        admin.dispose()
finally:
    if container_id:
        state=json.loads(docker('inspect',container_id).stdout)[0]
        if state['Name']!='/'+NAME or state['Config']['Labels'].get('audit.owner')!=LABEL.split('=',1)[1]:
            raise RuntimeError('Container cleanup ownership mismatch')
        docker('rm','-f',container_id)
        resource['container_removed']=docker('inspect',container_id,check=False).returncode!=0
    if volume_id:
        state=json.loads(docker('volume','inspect',VOLUME).stdout)[0]
        if state['Name']!=VOLUME or state['Labels'].get('audit.owner')!=LABEL.split('=',1)[1]:
            raise RuntimeError('Volume cleanup ownership mismatch')
        docker('volume','rm',VOLUME)
        resource['volume_removed']=docker('volume','inspect',VOLUME,check=False).returncode!=0
    if network_id:
        state=json.loads(docker('network','inspect',network_id).stdout)[0]
        if state['Name']!=NETWORK or state['Labels'].get('audit.owner')!=LABEL.split('=',1)[1] or state['Containers']:
            raise RuntimeError('Network cleanup ownership mismatch')
        docker('network','rm',network_id)
        resource['network_removed']=docker('network','inspect',network_id,check=False).returncode!=0
    with socket.socket() as probe:
        probe.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        probe.bind(('127.0.0.1',55540))
    resource['port_reusable']=True
    resource['generator_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    exclusive(OUT/'resources.json',resource)
    print('CLEANUP_READBACK',json.dumps({k:resource[k] for k in ('container_removed','volume_removed','network_removed','port_reusable')}),flush=True)
