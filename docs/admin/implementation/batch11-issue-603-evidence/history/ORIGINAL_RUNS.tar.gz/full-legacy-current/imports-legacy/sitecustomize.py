import importlib.util
from importlib.abc import MetaPathFinder
import os
import sys
try:
    spec = importlib.util.spec_from_file_location('_ci_package_owner', '/Users/roger/.codex/worktrees/batch11-bootstrap-admission/audit_app/.github/scripts/run_backend_tests.py')
    launcher = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(launcher)
    owners = {'seeding': launcher.BACKEND / 'seeding',
              'etl': launcher.ROOT / 'etl'}
    for name, directory in owners.items():
        launcher.owned_package_spec(name, directory)
    class PackageOwner(MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            if fullname in owners:
                return launcher.owned_package_spec(fullname, owners[fullname])
            return None
    sys.meta_path.insert(0, PackageOwner())
except BaseException:
    os.write(2, b'CI descendant package ownership failed\n')
    os._exit(78)
