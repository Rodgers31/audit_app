import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/Users/roger/.codex/worktrees/batch11-bootstrap-admission/audit_app')
OUT = Path(__file__).parent
ORIGINAL = OUT / 'current-packet'
VERIFY = ROOT / 'docs/admin/implementation/batch11-issue-603-evidence/verify.py'
result = []
for fault in ('valid', 'null_timestamp', 'invalid_environment', 'enabled_dispatch', 'wrong_portable_entrypoint'):
    for optimized in (False, True):
        packet = OUT / f'mutant-{fault}-{optimized}'
        shutil.copytree(ORIGINAL, packet)
        index = json.loads((packet / 'INDEX.json').read_text())
        receipt = json.loads((packet / 'receipt.json').read_text())
        if fault == 'null_timestamp':
            receipt['started_at'] = None
        elif fault == 'invalid_environment':
            receipt['environment'] = None
        elif fault == 'enabled_dispatch':
            receipt['environment']['ENABLE_ETL_SCHEDULER'] = 'true'
        elif fault == 'wrong_portable_entrypoint':
            index['portable_command'] = ['<python>', '-m', 'fake_cli']
        (packet / 'receipt.json').write_text(json.dumps(receipt, indent=2))
        index['files']['receipt.json'] = hashlib.sha256((packet / 'receipt.json').read_bytes()).hexdigest()
        (packet / 'INDEX.json').write_text(json.dumps(index, indent=2))
        command = [sys.executable, *(['-O'] if optimized else []), str(VERIFY), '--root', str(ROOT), '--index', str(packet / 'INDEX.json')]
        child = subprocess.run(command, env=dict(PATH=os.environ['PATH'], PYTHON_DOTENV_DISABLED='1', PYTHONDONTWRITEBYTECODE='1'), text=True, capture_output=True, timeout=10)
        log = packet / 'validation.log'
        log.write_text(child.stdout + child.stderr)
        result.append(dict(fault=fault, optimized=optimized, exit=child.returncode, command=command, raw_log=str(log), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
with (OUT / 'packet-controls-results.json').open('x') as stream:
    json.dump(dict(generator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), results=result),stream,indent=2)
print(json.dumps(result,indent=2))
assert all(r['exit'] == 0 for r in result if r['fault'] == 'valid')
