import importlib.util,sys,json,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
root=Path(sys.argv[1]);out=Path(sys.argv[2])
spec=importlib.util.spec_from_file_location('standards_record',root/'docs/admin/implementation/batch11-issue-611-evidence/record.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
common=Path(m.git('rev-parse','--path-format=absolute','--git-common-dir'))
rows=subprocess.check_output(['git','worktree','list','--porcelain','-z'],cwd=root).decode().split('\0')
checkouts=[Path(row[9:]) for row in rows if row.startswith('worktree ')]
link=out/'source-link';link.symlink_to(root,target_is_directory=True)
vectors=[('external',out/'unused-fresh',True,True),('existing',out,True,False),('git-name',out/'.git'/'output',False,False),('dotdot',out/'abc'/'..'/'dest',False,False),('symlink',link/'output',False,False),('common-git',common/'standards-output',False,False)]+[(f'checkout-{i}',p/'standards-output',False,False) for i,p in enumerate(checkouts)]
results=[]
for name,path,fresh,expected in vectors:
 try:m.output_path(path,fresh=fresh);accepted=True;error=None
 except ValueError as exc:accepted=False;error=str(exc)
 results.append({'id':name,'expected':expected,'accepted':accepted,'passed':accepted==expected,'error':error})
link.unlink()
print(json.dumps({'cases':results,'python':sys.version},indent=2))
sys.exit(0 if all(r['passed'] for r in results) else 1)
