import importlib.util,json,sys,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
root=Path(sys.argv[1]); packet=root/'docs/admin/implementation/batch11-issue-611-evidence'
spec=importlib.util.spec_from_file_location('standards_prototype',packet/'prototype.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
from fastapi import HTTPException
valid=['3:3:','3:5:3,4','4294967294:4294967299:4294967295,4294967297','9007199254740993:9007199254740995:9007199254740994','18446744073709551613:18446744073709551615:18446744073709551614','03:05:03,04']
invalid=[None,True,False,0,3.0,float('nan'),float('inf'),[],{},'','2:5:','5:3:','3:18446744073709551616:','3:5:5','3:5:2','3:5:4,3','3:5:3,3','٣:٥:','3:5:+4','3:5:4,','3:5: 4','3:5:4:','3:5:4\n','3:5:4\r','3:5:4\u2028','3:5:4\u2029','3:5:'+('4,'*2100)]
results=[]
for value,expected in [(v,True) for v in valid]+[(v,False) for v in invalid]:
 try: actual=module.snapshot8(value);accepted=True
 except HTTPException as e: actual=e.status_code;accepted=False
 results.append({'id':'snapshot/'+str(len(results)),'input_repr':repr(value),'expected':expected,'accepted':accepted,'actual':actual,'passed':accepted==expected})
scope='61100000-0000-4000-8000-000000000001'
bookmarks=[('v2:'+scope+':'+v,True) for v in valid]+[(v,False) for v in [None,True,{},'3:5:','v1:'+scope+':3:5:','v3:'+scope+':3:5:','v2:garbage:3:5:','v2:'+scope.upper()+':3:5:','v2:{'+scope+'}:3:5:','v2:'+scope.replace('-','')+':3:5:','v2:'+scope+':3:5:4,3','v2:'+scope+':3:5:5']]
# This scope happens to contain digits only; use alphabetic scope to test case canonicality.
bookmarks=[(v,e) for v,e in bookmarks if v!='v2:'+scope.upper()+':3:5:']+[('v2:abcdefab-cdef-abcd-efab-cdefabcdefab:3:5:',True),('v2:ABCDEFAB-CDEF-ABCD-EFAB-CDEFABCDEFAB:3:5:',False)]
for value,expected in bookmarks:
 try: actual=module.bookmark(value);accepted=True
 except HTTPException as e: actual=e.status_code;accepted=False
 results.append({'id':'bookmark/'+str(len(results)),'input_repr':repr(value),'expected':expected,'accepted':accepted,'actual':actual,'passed':accepted==expected})
print(json.dumps({'python':sys.version,'source_sha256':hashlib.sha256((packet/'prototype.py').read_bytes()).hexdigest(),'cases':results},indent=2))
sys.exit(0 if all(r['passed'] for r in results) else 1)
