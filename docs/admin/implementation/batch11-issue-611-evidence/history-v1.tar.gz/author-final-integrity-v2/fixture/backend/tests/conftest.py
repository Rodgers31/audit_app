def pytest_collection_modifyitems(items):
    for item in items:
        if item.nodeid.startswith("tests/test_duplicate.py::"):
            item._nodeid="tests/test_duplicate.py::same_identity"
