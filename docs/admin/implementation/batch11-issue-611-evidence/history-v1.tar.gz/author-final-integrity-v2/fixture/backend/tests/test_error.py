import pytest
@pytest.fixture
def failure():
    raise RuntimeError("controlled setup failure")
def test_error(failure):
    pass
