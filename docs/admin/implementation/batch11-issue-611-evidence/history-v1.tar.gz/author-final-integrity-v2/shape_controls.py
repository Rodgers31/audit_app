import copy
import hashlib
import json
import platform
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime, timezone

OUT=Path(__file__).parent
FIXTURE=OUT/'fixture'; PACKET=FIXTURE/'docs/admin/implementation/batch11-issue-611-evidence'
RUNS=OUT/'runs'; POSITIVE=RUNS/'positive'
ENV={'PATH':'/usr/bin:/bin','PYTHON_DOTENV_DISABLED':'1'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=FIXTURE,env=ENV,text=True,timeout=10).strip()
before={name:sha(PACKET/name) for name in ['record.py','verify_run.py']}
status=git('status','--porcelain=v1'); caches_before={str(p.relative_to(FIXTURE)):sha(p) for p in FIXTURE.rglob('*.pyc')}
original=json.loads((POSITIVE/'run.json').read_text());original_exec=json.loads((POSITIVE/'execution.json').read_text());rows=[]
mutations={
 'different-shaped-command':lambda e:e['command'].__setitem__(6,'tests/test_error.py'),
 'fictional-platform':lambda e:e.update(platform='fictional-platform'),
 'ancient-date':lambda e:e.update(generated_at='1970-01-01T00:00:00+00:00'),
}
for name,mutate in mutations.items():
    folder=RUNS/('shape-'+name);folder.mkdir()
    for output in original['outputs_sha256']:shutil.copyfile(POSITIVE/output,folder/output)
    e=copy.deepcopy(original_exec);mutate(e);(folder/'execution.json').write_text(json.dumps(e,indent=2));r=copy.deepcopy(original);r.update(e);r['outputs_sha256']['execution.json']=sha(folder/'execution.json');(folder/'run.json').write_text(json.dumps(r,indent=2))
    for optimized in [False,True]:
        command=[sys.executable,*(['-O'] if optimized else []),str(PACKET/'verify_run.py'),str(folder/'run.json')]
        p=subprocess.run(command,cwd=FIXTURE,env=ENV,text=True,capture_output=True,timeout=30)
        row={'id':name+('-optimized' if optimized else ''),'command':command,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'actual_success':p.returncode==0}
        rows.append(row);print(json.dumps(row),flush=True)
folder=RUNS/'shape-junit-summary';folder.mkdir()
for output in original['outputs_sha256']:shutil.copyfile(POSITIVE/output,folder/output)
tree=ET.parse(folder/'tests.xml');suite=next(tree.iter('testsuite'));suite.set('errors','1');suite.set('tests','2');tree.write(folder/'tests.xml',encoding='unicode');r=copy.deepcopy(original);r['outputs_sha256']['tests.xml']=sha(folder/'tests.xml');(folder/'run.json').write_text(json.dumps(r,indent=2))
for optimized in [False,True]:
    command=[sys.executable,*(['-O'] if optimized else []),str(PACKET/'verify_run.py'),str(folder/'run.json')]
    p=subprocess.run(command,cwd=FIXTURE,env=ENV,text=True,capture_output=True,timeout=30)
    row={'id':'inconsistent-junit-summary'+('-optimized' if optimized else ''),'command':command,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'actual_success':p.returncode==0}
    rows.append(row);print(json.dumps(row),flush=True)
receipt={'generated_by':Path(__file__).name,'generator_sha256':sha(Path(__file__)),'generated_at':datetime.now(timezone.utc).isoformat(),'source_sha256':before,'source_unchanged':all(sha(PACKET/name)==hash_ for name,hash_ in before.items()),'fixture_head':git('rev-parse','HEAD'),'fixture_tree':git('rev-parse','HEAD^{tree}'),'status_unchanged':status==git('status','--porcelain=v1'),'cache_unchanged':caches_before=={str(p.relative_to(FIXTURE)):sha(p) for p in FIXTURE.rglob('*.pyc')},'runtime':platform.python_version(),'cases':rows,'accepted_count':sum(row['actual_success'] for row in rows)}
with (OUT/'shape-controls.json').open('x') as f:json.dump(receipt,f,indent=2)
if json.loads((OUT/'shape-controls.json').read_text())!=receipt:raise RuntimeError('readback failed')
