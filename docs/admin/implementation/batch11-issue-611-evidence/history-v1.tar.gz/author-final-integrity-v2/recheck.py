import copy
import hashlib
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from datetime import datetime, timezone

OUT=Path(__file__).parent
ROOT=Path('/Users/roger/.codex/worktrees/batch11-audit-pagination/audit_app')
PACKET=ROOT/'docs/admin/implementation/batch11-issue-611-evidence'
HOST=OUT/'fixture-host';FIXTURE=OUT/'fixture';RUNS=OUT/'runs'
HOST.mkdir();RUNS.mkdir()
# Deliberately omit PYTHONDONTWRITEBYTECODE, PYTHONPYCACHEPREFIX and -B.
ENV={'PATH':'/usr/bin:/bin','PYTHON_DOTENV_DISABLED':'1','DATABASE_URL':'sqlite:///'+str(OUT/'inert.sqlite'),'SUPABASE_URL':'http://127.0.0.1:18034','SUPABASE_SERVICE_ROLE_KEY':'inert','SUPABASE_JWT_SECRET':'inert'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(cwd,*args):return subprocess.check_output(['git',*args],cwd=cwd,env=ENV,text=True,timeout=10).strip()
def caches(root):return {str(p.relative_to(root)):sha(p) for p in root.rglob('*.pyc')}
def sources(root):return {p:sha(root/p) for p in git(root,'ls-files').splitlines()}
def process(args,cwd=FIXTURE):
    r=subprocess.run(list(map(str,args)),cwd=cwd,env=ENV,text=True,capture_output=True,timeout=30)
    return {'command':list(map(str,args)),'cwd':str(cwd),'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
candidate_before={name:sha(PACKET/name) for name in ['record.py','verify_run.py']}
candidate_status=git(ROOT,'status','--porcelain=v1')
candidate_caches=caches(PACKET)
setup=[]
for args in [['git','init',HOST],['git','-C',HOST,'-c','user.name=Adversary','-c','user.email=adversary@example.invalid','commit','--allow-empty','-m','test: initialize owned repaired-recorder fixture'],['git','-C',HOST,'worktree','add','-b','adversary-recheck',FIXTURE]]:
    row=process(args,cwd=OUT);setup.append(row)
    if row['exit']:raise RuntimeError(row)
packet=FIXTURE/'docs/admin/implementation/batch11-issue-611-evidence';packet.mkdir(parents=True)
for name in candidate_before:shutil.copyfile(PACKET/name,packet/name)
tests=FIXTURE/'backend/tests';tests.mkdir(parents=True)
(tests/'test_pass.py').write_text('def test_pass():\n    assert True\n')
(tests/'test_empty.py').write_text('# no executed cases\n')
(tests/'test_error.py').write_text('import pytest\n@pytest.fixture\ndef failure():\n    raise RuntimeError("controlled setup failure")\ndef test_error(failure):\n    pass\n')
(tests/'test_duplicate.py').write_text('def test_one():\n    assert True\ndef test_two():\n    assert True\n')
(tests/'conftest.py').write_text('def pytest_collection_modifyitems(items):\n    for item in items:\n        if item.nodeid.startswith("tests/test_duplicate.py::"):\n            item._nodeid="tests/test_duplicate.py::same_identity"\n')
target=HOST/'.git'/'symlink-race-target';target.mkdir()
(tests/'test_race.py').write_text('from pathlib import Path\ndef test_redirect_output(request):\n    out=Path(request.config.option.xmlpath).parent\n    original=out.with_name(out.name+"-original")\n    out.rename(original)\n    out.symlink_to('+repr(str(target))+',target_is_directory=True)\n    assert out.is_symlink()\n')
for args in [['git','add','.'],['git','-c','user.name=Adversary','-c','user.email=adversary@example.invalid','commit','-m','test: own repaired recorder and verifier controls']]:
    row=process(args);setup.append(row)
    if row['exit']:raise RuntimeError(row)
fixture_before=sources(FIXTURE);fixture_status=git(FIXTURE,'status','--porcelain=v1');fixture_caches=caches(FIXTURE)
rows=[]
def record_row(id,result,expected,receipt_path=None):
    success=result['exit']==0
    row={'id':id,'expected_success':expected,'actual_success':success,'passed':success==expected,'process':result,'fixture_status_unchanged':git(FIXTURE,'status','--porcelain=v1')==fixture_status,'fixture_cache_unchanged':caches(FIXTURE)==fixture_caches,'fixture_source_unchanged':sources(FIXTURE)==fixture_before}
    if receipt_path and receipt_path.is_file():row['receipt']=json.loads(receipt_path.read_text())
    rows.append(row)
    with (OUT/(id+'.process.json')).open('x') as f:json.dump(row,f,indent=2)
    print(json.dumps({'id':id,'exit':result['exit'],'expected_success':expected,'actual_success':success,'source_unchanged':row['fixture_source_unchanged'],'status_unchanged':row['fixture_status_unchanged'],'cache_unchanged':row['fixture_cache_unchanged'],'stdout':result['stdout'],'stderr':result['stderr']}),flush=True)
def producer(id,path,selection,expected,optimized=False):
    result=process([sys.executable,*(['-O'] if optimized else []),packet/'record.py','--python',sys.executable,'--out',path,*selection])
    record_row(id,result,expected,path/'run.json')
    return result
def verifier(id,path,expected,optimized=False):
    record_row(id,process([sys.executable,*(['-O'] if optimized else []),packet/'verify_run.py',path]),expected)
positive=RUNS/'positive'
if producer('produce-positive',positive,['tests/test_pass.py'],True)['exit']:raise RuntimeError('positive prerequisite failed')
verifier('verify-positive',positive/'run.json',True)
verifier('verify-positive-optimized',positive/'run.json',True,True)
optimized=RUNS/'optimized-positive'
producer('produce-positive-optimized',optimized,['tests/test_pass.py'],True,True)
verifier('verify-optimized-producer',optimized/'run.json',True)
for id,path,test in [('hidden-git',HOST/'.git'/'forbidden-output','tests/test_pass.py'),('sibling-checkout',HOST/'forbidden-output','tests/test_pass.py'),('destination-race',RUNS/'destination-race','tests/test_race.py'),('empty-inventory',RUNS/'empty','tests/test_empty.py'),('error-inventory',RUNS/'error','tests/test_error.py'),('duplicate-inventory',RUNS/'duplicate','tests/test_duplicate.py'),('internal-source',FIXTURE/'forbidden-output','tests/test_pass.py')]:
    producer('produce-'+id,path,[test],False)
original=json.loads((positive/'run.json').read_text()); original_exec=json.loads((positive/'execution.json').read_text())
names=list(original['outputs_sha256'])
if len(names)!=6:raise RuntimeError('expected all six retained producer outputs')
def fresh(name):
    folder=RUNS/name;folder.mkdir()
    for output in names:shutil.copyfile(positive/output,folder/output)
    return folder
mutations={
 'bool-exit':lambda r:r.update(child_exit=False),
 'bool-verification':lambda r:r.update(verification_exit=False),
 'bool-count':lambda r:r['counts'].update(passed=True),
 'nan-count':lambda r:r['counts'].update(passed=float('nan')),
 'inf-exit':lambda r:r.update(child_exit=float('inf')),
 'string-unchanged':lambda r:r.update(source_unchanged='true'),
 'empty-cases':lambda r:r.update(cases=[],counts={'passed':0,'failure':0,'error':0,'skipped':0}),
 'duplicate-cases':lambda r:r.update(cases=r['cases']*2,counts={'passed':2,'failure':0,'error':0,'skipped':0}),
 'wrong-generator':lambda r:r.update(generated_by='fiction.py'),
 'stale-source':lambda r:r['source_sha256'].update({'backend/tests/test_pass.py':'0'*64}),
 'invented-case':lambda r:r['cases'][0].update(id='fabricated.test_module::test_not_executed'),
 'invented-git':lambda r:r.update(target_commit='0'*40,target_tree='0'*40),
 'missing-metadata':lambda r:[r.pop(k,None) for k in ['command','env','generated_at','platform','status_before','status_after']],
 'fictional-runtime':lambda r:r.update(runtime={'python':'fiction','sqlalchemy':'fiction','fastapi':'fiction'}),
}
for id,mutate in mutations.items():
    folder=fresh('receipt-'+id);r=copy.deepcopy(original);mutate(r);(folder/'run.json').write_text(json.dumps(r,indent=2))
    verifier('receipt-'+id,folder/'run.json',False);verifier('receipt-'+id+'-optimized',folder/'run.json',False,True)
# Mutate retained execution AND duplicate receipt fields; update execution digest.
exec_mutations={
 'invented-git':lambda e:e.update(target_commit='0'*40,target_tree='0'*40),
 'fictional-runtime':lambda e:e.update(runtime={'python':'fiction','sqlalchemy':'fiction','fastapi':'fiction'}),
 'fake-status':lambda e:e.update(status_before='?? fictional-source.py',status_after='?? fictional-source.py'),
 'missing-command':lambda e:e.pop('command'),
 'bad-command':lambda e:e.update(command=['<owned-python>','-c','print("fiction")']),
 'bad-env':lambda e:e.update(env={'DATABASE_URL':'fiction'}),
 'bool-exit':lambda e:e.update(child_exit=False),
 'invalid-date':lambda e:e.update(generated_at='not-a-date'),
 'bad-probe-command':lambda e:e.update(runtime_probe_command=['<owned-python>','-c','print("fiction")']),
}
for id,mutate in exec_mutations.items():
    folder=fresh('execution-'+id);e=copy.deepcopy(original_exec);mutate(e);(folder/'execution.json').write_text(json.dumps(e,indent=2));r=copy.deepcopy(original)
    for key in original_exec:
        if key in e:r[key]=e[key]
        else:r.pop(key,None)
    r['outputs_sha256']['execution.json']=sha(folder/'execution.json');(folder/'run.json').write_text(json.dumps(r,indent=2))
    verifier('execution-'+id,folder/'run.json',False);verifier('execution-'+id+'-optimized',folder/'run.json',False,True)
# Each actual output symlink is rejected even when retained content/hash is valid.
link=RUNS/'symlink-receipt';link.symlink_to(positive,target_is_directory=True)
verifier('symlink-receipt',link/'run.json',False);verifier('symlink-receipt-optimized',link/'run.json',False,True)
folder=fresh('symlink-output');(folder/'stdout.txt').unlink();(folder/'stdout.txt').symlink_to(positive/'stdout.txt');(folder/'run.json').write_text(json.dumps(original,indent=2))
verifier('symlink-output',folder/'run.json',False);verifier('symlink-output-optimized',folder/'run.json',False,True)
verifier('internal-receipt',packet/'record.py',False)
receipt={'generated_by':str(Path(__file__).name),'generator_sha256':sha(Path(__file__)),'generated_at':datetime.now(timezone.utc).isoformat(),'target_commit':git(ROOT,'rev-parse','HEAD'),'target_tree':git(ROOT,'rev-parse','HEAD^{tree}'),'source_sha256':{str((PACKET/name).relative_to(ROOT)):value for name,value in candidate_before.items()},'source_unchanged':all(sha(PACKET/name)==value for name,value in candidate_before.items()),'candidate_status_before':candidate_status,'candidate_status_after':git(ROOT,'status','--porcelain=v1'),'candidate_cache_before':candidate_caches,'candidate_cache_after':caches(PACKET),'fixture_status_before':fixture_status,'fixture_status_after':git(FIXTURE,'status','--porcelain=v1'),'fixture_cache_before':fixture_caches,'fixture_cache_after':caches(FIXTURE),'fixture_source_sha256':fixture_before,'fixture_source_unchanged':sources(FIXTURE)==fixture_before,'copied_source_sha256':{name:sha(packet/name) for name in candidate_before},'runtime':platform.python_version(),'platform':platform.platform(),'env':ENV,'setup':setup,'cases':rows,'counts':{'passed':sum(r['passed'] for r in rows),'failure':sum(not r['passed'] for r in rows)}}
with (OUT/'recheck.json').open('x') as f:json.dump(receipt,f,indent=2)
if json.loads((OUT/'recheck.json').read_text())!=receipt:raise RuntimeError('readback failed')
print(json.dumps({'counts':receipt['counts'],'source_unchanged':receipt['source_unchanged'],'fixture_source_unchanged':receipt['fixture_source_unchanged'],'candidate_status_unchanged':receipt['candidate_status_before']==receipt['candidate_status_after'],'candidate_cache_unchanged':receipt['candidate_cache_before']==receipt['candidate_cache_after'],'fixture_status_unchanged':receipt['fixture_status_before']==receipt['fixture_status_after'],'fixture_cache_unchanged':receipt['fixture_cache_before']==receipt['fixture_cache_after'],'source_sha256':receipt['source_sha256']}),flush=True)
raise SystemExit(1 if receipt['counts']['failure'] else 0)
