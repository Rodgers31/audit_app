"""Portable audit-cohort recorder. Outputs must be fresh and outside the checkout."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[4]


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory():
    paths = set(git("ls-files").splitlines())
    for directory in (
        "backend/tests/admin_audit_epoch",
        "docs/admin/implementation/batch11-issue-611-evidence",
    ):
        paths.update(
            str(p.relative_to(ROOT))
            for p in (ROOT / directory).rglob("*")
            if p.is_file() and "__pycache__" not in p.parts
        )
    return {p: digest(ROOT / p) for p in sorted(paths)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--python", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("tests", nargs="+")
    args = parser.parse_args()
    out = args.out.absolute()
    if out.resolve() != out or ROOT == out or ROOT in out.parents or out.exists():
        raise ValueError(
            "Fresh external output required; no internal or symlink destinations"
        )
    if not args.python.is_file() or any(
        not name.startswith("tests/") or ".." in Path(name).parts for name in args.tests
    ):
        raise ValueError("Explicit interpreter and backend tests required")
    out.mkdir(parents=True, exist_ok=False)
    before = inventory()
    status = git("status", "--porcelain=v1")
    env = {
        "PATH": "/usr/bin:/bin",
        "PYTHON_DOTENV_DISABLED": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": str(ROOT / "backend"),
        "DATABASE_URL": "postgresql+psycopg2://inert:inert@127.0.0.1:55534/issue611",
        "SUPABASE_URL": "http://127.0.0.1:18034",
        "SUPABASE_SERVICE_ROLE_KEY": "inert",
        "SUPABASE_JWT_SECRET": "inert",
        "ISSUE611_OWNED_POSTGRES": "1",
    }
    command = [
        str(args.python),
        "-m",
        "pytest",
        "--confcutdir=tests",
        "-p",
        "no:cacheprovider",
        *args.tests,
        "-v",
        "-s",
        f"--junitxml={out / 'tests.xml'}",
    ]
    metadata = subprocess.check_output(
        [
            str(args.python),
            "-c",
            "import json,sys,sqlalchemy,fastapi;print(json.dumps({'python':sys.version,'sqlalchemy':sqlalchemy.__version__,'fastapi':fastapi.__version__}))",
        ],
        env=env,
        text=True,
    )
    receipt = {
        "generated_by": str(Path(__file__).relative_to(ROOT)),
        "generator_sha256": digest(Path(__file__)),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "target_commit": git("rev-parse", "HEAD"),
        "target_tree": git("rev-parse", "HEAD^{tree}"),
        "source_sha256": before,
        "status_before": status,
        "runtime": json.loads(metadata),
        "platform": platform.platform(),
        "command": [
            "<owned-python>",
            *command[1:-1],
            "--junitxml=<external>/tests.xml",
        ],
        "env": {k: v for k, v in env.items() if k != "PYTHONPATH"},
    }
    try:
        child = subprocess.run(
            command,
            cwd=ROOT / "backend",
            env=env,
            capture_output=True,
            text=True,
            timeout=180,
        )
        (out / "stdout.txt").write_text(child.stdout)
        (out / "stderr.txt").write_text(child.stderr)
        receipt["child_exit"] = child.returncode
    except subprocess.TimeoutExpired as exc:
        (out / "stdout.txt").write_bytes(exc.stdout or b"")
        (out / "stderr.txt").write_bytes(exc.stderr or b"")
        receipt["child_exit"] = None
    cases = []
    if (out / "tests.xml").is_file():
        for case in ET.parse(out / "tests.xml").iter("testcase"):
            state = next(
                (
                    s
                    for s in ("failure", "error", "skipped")
                    if case.find(s) is not None
                ),
                "passed",
            )
            cases.append(
                {
                    "id": case.attrib["classname"] + "::" + case.attrib["name"],
                    "state": state,
                }
            )
    identities = [c["id"] for c in cases]
    unchanged = before == inventory() and status == git("status", "--porcelain=v1")
    receipt.update(
        cases=cases,
        counts={
            s: sum(c["state"] == s for c in cases)
            for s in ("passed", "failure", "error", "skipped")
        },
        source_unchanged=unchanged,
        status_after=git("status", "--porcelain=v1"),
    )
    accepted = (
        receipt["child_exit"] == 0
        and unchanged
        and bool(cases)
        and len(set(identities)) == len(identities)
        and all(c["state"] == "passed" for c in cases)
    )
    receipt["verification_exit"] = 0 if accepted else 1
    receipt["verdict"] = "PASS" if accepted else "NOT_ACCEPTED"
    receipt["outputs_sha256"] = {
        p.name: digest(p) for p in out.iterdir() if p.is_file()
    }
    with (out / "run.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    if json.loads((out / "run.json").read_text()) != receipt:
        raise RuntimeError("Receipt readback mismatch")
    print(
        json.dumps(
            {
                k: receipt[k]
                for k in ("verdict", "child_exit", "counts", "source_unchanged")
            }
        )
    )
    return receipt["verification_exit"]


if __name__ == "__main__":
    sys.exit(main())
