import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path('/Users/roger/.codex/worktrees/batch11-audit-pagination/audit_app')
OUT = Path(__file__).parent
SOURCE = ROOT/'docs/admin/implementation/batch11-issue-611-evidence/record.py'
PYTHON = Path(sys.executable)
ENV = {'PATH':'/usr/bin:/bin','PYTHON_DOTENV_DISABLED':'1','PYTHONDONTWRITEBYTECODE':'1','DATABASE_URL':'sqlite:///'+str(OUT/'inert.sqlite'),'SUPABASE_URL':'http://127.0.0.1:18034','SUPABASE_SERVICE_ROLE_KEY':'inert','SUPABASE_JWT_SECRET':'inert'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def execute(command,cwd=None):
    r=subprocess.run(list(map(str,command)),cwd=cwd,env=ENV,text=True,capture_output=True,timeout=30)
    return {'command':list(map(str,command)),'cwd':str(cwd) if cwd else None,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
host=OUT/'fixture-host'; fixture=OUT/'fixture'; host.mkdir()
setup=[execute(['git','init',host]),execute(['git','-C',host,'-c','user.name=Adversary','-c','user.email=adversary@example.invalid','commit','--allow-empty','-m','test: initialize owned recorder fixture']),execute(['git','-C',host,'worktree','add','-b','adversary-controls',fixture])]
for result in setup:
    if result['exit']: raise RuntimeError(result)
record=fixture/'docs/admin/implementation/batch11-issue-611-evidence/record.py';record.parent.mkdir(parents=True);shutil.copyfile(SOURCE,record)
tests=fixture/'backend/tests';tests.mkdir(parents=True)
contents={
 'test_pass.py':'def test_pass():\n    assert True\n',
 'test_empty.py':'# no executable test cases\n',
 'test_failure.py':'def test_failure():\n    assert False\n',
 'test_error.py':'import pytest\n@pytest.fixture\ndef broken():\n    raise RuntimeError("controlled setup error")\ndef test_error(broken):\n    pass\n',
 'test_skip.py':'import pytest\n@pytest.mark.skip(reason="controlled prerequisite skip")\ndef test_skip():\n    pass\n',
 'test_xfail.py':'import pytest\n@pytest.mark.xfail(reason="controlled expected failure")\ndef test_xfail():\n    assert False\n',
}
for name,bytes_ in contents.items():(tests/name).write_text(bytes_)
setup.extend([execute(['git','-C',fixture,'add','.']),execute(['git','-C',fixture,'-c','user.name=Adversary','-c','user.email=adversary@example.invalid','commit','-m','test: own recorder controls'])])
for result in setup:
    if result['exit']: raise RuntimeError(result)
source_before=sha(SOURCE);copied_sha=sha(record)
rows=[]
def run(id,destination,selection=['tests/test_pass.py'],expect=False):
    command=[PYTHON,record,'--python',PYTHON,'--out',destination,*selection]
    result=execute(command,cwd=fixture)
    path=destination/'run.json'
    parsed=None
    if path.is_file():
        try: parsed=json.loads(path.read_text())
        except Exception as e:parsed={'parse_error':repr(e)}
    success=result['exit']==0 and parsed is not None and parsed.get('verdict')=='PASS'
    row={'id':id,'expected_success':expect,'actual_success':success,'passed':success==expect,'process':result,'receipt':parsed}
    rows.append(row)
    (OUT/(id+'.process.json')).write_text(json.dumps(row,indent=2))
    print(json.dumps({'id':id,'exit':result['exit'],'actual_success':success,'expected_success':expect,'receipt_verdict':parsed.get('verdict') if parsed else None,'counts':parsed.get('counts') if parsed else None}),flush=True)
run('positive',OUT/'recorder-positive',expect=True)
run('empty',OUT/'recorder-empty',['tests/test_empty.py'])
run('duplicate',OUT/'recorder-duplicate',['tests/test_pass.py','tests/test_pass.py'])
run('failure',OUT/'recorder-failure',['tests/test_failure.py'])
run('error',OUT/'recorder-error',['tests/test_error.py'])
run('skip',OUT/'recorder-skip',['tests/test_skip.py'])
run('xfail',OUT/'recorder-xfail',['tests/test_xfail.py'])
run('missing_test',OUT/'recorder-missing',['tests/test_missing.py'])
run('internal',fixture/'recorder-internal')
run('self_overwrite',record)
run('source_parent',record.parent)
existing=OUT/'existing';existing.mkdir();sentinel=existing/'sentinel';sentinel.write_text('preserve original');original=sha(sentinel)
run('overwrite',existing)
target=OUT/'symlink-target';target.mkdir();link=OUT/'symlink';link.symlink_to(target,target_is_directory=True)
run('symlink',link/'fresh')
broken=OUT/'broken-link';broken.symlink_to(OUT/'nonexistent-target',target_is_directory=True)
run('broken_symlink',broken/'fresh')
run('traversal',OUT/'unused'/'..'/'traversed')
run('hidden_git',host/'.git'/'recorder-hidden-git')
run('other_git_source',host/'recorder-other-source')
run('test_traversal',OUT/'recorder-test-traversal',['tests/../test_pass.py'])
run('non_test',OUT/'recorder-non-test',['backend/tests/test_pass.py'])
receipt={'generated_by':__file__,'generator_sha256':sha(Path(__file__)),'generated_at':datetime.now(timezone.utc).isoformat(),'target_commit':execute(['git','rev-parse','HEAD'],ROOT)['stdout'].strip(),'target_tree':execute(['git','rev-parse','HEAD^{tree}'],ROOT)['stdout'].strip(),'source_sha256':{str(SOURCE.relative_to(ROOT)):source_before},'source_unchanged':source_before==sha(SOURCE),'copied_generator_sha256':copied_sha,'copy_unchanged':sha(record)==copied_sha,'runtime':platform.python_version(),'platform':platform.platform(),'setup':setup,'existing_sentinel_unchanged':sha(sentinel)==original,'fixture_inventory':{str(p.relative_to(fixture)):sha(p) for p in [record,*sorted(tests.glob('*.py'))]},'cases':rows,'counts':{'passed':sum(r['passed'] for r in rows),'failure':sum(not r['passed'] for r in rows)}}
with (OUT/'recorder-controls.json').open('x') as f:json.dump(receipt,f,indent=2)
if json.loads((OUT/'recorder-controls.json').read_text()) != receipt:raise RuntimeError('readback failed')
raise SystemExit(1 if receipt['counts']['failure'] else 0)
