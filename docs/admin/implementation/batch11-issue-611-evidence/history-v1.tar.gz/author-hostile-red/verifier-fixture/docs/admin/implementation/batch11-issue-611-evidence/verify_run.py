"""Verify a fresh external current-checkout replay, never historical acceptance."""

import argparse
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("issue611_recorder", HERE / "record.py")
recorder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recorder)


def verify(path):
    absolute = path.absolute()
    if (
        absolute.resolve() != absolute
        or recorder.ROOT == absolute
        or recorder.ROOT in absolute.parents
    ):
        raise ValueError("Current replay must be external and unsymlinked")
    record = json.loads(absolute.read_text())
    if type(record) is not dict:
        raise ValueError("Object receipt required")
    expected = str((HERE / "record.py").relative_to(recorder.ROOT))
    if record.get("generated_by") != expected or record.get(
        "generator_sha256"
    ) != recorder.digest(HERE / "record.py"):
        raise ValueError("Expected live recorder identity required")
    for field in ("child_exit", "verification_exit"):
        if type(record.get(field)) is not int or record[field] != 0:
            raise ValueError("Actual successful integer exits required")
    if record.get("verdict") != "PASS" or record.get("source_unchanged") is not True:
        raise ValueError("Accepted unchanged execution required")
    if type(record.get("runtime")) is not dict or any(
        type(record["runtime"].get(k)) is not str or not record["runtime"][k]
        for k in ("python", "sqlalchemy", "fastapi")
    ):
        raise ValueError("Complete runtime identity required")
    cases = record.get("cases")
    if type(cases) is not list or not cases:
        raise ValueError("Nonempty actual testcase inventory required")
    ids = []
    for case in cases:
        if (
            type(case) is not dict
            or set(case) != {"id", "state"}
            or type(case["id"]) is not str
            or not case["id"]
            or case["state"] != "passed"
        ):
            raise ValueError("Complete passing testcase identities required")
        ids.append(case["id"])
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate testcase identity")
    counts = record.get("counts")
    if (
        type(counts) is not dict
        or set(counts) != {"passed", "failure", "error", "skipped"}
        or any(type(n) is not int for n in counts.values())
        or counts != {"passed": len(ids), "failure": 0, "error": 0, "skipped": 0}
    ):
        raise ValueError("Exact executed outcome counts required")
    if record.get("source_sha256") != recorder.inventory():
        raise ValueError("Historical source identity; fresh current replay required")
    outputs = record.get("outputs_sha256")
    if type(outputs) is not dict or set(outputs) != {
        "stdout.txt",
        "stderr.txt",
        "tests.xml",
    }:
        raise ValueError("Exact raw execution outputs required")
    for name, sha in outputs.items():
        output = absolute.parent / name
        if (
            output.resolve() != output
            or not output.is_file()
            or type(sha) is not str
            or recorder.digest(output) != sha
        ):
            raise ValueError("Execution output identity mismatch")
    print(
        json.dumps(
            {
                "scope": "current local backend replay",
                "verdict": "PASS",
                "cases": len(ids),
            }
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("receipt", type=Path)
    args = parser.parse_args()
    try:
        verify(args.receipt)
    except (ValueError, KeyError, OSError, json.JSONDecodeError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
