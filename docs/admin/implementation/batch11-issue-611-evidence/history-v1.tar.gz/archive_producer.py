import io,json,hashlib,platform,sys,tarfile,subprocess
from pathlib import Path
from datetime import datetime,timezone
BASE=Path(__file__).resolve().parent
ROOT=Path('/Users/roger/.codex/worktrees/batch11-audit-pagination/audit_app')
PACKET=ROOT/'docs/admin/implementation/batch11-issue-611-evidence'
GROUPS={
 'baseline-recorded':'epoch-zero historical positive, original recorder source not retained',
 'epochone-red':'actual epoch-one capability red; original recorder source not retained',
 'prototype-current-v1':'NOT_ACCEPTED teardown errors',
 'policy-red':'actual internal prototype RLS defect before repair',
 'prototype-current-v2':'historical current35pass',
 'prototype-minimum312-v2':'historical minimum35pass',
 'author-current-v3':'historical current38pass',
 'author-minimum-v3':'historical minimum52pass',
 'author-hostile-red':'author reproduced original artifact defects',
 'author-hostile-green':'historical repaired artifact checks',
 'author-shape-red':'setup-stale attempt, not behavioral red',
 'author-shape-red-v2':'actual selector/JUnit contradictions before repair',
 'author-final-integrity-v2':'final recorder controls63pass; selector/JUnit repair and origin limits',
 'author-repaired-v5':'NOT_ACCEPTED52pass19fixture-setup-errors',
 'author-complete-v6':'historical current71pass',
 'author-minimum-complete-v6':'NOT_ACCEPTED despite71pass because source changed',
 'author-minimum-complete-v7':'historical minimum71pass',
 'browser-v1':'failed auth-fixture journey',
 'browser-v2':'failed duplicate-table fixture setup',
 'browser-v3':'diagnostic journey pass, resource lifecycle failed',
 'browser-review-v4':'actual owned API/browser pass including explicit cleanup',
 'frontend-review-v4':'actual client65pass/type/lint/build source-bound gates',
 'review-adversary':'independent preliminary defects and parser controls',
 'review-adversary-final-v1':'independent63repair controls plus later confirmed selector/JUnit gaps',
 'review-spec':'independent dce1991 bounded-spec52current/minimum passes',
 'review-standards':'independent dce1991 standards review and executed controls',
}
FILES=['launch.json','initial-resource.json','owned-epoch-resources.json','baseline-epochzero.xml','baseline-epochzero-v2.xml','legacy-review.xml','client-red.json','client-green.json','capture_frontend.py','SETUP_HISTORY.md','archive_producer.py']
def sha(data):return hashlib.sha256(data).hexdigest()
items={}
for name in FILES:
    p=BASE/name
    if p.is_file():items[name]=p.read_bytes()
for prefix in GROUPS:
    for p in sorted((BASE/prefix).rglob('*')):
        if p.is_file() and not p.is_symlink() and '.git' not in p.parts and '__pycache__' not in p.parts and p.resolve()==p.absolute():items[str(p.relative_to(BASE))]=p.read_bytes()
archive=PACKET/'history-v1.tar.gz';index=PACKET/'history-index.json'
if archive.exists() or index.exists():raise ValueError('Fresh publication only; never replace historical evidence')
with archive.open('xb') as stream:
    with tarfile.open(fileobj=stream,mode='w:gz') as bundle:
        for name,data in sorted(items.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;bundle.addfile(info,io.BytesIO(data))
record={'schema':1,'scope':'historical diagnostic evidence only','archive':archive.name,'archive_sha256':sha(archive.read_bytes()),'producer':{'path':'archive_producer.py','sha256':sha(items['archive_producer.py'])},'generated_at':datetime.now(timezone.utc).isoformat(),'runtime':sys.version,'platform':platform.platform(),'packaging_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'groups':GROUPS,'origin_limitations':'See retained SETUP_HISTORY.md; originals remain unchanged; final external replay is required','entries':[{'path':name,'sha256':sha(data)} for name,data in sorted(items.items())]}
with index.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
if json.loads(index.read_text())!=record:raise ValueError('Index readback mismatch')
print(json.dumps({'artifacts':len(items),'archive_sha256':record['archive_sha256'],'bytes':archive.stat().st_size,'scope':record['scope']}))
