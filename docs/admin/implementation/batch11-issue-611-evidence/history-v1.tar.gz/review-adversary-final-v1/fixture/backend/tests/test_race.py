from pathlib import Path
def test_redirect_output(request):
    out=Path(request.config.option.xmlpath).parent
    original=out.with_name(out.name+"-original")
    out.rename(original)
    out.symlink_to('/Users/roger/.codex/visualizations/2026/10/10/01a12626-7521-7981-be0d-a6d3da5358bf/issue611/review-adversary-final-v1/fixture-host/.git/symlink-race-target',target_is_directory=True)
    assert out.is_symlink()
