# Independent repaired-byte data integrity replay

Reviewed candidate HEAD `bcb5ff99854de595bbe3f7d60cc8796b7ada5a20`, tree
`9d0061928c16d173859f98cb6daa5f2f591b257c`, with uncommitted repaired files:

- recorder SHA256 `659ae7b70bafb7103017db51b3f0904c05bca39dabfc70acb897b33b5fe149e4`
- verifier SHA256 `469b025c527e03c266d14a81e933b79b031e3fc118fc3c7996c0695447f66758`

The exact copied files, ordinary local pytest fixtures, actual commands/exits,
stdout/stderr, and raw producer packets are preserved in this directory. This
review executed no database, network, API, browser or production operations and
modified no candidate source. Historical reports remain unchanged.

## Repaired controls

`recheck.json` records **63 controls passing, zero unexpected results**. The
original hidden common-Git destination, sibling source checkout destination and
output symlink replacement during actual child execution all return nonzero.
The latter refuses after the actual pytest child finishes, before publishing a
new success receipt. Empty, setup-error and duplicated executed identities also
refuse. Real one-case producer packets verify normally and under `python -O`;
a producer launched under `-O` also verifies.

All receipt mutation packets copy the complete six retained outputs. Normal and
optimized verifier runs refuse missing, boolean, NaN/infinite, empty, duplicate,
invented testcase, stale-source and malformed metadata paths. Mutating
`execution.json` plus matching receipt fields and updating its digest still
refuses invented current Git identities, fictional runtime differing from the
captured probe, changed source status, invalid command/environment/probe metadata,
invalid dates and boolean exits. Internal and symlinked outputs refuse.

The outer producer/verifier invocations use default bytecode settings: no `-B`,
`PYTHONDONTWRITEBYTECODE` or cache-prefix override. The recorder's intentional child
environment and the verifier's explicit cache guard execute as written. Candidate
source hashes/status/cache and fixture tracked hashes/status/cache were identical
before and after every reviewed run. See the exact readbacks in `recheck.json`.

## Remaining demonstrated gaps and limits

`shape-controls.json` preserves eight further runs, normal and optimized, which
all return exit 0 and `PASS` on four internally contradictory or substituted
metadata packets:

1. Change the retained execution command's selector from `tests/test_pass.py` to
   `tests/test_error.py`, mirror it in the receipt, and update the execution
   digest. The untouched stdout/JUnit still records only the actual pass test.
   The verifier accepts the claimed different cohort.
2. Change the JUnit testsuite summary to `tests=2`, `errors=1`, leaving its single
   passed testcase intact, and update the XML output digest. The verifier accepts
   the contradictory JUnit aggregate metadata.
3. Change platform to the nonempty string `fictional-platform` in both retained
   execution and receipt, with the execution digest updated. The verifier accepts
   that substituted origin value.
4. Change the timestamp in both retained execution and receipt to
   `1970-01-01T00:00:00+00:00`, updating the execution digest. The unchanged actual
   JUnit timestamp remains in 2026; the verifier accepts the substituted date.

The first two are reproducible report consistency gaps. The latter two are
metadata-origin limits if the contract promises only consistency with a retained
producer record, rather than independently proving its origin/date. This review
does not assume a local unsigned packet can prevent an authorized attacker from
forging every record. It does require stated integrity claims to distinguish
these demonstrated limits. Exact packets are under `runs/shape-*`; raw commands
and results are in `shape-controls.stdout.txt` and `shape-controls.json`.

Later source changes require new source-bound checks. This report is local
data-integrity evidence for the hashes above, not acceptance of a final published
packet or durable production pagination.
