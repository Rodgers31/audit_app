import argparse,sys,importlib.util,subprocess,json,hashlib,platform
from pathlib import Path
from datetime import datetime,timezone
sys.dont_write_bytecode=True
ROOT=Path('/Users/roger/.codex/worktrees/batch11-audit-pagination/audit_app')
source=ROOT/'docs/admin/implementation/batch11-issue-611-evidence/record.py'
spec=importlib.util.spec_from_file_location('owned_recorder',source); recorder=importlib.util.module_from_spec(spec);spec.loader.exec_module(recorder)
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--browser',action='store_true');args=p.parse_args()
destination=recorder.Destination(args.out);out=destination.path
before,status=recorder.inventory(),recorder.git('status','--porcelain=v1')
node=Path('/Users/roger/.nvm/versions/node/v22.19.0/bin/node')
python=Path('/Users/roger/.codex/visualizations/2026/10/10/01a12626-7521-7981-be0d-a6d3da5358bf/issue611/current/bin/python')
env={'PATH':str(node.parent)+':/usr/bin:/bin','PYTHON_DOTENV_DISABLED':'1','NEXT_PUBLIC_API_URL':'http://127.0.0.1:18034','NEXT_PUBLIC_SUPABASE_URL':'http://127.0.0.1:18034','NEXT_PUBLIC_SUPABASE_ANON_KEY':'inert','NEXT_TELEMETRY_DISABLED':'1','DATABASE_URL':'postgresql+psycopg2://inert:inert@127.0.0.1:55534/issue611','SUPABASE_URL':'http://127.0.0.1:18034','SUPABASE_SERVICE_ROLE_KEY':'inert','SUPABASE_JWT_SECRET':'inert','ISSUE611_OWNED_POSTGRES':'1','PLAYWRIGHT_BROWSERS_PATH':'/Users/roger/Library/Caches/ms-playwright'}
if args.browser:
    env.update(ISSUE611_BROWSER_PYTHON=str(python),ISSUE611_BROWSER_OUTPUT=str(out/'browser'))
    commands={'browser':[str(node),'node_modules/@playwright/test/cli.js','test','--config=e2e/admin-audit-epoch/playwright.config.ts']}
else:
    commands={'client':[str(node),'node_modules/jest/bin/jest.js','__tests__/admin/overview-audit','--runInBand','--json','--outputFile='+str(out/'client.json')],'types':[str(node),'node_modules/typescript/bin/tsc','--noEmit','--incremental','false'],'lint':[str(node),'node_modules/next/dist/bin/next','lint','--file','lib/admin/audit.ts','--file','__tests__/admin/overview-audit/epoch-bookmarks.test.ts','--file','e2e/admin-audit-epoch/controls.spec.ts','--file','e2e/admin-audit-epoch/playwright.config.ts'],'build':[str(node),str(node.parent.parent/'lib/node_modules/npm/bin/npm-cli.js'),'run','build']}
rows=[]
for name,command in commands.items():
    phase_env={**env,'NODE_ENV':'test' if name=='client' else 'production' if name=='build' else 'development'}
    child=subprocess.run(command,cwd=ROOT/'frontend',env=phase_env,text=True,capture_output=True,timeout=240)
    destination.write(name+'.stdout.txt',child.stdout.encode());destination.write(name+'.stderr.txt',child.stderr.encode())
    rows.append({'phase':name,'command':command,'env':phase_env,'exit':child.returncode})
    print(name,child.returncode,flush=True)
    if child.returncode:break
counts=None
if args.browser and (out/'browser/report.json').is_file():
    stats=json.loads((out/'browser/report.json').read_text())['stats'];counts={k:stats[k] for k in ['expected','unexpected','skipped','flaky']}
    accepted=counts=={'expected':1,'unexpected':0,'skipped':0,'flaky':0}
elif not args.browser and (out/'client.json').is_file():
    report=json.loads((out/'client.json').read_text());counts={k:report[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numRuntimeErrorTestSuites']}
    accepted=counts=={'numTotalTests':65,'numPassedTests':65,'numFailedTests':0,'numPendingTests':0,'numRuntimeErrorTestSuites':0}
else:accepted=False
unchanged=before==recorder.inventory() and status==recorder.git('status','--porcelain=v1')
accepted=accepted and unchanged and len(rows)==len(commands) and all(row['exit']==0 for row in rows)
receipt={'generated_by':str(Path(__file__)),'generator_sha256':recorder.digest(Path(__file__)),'generated_at':datetime.now(timezone.utc).isoformat(),'scope':'actual owned browser/API' if args.browser else 'client cohort and frontend gates','target_commit':recorder.git('rev-parse','HEAD'),'target_tree':recorder.git('rev-parse','HEAD^{tree}'),'source_sha256':before,'runtime':subprocess.check_output([str(node),'-p','JSON.stringify(process.versions)'],env=env,text=True).strip(),'platform':platform.platform(),'processes':rows,'case_counts':counts,'source_unchanged':unchanged,'verdict':'PASS' if accepted else 'NOT_ACCEPTED','outputs_sha256':{str(f.relative_to(out)):recorder.digest(f) for f in out.rglob('*') if f.is_file()}}
destination.write('run.json',(json.dumps(receipt,indent=2)+'\n').encode())
if json.loads(destination.read('run.json'))!=receipt:raise RuntimeError('Receipt readback mismatch')
print(json.dumps({'scope':receipt['scope'],'verdict':receipt['verdict'],'counts':counts,'source_unchanged':unchanged}))
raise SystemExit(0 if accepted else 1)
