import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/Users/roger/.codex/worktrees/batch11-audit-pagination/audit_app')
out=Path('/Users/roger/.codex/visualizations/2026/10/10/01a12626-7521-7981-be0d-a6d3da5358bf/issue611/review-spec')
artifact=out.parent
packet=root/'docs/admin/implementation/batch11-issue-611-evidence'
current=artifact/'current/bin/python'
minimal={'PATH':'/usr/bin:/bin','PYTHON_DOTENV_DISABLED':'1'}
def inventory():
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
    return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if p}
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def run(name,command):
    start=time.time()
    before=inventory()
    status=git('status','--porcelain=v1')
    proc=subprocess.run([str(x) for x in command],cwd=root,env=minimal,capture_output=True,text=True,timeout=260)
    (out/(name+'.stdout.txt')).write_text(proc.stdout)
    (out/(name+'.stderr.txt')).write_text(proc.stderr)
    receipt={'command':[str(x) for x in command],'exit':proc.returncode,'elapsed':time.time()-start,'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'source_before':before,'source_after':inventory(),'status_before':status,'status_after':git('status','--porcelain=v1'),'env':minimal,'stdout_sha256':hashlib.sha256(proc.stdout.encode()).hexdigest(),'stderr_sha256':hashlib.sha256(proc.stderr.encode()).hexdigest()}
    with (out/(name+'.process.json')).open('x') as f:json.dump(receipt,f,indent=2)
    print(json.dumps({'name':name,'exit':proc.returncode,'source_unchanged':receipt['source_before']==receipt['source_after'] and status==receipt['status_after'],'stdout':proc.stdout,'stderr':proc.stderr}),flush=True)
    return proc.returncode
probe="import psycopg2,json;c=psycopg2.connect(host='127.0.0.1',port=55534,dbname='issue611',user='inert',password='inert');q=c.cursor();q.execute(\"SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename IN ('admin_audit_log','issue611_capability') ORDER BY 1\");tables=q.fetchall();q.execute(\"SELECT rolname FROM pg_roles WHERE rolname LIKE 'issue611_%' ORDER BY 1\");roles=q.fetchall();q.execute('SELECT version(),pg_current_snapshot()::text');meta=q.fetchone();print(json.dumps({'tables':tables,'roles':roles,'metadata':meta}));c.close()"
run('db-before',[current,'-c',probe])
for name,python in [('current',current),('minimum',artifact/'minimum312/bin/python')]:
    run(name,[current,packet/'record.py','--python',python,'--out',out/name,'tests/admin_audit_epoch/test_prototype.py','tests/admin_overview_audit/test_review_boundaries.py'])
    for optimized in [False,True]:
        run(name+('-verify-optimized' if optimized else '-verify-normal'),[current,*(['-O'] if optimized else []),packet/'verify_run.py',out/name/'run.json'])
run('db-after',[current,'-c',probe])
