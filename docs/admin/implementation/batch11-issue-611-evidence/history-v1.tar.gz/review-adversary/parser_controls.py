import hashlib
import importlib.util
import json
import platform
import subprocess
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path('/Users/roger/.codex/worktrees/batch11-audit-pagination/audit_app')
OUT = Path(__file__).parent
SOURCE = ROOT / 'docs/admin/implementation/batch11-issue-611-evidence/prototype.py'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('issue611_adversary_prototype', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
scope = '61100000-0000-4000-8000-000000000001'
snap_good = ['3:3:', '3:5:4', '4294967294:4294967299:4294967295,4294967297', '9007199254740993:9007199254740995:9007199254740994', '18446744073709551613:18446744073709551615:18446744073709551614']
bad = [('missing', None), ('boolean', True), ('integer', 3), ('nan', float('nan')), ('inf', float('inf')), ('negative_inf', float('-inf')), ('list', []), ('object', {}), ('empty', ''), ('unicode', '٣:٤:'), ('negative', '-3:5:'), ('zero', '0:5:'), ('inverted', '5:3:'), ('duplicate', '3:5:4,4'), ('unsorted', '3:5:4,3'), ('outside_low', '3:5:2'), ('at_high', '3:5:5'), ('overflow', '3:18446744073709551616:'), ('active_overflow', '3:18446744073709551615:18446744073709551616'), ('huge_active', '3:99999:' + ','.join(str(i) for i in range(3,3000))), ('newline', '3:5:\n'), ('carriage_return', '3:5:\r'), ('unicode_separator', '3:5:\u2028'), ('space', '3:5: ')]
rows = []
before = sha(SOURCE)
def run(name, fn, value, accepted):
    try:
        output = fn(value)
        got = True
        detail = repr(output)
    except Exception as e:
        got = False
        detail = type(e).__name__ + ':' + str(getattr(e, 'status_code', '')) + ':' + str(getattr(e, 'detail', e))
    rows.append({'id':name, 'expected_accept':accepted, 'actual_accept':got, 'detail':detail, 'passed':got == accepted})
for i, value in enumerate(snap_good):
    run(f'snapshot_positive_{i}', module.snapshot8, value, True)
    run(f'bookmark_positive_{i}', module.bookmark, f'v2:{scope}:{value}', True)
for name, value in bad:
    run('snapshot_' + name, module.snapshot8, value, False)
    run('bookmark_' + name, module.bookmark, f'v2:{scope}:{value}' if isinstance(value,str) else value, False)
for name, value in [('unversioned', '3:5:'), ('version', f'v3:{scope}:3:5:'), ('scope', 'v2:garbage:3:5:'), ('uppercase', f'v2:{scope.upper().replace("a", "A")}:3:5:')]:
    if name == 'uppercase': value = 'v2:61100000-0000-4000-8000-abcdef000001:3:5:'.upper().replace('V2:', 'v2:')
    run('bookmark_' + name, module.bookmark, value, False)
receipt = {'generated_by':__file__, 'generator_sha256':sha(Path(__file__)), 'generated_at':datetime.now(timezone.utc).isoformat(), 'target_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(), 'target_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(), 'source_sha256':{str(SOURCE.relative_to(ROOT)):before}, 'source_unchanged':sha(SOURCE)==before, 'runtime':platform.python_version(), 'platform':platform.platform(), 'cases':rows, 'counts':{'passed':sum(r['passed'] for r in rows),'failure':sum(not r['passed'] for r in rows)}}
with (OUT/'parser-python.json').open('x') as f: json.dump(receipt,f,indent=2)
if json.loads((OUT/'parser-python.json').read_text()) != receipt: raise RuntimeError('readback failed')
print(json.dumps(receipt,indent=2))
raise SystemExit(1 if any(not r['passed'] for r in rows) else 0)
