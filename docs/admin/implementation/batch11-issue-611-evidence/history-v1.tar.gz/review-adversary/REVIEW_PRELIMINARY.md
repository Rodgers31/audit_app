# Issue 611 adversarial execution, preliminary candidate

This report describes the exact preserved candidate bytes recorded in the JSON
receipts below. It is not acceptance of later candidate bytes, production storage,
restore/retention support, or a published final packet. No candidate files,
databases, live service handlers, primary checkout, or sibling lane resources were
modified. All fixture repositories and outputs are under this external directory.

The reviewed launch HEAD was `bcb5ff99854de595bbe3f7d60cc8796b7ada5a20`, tree
`9d0061928c16d173859f98cb6daa5f2f591b257c`; candidate files were uncommitted.
Each JSON receipt records the actual generator/source hashes and source drift
readback. Commands execute with an explicit allowlist environment and inert
database/Supabase configuration. Parser imports had dotenv and bytecode disabled;
no database connections were made. Python 3.13.9 and Node v22.19.0 ran actual code.

## Demonstrated findings

1. The original recorder accepts fresh output inside the linked fixture's common
   Git directory and another registered fixture source checkout. Both return
   process exit 0 and `PASS`. See `hidden_git.process.json` and
   `other_git_source.process.json`. The preserved recorder is at
   `fixture/docs/admin/implementation/batch11-issue-611-evidence/record.py`.

2. The original recorder validates its output only before launching the child.
   An actual pytest test renames the fresh validated output and replaces it with
   a symlink into the owned common Git directory. The recorder then publishes
   stdout, stderr, JUnit and a `PASS` receipt through that symlink. See
   `destination_race.process.json`, `recorder-additional.json`, and the retained
   actual test at `fixture/backend/tests/test_symlink_race.py`.

3. The preliminary verifier accepts an invented testcase identity while unchanged
   hashed `tests.xml` records the actual different identity. It reports exit 0
   and `PASS` under both normal and optimized Python. See
   `invented_case.verify.process.json` and
   `invented_case-optimized.verify.process.json`; the mutated receipt and raw
   actual outputs are in `verifier-runs/invented_case/`. The verifier's exact
   tested bytes are retained at
   `verifier-fixture/docs/admin/implementation/batch11-issue-611-evidence/verify_run.py`.

4. The preliminary verifier also reports `PASS` for fictional runtime strings,
   all-zero commit/tree values, or deletion of command/environment/time/platform/
   status execution metadata. These are metadata integrity findings; this review
   does not claim a local evidence system can prevent a fully authorized attacker
   from forging every retained artifact. See the corresponding
   `fake_runtime`, `invented_commit`, and `missing_metadata` normal/optimized
   process records and packets.

## Executed controls and limits

`parser-python.json`: 62 direct snapshot8/bookmark controls passed, including
missing/wrong primitive types, booleans, NaN/infinities, Unicode, uint64 overflow,
large active sets, active-ID ordering, epoch boundaries, and malformed scope/
version. `parser-js.json`: 36 actual transpiled frontend parser/filter-transfer
controls passed. These controls bind their measured source bytes explicitly.

`recorder-controls.json`: real pytest positive, empty, failure, setup error,
skip, xfail, absent test, internal/source/self-overwrite/existing destination,
traversal and pre-existing symlink controls ran. The argv duplicate-selection
attempt was deduplicated by pytest into one actual testcase; its harness expected
refusal, so that historical receipt records a harness expectation mismatch. It is
not a product finding or a duplicate executed inventory. The second batch in
`recorder-additional.json` executes two actual functions with identical testcase
identities and confirms recorder refusal. Positive, empty, and internal output
controls also execute under Python `-O`.

`verifier-controls.json`: real producer/untampered verifier positive controls
pass normal and optimized execution. Missing exits, boolean exits/counts, NaN,
infinity, string unchanged flags, empty/duplicate/error testcase inventories,
wrong generator, and stale source hashes refuse normal and optimized execution.
Internal receipt, symlink receipt, and symlink raw outputs refuse. Findings above
are separate tampering paths that actually return success.

All raw command stdout/stderr and exact process exits are retained next to these
receipts. No actual API/DB/browser behavior is certified by this review; those
surfaces belong to separate serialized source-bound author/reviewer controls.
Final repaired recorder/verifier rechecks remain pending at this report's creation.
