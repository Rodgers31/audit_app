import copy
import hashlib
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from datetime import datetime, timezone

OUT=Path(__file__).parent
ROOT=Path('/Users/roger/.codex/worktrees/batch11-audit-pagination/audit_app')
PACKET=ROOT/'docs/admin/implementation/batch11-issue-611-evidence'
FIXTURE=OUT/'verifier-fixture'; FIXTURE.mkdir()
EXTERNAL=OUT/'verifier-runs'; EXTERNAL.mkdir()
ENV={'PATH':'/usr/bin:/bin','PYTHON_DOTENV_DISABLED':'1','PYTHONDONTWRITEBYTECODE':'1','DATABASE_URL':'sqlite:///'+str(OUT/'inert.sqlite'),'SUPABASE_URL':'http://127.0.0.1:18034','SUPABASE_SERVICE_ROLE_KEY':'inert','SUPABASE_JWT_SECRET':'inert'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def process(args,cwd=FIXTURE):
    r=subprocess.run(list(map(str,args)),cwd=cwd,env=ENV,text=True,capture_output=True,timeout=30)
    return {'command':list(map(str,args)),'cwd':str(cwd),'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
source_before={name:sha(PACKET/name) for name in ['record.py','verify_run.py']}
packet=FIXTURE/'docs/admin/implementation/batch11-issue-611-evidence';packet.mkdir(parents=True)
for name in source_before:shutil.copyfile(PACKET/name,packet/name)
tests=FIXTURE/'backend/tests';tests.mkdir(parents=True);(tests/'test_pass.py').write_text('def test_pass():\n    assert True\n')
setup=[process(['git','init','.']),process(['git','add','.']),process(['git','-c','user.name=Adversary','-c','user.email=adversary@example.invalid','commit','-m','test: own current verifier fixture'])]
if any(r['exit'] for r in setup):raise RuntimeError(setup)
positive=EXTERNAL/'positive'
record_command=[sys.executable,packet/'record.py','--python',sys.executable,'--out',positive,'tests/test_pass.py']
producer=process(record_command)
if producer['exit']:raise RuntimeError(producer)
original=json.loads((positive/'run.json').read_text())
rows=[]
def run(name,path,expected,optimized=False):
    result=process([sys.executable,*(['-O'] if optimized else []),packet/'verify_run.py',path])
    success=result['exit']==0
    row={'id':name+('-optimized' if optimized else ''),'expected_success':expected,'actual_success':success,'passed':success==expected,'process':result}
    rows.append(row)
    with (OUT/(row['id']+'.verify.process.json')).open('x') as f:json.dump(row,f,indent=2)
    print(json.dumps({'id':row['id'],'exit':result['exit'],'expected_success':expected,'actual_success':success,'stdout':result['stdout'],'stderr':result['stderr']}),flush=True)
run('untampered',positive/'run.json',True)
run('untampered',positive/'run.json',True,True)
transforms={
 'missing_exit':lambda r:r.pop('child_exit'),
 'bool_exit':lambda r:r.update(child_exit=False),
 'bool_verifier_exit':lambda r:r.update(verification_exit=False),
 'string_unchanged':lambda r:r.update(source_unchanged='true'),
 'bool_count':lambda r:r['counts'].update(passed=True),
 'nan_count':lambda r:r['counts'].update(passed=float('nan')),
 'inf_exit':lambda r:r.update(child_exit=float('inf')),
 'empty_cases':lambda r:r.update(cases=[],counts={'passed':0,'failure':0,'error':0,'skipped':0}),
 'duplicate_cases':lambda r:r.update(cases=r['cases']*2,counts={'passed':2,'failure':0,'error':0,'skipped':0}),
 'error_case':lambda r:r['cases'][0].update(state='error'),
 'wrong_generator':lambda r:r.update(generated_by='anywhere.py'),
 'stale_source':lambda r:r['source_sha256'].update({'backend/tests/test_pass.py':'0'*64}),
 'invented_case':lambda r:r['cases'][0].update(id='fabricated.test_module::test_not_executed'),
 'invented_commit':lambda r:r.update(target_commit='0'*40,target_tree='0'*40),
 'missing_metadata':lambda r:[r.pop(k,None) for k in ['command','env','generated_at','platform','status_before','status_after']],
 'fake_runtime':lambda r:r.update(runtime={'python':'fiction','sqlalchemy':'fiction','fastapi':'fiction'}),
}
for name,mutate in transforms.items():
    folder=EXTERNAL/name;folder.mkdir()
    for output in ['stdout.txt','stderr.txt','tests.xml','runtime.stdout.txt','runtime.stderr.txt','execution.json']:shutil.copyfile(positive/output,folder/output)
    receipt=copy.deepcopy(original);mutate(receipt)
    with (folder/'run.json').open('x') as f:json.dump(receipt,f,indent=2)
    run(name,folder/'run.json',False)
    run(name,folder/'run.json',False,True)
internal=FIXTURE/'internal';internal.mkdir()
for name in ['run.json','stdout.txt','stderr.txt','tests.xml','runtime.stdout.txt','runtime.stderr.txt','execution.json']:shutil.copyfile(positive/name,internal/name)
run('internal',internal/'run.json',False)
link=EXTERNAL/'symlink';link.symlink_to(positive,target_is_directory=True)
run('symlink_receipt',link/'run.json',False)
folder=EXTERNAL/'symlink_output';folder.mkdir();shutil.copyfile(positive/'run.json',folder/'run.json')
for name in ['stdout.txt','stderr.txt','tests.xml','runtime.stdout.txt','runtime.stderr.txt','execution.json']:(folder/name).symlink_to(positive/name)
run('symlink_output',folder/'run.json',False)
receipt={'generated_by':__file__,'generator_sha256':sha(Path(__file__)),'generated_at':datetime.now(timezone.utc).isoformat(),'target_commit':process(['git','rev-parse','HEAD'],ROOT)['stdout'].strip(),'target_tree':process(['git','rev-parse','HEAD^{tree}'],ROOT)['stdout'].strip(),'source_sha256':{str((PACKET/name).relative_to(ROOT)):value for name,value in source_before.items()},'source_unchanged':all(sha(PACKET/name)==value for name,value in source_before.items()),'copied_source_sha256':{name:sha(packet/name) for name in source_before},'runtime':platform.python_version(),'platform':platform.platform(),'setup':setup,'producer':producer,'cases':rows,'counts':{'passed':sum(r['passed'] for r in rows),'failure':sum(not r['passed'] for r in rows)}}
with (OUT/'verifier-controls.json').open('x') as f:json.dump(receipt,f,indent=2)
if json.loads((OUT/'verifier-controls.json').read_text())!=receipt:raise RuntimeError('readback failed')
raise SystemExit(1 if receipt['counts']['failure'] else 0)
