def pytest_collection_modifyitems(items):
    for item in items:
        if item.nodeid.startswith("tests/test_collision.py::"):
            item._nodeid="tests/test_collision.py::same_identity"
