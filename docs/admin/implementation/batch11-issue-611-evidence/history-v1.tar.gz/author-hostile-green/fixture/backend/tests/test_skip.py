import pytest
@pytest.mark.skip(reason="controlled prerequisite skip")
def test_skip():
    pass
