import pytest
@pytest.mark.xfail(reason="controlled expected failure")
def test_xfail():
    assert False
