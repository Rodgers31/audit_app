import pytest
@pytest.fixture
def broken():
    raise RuntimeError("controlled setup error")
def test_error(broken):
    pass
