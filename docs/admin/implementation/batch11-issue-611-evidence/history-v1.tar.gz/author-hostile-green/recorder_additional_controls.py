import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path
from datetime import datetime, timezone

OUT=Path(__file__).parent
ROOT=Path('/Users/roger/.codex/worktrees/batch11-audit-pagination/audit_app')
FIXTURE=OUT/'fixture'; HOST=OUT/'fixture-host'
RECORDER=FIXTURE/'docs/admin/implementation/batch11-issue-611-evidence/record.py'
SOURCE=ROOT/'docs/admin/implementation/batch11-issue-611-evidence/record.py'
ENV={'PATH':'/usr/bin:/bin','PYTHON_DOTENV_DISABLED':'1','PYTHONDONTWRITEBYTECODE':'1','DATABASE_URL':'sqlite:///'+str(OUT/'inert.sqlite'),'SUPABASE_URL':'http://127.0.0.1:18034','SUPABASE_SERVICE_ROLE_KEY':'inert','SUPABASE_JWT_SECRET':'inert'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def process(args,cwd=FIXTURE):
    r=subprocess.run(list(map(str,args)),cwd=cwd,env=ENV,text=True,capture_output=True,timeout=30)
    return {'command':list(map(str,args)),'cwd':str(cwd),'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
tests=FIXTURE/'backend/tests'
(tests/'test_collision.py').write_text('def test_one():\n    assert True\ndef test_two():\n    assert True\n')
(tests/'conftest.py').write_text('def pytest_collection_modifyitems(items):\n    for item in items:\n        if item.nodeid.startswith("tests/test_collision.py::"):\n            item._nodeid="tests/test_collision.py::same_identity"\n')
hidden=HOST/'.git'/'symlink-race-target';hidden.mkdir()
(tests/'test_symlink_race.py').write_text('from pathlib import Path\ndef test_redirect_output(request):\n    out=Path(request.config.option.xmlpath).parent\n    original=out.with_name(out.name+"-original")\n    out.rename(original)\n    out.symlink_to('+repr(str(hidden))+',target_is_directory=True)\n    assert out.is_symlink()\n')
setup=[process(['git','add','.']),process(['git','-c','user.name=Adversary','-c','user.email=adversary@example.invalid','commit','-m','test: own inventory and destination race controls'])]
if any(r['exit'] for r in setup):raise RuntimeError(setup)
before=sha(SOURCE)
rows=[]
for id,path,selection,optimized,expected in [
 ('executed_duplicate',OUT/'recorder-executed-duplicate',['tests/test_collision.py'],False,False),
 ('destination_race',OUT/'recorder-destination-race',['tests/test_symlink_race.py'],False,False),
 ('optimized_positive',OUT/'recorder-optimized-positive',['tests/test_pass.py'],True,True),
 ('optimized_empty',OUT/'recorder-optimized-empty',['tests/test_empty.py'],True,False),
 ('optimized_internal',FIXTURE/'optimized-internal',['tests/test_pass.py'],True,False),
]:
    command=[sys.executable,*(['-O'] if optimized else []),RECORDER,'--python',sys.executable,'--out',path,*selection]
    result=process(command)
    receipt=json.loads((path/'run.json').read_text()) if (path/'run.json').is_file() else None
    success=result['exit']==0 and receipt is not None and receipt.get('verdict')=='PASS'
    row={'id':id,'expected_success':expected,'actual_success':success,'passed':success==expected,'process':result,'receipt':receipt,'out_symlink':path.is_symlink(),'resolved_out':str(path.resolve())}
    rows.append(row)
    with (OUT/(id+'.process.json')).open('x') as f:json.dump(row,f,indent=2)
    print(json.dumps({'id':id,'exit':result['exit'],'success':success,'out_symlink':path.is_symlink(),'verdict':receipt.get('verdict') if receipt else None,'counts':receipt.get('counts') if receipt else None}),flush=True)
receipt={'generated_by':__file__,'generator_sha256':sha(Path(__file__)),'generated_at':datetime.now(timezone.utc).isoformat(),'target_commit':process(['git','rev-parse','HEAD'],ROOT)['stdout'].strip(),'target_tree':process(['git','rev-parse','HEAD^{tree}'],ROOT)['stdout'].strip(),'source_sha256':{str(SOURCE.relative_to(ROOT)):before},'source_unchanged':sha(SOURCE)==before,'copied_recorder_sha256':sha(RECORDER),'runtime':platform.python_version(),'platform':platform.platform(),'setup':setup,'cases':rows,'counts':{'passed':sum(r['passed'] for r in rows),'failure':sum(not r['passed'] for r in rows)}}
with (OUT/'recorder-additional.json').open('x') as f:json.dump(receipt,f,indent=2)
if json.loads((OUT/'recorder-additional.json').read_text()) != receipt:raise RuntimeError('readback failed')
raise SystemExit(1 if receipt['counts']['failure'] else 0)
