# Diagnostic and setup history

All retained run.json files keep their original bytes and identities. The bundle
is a superseding diagnostic index, not a relabeling of historical passes as final
acceptance. Fresh final replays will be external after the publication commit.

- baseline-recorded: unchanged launch reader, actual epoch zero, two cases passed.
- epochone-red: same retained actual HTTP assertion expected200, got private503.
  The unformatted recorder implementation used for these earliest two receipts
  was not preserved before formatting. Its recorded hash remains unchanged;
  these receipts have that generator-origin limitation. launch_probe.py retains
  the original actual test bytes; current prototype imports identical functions.
- prototype-current-v1: setup teardown collision, passed tests plus errors;
  NOT_ACCEPTED. policy-red: changed RLS predicate caused an incorrect empty200.
- prototype-current-v2/minimum312-v2: 35 passing prototype cases at their measured
  source identity. prototype-minimum-v2 was a Python3.13/SQLAlchemy2.0.23 import
  setup failure before receipt generation; its empty directory is not success.
- author-current-v3: 38 passed. author-minimum-v3: 52 passed including unchanged
  legacy guard checks. review-spec: independent dce1991 current/minimum52 passes.
- client-red.json: actual assertion messages, three failures and ten passes.
  client-green.json: historical65 passes. frontend-review-v4 retains65 passes
  plus actual type/lint/build commands, exits, raw output and source inventory.
- browser-v1: missing fixture auth endpoint. browser-v2: owned tables persisted
  from an interrupted fixture. browser-v3: journey passed but later tool readback
  found2tables/3roles; it is diagnostic, not accepted resource lifecycle evidence.
  browser-review-v4: explicit cleanup endpoint/readback, journey passed; external
  author tool readback separately showed tables0/roles0 and no API/UI listeners.
- author-hostile-red: original invalid destinations/receipt fields accepted;
  author-hostile-green: repaired destinations and primitive metadata controls.
  author-shape-red first attempt: stale fixture status refused, not a behavioral
  red. author-shape-red-v2: selector and JUnit contradictions actually accepted.
  author-final-integrity-v2:63 controls passed; selector/JUnit contradictions now
  refused normally and optimized. Rewriting all records can still invent plausible
  origin dates/platforms; local consistency is explicitly bounded.
- author-repaired-v5:52passes/19SQLite JSONB fixture setup errors, NOT_ACCEPTED.
  author-complete-v6 and author-minimum-complete-v7:71passes, unchanged source.
  author-minimum-complete-v6:71passing cases but source changed while its docs were
  being edited, so NOT_ACCEPTED. The immutable v7 retry supersedes that attempt.

No setup failure, skipped test, historical pass or receipt-origin gap is promoted
into final local acceptance, hosted acceptance or production readiness.
