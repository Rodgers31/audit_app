import production from '/app/frontend/playwright.ci-cohorts.config';
export default { ...production, webServer: [], testDir: '/evidence', testMatch: 'probe.spec.ts', outputDir: '/evidence/' + process.env.SCROLL_ATTEMPT + '-output', reporter: [['list'], ['json', { outputFile: '/evidence/' + process.env.SCROLL_ATTEMPT + '-results.json' }]], use: {...production.use, trace: 'on', video: 'off'} };
