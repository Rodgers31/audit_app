'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const patchSet = require('./tooling-repairs.json');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const digest = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);

function validateRelativePath(relative) {
 assert.ok(typeof relative === 'string' && !path.isAbsolute(relative) && !relative.split('/').some(p => !p || p === '.' || p === '..'), 'tooling repair: unsafe package path');
}

function regularPath(root, relative, absent = false) {
 validateRelativePath(relative);
 let current = root;
 for (const part of relative.split('/')) {
  current = path.join(current, part);
  if (!fs.existsSync(current) && !fs.lstatSync(path.dirname(current)).isSymbolicLink()) {
   try { assert.ok(!fs.lstatSync(current).isSymbolicLink(), `tooling repair: symlink refused ${relative}`); } catch (error) { if (error.code !== 'ENOENT') throw error; }
   assert.ok(absent && current === path.join(root, relative), `tooling repair: absent path ${relative}`);
   return current;
  }
  assert.ok(!fs.lstatSync(current).isSymbolicLink(), `tooling repair: symlink refused ${relative}`);
 }
 assert.ok(fs.statSync(current).isFile(), `tooling repair: regular file required ${relative}`);
 return current;
}

function planRepairs(root, { check = false, production = false } = {}) {
 assert.ok(typeof check === 'boolean' && typeof production === 'boolean', 'tooling repair: boolean modes required');
 assert.ok(fs.statSync(root).isDirectory() && !fs.lstatSync(root).isSymbolicLink(), 'tooling repair: real frontend root required');
 assert.equal(patchSet.schema, 1, 'tooling repair: unsupported patch schema');
 assert.ok(Array.isArray(patchSet.patches) && patchSet.patches.length > 0, 'tooling repair: nonempty patches required');
 const lock = JSON.parse(fs.readFileSync(regularPath(root, 'package-lock.json')));
 assert.ok(lock && lock.lockfileVersion === 3 && lock.packages && !Array.isArray(lock.packages), 'tooling repair: lock package inventory required');
 const modules = path.join(root, 'node_modules');
 assert.ok(fs.statSync(modules).isDirectory() && !fs.lstatSync(modules).isSymbolicLink(), 'tooling repair: real owned node_modules required');
 const operations = [], seen = new Set(), packages = new Set(), absentPackages = new Set();
 for (const patch of patchSet.patches) {
  assert.ok(['braces', 'sprintf-js'].includes(patch.package) && typeof patch.version === 'string' && digest(patch.repaired_sha256), 'tooling repair: invalid patch identity');
  const entries = Object.entries(lock.packages).filter(([name]) => name.endsWith(`/node_modules/${patch.package}`) || name === `node_modules/${patch.package}`);
  assert.ok(entries.length > 0, `tooling repair: missing locked ${patch.package}`);
  for (const [entry, record] of entries) {
   assert.ok(record.version === patch.version && record.dev === true, `tooling repair: incompatible locked ${entry}`);
   validateRelativePath(entry);
   assert.ok(entry.startsWith('node_modules/'), 'tooling repair: unsafe package path');
   const packageRoot = path.join(root, entry);
   if (!fs.existsSync(packageRoot)) {
    assert.ok(production, `tooling repair: absent installed ${entry}`);
    absentPackages.add(entry);
    continue;
   }
   const metadata = JSON.parse(fs.readFileSync(regularPath(root, `${entry}/package.json`)));
   assert.ok(metadata.name === patch.package && metadata.version === patch.version, `tooling repair: incompatible installed ${entry}`);
   const relative = `${entry}/${patch.file}`;
   assert.ok(!seen.has(relative), 'tooling repair: duplicate patch target'); seen.add(relative); packages.add(entry);
   const target = regularPath(root, relative, patch.original_sha256 === null);
   let bytes = fs.existsSync(target) ? fs.readFileSync(target) : null;
   if (bytes && hash(bytes) === patch.repaired_sha256) continue;
   assert.ok(!check, `tooling repair: unpatched ${relative}; run npm ci with scripts enabled`);
   if (patch.original_sha256 === null) {
    assert.ok(bytes === null && typeof patch.addition === 'string' && patch.edits.length === 0, `tooling repair: unexpected helper ${relative}`);
    bytes = Buffer.from(patch.addition);
   } else {
    assert.ok(digest(patch.original_sha256) && bytes && hash(bytes) === patch.original_sha256, `tooling repair: upstream bytes changed ${relative}`);
    let source = bytes.toString('utf8');
    assert.ok(Array.isArray(patch.edits) && patch.edits.length > 0 && patch.addition === null, 'tooling repair: invalid edit set');
    for (const edit of patch.edits) {
     assert.ok(typeof edit.before === 'string' && edit.before && typeof edit.after === 'string' && source.split(edit.before).length === 2, `tooling repair: ambiguous edit ${relative}`);
     source = source.replace(edit.before, edit.after);
    }
    bytes = Buffer.from(source);
   }
   assert.equal(hash(bytes), patch.repaired_sha256, `tooling repair: replacement hash mismatch ${relative}`);
   operations.push({ target, bytes });
  }
 }
 return { operations, packages: [...packages], absentPackages: [...absentPackages] };
}

function applyRepairs(root = path.resolve(__dirname, '..'), options = {}) {
 const { check = false } = options;
 const lockPath = path.join(root, 'node_modules', '.tooling-repair-lock');
 // Concurrent installs fail visibly; never delete an unknown/stale owner lock.
 assert.ok(fs.statSync(root).isDirectory() && !fs.lstatSync(root).isSymbolicLink(), 'tooling repair: real frontend root required');
 const modules = path.join(root, 'node_modules');
 assert.ok(fs.statSync(modules).isDirectory() && !fs.lstatSync(modules).isSymbolicLink(), 'tooling repair: real owned node_modules required');
 if (!check) fs.mkdirSync(lockPath);
 try {
  const plan = planRepairs(root, options);
  for (const { target, bytes } of plan.operations) {
   const temporary = `${target}.repair-${process.pid}`;
   try {
    fs.writeFileSync(temporary, bytes, { flag: 'wx' });
    fs.renameSync(temporary, target);
   } finally {
    if (fs.existsSync(temporary)) fs.unlinkSync(temporary);
   }
   assert.equal(hash(fs.readFileSync(target)), hash(bytes), 'tooling repair: write readback failed');
  }
  const verified = planRepairs(root, { ...options, check: true });
  return { check: 'source-bound-tooling-repairs', packages: verified.packages, absentPackages: verified.absentPackages, changedFiles: plan.operations.length };
 } finally {
  if (!check) fs.rmdirSync(lockPath);
 }
}
if (require.main === module) {
 try {
  assert.ok(process.argv.slice(2).every(x => x === '--check'), 'tooling repair: unknown argument');
  console.log(JSON.stringify(applyRepairs(undefined, { check: process.argv.includes('--check'), production: (process.env.npm_config_omit || '').split(/[ ,]+/).includes('dev') })));
 } catch (error) { console.error(error.message); process.exitCode = 1; }
}
module.exports = { applyRepairs, planRepairs };
