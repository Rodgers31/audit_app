'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
const source='/Users/roger/.codex/worktrees/batch11-dependency-compatibility/audit_app',frontend=path.join(source,'frontend');
const installer=path.join(frontend,'scripts/apply-tooling-repairs.cjs'),{applyRepairs}=require(installer);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const env={PATH:path.dirname(process.execPath)+':/usr/bin:/bin',HOME:path.join(__dirname,'inert-home')};
const root=fs.mkdtempSync(path.join(__dirname,'fixture-extra-'));
try{
 fs.mkdirSync(path.join(root,'node_modules'));fs.copyFileSync(path.join(frontend,'package-lock.json'),path.join(root,'package-lock.json'));
 for(const name of ['braces','sprintf-js','fill-range','to-regex-range','is-number'])fs.cpSync(path.join(frontend,'node_modules',name),path.join(root,'node_modules',name),{recursive:true});
 const metadata=path.join(root,'node_modules/braces/package.json'),data=JSON.parse(fs.readFileSync(metadata));data.main='lib/constants.js';fs.writeFileSync(metadata,JSON.stringify(data));
 const repair=applyRepairs(root,{check:true});
 const result=spawnSync(process.execPath,['-e',`const b=require(${JSON.stringify(path.join(root,'node_modules/braces'))});console.log(b.parse('{a,b}'));`],{env,encoding:'utf8',timeout:10000});
 console.log(JSON.stringify({name:'required-package-main-metadata-drift',producer_sha256:hash(fs.readFileSync(__filename)),source_installer_sha256:hash(fs.readFileSync(installer)),source_manifest_sha256:hash(fs.readFileSync(path.join(frontend,'scripts/tooling-repairs.json'))),runtime:process.version,platform:process.platform,arch:process.arch,repair,actual:{status:result.status,signal:result.signal,stdout:result.stdout,stderr:result.stderr}}));
}finally{fs.rmSync(root,{recursive:true,force:true});console.log(JSON.stringify({cleanup:!fs.existsSync(root)}));}
