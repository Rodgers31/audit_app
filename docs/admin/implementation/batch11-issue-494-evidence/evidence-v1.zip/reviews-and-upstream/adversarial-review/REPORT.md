# Independent adversarial execution: original repair candidate

Executed 156 unique controls plus one metadata-drift extension on Node 22.19.0, Darwin arm64. The producer exited 0; behavioral review identified six failing controls in four invariants, plus the metadata extension of the source-integrity invariant. Other 150 controls met their expected rejection/acceptance behavior or returned harmless upstream results. No skipped controls, timeouts, or product setup errors occurred. A separate producer-launch wrapper ReferenceError happened before the extension child ran; it is retained in producer-attempts.json and is not behavioral red.

The actual source was launch HEAD bcb5ff99854de595bbe3f7d60cc8796b7ada5a20 / tree 9d0061928c16d173859f98cb6daa5f2f591b257c with seven measured uncommitted source files. identity.json binds their bytes, installed patch hashes, runtime and source state. baseline-source/ preserves those exact original bytes; source hashes were unchanged after the run. No source or installed library mutations occurred outside owned fixture copies. All fixture paths were absent after cleanup; inert-home remains as an owned empty child HOME.

## Reproduced findings for author judgment

1. **P2: the success report does not bind mandatory unchanged source or main metadata.** On a repaired fixture, remove node_modules/braces/index.js or lib/constants.js, then call applyRepairs(root,{check:true}). It returns `check: source-bound-tooling-repairs`, both packages, zero absent packages and zero changed files. An actual separate Node process requiring/using braces then exits 1 with MODULE_NOT_FOUND. Likewise preserving package name/version but changing package.json main to lib/constants.js passes the check, then an actual require followed by parse exits with TypeError. Suggested invariant: verify the complete reviewed upstream library file inventory and entrypoint metadata, including unchanged required bytes, before returning success. Evidence controls: unmodified-required-source-missing-braces/index.js, unmodified-required-source-missing-braces/lib/constants.js in controls.json; required-package-main-metadata-drift in extra-output.jsonl.

2. **P2: the production omission path accepts a dangling package symlink.** Remove the copied braces directory; create node_modules/braces as a dangling link to an owned absent path; call applyRepairs(root,{production:true,check:true}). It returns success and lists node_modules/braces in absentPackages while the link remains. An existing package link is correctly refused. Suggested invariant: use lstat to distinguish ENOENT from any symlink before classifying a development package as omitted. Evidence: dangling-package-link-omit-dev and existing-package-link-omit-dev.

3. **P2 if hostile direct AST inputs are covered: append recursion escapes the walker bound.** In a real repaired library, create a root AST whose single text node value is an array nested 8,000 levels; call braces.expand(ast). The child finishes with RangeError: Maximum call stack size exceeded, without ERR_BRACES_DEPTH. The new depth check bounds walk/flatten, but append recursively traverses nested arrays first. Suggested invariant: carry the same bound through append recursion or reject non-string AST text values before recursive work. This requires a deliberately malformed programmatic AST; ordinary nested string patterns correctly fail at the 65-level parser boundary. Evidence: braces-shallow-ast-nested-array-value.

4. **P2 if mutable direct formatting ASTs are covered: native formatting rereads precision after validation.** Use sprintf.parse('%.2f'), then invoke sprintf.format(tree,['%.2f', callback]) where callback changes tree[0][7] to '101' and returns 1.25. The callback executes, then native toFixed throws RangeError instead of the bounded error. An index-7 getter returning '2' for its first two reads and '101' thereafter reproduces the same result. Suggested invariant: native formatting consumes the checked local precision snapshot. Normal format strings and simple malformed precision values already throw ERR_SPRINTF_PRECISION before callback execution. Evidence: sprintf-callback-mutates-precision, sprintf-accessor-mutates-precision.

## Executed positive and negative coverage

- Cold reverse-reconstructed upstream fixture: each original source hash verified; precheck failed; seven repairs applied; repeat and check were idempotent.
- All seven declared targets individually tampered and individually absent: every check failed.
- Direct missing/invalid roots, invalid boolean modes, empty/malformed/unsupported locks, real package links, genuine production omission and development absence: executed.
- Real held-lock competitor and two concurrent installer processes: competitor failed EEXIST, intermediate incomplete read failed, final check passed, lock removed. Only scheduler timing was instrumented; the actual installer and filesystem executed.
- Actual braces parse/compile/stringify/expand at 64, 65 and 4,000 levels; deep/cyclic direct AST nodes; malformed AST values; finite shallow expansion/compile/stringify behavior: executed.
- Actual sprintf direct format across e/f/g with NaN, infinities, negative, boolean, null, empty, malformed, zero, boundary and over-limit precisions; ordinary oversized format; valid numeric/named/positional formatting: executed.

## Replay and boundaries

Preserve the original run-controls.cjs and its original source identity. portable-control-runner.cjs is a distinct derivative producer; it accepts source/output parameters and records its own hash. Run from any location with the compatible actual Node runtime:

```text
node portable-control-runner.cjs /absolute/checkout/root /absolute/fresh/owned/output > raw-output.jsonl 2> raw-stderr.txt
```

The checkout must contain the real installed repaired dependencies. Outputs must be fresh and owned. The runner uses allowlisted PATH/HOME, copies actual packages into owned fixtures, verifies reconstruction hashes before repair, and cleans exact fixtures. It records actual source hashes rather than claiming old execution on later bytes. The exported installer APIs and real installed libraries are executed; no replacement CLI is used.

This report supplies adversarial candidate acceptance only. It does not supply Linux inference, model/image decoding, browser, build, audit, hosted, or production acceptance, and does not claim a patched upstream release or residual-risk exception. The author must reproduce findings, choose their applicability to the documented AST boundary, add meaningful red/green regressions, and request final recheck after repair.
