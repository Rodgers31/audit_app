'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const os = require('node:os');
const { spawnSync, spawn } = require('node:child_process');
const assert = require('node:assert/strict');
const source = '/Users/roger/.codex/worktrees/batch11-dependency-compatibility/audit_app';
const out = __dirname;
const frontend = path.join(source, 'frontend');
const installer = path.join(frontend, 'scripts/apply-tooling-repairs.cjs');
const manifestPath = path.join(frontend, 'scripts/tooling-repairs.json');
const patchSet = JSON.parse(fs.readFileSync(manifestPath));
const { applyRepairs, planRepairs } = require(installer);
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const controls = [];
const env = { PATH: path.dirname(process.execPath) + ':/usr/bin:/bin', HOME: path.join(out, 'inert-home') };
fs.mkdirSync(env.HOME, { recursive: true });
const git = args => spawnSync('/usr/bin/git', args, {cwd: source, env, encoding:'utf8', timeout:10000});
const identity = {
  start: new Date().toISOString(), runtime: process.version, platform: process.platform, arch: process.arch,
  head: git(['rev-parse','HEAD']).stdout.trim(), tree: git(['rev-parse','HEAD^{tree}']).stdout.trim(),
  status: git(['status','--short']).stdout, producer_sha256: hash(fs.readFileSync(__filename)),
  sources: Object.fromEntries(['frontend/package.json','frontend/package-lock.json','frontend/scripts/test-runtime-dependencies.cjs','frontend/scripts/apply-tooling-repairs.cjs','frontend/scripts/tooling-repairs.json','frontend/scripts/tooling-repair-behavior.test.cjs','frontend/scripts/tooling-repair-install.test.cjs'].map(p=>[p,hash(fs.readFileSync(path.join(source,p)))])),
  installed_patch_targets: patchSet.patches.map(p=>({package:p.package,file:p.file,sha256:hash(fs.readFileSync(path.join(frontend,'node_modules',p.package,p.file))),expected:p.repaired_sha256}))
};
fs.writeFileSync(path.join(out,'source.diff'),git(['diff','--binary']).stdout);
fs.writeFileSync(path.join(out,'identity.json'),JSON.stringify(identity,null,2)+'\n');
function encode(value) { if (typeof value === 'bigint') return String(value)+'n'; return value; }
function outcome(fn) { try {return {kind:'success', value:fn()};} catch(e) {return {kind:'exception',name:e.name,code:e.code||null,message:e.message};} }
function record(name,result,expected,interpretation) {
  assert.ok(!controls.some(x=>x.name===name),'unique control identities');
  const item={name,result,expected,interpretation}; controls.push(item); console.log(JSON.stringify(item,(_,v)=>encode(v)));
}
function fixture(upstream=false) {
  const root=fs.mkdtempSync(path.join(out,'fixture-'));
  fs.copyFileSync(path.join(frontend,'package-lock.json'),path.join(root,'package-lock.json'));
  fs.mkdirSync(path.join(root,'node_modules'));
  for (const name of ['braces','sprintf-js','fill-range','to-regex-range','is-number']) fs.cpSync(path.join(frontend,'node_modules',name),path.join(root,'node_modules',name),{recursive:true});
  if (upstream) for (const p of patchSet.patches) {
    const target=path.join(root,'node_modules',p.package,p.file);
    if (p.original_sha256===null) fs.unlinkSync(target);
    else {
      let text=fs.readFileSync(target,'utf8'); for (const e of [...p.edits].reverse()) text=text.replace(e.after,e.before);
      assert.equal(hash(Buffer.from(text)),p.original_sha256,`actual upstream source ${p.file}`); fs.writeFileSync(target,text);
    }
  }
  return root;
}
function withFixture(fn,upstream=false) {
  const root=fixture(upstream);try{return fn(root);}finally{fs.rmSync(root,{recursive:true,force:true});assert.equal(fs.existsSync(root),false);}
}
function child(code,timeout=10000) {
  const r=spawnSync(process.execPath,['-e',code],{env,encoding:'utf8',timeout,maxBuffer:1024*1024});
  return {status:r.status,signal:r.signal,error:r.error?.message||null,stdout:r.stdout,stderr:r.stderr};
}
function installerChild(root,options) {return child(`console.log(JSON.stringify(require(${JSON.stringify(installer)}).applyRepairs(${JSON.stringify(root)},${JSON.stringify(options)})))`);}
record('installed-repairs-check',outcome(()=>applyRepairs(frontend,{check:true})),'success','Actual author installed tree read only.');
record('fresh-upstream-plan-and-apply',withFixture(root=>({precheck:outcome(()=>applyRepairs(root,{check:true})),plan:planRepairs(root).operations.length,apply:applyRepairs(root),repeat:applyRepairs(root),check:applyRepairs(root,{check:true})}),true),'precheck failure; seven writes; idempotent success','Reverse reconstructed upstream source hashes were measured before repair.');
for (const value of [null,false,true,0,-1,NaN,Infinity,'',{},[]]) record(`invalid-root-${String(value)}-${typeof value}`,outcome(()=>applyRepairs(value,{check:true})),'exception','Direct API, no CLI validation.');
for (const key of ['check','production']) for (const value of [null,0,-1,NaN,Infinity,'false',{},[]]) record(`invalid-mode-${key}-${String(value)}-${typeof value}`,withFixture(root=>outcome(()=>applyRepairs(root,{[key]:value}))),'exception','Direct boolean mode validation.');
for (const p of patchSet.patches) {
  record(`each-target-tamper-${p.package}-${p.file}`,withFixture(root=>{fs.appendFileSync(path.join(root,'node_modules',p.package,p.file),'\n// independent drift');return installerChild(root,{check:true});}),'exit 1; unpatched diagnostic','Every declared patched file hash must check.');
  record(`each-target-missing-${p.package}-${p.file}`,withFixture(root=>{fs.unlinkSync(path.join(root,'node_modules',p.package,p.file));return installerChild(root,{check:true});}),'exit 1','Every declared patched file must exist in an installed package.');
}
for (const entry of ['braces/index.js','braces/lib/constants.js']) {
  record(`unmodified-required-source-missing-${entry}`,withFixture(root=>{fs.unlinkSync(path.join(root,'node_modules',entry));return {repair:outcome(()=>applyRepairs(root,{check:true})),actualRequire:child(`const b=require(${JSON.stringify(path.join(root,'node_modules/braces'))});console.log(JSON.stringify(b.parse('{a,b}')));`)};}),'check failure if complete upstream identity is promised','Incomplete deployment probe: real library required entrypoint/dependency removed; no replacement CLI.');
}
record('dangling-package-link-omit-dev',withFixture(root=>{const target=path.join(root,'node_modules/braces');fs.rmSync(target,{recursive:true});fs.symlinkSync(path.join(root,'absent-braces'),target);return {repair:outcome(()=>applyRepairs(root,{production:true,check:true})),linkRemains:fs.lstatSync(target).isSymbolicLink()};}),'exception for symlink','Omitted-package branch receives a real dangling package link.');
record('existing-package-link-omit-dev',withFixture(root=>{const target=path.join(root,'node_modules/braces'),other=path.join(root,'actual-braces');fs.renameSync(target,other);fs.symlinkSync(other,target);return outcome(()=>applyRepairs(root,{production:true,check:true}));}),'exception','Installed package link with present target.');
record('genuine-omit-dev-absence',withFixture(root=>{for(const name of ['braces','sprintf-js'])fs.rmSync(path.join(root,'node_modules',name),{recursive:true});return {production:applyRepairs(root,{production:true,check:true}),development:outcome(()=>applyRepairs(root,{check:true}))};}),'explicit two omitted packages; development failure','Expected absence control.');
for(const contents of ['', '{', '{}', 'null', 'true', '[]', '{"lockfileVersion":3,"packages":false}', '{"lockfileVersion":3,"packages":{}}']) record(`malformed-lock-${hash(contents).slice(0,12)}`,withFixture(root=>{fs.writeFileSync(path.join(root,'package-lock.json'),contents);return outcome(()=>applyRepairs(root,{check:true}));}),'exception','Direct JSON file parser.');
record('held-lock',withFixture(root=>{const lock=path.join(root,'node_modules/.tooling-repair-lock');fs.mkdirSync(lock);const result=installerChild(root,{});return {result,retained:fs.statSync(lock).isDirectory()};}),'exit 1 EEXIST and retained owner lock','Real separate installer process.');
const braces=require(path.join(frontend,'node_modules/braces'));
for (const method of ['parse','compile','stringify','expand']) for(const count of [64,65,4000]) record(`braces-${method}-nest-${count}`,outcome(()=>{const result=braces[method]('{'.repeat(count)+'a,b'+'}'.repeat(count));return typeof result==='string'?{type:typeof result,length:result.length}:{type:typeof result};}),count===64?'success':'ERR_BRACES_DEPTH','Actual installed repaired library.');
for(const method of ['compile','stringify','expand']) for(const shape of ['deep','cyclic','parent-cyclic']) {
  record(`braces-${method}-ast-${shape}`,outcome(()=>{
    const ast={type:'root',nodes:[]};let n=ast;
    if(shape==='deep')for(let i=0;i<160;i++){const child={type:'brace',nodes:[],parent:n,open:true,close:true,commas:1};n.nodes.push(child);n=child;}
    if(shape==='cyclic')ast.nodes.push(ast);
    if(shape==='parent-cyclic'){const child={type:'text',nodes:[]};child.parent=child;ast.nodes.push(child);}
    return braces[method](ast);
  }),'ERR_BRACES_DEPTH for traversed recursive structures','Parent cycle is relevant only where actual walker traverses it.');
}
for(const method of ['compile','stringify','expand'])for(const value of [null,undefined,true,false,0,NaN,{},[]])record(`braces-${method}-malformed-${String(value)}-${typeof value}`,outcome(()=>braces[method](value)),'exception or harmless empty result according to upstream API','Malformed AST acceptance itself is not security failure without unsafe work.');
record('braces-shallow-ast-nested-array-value',child(`const b=require(${JSON.stringify(path.join(frontend,'node_modules/braces'))});let a='x';for(let i=0;i<8000;i++)a=[a];const ast={type:'root',nodes:[{type:'text',value:a}]};try{console.log(JSON.stringify({kind:'success',value:b.expand(ast)}));}catch(e){console.log(JSON.stringify({kind:'exception',name:e.name,code:e.code||null,message:e.message}));}`),'ERR_BRACES_DEPTH if malformed nested value arrays covered','Real expand internal append recursion; 10s child deadline.');
const {sprintf}=require(path.join(frontend,'node_modules/sprintf-js'));
for(const type of ['e','f','g'])for(const precision of [NaN,Infinity,-Infinity,-1,true,false,null,'','garbage',{},[],0,1,100,101,'999999999999999999999999']) {
  const label=typeof precision==='object'?JSON.stringify(precision):String(precision);
  record(`sprintf-${type}-precision-${label}-${typeof precision}`,outcome(()=>{const tree=sprintf.parse('%.2'+type);tree[0][7]=precision;let called=false;let format;try{format=outcome(()=>sprintf.format(tree,['%.2'+type,()=>{called=true;return 1.25;}]));}finally{return {called,format};}}),'valid numeric bounds succeed; invalid bounds ERR_SPRINTF_PRECISION before callback','Direct public format API with invalid precision.');
}
record('sprintf-parser-large-precision',outcome(()=>sprintf('%.999999999999999999999999f',()=>1.25)),'ERR_SPRINTF_PRECISION','Normal format-string public caller.');
record('sprintf-callback-mutates-precision',outcome(()=>{const tree=sprintf.parse('%.2f');let called=false;const format=outcome(()=>sprintf.format(tree,['%.2f',()=>{called=true;tree[0][7]='101';return 1.25;}]));return {called,format};}),'guarded precision cannot change after validation if direct AST callbacks covered','Programmatic callback mutates already validated tree.');
record('sprintf-accessor-mutates-precision',outcome(()=>{const tree=sprintf.parse('%.2f');let reads=0,called=false;Object.defineProperty(tree[0],7,{get(){return ++reads<=2?'2':'101';}});const format=outcome(()=>sprintf.format(tree,['%.2f',()=>{called=true;return 1.25;}]));return {reads,called,format};}),'guarded precision cannot change after validation if accessor ASTs covered','Programmatic accessor changes same match field after validation.');
record('braces-positive-shallow-semantics',outcome(()=>({expand:braces.expand('x/{a,b}/{1..3}'),compile:braces.compile('x/{a,b}'),stringify:braces.stringify('x/{a,b}')})),'prior finite expansion/compile/stringify behavior','Positive actual API control.');
record('sprintf-positive-semantics',outcome(()=>({fixed:sprintf('%.2f %s',1.25,'done'),named:sprintf('%(name)s',{name:'sample'}),positional:sprintf('%2$s %1$d',7,'item'),g:sprintf('%.100g',1)})),'prior valid behavior','Positive actual API control.');
async function concurrent(){
  const root=fixture(true),ready=path.join(root,'ready'),release=path.join(root,'release');
  const script=`const fs=require('node:fs');const original=fs.renameSync;let first=true;fs.renameSync=(...a)=>{if(first){first=false;fs.writeFileSync(${JSON.stringify(ready)},'ready');const end=Date.now()+5000;while(!fs.existsSync(${JSON.stringify(release)})){if(Date.now()>end)throw Error('bounded gate timeout');Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,10)}}return original(...a)};console.log(JSON.stringify(require(${JSON.stringify(installer)}).applyRepairs(${JSON.stringify(root)})))`;
  const worker=spawn(process.execPath,['-e',script],{env});let stdout='',stderr='';worker.stdout.on('data',b=>stdout+=b);worker.stderr.on('data',b=>stderr+=b);
  const finished=new Promise(resolve=>worker.on('close',(code,signal)=>resolve({code,signal})));
  try{
    const end=Date.now()+5000;while(!fs.existsSync(ready)&&Date.now()<end)await new Promise(r=>setTimeout(r,10));assert.ok(fs.existsSync(ready),stderr);
    const competitor=installerChild(root,{});const midCheck=installerChild(root,{check:true});fs.writeFileSync(release,'release');const first=await finished;
    record('real-concurrent-install-and-check',{competitor,midCheck,first,stdout,stderr,finalCheck:applyRepairs(root,{check:true}),lockAbsent:!fs.existsSync(path.join(root,'node_modules/.tooling-repair-lock'))},'competing write EEXIST; incomplete check failure; final check success','Two real processes execute actual installer; renamed-file pause only controls scheduler timing.');
  }finally{if(worker.exitCode===null){worker.kill('SIGTERM');await finished;}fs.rmSync(root,{recursive:true,force:true});assert.equal(fs.existsSync(root),false);}
}
concurrent().then(()=>{
 const final={finished:new Date().toISOString(),control_count:controls.length,controls,cleanup:{fixture_paths:fs.readdirSync(out).filter(p=>p.startsWith('fixture-')),owned_home_only:true},source_hashes_after:Object.fromEntries(Object.keys(identity.sources).map(p=>[p,hash(fs.readFileSync(path.join(source,p)))]))};
 fs.writeFileSync(path.join(out,'controls.json'),JSON.stringify(final,null,2)+'\n');
 console.log(JSON.stringify({summary:{controls:controls.length,cleanup:final.cleanup,unchangedSources:JSON.stringify(final.source_hashes_after)===JSON.stringify(identity.sources)}}));
}).catch(e=>{console.error(e);process.exitCode=1;});
