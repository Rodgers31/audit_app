import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path('/Users/roger/.codex/worktrees/batch11-dependency-compatibility/audit_app')
owned = Path(__file__).resolve().parent
node = Path('/Users/roger/.nvm/versions/node/v22.19.0/bin/node')
entry = owned / 'review-v3.cjs'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
environment = {'PATH': str(node.parent) + ':/usr/bin:/bin', 'HOME': str(owned / 'launch3-home'), 'TMPDIR': str(owned / 'launch3-tmp'), 'DOTENV_DISABLE': 'true', 'NEXT_TELEMETRY_DISABLED': '1'}
for name in ('launch3-home', 'launch3-tmp'):
    (owned / name).mkdir()
command = [str(node), str(entry), str(root), str(owned / 'run-3')]
record = {'schema': 1, 'command': command, 'cwd': str(root), 'environment': environment, 'started_unix': time.time(), 'producer_sha256': digest(Path(__file__)), 'entry_sha256': digest(entry), 'runtime_sha256': digest(node), 'timeout_seconds': 120}
with (owned / 'stdout3.jsonl').open('xb') as stdout, (owned / 'stderr3.txt').open('xb') as stderr:
    child = subprocess.Popen(command, cwd=root, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
    try:
        record['exit'] = child.wait(timeout=120)
        record['timed_out'] = False
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGTERM)
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait()
        record['exit'] = child.returncode
        record['timed_out'] = True
record['finished_unix'] = time.time()
record['entry_stable'] = record['entry_sha256'] == digest(entry)
record['stdout_sha256'] = digest(owned / 'stdout3.jsonl')
record['stderr_sha256'] = digest(owned / 'stderr3.txt')
with (owned / 'launch3.json').open('x') as receipt:
    json.dump(record, receipt, indent=2)
print(json.dumps(record))
raise SystemExit(record['exit'] or (1 if record['timed_out'] or not record['entry_stable'] else 0))
