'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const cp = require('node:child_process');
const { createRequire } = require('node:module');
const root = path.resolve(process.argv[2]);
const out = path.resolve(process.argv[3]);
assert.ok(path.isAbsolute(root) && path.isAbsolute(out) && !out.startsWith(root + path.sep));
fs.mkdirSync(out);
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
const env = { PATH: path.dirname(process.execPath) + ':/usr/bin:/bin', HOME: path.join(out, 'home'), TMPDIR: path.join(out, 'tmp'), DOTENV_CONFIG_QUIET: 'true', DOTENV_DISABLE: 'true', NEXT_TELEMETRY_DISABLED: '1' };
for (const dir of ['home', 'tmp', 'fixtures']) fs.mkdirSync(path.join(out, dir));
const git = (...args) => {
 const child = cp.spawnSync('/usr/bin/git', args, { cwd: root, env, encoding: 'utf8', timeout: 10000 });
 assert.equal(child.status, 0, child.stderr); return child.stdout.trim();
};
const frontend = path.join(root, 'frontend');
const patchSet = JSON.parse(fs.readFileSync(path.join(frontend, 'scripts/tooling-repairs.json')));
function inventory() {
 const source = {}, installed = {};
 for (const rel of git('ls-files', '-co', '--exclude-standard').split('\n').filter(Boolean).sort()) {
  assert.ok(!/(^|\/)\.env(?:\.|$)/.test(rel) || /(?:example|sample|template)/.test(rel), 'refuse private environment file');
  const full = path.join(root, rel); const stat = fs.lstatSync(full);
  assert.ok(stat.isFile() || stat.isSymbolicLink());
  source[rel] = stat.isSymbolicLink() ? { link: fs.readlinkSync(full) } : hash(fs.readFileSync(full));
 }
 for (const pkg of patchSet.packages) for (const file of Object.keys(pkg.files)) {
  const rel = `node_modules/${pkg.name}/${file}`;
  const full = path.join(frontend, rel); assert.ok(fs.lstatSync(full).isFile());
  installed[rel] = hash(fs.readFileSync(full));
 }
 return { head: git('rev-parse', 'HEAD'), tree: git('rev-parse', 'HEAD^{tree}'), status: git('status', '--porcelain=v1'), source, installed };
}
const before = inventory();
const record = { schema: 1, classification: 'independent-current-scoped-controls', accepted_base: 'bcb5ff99854de595bbe3f7d60cc8796b7ada5a20', started: new Date().toISOString(), generator_sha256: hash(fs.readFileSync(__filename)), runtime: { node: process.version, executable: process.execPath, executable_sha256: hash(fs.readFileSync(process.execPath)), platform: process.platform, arch: process.arch }, environment: env, before };
fs.writeFileSync(path.join(out, 'before.json'), JSON.stringify(record, null, 2), { flag: 'wx' });
let total = 0, failures = 0, fixtures = 0;
function control(name, fn) {
 const start = process.hrtime.bigint(); let result;
 try { result = { name, satisfied: true, detail: fn() ?? null }; }
 catch (error) { failures++; result = { name, satisfied: false, error: { name: error.name, code: error.code ?? null, message: error.message, stack: error.stack } }; }
 total++; result.elapsed_ms = Number(process.hrtime.bigint() - start) / 1e6;
 fs.appendFileSync(path.join(out, 'controls.jsonl'), JSON.stringify(result) + '\n', { flag: 'a' });
 process.stdout.write(JSON.stringify(result) + '\n');
}
const app = createRequire(path.join(frontend, 'package.json'));
const callerPaths = {};
for (const name of ['tailwindcss', '@next/eslint-plugin-next']) {
 const caller = createRequire(app.resolve(name + '/package.json'));
 const fast = createRequire(caller.resolve('fast-glob/package.json'));
 const micro = createRequire(fast.resolve('micromatch/package.json'));
 const braces = micro('braces');
 callerPaths[name] = [app.resolve(name + '/package.json'), caller.resolve('fast-glob/package.json'), fast.resolve('micromatch/package.json'), micro.resolve('braces')];
 control(name + ' actual fast-glob deep input', () => assert.throws(() => caller('fast-glob').sync('{'.repeat(4000) + 'a,b' + '}'.repeat(4000)), e => e.code === 'ERR_BRACES_DEPTH'));
 for (const depth of [0, 1, 63, 64]) control(name + ' parse safe depth ' + depth, () => assert.equal(braces.stringify(braces.parse('{'.repeat(depth) + 'a,b' + '}'.repeat(depth))), '{'.repeat(depth) + 'a,b' + '}'.repeat(depth)));
 for (const options of [{}, { maxDepth: Infinity }, { maxDepth: false }, { maxLength: Infinity }]) {
  for (const [left, right] of [['{', '}'], ['(', ')']]) control(name + ' parse 65 refuses ' + left + JSON.stringify(options), () => assert.throws(() => braces.parse(left.repeat(65) + 'a,b' + right.repeat(65), options), e => e.code === 'ERR_BRACES_DEPTH'));
 }
 for (const method of ['compile', 'stringify', 'expand']) {
  control(name + ' direct ' + method + ' deep AST', () => {
   const ast = { type: 'root', nodes: [] }; let node = ast;
   for (let i = 0; i < 256; i++) { const next = { type: 'paren', nodes: [], parent: node }; node.nodes.push(next); node = next; }
   assert.throws(() => braces[method](ast), e => e.code === 'ERR_BRACES_DEPTH');
  });
  control(name + ' direct ' + method + ' cycle', () => { const ast = { type: 'root', nodes: [] }; ast.nodes.push(ast); assert.throws(() => braces[method](ast), e => e.code === 'ERR_BRACES_DEPTH'); });
 }
 control(name + ' expanding queue arrays', () => { let value = 'x'; for (let i = 0; i < 4096; i++) value = [value]; assert.throws(() => braces.expand({ type: 'root', nodes: [{ type: 'text', value }] }), e => e.code === 'ERR_BRACES_DEPTH'); });
 for (const input of ['x/{a,b}/{1..3}', '\\{a,b\\}', '"{a,b}"', '[{a,b}]', '{a,b}{c,d}', 'a/(b|c)/{x,y}']) control(name + ' retained ordinary ' + input, () => {
  assert.ok(braces.expand(input).length > 0); assert.equal(braces.stringify(braces.parse(input, { keepQuotes: true, keepEscaping: true })), input);
 });
}
const nyc = createRequire(app.resolve('@istanbuljs/load-nyc-config/package.json'));
const yaml = createRequire(nyc.resolve('js-yaml/package.json'));
const argparse = createRequire(yaml.resolve('argparse/package.json'));
const sprintfRoot = path.dirname(argparse.resolve('sprintf-js/package.json'));
callerPaths.sprintf = [app.resolve('@istanbuljs/load-nyc-config/package.json'), nyc.resolve('js-yaml/package.json'), yaml.resolve('argparse/package.json'), argparse.resolve('sprintf-js')];
for (const entry of ['src/sprintf.js', 'dist/sprintf.min.js']) {
 const { sprintf, vsprintf } = require(path.join(sprintfRoot, entry));
 for (const conversion of ['e', 'f', 'g']) {
  for (const precision of [101, 1000]) for (const api of ['sprintf', 'vsprintf', 'format']) control(entry + ' ' + api + ' ' + conversion + ' rejects ' + precision, () => {
   const fmt = '%.' + precision + conversion;
   const fn = api === 'sprintf' ? () => sprintf(fmt, 1) : api === 'vsprintf' ? () => vsprintf(fmt, [1]) : () => sprintf.format(sprintf.parse(fmt), [fmt, 1]);
   assert.throws(fn, e => e.code === 'ERR_SPRINTF_PRECISION');
  });
  const accepted = conversion === 'g' ? [1, 2, 100] : [0, 1, 2, 100];
  for (const precision of accepted) control(entry + ' retained ' + conversion + ' precision ' + precision, () => {
   const actual = sprintf('%.' + precision + conversion, 1.25);
   const native = conversion === 'e' ? (1.25).toExponential(precision) : conversion === 'f' ? (1.25).toFixed(precision) : (1.25).toPrecision(precision);
   assert.equal(actual, native);
  });
  control(entry + ' snapshots precision/conversion before callback ' + conversion, () => {
   const fmt = '%.2' + conversion, tree = sprintf.parse(fmt);
   const expected = sprintf(fmt, 1.25);
   assert.equal(sprintf.format(tree, [fmt, () => { tree[0][7] = '1000'; tree[0][8] = 'g'; return 1.25; }]), expected);
  });
 }
 control(entry + ' read precision getter once', () => {
  const tree = sprintf.parse('%.2f'); let reads = 0;
  Object.defineProperty(tree[0], '7', { get() { return ++reads === 1 ? '2' : '1000'; } });
  assert.equal(sprintf.format(tree, ['%.2f', 1.25]), '1.25'); assert.equal(reads, 1);
 });
 control(entry + ' named positional string and json', () => {
  assert.equal(sprintf('%(person.name)s', { person: { name: 'test' } }), 'test');
  assert.equal(sprintf('%2$s %1$d', 7, 'name'), 'name 7'); assert.equal(sprintf('%.200s', 'small'), 'small');
  assert.equal(sprintf('%j', { ok: true }), '{"ok":true}');
 });
}
const installer = require(path.join(frontend, 'scripts/apply-tooling-repairs.cjs'));
function fixture(fn) {
 const target = path.join(out, 'fixtures', String(++fixtures)); fs.mkdirSync(target); fs.mkdirSync(path.join(target, 'node_modules'));
 fs.copyFileSync(path.join(frontend, 'package-lock.json'), path.join(target, 'package-lock.json'));
 for (const pkg of patchSet.packages) fs.cpSync(path.join(frontend, 'node_modules', pkg.name), path.join(target, 'node_modules', pkg.name), { recursive: true });
 for (const patch of patchSet.patches) {
  const file = path.join(target, 'node_modules', patch.pkg, patch.file);
  if (patch.original_sha256 === null) fs.unlinkSync(file);
  else {
   let text = fs.readFileSync(file, 'utf8');
   for (const edit of [...patch.edits].reverse()) { assert.equal(text.split(edit.after).length, 2); text = text.replace(edit.after, edit.before); }
   assert.equal(hash(Buffer.from(text)), patch.original_sha256); fs.writeFileSync(file, text);
  }
 }
 try { return fn(target); } finally { fs.rmSync(target, { recursive: true }); }
}
control('actual installed source readback', () => { const result = installer.applyRepairs(frontend, { check: true }); assert.equal(result.changedFiles, 0); assert.equal(result.packages.length, 2); return result; });
control('cold upstream refusal then complete repair and idempotence', () => fixture(target => {
 assert.throws(() => installer.applyRepairs(target, { check: true }), /unpatched/);
 assert.equal(installer.applyRepairs(target).changedFiles, 10);
 assert.equal(installer.applyRepairs(target).changedFiles, 0);
 assert.equal(installer.applyRepairs(target, { check: true }).changedFiles, 0);
 for (const pkg of patchSet.packages) for (const [file, identity] of Object.entries(pkg.files)) assert.equal(hash(fs.readFileSync(path.join(target, 'node_modules', pkg.name, file))), identity.repaired_sha256);
}));
for (const [description, mutate, expected] of [
 ['unmodified entry deletion', target => fs.unlinkSync(path.join(target, 'node_modules/braces/index.js')), /absent path/],
 ['main export changed', target => { const file = path.join(target, 'node_modules/braces/package.json'); const data = JSON.parse(fs.readFileSync(file)); data.main = 'lib/constants.js'; fs.writeFileSync(file, JSON.stringify(data)); }, /upstream bytes changed/],
 ['README changed', target => fs.appendFileSync(path.join(target, 'node_modules/sprintf-js/README.md'), '\nchanged'), /upstream bytes changed/],
 ['unexpected file', target => fs.writeFileSync(path.join(target, 'node_modules/braces/extra.js'), 'extra'), /unexpected pkg file/],
 ['dangling pkg symlink', target => { const entry = path.join(target, 'node_modules/braces'); fs.rmSync(entry, { recursive: true }); fs.symlinkSync(path.join(target, 'absent'), entry); }, /symlink refused/],
 ['dangling helper symlink', target => { const file = path.join(target, 'node_modules/braces/lib/audit-bounds.js'); fs.unlinkSync(file); fs.symlinkSync(path.join(target, 'absent'), file); }, /symlink refused/],
 ['lock pkg marked production', target => { const file = path.join(target, 'package-lock.json'); const data = JSON.parse(fs.readFileSync(file)); delete data.packages['node_modules/braces'].dev; fs.writeFileSync(file, JSON.stringify(data)); }, /incompatible locked/],
 ['unsafe omitted lock path', target => { const file = path.join(target, 'package-lock.json'); const data = JSON.parse(fs.readFileSync(file)); data.packages['../node_modules/braces'] = data.packages['node_modules/braces']; fs.writeFileSync(file, JSON.stringify(data)); }, /unsafe pkg path/],
]) control('check and production refuse ' + description, () => fixture(target => {
 installer.applyRepairs(target); mutate(target);
 for (const options of [{ check: true }, { check: true, production: true }]) assert.throws(() => installer.applyRepairs(target, options), expected);
}));
control('planning refuses drift before any patch write', () => fixture(target => {
 const file = path.join(target, 'node_modules/sprintf-js/src/sprintf.js'); const before = fs.readFileSync(file);
 fs.appendFileSync(path.join(target, 'node_modules/braces/lib/constants.js'), '\nchanged');
 assert.throws(() => installer.applyRepairs(target), /upstream bytes changed/); assert.deepEqual(fs.readFileSync(file), before);
 assert.equal(fs.existsSync(path.join(target, 'node_modules/.tooling-repair-lock')), false);
}));
control('production omission has explicit absence result', () => fixture(target => {
 for (const pkg of patchSet.packages) fs.rmSync(path.join(target, 'node_modules', pkg.name), { recursive: true });
 const result = installer.applyRepairs(target, { production: true }); assert.deepEqual(result.packages, []); assert.equal(result.absentPackages.length, 2); assert.equal(result.changedFiles, 0);
 assert.throws(() => installer.applyRepairs(target, { check: true }), /absent installed/); return result;
}));
control('lock preservation and ownership', () => {
 const baseline = JSON.parse(git('show', record.accepted_base + ':frontend/package-lock.json'));
 const current = JSON.parse(fs.readFileSync(path.join(frontend, 'package-lock.json')));
 const entries = Object.entries(baseline.packages).filter(([name]) => name.startsWith('node_modules/'));
 assert.equal(entries.length, 901); for (const [name, value] of entries) assert.deepEqual(current.packages[name], value);
 const production = entries.filter(([, value]) => value.dev !== true); assert.equal(production.length, 173);
 const diffPaths = git('diff', '--name-only', record.accepted_base + '...HEAD').split('\n'); assert.ok(diffPaths.every(name => /^frontend\/(?:pkg(?:-lock)?\.json|scripts\/)/.test(name)));
 return { existing_lock_records: entries.length, production_records: production.length, diff_paths: diffPaths };
});
const callerIdentity = Object.fromEntries(Object.entries(callerPaths).map(([name, files]) => [name, files.map(file => ({ path: path.relative(root, file), sha256: hash(fs.readFileSync(file)) }))]));
const after = inventory();
const sourceStable = JSON.stringify(before) === JSON.stringify(after);
if (!sourceStable) failures++;
record.finished = new Date().toISOString(); record.after = after; record.source_stable = sourceStable; record.total = total; record.failures = failures; record.skipped = 0; record.fixture_directories_remaining = fs.readdirSync(path.join(out, 'fixtures')); record.caller_identity = callerIdentity; record.actual_control_exit = failures ? 1 : 0;
fs.writeFileSync(path.join(out, 'receipt.json'), JSON.stringify(record, null, 2), { flag: 'wx' });
process.stdout.write(JSON.stringify({ total, failures, source_stable: sourceStable, actual_control_exit: record.actual_control_exit }) + '\n');
process.exitCode = record.actual_control_exit;
