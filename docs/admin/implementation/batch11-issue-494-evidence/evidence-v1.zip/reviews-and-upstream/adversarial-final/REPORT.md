# Independent recheck before distributed-entry repair

Executed 274 unique controls on Node 22.19.0 / Darwin arm64: 156 original replay controls and 118 expanded controls. Of these, 273 scoped acceptance controls passed; one separate alternate-entry exposure observation remains outstanding. No acceptance failures, errors, skips, xfails, or timed-out children occurred. Both execution producers exited 0; exact raw child exits and diagnostics are retained. Every owned fixture was removed and source bytes remained unchanged throughout both runs.

All four original findings are fixed on the measured source: complete package bytes/metadata are checked, production omission cannot accept dangling links, append recursion uses the depth ceiling, and numeric formatting uses the checked precision/conversion snapshots. This acceptance remains bound to the seven source hashes in original-replay/identity.json and expanded-replay/identity.json, launch HEAD bcb5ff99854de595bbe3f7d60cc8796b7ada5a20 / tree 9d0061928c16d173859f98cb6daa5f2f591b257c with the recorded uncommitted delta. Expanded-replay/source/ preserves the actual tested bytes. Later changes require a new replay.

## Expanded measured coverage

- All 27 inventoried package files were independently changed, deleted, and replaced with symlinks: 81 rejections, including unchanged metadata and library files.
- Extra files, nested files, real/dangling extra symlinks, and main-field drift for both packages: rejected.
- Nested locked package paths with missing genuine parents explicitly reported omission in production; real/dangling symlink parents and non-directory parents were rejected.
- Real installer publication was intercepted only to schedule a collision after planning. Actual wx writes rejected regular-file and symlink collisions while preserving exact unrelated bytes and cleaning the owner lock. A real injected rename EIO removed the created temporary and cleaned the lock without success.
- Deep/cyclic array stashes and deep queues rejected with ERR_BRACES_DEPTH before stack exhaustion.
- e/f/g format callbacks and precision/conversion getters could not change the checked numeric operation. Precision getters were read once; invalid precision objects were rejected before coercion and callback.
- The original positives, negative malformed-input controls, fresh source-hash-verified repair, idempotence, and real concurrent processes were replayed.

## Remaining boundary

The distributed alternate entrypoint `sprintf-js/dist/sprintf.min.js` is currently inventoried as unchanged upstream bytes. In the actual installed package, `require('sprintf-js/dist/sprintf.min.js').sprintf('%.101f', 1.25)` still throws the native RangeError rather than ERR_SPRINTF_PRECISION. This is separate from the reviewed argparse main entrypoint and is not counted as successful all-package repair acceptance. Evidence: expanded-replay/controls.json control alternate-sprintf-dist-boundary. The author confirmed that distribution coverage will be repaired and submitted for another independent replay; this report deliberately preserves the earlier source identity and outstanding limitation.

## Receipts and replay

acceptance-assessment.json contains 274 complete unique identities, the scored-control counts, source correspondence and cleanup. execution-receipt.json records commands/exits/environment/deadlines. Original and expanded raw outputs and source/generator identities are in their respective replay directories. Both portable producers accept a checkout root and a fresh owned output directory:

```text
node portable-control-runner.cjs CHECKOUT_ROOT FRESH_ORIGINAL_OUTPUT
node expanded-control-runner.cjs CHECKOUT_ROOT FRESH_EXPANDED_OUTPUT
```

Children received only allowlisted PATH and inert HOME. Individual child deadlines were 10 seconds; concurrency scheduler gates were bounded at 5 seconds. No primary-checkout reads/writes, installed-library mutations, live provider operations, network requests or credentials were involved. The author-reported recovered primary-write incident was outside this independent execution and was not assessed here.

A first result-classification helper exited 1 because its broad AST name predicate captured the separately wrapped append control and its concurrency predicate expected the old diagnostic. The unchanged raw outcomes showed ERR_BRACES_DEPTH and a precise unexpected-temporary-file refusal. The corrected standalone assessor orders the specific control first and accepts those two explicitly intended refusal diagnostics. This classifier setup error is retained separately in assessment-attempts.json; it was not product red and no behavioral assertions were weakened.

This supplies local adversarial acceptance of the measured scoped repair. It supplies no Linux/native/model/browser/build/audit/hosted/production acceptance and grants no residual-risk exception.
