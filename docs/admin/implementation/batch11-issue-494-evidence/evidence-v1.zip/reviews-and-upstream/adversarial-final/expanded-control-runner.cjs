'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),{spawnSync}=require('node:child_process');
const source=path.resolve(process.argv[2]),out=path.resolve(process.argv[3]);fs.mkdirSync(out,{recursive:true});
const frontend=path.join(source,'frontend'),installer=path.join(frontend,'scripts/apply-tooling-repairs.cjs'),manifest=path.join(frontend,'scripts/tooling-repairs.json');
const patchSet=JSON.parse(fs.readFileSync(manifest)),{applyRepairs}=require(installer),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const env={PATH:path.dirname(process.execPath)+':/usr/bin:/bin',HOME:path.join(out,'inert-home')};fs.mkdirSync(env.HOME,{recursive:true});
const sourcePaths=['frontend/package.json','frontend/package-lock.json','frontend/scripts/test-runtime-dependencies.cjs','frontend/scripts/apply-tooling-repairs.cjs','frontend/scripts/tooling-repairs.json','frontend/scripts/tooling-repair-behavior.test.cjs','frontend/scripts/tooling-repair-install.test.cjs'];
const hashes=()=>Object.fromEntries(sourcePaths.map(p=>[p,hash(fs.readFileSync(path.join(source,p)))]));
const git=args=>spawnSync('/usr/bin/git',args,{cwd:source,env,encoding:'utf8',timeout:10000});
const identity={start:new Date().toISOString(),head:git(['rev-parse','HEAD']).stdout.trim(),tree:git(['rev-parse','HEAD^{tree}']).stdout.trim(),status:git(['status','--short']).stdout,source_sha256:hashes(),generator_sha256:hash(fs.readFileSync(__filename)),runtime:process.version,platform:process.platform,arch:process.arch,package_file_count:patchSet.packages.reduce((n,p)=>n+Object.keys(p.files).length,0)};
fs.writeFileSync(path.join(out,'identity.json'),JSON.stringify(identity,null,2)+'\n');
for(const p of sourcePaths){const target=path.join(out,'source',p);fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(path.join(source,p),target);}
const controls=[];
const attempt=fn=>{try{return {kind:'success',value:fn()};}catch(e){return {kind:'exception',name:e.name,code:e.code||null,message:e.message};}};
function record(name,result,predicate,expected){assert.ok(!controls.some(c=>c.name===name));let pass=false,assessmentError=null;try{pass=Boolean(predicate(result));}catch(e){assessmentError=e.message;}const row={name,result,pass,expected,assessmentError};controls.push(row);console.log(JSON.stringify(row));}
function fixture(upstream=false){
 const root=fs.mkdtempSync(path.join(out,'fixture-'));fs.mkdirSync(path.join(root,'node_modules'));fs.copyFileSync(path.join(frontend,'package-lock.json'),path.join(root,'package-lock.json'));
 for(const name of ['braces','sprintf-js','fill-range','to-regex-range','is-number'])fs.cpSync(path.join(frontend,'node_modules',name),path.join(root,'node_modules',name),{recursive:true});
 if(upstream)for(const p of patchSet.patches){const target=path.join(root,'node_modules',p.package,p.file);if(p.original_sha256===null)fs.unlinkSync(target);else{let text=fs.readFileSync(target,'utf8');for(const e of [...p.edits].reverse())text=text.replace(e.after,e.before);assert.equal(hash(text),p.original_sha256);fs.writeFileSync(target,text);}}
 return root;
}
function owned(fn,upstream=false){const root=fixture(upstream);try{return fn(root);}finally{fs.rmSync(root,{recursive:true,force:true});assert.equal(fs.existsSync(root),false);}}
const fail=r=>r.kind==='exception';
function child(code){const r=spawnSync(process.execPath,['-e',code],{env,encoding:'utf8',timeout:10000,maxBuffer:1024*1024});return {status:r.status,signal:r.signal,error:r.error?.message||null,stdout:r.stdout,stderr:r.stderr};}
function installChild(root,options){return child(`const fn=require(${JSON.stringify(installer)}).applyRepairs;try{console.log(JSON.stringify({kind:'success',value:fn(${JSON.stringify(root)},${JSON.stringify(options)})}));}catch(e){console.log(JSON.stringify({kind:'exception',name:e.name,code:e.code||null,message:e.message}));process.exitCode=1}`);}
for(const inventory of patchSet.packages)for(const file of Object.keys(inventory.files))for(const mutation of ['changed','missing','linked']){
 record(`inventory-${inventory.name}-${file}-${mutation}`,owned(root=>{
  const target=path.join(root,'node_modules',inventory.name,file);
  if(mutation==='changed')fs.appendFileSync(target,'\nindependent drift');
  if(mutation==='missing')fs.unlinkSync(target);
  if(mutation==='linked'){const retained=path.join(root,'retained-source');fs.renameSync(target,retained);fs.symlinkSync(retained,target);}
  return attempt(()=>applyRepairs(root,{check:true}));
 }),fail,'Every inventoried file must reject changed/missing/symlinked bytes.');
}
for(const name of ['braces','sprintf-js'])for(const kind of ['file','directory-file','symlink','dangling-symlink'])record(`unexpected-${name}-${kind}`,owned(root=>{
 const target=path.join(root,'node_modules',name,'unexpected');
 if(kind==='file')fs.writeFileSync(target,'unknown');
 if(kind==='directory-file'){fs.mkdirSync(target);fs.writeFileSync(path.join(target,'unknown.js'),'unknown');}
 if(kind==='symlink'){const real=path.join(root,'unknown-source');fs.writeFileSync(real,'unknown');fs.symlinkSync(real,target);}
 if(kind==='dangling-symlink')fs.symlinkSync(path.join(root,'absent-target'),target);
 return attempt(()=>applyRepairs(root,{check:true}));
}),fail,'Reject every extra package file/link without interpreting it as reviewed bytes.');
for(const name of ['braces','sprintf-js'])record(`metadata-main-drift-${name}`,owned(root=>{const target=path.join(root,'node_modules',name,'package.json'),metadata=JSON.parse(fs.readFileSync(target));metadata.main='missing.js';fs.writeFileSync(target,JSON.stringify(metadata));return attempt(()=>applyRepairs(root,{check:true}));}),fail,'Entrypoint metadata is bound even when name/version remain valid.');
for(const shape of ['absent-parent','dangling-parent','linked-parent','file-parent','dangling-modules-parent'])record(`nested-package-${shape}`,owned(root=>{
 const lockPath=path.join(root,'package-lock.json'),lock=JSON.parse(fs.readFileSync(lockPath));lock.packages['node_modules/holder/node_modules/braces']={...lock.packages['node_modules/braces']};fs.writeFileSync(lockPath,JSON.stringify(lock));
 const parent=path.join(root,'node_modules/holder');
 if(shape==='dangling-parent')fs.symlinkSync(path.join(root,'absent-parent'),parent);
 if(shape==='linked-parent'){const real=path.join(root,'linked-real');fs.mkdirSync(real);fs.symlinkSync(real,parent);}
 if(shape==='file-parent')fs.writeFileSync(parent,'not directory');
 if(shape==='dangling-modules-parent'){fs.mkdirSync(parent);fs.symlinkSync(path.join(root,'absent-modules'),path.join(parent,'node_modules'));}
 return attempt(()=>applyRepairs(root,{production:true,check:true}));
}),r=>shape==='absent-parent'?r.kind==='success'&&r.value.absentPackages.includes('node_modules/holder/node_modules/braces'):fail(r),'True production absence is explicit; parent links/files cannot masquerade as absence.');
for(const kind of ['regular','symlink'])record(`temporary-race-collision-${kind}`,owned(root=>child(`
 const fs=require('node:fs'),path=require('node:path');const write=fs.writeFileSync;let temporary,first=true;const sentinel=path.join(${JSON.stringify(root)},'collision-sentinel');write(sentinel,'unrelated owned bytes');
 fs.writeFileSync=(target,...args)=>{if(first&&String(target).endsWith('.repair-'+process.pid)){first=false;temporary=target;${kind==='regular'?'write(target,\'unknown collision\');':'fs.symlinkSync(sentinel,target);'}}return write(target,...args)};
 let result;try{result={kind:'success',value:require(${JSON.stringify(installer)}).applyRepairs(${JSON.stringify(root)})}}catch(e){result={kind:'exception',code:e.code,message:e.message}}
 console.log(JSON.stringify({result,temporaryKind:temporary?(fs.lstatSync(temporary).isSymbolicLink()?'symlink':'file'):null,temporaryBytes:temporary?fs.readFileSync(temporary,'utf8'):null,sentinelBytes:fs.readFileSync(sentinel,'utf8'),lockAbsent:!fs.existsSync(path.join(${JSON.stringify(root)},'node_modules/.tooling-repair-lock'))}));
`),true),r=>{const d=JSON.parse(r.stdout);return r.status===0&&d.result.kind==='exception'&&d.result.code==='EEXIST'&&d.temporaryKind===(kind==='regular'?'file':'symlink')&&d.temporaryBytes===(kind==='regular'?'unknown collision':'unrelated owned bytes')&&d.sentinelBytes==='unrelated owned bytes'&&d.lockAbsent;},'Existing collision survives actual wx failure; owner lock cleans up.');
record('rename-failure-owned-temporary-cleanup',owned(root=>child(`
 const fs=require('node:fs'),path=require('node:path');let temporary;fs.renameSync=(from)=>{temporary=from;throw Object.assign(Error('independent injected rename EIO'),{code:'EIO'})};let result;
 try{result={kind:'success',value:require(${JSON.stringify(installer)}).applyRepairs(${JSON.stringify(root)})}}catch(e){result={kind:'exception',code:e.code,message:e.message}}
 console.log(JSON.stringify({result,temporaryAbsent:temporary&&!fs.existsSync(temporary),lockAbsent:!fs.existsSync(path.join(${JSON.stringify(root)},'node_modules/.tooling-repair-lock'))}));
`),true),r=>{const d=JSON.parse(r.stdout);return r.status===0&&d.result.code==='EIO'&&d.temporaryAbsent&&d.lockAbsent;},'Created temporary is removed after real failed publication; no success report.');
const braces=require(path.join(frontend,'node_modules/braces'));
for(const shape of ['deep-stash','cyclic-stash','deep-queue'])record(`append-${shape}`,attempt(()=>{
 let a='x';if(shape==='cyclic-stash'){a=[];a.push(a);}else for(let i=0;i<8000;i++)a=[a];
 const nodes=shape==='deep-queue'?[{type:'text',value:a},{type:'text',value:'y'}]:[{type:'text',value:a}];return braces.expand({type:'root',nodes});
}),r=>r.kind==='exception'&&r.code==='ERR_BRACES_DEPTH','All append recursion rejects by policy before JavaScript stack exhaustion.');
const {sprintf}=require(path.join(frontend,'node_modules/sprintf-js'));
for(const conversion of ['e','f','g'])for(const shape of ['callback-precision','callback-conversion','precision-getter','conversion-getter'])record(`format-snapshot-${conversion}-${shape}`,attempt(()=>{
 const tree=sprintf.parse('%.2'+conversion);let reads=0;
 if(shape==='precision-getter')Object.defineProperty(tree[0],7,{get(){return ++reads===1?'2':'101';}});
 if(shape==='conversion-getter')Object.defineProperty(tree[0],8,{get(){return ++reads===1?conversion:'g';}});
 const formatted=sprintf.format(tree,['%.2'+conversion,()=>{if(shape==='callback-precision')tree[0][7]='101';if(shape==='callback-conversion'){tree[0][8]='g';tree[0][7]='0';}return 1.25;}]);
 const expected=conversion==='e'?(1.25).toExponential(2):conversion==='f'?(1.25).toFixed(2):(1.25).toPrecision(2);return {formatted,expected,reads};
}),r=>r.kind==='success'&&r.value.formatted===r.value.expected&&(r.value.reads===0||r.value.reads===1),'Same checked precision/conversion snapshots survive getters and callbacks.');
for(const conversion of ['e','f','g'])record(`format-malformed-object-${conversion}`,attempt(()=>{const tree=sprintf.parse('%.2'+conversion);let coerced=false,called=false;tree[0][7]={valueOf(){coerced=true;return 2;}};const result=attempt(()=>sprintf.format(tree,['%.2'+conversion,()=>{called=true;return 1.25;}]));return {result,coerced,called};}),r=>r.kind==='success'&&r.value.result.code==='ERR_SPRINTF_PRECISION'&&!r.value.coerced&&!r.value.called,'Invalid precision object rejects before coercion/callback.');
record('alternate-sprintf-dist-boundary',attempt(()=>{const fn=require(path.join(frontend,'node_modules/sprintf-js/dist/sprintf.min.js')).sprintf;return attempt(()=>fn('%.101f',1.25));}),r=>r.kind==='success'&&r.value.kind==='exception'&&r.value.name==='RangeError','Recorded exposure boundary: distributed alternate entrypoint remains upstream and is outside reviewed argparse main caller.');
const final={finished:new Date().toISOString(),control_count:controls.length,pass:controls.filter(c=>c.pass).length,fail:controls.filter(c=>!c.pass).length,error:controls.filter(c=>c.assessmentError).length,skip:0,xfail:0,controls,cleanup:{fixture_paths:fs.readdirSync(out).filter(x=>x.startsWith('fixture-'))},source_sha256_after:hashes()};
final.unchanged_source=JSON.stringify(final.source_sha256_after)===JSON.stringify(identity.source_sha256);
fs.writeFileSync(path.join(out,'controls.json'),JSON.stringify(final,null,2)+'\n');console.log(JSON.stringify({summary:{controls:final.control_count,pass:final.pass,fail:final.fail,error:final.error,cleanup:final.cleanup,unchanged_source:final.unchanged_source}}));
if(final.fail||final.error||!final.unchanged_source||final.cleanup.fixture_paths.length)process.exitCode=1;
