'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {createRequire}=require('node:module');
const app=createRequire('/Users/roger/.codex/worktrees/batch11-dependency-compatibility/audit_app/frontend/package.json');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const sourcePath=app.resolve('sprintf-js/src/sprintf.js');
const source=fs.readFileSync(sourcePath,'utf8');
const minifierPath=app.resolve('next/dist/compiled/terser');
const result=app(minifierPath).minify_sync({'../src/sprintf.js':source},{sourceMap:{filename:'sprintf.min.js',url:'sprintf.min.map',includeSources:true},format:{comments:/sprintf-js/}});
assert.equal(result.error,undefined);
for(const file of ['dist/sprintf.min.js','dist/sprintf.min.map','dist/sprintf.min.js.map']){
 const installed=fs.readFileSync(app.resolve(`sprintf-js/${file}`),'utf8');
 const generated=(file.endsWith('.js')?result.code:result.map)+'\n';
 assert.equal(installed,generated);
 console.log(JSON.stringify({control:`independently regenerated ${file} matches source`,satisfied:true,installed_sha256:hash(installed),generated_sha256:hash(generated)}));
}
console.log(JSON.stringify({controls:3,failures:0,skips:0,source_sha256:hash(source),minifier_sha256:hash(fs.readFileSync(minifierPath)),next_version:app('next/package.json').version,node:process.version,platform:process.platform,arch:process.arch,producer_sha256:hash(fs.readFileSync(__filename))}));
