"""Schema refusals tested against a copied, independently identified draft."""
import copy, hashlib, importlib.util, json, tempfile, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'draft-verifier-initial.py'
spec=importlib.util.spec_from_file_location('candidate_verifier',SOURCE)
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
PACKET=ROOT.parent/'packet-initial'
ARCHIVE=PACKET/'evidence-v1.zip';MANIFEST=PACKET/'evidence-v1.manifest.json'
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest=json.loads(MANIFEST.read_bytes())
with zipfile.ZipFile(ARCHIVE) as z:members={name:z.read(name) for name in manifest['members']}
receipt_name=next(iter(manifest['receipts']))
print(json.dumps({'verifier_sha256':sha(SOURCE.read_bytes()),'producer_sha256':sha(Path(__file__).read_bytes()),'archive_sha256':sha(ARCHIVE.read_bytes()),'manifest_sha256':sha(MANIFEST.read_bytes()),'source_receipt':receipt_name}))
print(json.dumps({'control':'unaltered actual packet','result':v.verify(ARCHIVE,MANIFEST)}))
cases=[
 ('missing receipt error',lambda r,m:r.pop('error')),
 ('empty resolved environment',lambda r,m:r.update(resolved_environment={})),
 ('missing error in receipt and expectation',lambda r,m:(r.pop('error'),m['receipts'][receipt_name].pop('error'))),
 ('malformed nonrelative source filename',lambda r,m:r['source_before']['files'].update({'../../outside':'0'*64})),
 ('missing actual command',lambda r,m:r.pop('command')),
 ('boolean exit',lambda r,m:r.update(exit=True)),
]
findings=0
for name,mutate in cases:
 m=copy.deepcopy(manifest);record=json.loads(members[receipt_name]);mutate(record,m)
 changed=(json.dumps(record)+'\n').encode();m['members'][receipt_name]=sha(changed)
 with tempfile.TemporaryDirectory(dir=ROOT) as scratch:
  folder=Path(scratch);archive=folder/'mutant.zip'
  with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_STORED) as z:
   for key,data in members.items():z.writestr(key,changed if key==receipt_name else data)
  m['archive_sha256']=sha(archive.read_bytes());p=folder/'manifest.json';p.write_text(json.dumps(m))
  try:
   result=v.verify(archive,p);accepted=True;diagnostic=None
  except Exception as error:
   accepted=False;diagnostic=f'{type(error).__name__}: {error}'
  findings+=accepted
  print(json.dumps({'control':name,'accepted':accepted,'diagnostic':diagnostic,'mutant_receipt_sha256':sha(changed),'archive_sha256':m['archive_sha256']}))
print(json.dumps({'schema_controls':len(cases),'accepted_invalid_controls':findings,'classification':'DRAFT_VERIFIER_FINDINGS_NOT_IMPLEMENTATION_ACCEPTANCE'}))
