'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const vm=require('node:vm');
const {createRequire}=require('node:module');
const root='/Users/roger/.codex/worktrees/batch11-dependency-compatibility/audit_app/frontend';
const app=createRequire(path.join(root,'package.json'));
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const manifest=app('./scripts/tooling-repairs.json');
let controls=0;
function check(name,fn){fn();controls++;console.log(JSON.stringify({control:name,satisfied:true}));}
for(const inventory of manifest.packages){
 for(const [file,identity] of Object.entries(inventory.files)){
  check(`installed hash ${inventory.name}/${file}`,()=>assert.equal(hash(fs.readFileSync(path.join(root,'node_modules',inventory.name,file))),identity.repaired_sha256));
 }
}
const src=fs.readFileSync(app.resolve('sprintf-js/src/sprintf.js'),'utf8');
for(const mapfile of ['sprintf.min.map','sprintf.min.js.map']){
 const map=JSON.parse(fs.readFileSync(app.resolve(`sprintf-js/dist/${mapfile}`)));
 check(`distributed ${mapfile} source corresponds to actual formatter`,()=>assert.deepEqual(map.sourcesContent,[src]));
 check(`distributed ${mapfile} points to canonical source`,()=>assert.deepEqual(map.sources,['../src/sprintf.js']));
}
for(const entry of ['src/sprintf.js','dist/sprintf.min.js']){
 const bytes=fs.readFileSync(app.resolve(`sprintf-js/${entry}`),'utf8');
 for(const mode of ['commonjs','browser','amd']){
  const context={};
  if(mode==='commonjs')context.exports={};
  else context.window={};
  if(mode==='amd'){context.define=fn=>{context.amd=fn();};context.define.amd=true;}
  vm.runInNewContext(bytes,context,{timeout:1000,filename:entry});
  const exported=mode==='commonjs'?context.exports:mode==='amd'?context.amd:context.window;
  const {sprintf,vsprintf}=exported;
  for(const conversion of ['e','f','g']){
   for(const precision of [1,2,100]){
    const pattern=`%.${precision}${conversion}`;
    const expected=conversion==='e'?(1.25).toExponential(precision):conversion==='f'?(1.25).toFixed(precision):(1.25).toPrecision(precision);
    check(`${entry} ${mode} valid ${pattern}`,()=>assert.equal(sprintf(pattern,1.25),expected));
   }
   for(const precision of [101,1000]){
    const pattern=`%.${precision}${conversion}`;
    for(const [kind,call] of [['sprintf',()=>sprintf(pattern,1)],['vsprintf',()=>vsprintf(pattern,[1])],['format',()=>sprintf.format(sprintf.parse(pattern),[pattern,1])]]){
     check(`${entry} ${mode} ${kind} rejects ${pattern}`,()=>assert.throws(call,e=>e.code==='ERR_SPRINTF_PRECISION' && e.name==='SyntaxError'));
    }
   }
   check(`${entry} ${mode} snapshots ${conversion}`,()=>{
    const pattern=`%.2${conversion}`,tree=sprintf.parse(pattern),expected=sprintf(pattern,1);
    assert.equal(sprintf.format(tree,[pattern,()=>{tree[0][7]='1000';tree[0][8]='g';return 1;}]),expected);
   });
  }
  check(`${entry} ${mode} retained positional strings`,()=>assert.equal(sprintf('%2$s %1$d',7,'item'),'item 7'));
 }
}
for(const name of ['tailwindcss','@next/eslint-plugin-next']){
 const caller=createRequire(app.resolve(`${name}/package.json`));
 check(`${name} actual fast-glob retains ordinary scan`,()=>assert.ok(caller('fast-glob').sync('scripts/*.cjs',{cwd:root}).includes('scripts/apply-tooling-repairs.cjs')));
 check(`${name} actual fast-glob bounds 4000 nested levels`,()=>assert.throws(()=>caller('fast-glob').sync('{'.repeat(4000)+'a,b'+'}'.repeat(4000)),e=>e.code==='ERR_BRACES_DEPTH'));
}
console.log(JSON.stringify({controls,failures:0,skips:0,node:process.version,platform:process.platform,arch:process.arch,producer_sha256:hash(fs.readFileSync(__filename))}));
