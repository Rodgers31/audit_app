'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const crypto=require('node:crypto');
const {createRequire}=require('node:module');
const root='/Users/roger/.codex/worktrees/batch11-dependency-compatibility/audit_app/frontend';
const app=createRequire(path.join(root,'package.json'));
const {applyRepairs}=app('./scripts/apply-tooling-repairs.cjs');
const manifest=app('./scripts/tooling-repairs.json');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
let controls=0;
function check(name,fn){fn();controls++;console.log(JSON.stringify({control:name,satisfied:true}));}
function fixture(fn){
 const target=fs.mkdtempSync(path.join(os.tmpdir(),'independent-standards-'));
 try{
  fs.copyFileSync(path.join(root,'package-lock.json'),path.join(target,'package-lock.json'));
  fs.mkdirSync(path.join(target,'node_modules'));
  for(const name of ['braces','sprintf-js'])fs.cpSync(path.join(root,'node_modules',name),path.join(target,'node_modules',name),{recursive:true});
  return fn(target);
 }finally{fs.rmSync(target,{recursive:true,force:true});}
}
function moduleHashes(target){const result={};for(const inv of manifest.packages){for(const file of Object.keys(inv.files)){const p=path.join(target,'node_modules',inv.name,file);try{const st=fs.lstatSync(p);result[`${inv.name}/${file}`]=st.isSymbolicLink()?'link:'+fs.readlinkSync(p):hash(fs.readFileSync(p));}catch(e){if(e.code!=='ENOENT')throw e;result[`${inv.name}/${file}`]=null;}}}return result;}
check('repaired check performs zero writes',()=>fixture(target=>{const before=moduleHashes(target);assert.equal(applyRepairs(target,{check:true}).changedFiles,0);assert.deepEqual(moduleHashes(target),before);}));
for(const inv of manifest.packages){
 for(const file of Object.keys(inv.files)){
  check(`missing required ${inv.name}/${file} refuses check`,()=>fixture(target=>{fs.unlinkSync(path.join(target,'node_modules',inv.name,file));assert.throws(()=>applyRepairs(target,{check:true}),/absent path|unpatched/);}));
 }
 check(`unrecognized ${inv.name} file refuses before writes`,()=>fixture(target=>{fs.writeFileSync(path.join(target,'node_modules',inv.name,'unexpected.js'),'module.exports=1;');const before=moduleHashes(target);assert.throws(()=>applyRepairs(target),/unexpected package file/);assert.deepEqual(moduleHashes(target),before);}));
 check(`dangling ${inv.name} production link refuses`,()=>fixture(target=>{fs.rmSync(path.join(target,'node_modules',inv.name),{recursive:true});fs.symlinkSync(path.join(target,'missing'),path.join(target,'node_modules',inv.name));assert.throws(()=>applyRepairs(target,{production:true}),/symlink refused/);}));
}
check('fresh canonical bytes reapply all ten hashes',()=>fixture(target=>{
 for(const patch of manifest.patches){const p=path.join(target,'node_modules',patch.package,patch.file);if(patch.original_sha256===null)fs.unlinkSync(p);else{let text=fs.readFileSync(p,'utf8');for(const edit of [...patch.edits].reverse()){assert.equal(text.split(edit.after).length,2);text=text.replace(edit.after,edit.before);}assert.equal(hash(text),patch.original_sha256);fs.writeFileSync(p,text);}}
 assert.throws(()=>applyRepairs(target,{check:true}),/unpatched/);assert.equal(applyRepairs(target).changedFiles,10);assert.equal(applyRepairs(target).changedFiles,0);
 for(const inv of manifest.packages)for(const [file,identity]of Object.entries(inv.files))assert.equal(hash(fs.readFileSync(path.join(target,'node_modules',inv.name,file))),identity.repaired_sha256);
}));
check('lock declaring production target refuses',()=>fixture(target=>{const lockfile=path.join(target,'package-lock.json'),lock=JSON.parse(fs.readFileSync(lockfile));lock.packages['node_modules/braces'].dev=false;fs.writeFileSync(lockfile,JSON.stringify(lock));assert.throws(()=>applyRepairs(target),/incompatible locked/);}));
console.log(JSON.stringify({controls,failures:0,skips:0,node:process.version,platform:process.platform,arch:process.arch,producer_sha256:hash(fs.readFileSync(__filename))}));
