"""Independent, finite command capture for the Standards review."""
import hashlib, json, os, platform, signal, subprocess, sys, time
from pathlib import Path

ROOT=Path('/Users/roger/.codex/worktrees/batch11-dependency-compatibility/audit_app')
OUT=Path(__file__).resolve().parent
NODE=Path('/Users/roger/.nvm/versions/node/v22.19.0/bin/node')
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['/usr/bin/git','-C',str(ROOT),*args])
def snapshot():
 files={}
 for raw in git('ls-files','-z').split(b'\0'):
  if not raw:continue
  name=raw.decode();p=ROOT/name
  if p.name=='.env':raise ValueError('credential-shaped tracked input refused')
  files[name]=sha(p.read_bytes())
 return {'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--porcelain=v1').decode(),'files':files}
def run(name,args,timeout=45):
 home=OUT/(name+'-home');home.mkdir();temp=home/'tmp';temp.mkdir()
 env={'PATH':str(NODE.parent)+':/usr/bin:/bin','HOME':str(home),'TMPDIR':str(temp),'LANG':'C.UTF-8','CI':'1'}
 before=snapshot();start=time.time();error=None
 process=subprocess.Popen(args,cwd=ROOT/'frontend',env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:
  stdout,stderr=process.communicate(timeout=timeout);code=process.returncode
 except subprocess.TimeoutExpired:
  error='timeout';os.killpg(process.pid,signal.SIGTERM)
  try:stdout,stderr=process.communicate(timeout=2)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL);stdout,stderr=process.communicate(timeout=2)
  code=process.returncode
 after=snapshot()
 for ext,data in [('stdout',stdout),('stderr',stderr)]:
  with (OUT/(name+'.'+ext)).open('xb') as f:f.write(data)
 record={'classification':'INDEPENDENT_STANDARDS_COMMAND_CAPTURE','command':args,'cwd':str(ROOT/'frontend'),'environment':env,'started_at':start,'ended_at':time.time(),'exit':code,'error':error,'source_before':before,'source_after':after,'source_stable':before==after,'producer_sha256':sha(Path(__file__).read_bytes()),'runtime':{'python':sys.version,'platform':platform.platform(),'machine':platform.machine(),'node':subprocess.check_output([str(NODE),'-p','JSON.stringify({version:process.version,platform:process.platform,arch:process.arch})'],env=env).decode().strip()},'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr)}
 with (OUT/(name+'.json')).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
 print(json.dumps({'name':name,'exit':code,'error':error,'source_stable':record['source_stable'],'seconds':record['ended_at']-start}))
 return code if code else (1 if error or before!=after else 0)
if __name__=='__main__':
 name=sys.argv[1];args=sys.argv[2:]
 if not args or not Path(args[0]).is_absolute():raise ValueError('absolute executable required')
 raise SystemExit(run(name,args))
