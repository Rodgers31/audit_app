"""Independent replay of initial metadata findings and stronger schema controls."""
import copy,hashlib,importlib.util,json,sys,tempfile,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fixed',ROOT/'verify_bundle.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
PACKET=ROOT.parents[1]/'packet-initial';archive=PACKET/'evidence-v1.zip';mp=PACKET/'evidence-v1.manifest.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads(mp.read_bytes())
with zipfile.ZipFile(archive) as z:members={name:z.read(name) for name in manifest['members']}
name=next(iter(manifest['receipts']))
original=json.loads(members[name]);failures=[]
cases=[
 ('missing receipt error',lambda r,m:r.pop('error'),'missing execution error'),
 ('empty resolved environment',lambda r,m:r.update(resolved_environment={}),'incomplete resolved environment'),
 ('missing error both',lambda r,m:(r.pop('error'),m['receipts'][name].pop('error')),'incomplete receipt expectation'),
 ('missing HOME',lambda r,m:r['resolved_environment'].pop('HOME'),'incomplete resolved environment'),
 ('empty HOME',lambda r,m:r['resolved_environment'].update(HOME=''),'invalid environment value'),
 ('relative HOME',lambda r,m:r['resolved_environment'].update(HOME='relative'),'relative environment path'),
 ('wrong native policy',lambda r,m:r['resolved_environment'].update(ONNXRUNTIME_NODE_INSTALL='cuda12'),'wrong captured environment policy'),
 ('unrecognized ambient token',lambda r,m:r['resolved_environment'].update(PROVIDER_TOKEN='unexpected'),'incomplete resolved environment'),
 ('wrong executable directory',lambda r,m:r['resolved_environment'].update(PATH='/wrong:'+r['resolved_environment']['PATH']),'wrong executable environment path'),
 ('unsafe source names both',lambda r,m:[r[key].update(files={'../escape':'0'*64}) for key in ('source_before','source_after')],'invalid source file digest'),
 ('colliding npm configs',lambda r,m:r['resolved_environment'].update(npm_config_globalconfig=r['resolved_environment']['npm_config_userconfig']),'colliding environment paths'),
 ('global HOME',lambda r,m:r['resolved_environment'].update(HOME='/Users/roger'),'environment path policy'),
 ('global npm user config',lambda r,m:r['resolved_environment'].update(npm_config_userconfig='/Users/roger/.npmrc'),'environment path policy'),
 ('extra PATH directory',lambda r,m:r['resolved_environment'].update(PATH=r['resolved_environment']['PATH']+':/Users/roger/.local/bin'),'environment path policy'),
]
print(json.dumps({'verifier_sha256':sha((ROOT/'verify_bundle.py').read_bytes()),'producer_sha256':sha(Path(__file__).read_bytes()),'optimized':sys.flags.optimize,'archive_sha256':sha(archive.read_bytes()),'manifest_sha256':sha(mp.read_bytes()),'python':sys.version,'source_receipt':name}))
print(json.dumps({'control':'unaltered historical packet','result':v.verify(archive,mp)}))
for title,change,expected in cases:
 record=copy.deepcopy(original);m=copy.deepcopy(manifest);change(record,m);data=(json.dumps(record)+'\n').encode();m['members'][name]=sha(data)
 with tempfile.TemporaryDirectory(dir=ROOT) as scratch:
  folder=Path(scratch);p=folder/'mutant.zip'
  with zipfile.ZipFile(p,'x',compression=zipfile.ZIP_STORED) as z:
   for n,b in members.items():z.writestr(n,data if n==name else b)
  m['archive_sha256']=sha(p.read_bytes());q=folder/'manifest.json';q.write_text(json.dumps(m))
  try:v.verify(p,q);refused=False;diagnostic='accepted'
  except ValueError as e:refused=True;diagnostic=str(e)
  if not refused:failures.append(title)
  print(json.dumps({'control':title,'refused':refused,'diagnostic':diagnostic,'expected':expected,'receipt_sha256':sha(data),'archive_sha256':m['archive_sha256']}))
print(json.dumps({'controls':1+len(cases),'accepted_invalid':failures,'failures':len(failures),'skips':0}))
raise SystemExit(bool(failures))
