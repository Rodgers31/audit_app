'use strict';
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const path = require('node:path');
const root = process.argv[2];
const app = createRequire(path.join(root, 'package.json'));
const tailwind = createRequire(app.resolve('tailwindcss/package.json'));
const next = createRequire(app.resolve('@next/eslint-plugin-next/package.json'));
let count = 0;
for (const [name, caller] of [['tailwind', tailwind], ['next-lint', next]]) {
 const fast = createRequire(caller.resolve('fast-glob/package.json'));
 const micro = createRequire(fast.resolve('micromatch/package.json'));
 const braces = micro('braces');
 const deep = '{'.repeat(5000)+'a,b'+'}'.repeat(5000);
 assert.throws(()=>caller('fast-glob').sync(deep), e=>e.code==='ERR_BRACES_DEPTH', name+' actual fast-glob must enforce depth limit');
 for (const method of ['parse','compile','expand','stringify']) {
  assert.throws(()=>braces[method](deep),e=>e.code==='ERR_BRACES_DEPTH', name+' '+method+' must enforce depth limit'); count++;
 }
 assert.deepEqual(braces.expand('x/{a,b}/{1..3}'),['x/a/1','x/a/2','x/a/3','x/b/1','x/b/2','x/b/3']); count++;
}
const nyc = createRequire(app.resolve('@istanbuljs/load-nyc-config/package.json'));
const yaml = createRequire(nyc.resolve('js-yaml/package.json'));
const argparse = createRequire(yaml.resolve('argparse/package.json'));
const { sprintf, vsprintf } = argparse('sprintf-js');
for (const fn of [f=>sprintf(f,1),f=>vsprintf(f,[1]),f=>sprintf.format(sprintf.parse(f),[f,1])]) {
 for (const f of ['%.101f','%.101e','%.101g','%.999999999999999999999999f']) {
  assert.throws(()=>fn(f),e=>e.code==='ERR_SPRINTF_PRECISION','precision must reject at declared caller');count++;
 }
}
assert.equal(sprintf('%.2f %s',1.25,'done'),'1.25 done');count++;
console.log(JSON.stringify({check:'real-caller-tooling-repairs',passed:count,failed:0,callers:['tailwind/fast-glob','next-lint/fast-glob','nyc/js-yaml/argparse/sprintf']}));
