"""PR860 only: fresh complete census before normal merge and authorized override."""
import datetime, hashlib, json, pathlib, subprocess
ROOT=pathlib.Path(__file__).parent

def material(d):
    return {k: d[k] for k in ('reviews','inline','comments')}

def validate(d,head,accepted):
    if (d['number']!=860 or d['headRefOid']!=head or d['baseRefName']!='main'
            or d['state']!='OPEN' or d['isDraft'] or d['closingIssuesReferences']):
        raise RuntimeError('PR identity/state/closing references changed')
    if d['reviewRequests'] or d['requests']['users'] or d['requests']['teams']:
        raise RuntimeError('Pending review request')
    q=d['graphql'];threads=q['reviewThreads']
    if (len(d['reviews'])!=q['reviews']['totalCount'] or len(d['comments'])!=q['comments']['totalCount']
            or threads['pageInfo']['hasNextPage'] or len(threads['nodes'])!=threads['totalCount']):
        raise RuntimeError('Incomplete review census')
    if sum(t['comments']['totalCount'] for t in threads['nodes'])!=len(d['inline']):
        raise RuntimeError('Incomplete inline census')
    for t in threads['nodes']:
        if (not t['isResolved'] or t['comments']['pageInfo']['hasNextPage']
                or len(t['comments']['nodes'])!=t['comments']['totalCount']):
            raise RuntimeError('Unresolved/incomplete thread')
    if d['reviewDecision']=='CHANGES_REQUESTED':raise RuntimeError('Aggregate changes requested')
    latest={}
    for review in d['reviews']:
        if review['state']=='PENDING':raise RuntimeError('Pending review')
        latest[review['user']['login']]=review['state']
    if any(s=='CHANGES_REQUESTED' for s in latest.values()):raise RuntimeError('Reviewer requests changes')
    if material(d)!=accepted:raise RuntimeError('New or changed unclassified review material')
    if any(c.get('conclusion') not in (None,'SUCCESS','NEUTRAL','SKIPPED') for c in d['statusCheckRollup']):
        raise RuntimeError('A reported check failed')

def coordinate(head,accepted,census,run):
    validate(census(),head,accepted)
    normal=run(['gh','pr','merge','860','--merge','--match-head-commit',head])
    if normal.returncode==0:return 'normal'
    text=(normal.stdout+normal.stderr).lower()
    if 'base branch policy prohibits' not in text and 'protected branch' not in text:
        raise RuntimeError('Unexpected normal merge rejection')
    validate(census(),head,accepted)
    override=run(['gh','pr','merge','860','--merge','--match-head-commit',head,'--admin'])
    if override.returncode:raise RuntimeError('Authorized override failed')
    return 'authorized_override'

def main():
    head=(ROOT/'release-head.txt').read_text().strip()
    accepted=json.loads((ROOT/'accepted-review-material.json').read_text())
    def census():
        r=subprocess.run(['python3',str(ROOT/'read-review-census.py'),'860'],capture_output=True,text=True,check=True)
        path=pathlib.Path(r.stdout.rsplit('SAVED ',1)[1].strip())
        return json.loads(path.read_text())[0]
    def run(args):
        r=subprocess.run(args,capture_output=True,text=True)
        name='override-merge' if '--admin'in args else 'normal-merge'
        (ROOT/(name+'.json')).write_text(json.dumps({'argv':args,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
        return r
    print(coordinate(head,accepted,census,run))
if __name__=='__main__':main()
