# PR860 OCR review reproduction — findings confirmed

Reviewed exact commit **16538db009704ece4e0aaa51ac162752d591180c**, frozen at `source-16538db`: 1,464 backend files; canonical mapping SHA256 **d2f6b9205334129b1e332ef08c29cfe3caf22110e823a0897d8a113b40072c12**. Every frozen file rehashed after execution; zero differences. No product edits.

**16 distinct cases ran normally and with actual `python -O`: 8 desired failures + 8 passing controls in each mode, zero errors/skips (0.87s / 1.60s).** These are intentional desired regressions, not setup errors, xfails or a passing acceptance result. Source 16538db is not accepted for these findings.

## Decisions and classification

The saved review census was read before reproduction. No recorded decision was found settling these three behaviors as intentional. The committed operational document promises bounded OCR of a single titled image annex with all financial gates retained; the parse-cache implementation explicitly avoids banking empty failure so that the next invocation retries. That is consistent with retaining current refusal on failure and enabling a later bounded recovery. Reviewed context is pinned in `decision-context.md` and `decision-search.json`.

### 1. Inline 4430767899 — valid, P2 availability defect

`test_partial_image_text_must_try_bounded_ocr_and_reach_full_gates[one_complete_row]` and `[one_short_row]` provide the recognized Annex 2a title, a sufficiently large image, and either one complete recognized financial row or one short row. The actual `parse_annex_lines` raises `rows_not_found`. `extract_page_texts` performs **zero OCR calls**; the edition remains refused although the owned OCR port has a complete valid table available. Both cases fail the desired OCR-call check in both modes.

Suggested fix **valid with constraints**: include incomplete-image parse outcomes in the bounded OCR recovery path. Preserve the single-candidate/image/pixel/time checks and all edition/narrative/sign/reconciliation gates. This does not authorize OCR for arbitrary text pages or require treating an unresolved parse as valid.

### 2. Body-only original-heading claim — valid, P2 title loss / P3 qualifier loss

`test_original_annex_title_must_survive_row_only_ocr`: the original text has the recognized Annex 2a title. OCR returns all valid rows without repeating that title. The OCR helper parses the rows successfully, but replacement of the entire page text removes the known title. The actual edition reader refuses with `annex_table_2a_not_found`.

`test_original_actual_column_heading_must_survive_ocr_rows`: the original text also contains the recognized Actual/Preliminary/Supplementary column heading, while OCR returns complete rows and the table title without that heading. The historical FY2023/24 split passes the actual financial gates but its `column_label` becomes **None**, losing the original `Actual` qualification.

Suggested fix **qualified**: preserve the recognized original title/column context and separately retain acquisition provenance. Blindly concatenating all partial original numeric rows with OCR rows is not established as safe; the table parser uses first matching row wins and could prefer an obsolete or corrupt partial cell. Do not discard ambiguity checks or invent missing headings.

### 3. Body-only unavailable-OCR cache claim — valid, P2 retry/recovery defect

`test_unavailable_ocr_cache_must_retry_after_same_engine_recovers[timeout|empty|incomplete]` first makes the actual extraction wrapper record `ocr_status=unavailable`. Although no Edition is usable, the nonempty page-record list is cached. A second call with the **same source bytes, package/engine/language identity and parser bytes** still returns zero editions, with OCR call count stuck at **1**. In the same test, cache-disabled parsing with the recovered current engine succeeds and actually executes `split_for_fiscal_year` plus `_apply_fiscal_framework`, applying expenditure **4785.2B**. This is cache persistence of a transient refusal, not an assertion that a source must be published while OCR is unavailable.

`test_same_unavailable_ocr_is_retried_each_invocation` separately shows that a second bounded attempt is suppressed even when failure persists. The cached refusal persists until entry eviction, key-changing source/parser/dependency change or cache bypass; it is not literally impossible to recover forever.

Suggested fix **valid with constraints**: avoid banking unusable OCR results, or detect them on a hit and perform a fresh bounded attempt. Keep valid matching successful parse-cache hits reusable. A global parse-cache disable or bypass of source/financial gates is unnecessary.

## Eight passing controls

- Valid successful OCR cache hit retains the full financially applied value and avoids a second OCR call.
- PDF byte change and engine-version change each invalidate an unavailable entry and permit recovery (two cases).
- Complete text-layer table with an image reaches full gates without unnecessary OCR.
- Incomplete text without an image remains an explicit refusal with zero OCR calls.
- Two image annexes remain ambiguous and are not OCR-selected.
- OCR-readable broken arithmetic still fails the real financial gate.
- Cache-disabled same-engine timeout then recovery executes the full gate/application correctly.

## Exact evidence and limits

Stable independent fixture: `test_review_ocr.py`. Exact capped offline Docker argv / real exit code 1: `{normal,optimized}/{command,exit}.json`. Actual output, JUnit and JSON acquisition/cache/full-gate observations: `{normal,optimized}/{run.txt,review.xml,observations/}`. Per-case ledger: `case-ledger.json`; input/after hashes: `input-pins.json`, `source-manifest.json`, `source-after.json`.

All project execution used cached `admin-redesign-python-runtime:local`, **network none / 1 CPU / 1 GiB / 256 PIDs**, source/test read-only and owned evidence/tmpfs writable. The actual extractor, numpy/image processing wrapper, parse cache, edition reader, financial checks and payload application ran. PDF pages, raster image, OCR outputs and version probes are owned fakes; this phase does not claim a fresh genuine-Tesseract/PDF acceptance run. The prior supplied genuine PDFs were not modified.

One host-stdlib snapshot attempt failed because host tarfile lacks its newer `filter` API; it was corrected before project execution and is retained separately in `setup-attempts.json`. No test setup errors occurred. No provider, network, production, PG, project env/credential, publish, upload, worker, dispatch or control action occurred; no resources remain (`runtime-cleanup.json`). Other PR860 source-fallback, revenue/GDP completeness and competing-edition claims are outside this assigned OCR scope. Repairs and frozen-byte acceptance recheck are pending.
