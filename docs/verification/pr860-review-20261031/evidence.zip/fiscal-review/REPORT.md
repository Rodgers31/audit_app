# PR860 independent fiscal review — original head

**Two fiscal findings reproduced on frozen `16538db009704ece4e0aaa51ac162752d591180c`. This is a RED report, not acceptance.** Scope: inline 4430767873 and the body-only competing-editions claim. Other review comments are outside this receipt.

## Result and exact input

Own Git-archive projection of backend/tools/workflows: 1,555 files, mapping SHA256 `e8e4bf3e11bc58fff4bef464f30c12abb5ee90db723f697e1d00420294629af1`. All hashes verified after execution.

11 distinct cases ran normally and the same 11 ran with Python `-O`: **four desired regression failures and seven passing controls in each mode**, zero executed-case errors/skips. One initial evidence-only collection typo is retained and uncredited; the corrected runs execute every stated case.

## Inline 4430767873 — Valid: incomplete per-year revenue coverage is live

The actual revenue builder gates a source-shaped Table 2 carrying only FY2026/27 and returns that one year without a refusal. The initial payload also carries FY2025/26, tested at both 2,754.7B and 2,784.4B prior ordinary-revenue vintages. Actual `_apply_revenue_estimates`, `_apply_fiscal_framework` (real stored Treasury text fixture, narrative/column/arithmetic gates), and `fetch_fiscal_summary_payload` then run. The old FY2025/26 revenue remains while `refresh_components.revenue.state` and whole-domain `freshness.mode` are both `live`.

The framework can still match and validate the old row's chosen revenue column in the current annex. That proves the old value appears in the document; it does **not** prove the current Table 2 source refreshed that year or chose the latest revenue vintage. The missing-year information is absent from the component verdict. Two desired REDs reproduce this with both original and revised old-row values. Complete-series controls remain live and pass.

The acquisition collaborators return owned, coherent typed parser outputs; no provider/network call or production data is asserted. Actual apply, financial gates and final verdict functions are not patched.

## Body-only competing editions — Valid for same edition FY, not blanket cross-vintage equality

Two FY2026/27 source texts each pass actual `read_edition` narrative identification and `split_for_fiscal_year` arithmetic. Their ordinary revenue and total expenditure are equal. One allocates recurrent/development **3,538.7/749.0B**; the other **3,548.7/739.0B**. All sums remain valid. `_apply_fiscal_framework` promotes whichever listed source comes first. Reversing the list changes the published allocation by 10B. Two desired REDs prove there is no same-lane conflict refusal/reconciliation before promotion.

Suggested fix scope: reconcile/refuse competing **same-edition-year, same financial claim** candidates before mutating the row. Source identity/order must not silently choose among contradictory approved allocations. Identical same-year figures are a passing control and need not be treated as a monetary conflict.

A broader suggestion to compare all editions for a row's fiscal year would contradict the existing documented policy. The fiscal-framework module explicitly joins historical columns on ordinary revenue from the **same document/vintage**, and the fetcher tries editions newest first. Executed controls preserve that behavior: FY2023/24 is **3,605.2B actual expenditure** when its revenue cites the newer FY2026/27 edition, and **3,599.3B approved expenditure** when it cites its own older edition. Both are individually gated, distinct claims; their disagreement is legitimate. Wrong historical source URLs cannot borrow the newer column. A single unbalanced source still refuses its money.

## Boundaries and retained artifacts

All executions used cached `admin-redesign-python-runtime:local`, capped `--network none --cpus 1 --memory 1g --pids-limit 256`, source read-only and `--rm`. Four social generation/financial/report/policy flags are explicitly false. No DB/PG/shared container, provider, credential, worker, hosted run, installation, production or GitHub mutation occurred. No product/repo edits. No persistent fixture needs cleanup.

The exact test file, normal/optimized commands/logs/XML and per-input JSON are adjacent. Review census is parent-owned and read as untrusted review hypotheses; classification here is based on execution. A repaired-byte recheck should retain these desired failures and the cross-vintage/equal-duplicate controls.
