"""Focused fresh-year/refusal boundaries of the PR860 fiscal repair."""
from copy import deepcopy
import pytest
from seeding.domains.fiscal_summary import fetcher
from test_fiscal_comments import NEW,ALTERNATE,edition,revenue


def test_refused_revenue_basis_cannot_claim_fresh_year():
    original={'fiscal_year':'FY 2025/26','total_revenue':2754.7,
              'revenue_basis':'including_aia','revenue_source':{'url':NEW}}
    payload={'fiscal_years':[deepcopy(original),{'fiscal_year':'FY 2026/27'}]}
    fresh=set()
    result,status=fetcher._apply_revenue_estimates(payload,revenue(False),refreshed_years=fresh)
    assert fresh=={'FY 2026/27'}
    assert result['fiscal_years'][0]==original
    assert 'refused=' in status


@pytest.mark.parametrize('missing_total',[True,False],ids=['fresh-annex-fill','prior-source-tag-only'])
def test_only_actual_new_annex_revenue_assignment_marks_fresh(missing_total):
    row={'fiscal_year':'FY 2026/27','revenue_source':{'url':NEW},
         '_revenue_source':'treasury_budget_summary_annex_live',
         'total_revenue':None if missing_total else 2985.7}
    fresh=set()
    result,status=fetcher._apply_fiscal_framework({'fiscal_years':[row]},[(NEW,edition())],refreshed_revenue_years=fresh)
    assert status.startswith('applied=')
    assert result['fiscal_years'][0]['total_revenue']==2985.7
    assert fresh==({'FY 2026/27'} if missing_total else set())


def test_conflicting_edition_cannot_supply_a_historical_row_either():
    payload={'fiscal_years':[
        {'fiscal_year':'FY 2025/26','total_revenue':2754.7,'revenue_source':{'url':NEW}},
        {'fiscal_year':'FY 2026/27','total_revenue':2985.7,'revenue_source':{'url':NEW}}]}
    fresh=set()
    result,status=fetcher._apply_fiscal_framework(payload,[(NEW,edition()),(ALTERNATE,edition(altered=True))],refreshed_revenue_years=fresh)
    assert fresh==set() and 'conflicting_approved_editions' in status
    assert all('recurrent_spending' not in row and 'fiscal_framework' not in row for row in result['fiscal_years'])
