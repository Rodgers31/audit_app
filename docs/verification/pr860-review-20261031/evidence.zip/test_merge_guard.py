import copy,json,pathlib,unittest
from types import SimpleNamespace
from merge_guard import coordinate,material
ROOT=pathlib.Path(__file__).parent
class GuardTests(unittest.TestCase):
 def setUp(self):
  self.base=json.loads((ROOT/'review-census-20261031T063009Z.json').read_text())
  if isinstance(self.base,list):self.base=self.base[0]
  for t in self.base['graphql']['reviewThreads']['nodes']:t['isResolved']=True
  self.accepted=material(self.base);self.calls=[];self.reads=0
 def run_case(self,change=None,late=False,normal_ok=False):
  def census():
   self.reads+=1;d=copy.deepcopy(self.base)
   if change and (not late or self.reads==2):change(d)
   return d
  def run(args):
   self.calls.append(args)
   return SimpleNamespace(returncode=0 if normal_ok or '--admin'in args else 1,stdout='',stderr='base branch policy prohibits the merge')
  return coordinate(self.base['headRefOid'],self.accepted,census,run)
 def test_normal(self):self.assertEqual(self.run_case(normal_ok=True),'normal');self.assertEqual(len(self.calls),1)
 def test_override(self):self.assertEqual(self.run_case(),'authorized_override');self.assertEqual(self.reads,2);self.assertEqual(len(self.calls),2)
 def test_late_blocks(self):
  changes=[lambda d:d['graphql']['reviewThreads']['nodes'][0].update(isResolved=False),lambda d:d['requests']['users'].append({'login':'Copilot'}),lambda d:d['reviews'][0].update(state='CHANGES_REQUESTED'),lambda d:d['reviews'][0].update(body='new finding'),lambda d:d['graphql']['reviewThreads']['pageInfo'].update(hasNextPage=True),lambda d:d.update(headRefOid='changed'),lambda d:d.update(reviewDecision='CHANGES_REQUESTED')]
  for change in changes:
   with self.subTest(change=change):
    self.calls=[];self.reads=0
    with self.assertRaises(RuntimeError):self.run_case(change,late=True)
    self.assertEqual(len(self.calls),1)
 def test_initial_blocks(self):
  with self.assertRaises(RuntimeError):self.run_case(lambda d:d['requests']['teams'].append({'slug':'review'}))
  self.assertEqual(self.calls,[])
if __name__=='__main__':unittest.main()
