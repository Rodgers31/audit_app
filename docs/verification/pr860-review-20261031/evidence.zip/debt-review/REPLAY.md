From this evidence directory, using the retained cached image and frozen projection:

```sh
python3 run-final-review.py --candidate candidate-3 --label replay
python3 run-final-review.py --candidate candidate-3 --label replay --optimized
python3 run-discriminator.py --candidate candidate-3 --label replay-discriminator
python3 run-discriminator.py --candidate candidate-3 --label replay-discriminator --optimized
```

These run92+1 cases per mode and use fresh artifact labels, preserving the sealed final receipts. The optimized commands execute `python -O -m pytest`, not a post-launch environment toggle. Docker source mounts are read-only; all network is disabled; caps are1CPU/1GiB/256PIDs. Image ID is pinned in `FINAL-RECEIPT.json`.

To reproduce retained REDs without changing product files:

```sh
python3 run-review.py --candidate candidate-1 --label replay-baseline
python3 run-review.py --candidate candidate-1 --label replay-baseline --optimized
python3 run-boundary.py --candidate candidate-2 --label replay-boundary
python3 run-discriminator.py --candidate candidate-2 --label replay-discriminator-red
```

Expected baseline result is7fail/6pass; boundary is1fail/6pass; within-tolerance discriminator is1fail. These are deliberate negative receipts, not acceptance.

Offline packet verification, without importing project code:

```sh
python3 - <<'PY'
import hashlib,json,pathlib
p=pathlib.Path('.')
for name,expected in json.loads((p/'ARTIFACT-HASHES.json').read_text()).items():
    assert hashlib.sha256((p/name).read_bytes()).hexdigest()==expected,name
print('all artifact hashes match')
PY
```
