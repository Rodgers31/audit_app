import argparse,json,pathlib,subprocess
p=argparse.ArgumentParser();p.add_argument('--optimized',action='store_true');p.add_argument('--candidate',default='candidate-1');p.add_argument('--label',default='baseline');a=p.parse_args();e=pathlib.Path(__file__).resolve().parent
label=a.label+('-optimized' if a.optimized else '-normal')
cmd=['docker','run','--pull','never','--rm','--name','pr860-debt-'+label,'--network','none','--cpus','1','--memory','1g','--pids-limit','256']
for item in ['PYTHONDONTWRITEBYTECODE=1','PYTHONPATH=/work/backend:/work/backend/tests:/evidence','DATABASE_URL=sqlite:////tmp/standards-inert.sqlite','AUTO_SEEDER_ENABLED=false','SOCIAL_GENERATION_HOOK_ENABLED=false','SOCIAL_NATIVE_FINANCIAL_GENERATION_ENABLED=false','SOCIAL_MEDIA_ENABLED=false','SOCIAL_WORKER_SUPERVISOR_ENABLED=false']:cmd+=['-e',item]
cmd+=['-v',str(e/a.candidate)+':/work:ro','-v',str(e)+':/evidence','-w','/work/backend','admin-redesign-python-runtime:local','python']
if a.optimized:cmd+=['-O']
cmd+=['-m','pytest','-q','-p','no:cacheprovider','/evidence/test_observation_boundary.py','--junitxml=/evidence/'+label+'.xml']
(e/(label+'-command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
with (e/(label+'.txt')).open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(e/(label+'-exit.json')).write_text(json.dumps({'exit_code':r.returncode})+'\n');raise SystemExit(r.returncode)
