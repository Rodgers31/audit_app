"""Distinguish acquisition binding from the separate 0.5% sum guard."""
from decimal import Decimal
from sqlalchemy import select
from test_fallback_independent import db,freshness,run_source,snapshots
from test_observation_boundary import capture
from models import DebtTimeline
from seeding.domains.debt_timeline import writer

def test_mixed_acquisitions_refuse_even_within_parser_stock_tolerance(db,tmp_path,monkeypatch):
    _,rows,_,_=run_source(db,tmp_path/'first',monkeypatch);before=snapshots(rows)
    older=capture(tmp_path/'older',monkeypatch,domestic=780000,external=520000,total=1300000)
    newer=capture(tmp_path/'newer',monkeypatch,domestic=878000,external=522000,total=1400000)
    external=next(e for e in older.source_evidence if e['identity']['measure']=='external')
    newer.source_evidence=[external if e['identity']['measure']=='external' else e for e in newer.source_evidence];newer.external=older.external
    assert abs(Decimal(str(newer.external))+Decimal(str(newer.domestic))-Decimal(str(newer.total)))<=Decimal(str(newer.total))*Decimal('.005')
    writer.write_debt_timeline_records(db,[newer],{});db.commit()
    rows=list(db.scalars(select(DebtTimeline).order_by(DebtTimeline.year)))
    assert snapshots(rows)==before
