"""Diagnostic trace, not additional pass credit; all source facts are controlled."""
import json,pathlib,tempfile
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from models import Country,SourceDocument,Extraction,DebtTimeline
from test_fallback_independent import run_source,api
with tempfile.TemporaryDirectory(prefix='pr860-seam-') as t,pytest.MonkeyPatch.context() as patch:
    tmp=pathlib.Path(t);engine=create_engine('sqlite:///'+str(tmp/'owned.sqlite'))
    for model in (Country,SourceDocument,Extraction,DebtTimeline):model.__table__.create(engine)
    with Session(engine) as db:
        db.add(Country(iso_code='KEN',name='Kenya',currency='KES',timezone='Africa/Nairobi',default_locale='en'));db.commit()
        trace=[]
        for phase,kwargs in [('observed',{}),('gdp_only',{'cbk':False,'values':{2024:15_000_000_000_000,2025:15_000_000_000_000}})]:
            result,rows,q,state=run_source(db,tmp/phase,patch,**kwargs)
            public=api(db)['timeline'][-1]
            trace.append({'phase':phase,'mode':state,'result':{'created':result.items_created,'updated':result.items_updated,'errors':result.errors,'metadata':result.metadata},'saved':{'year':rows[-1].year,'stock':str(rows[-1].total),'gdp':str(rows[-1].gdp),'ratio':str(rows[-1].gdp_ratio),'source_document_id':rows[-1].source_document_id,'stock_qualification':q[rows[-1].id]['total']['status'],'evidence_measures':[e['identity']['measure'] for e in rows[-1].meta['source_evidence']]},'api':{'total':public['total'],'gdp':public['gdp'],'ratio':public['gdp_ratio'],'stock_status':public['qualifications']['total']['status'],'ratio_status':public['qualifications']['gdp_ratio']['status']}})
        print(json.dumps(trace,indent=2))
    engine.dispose()
