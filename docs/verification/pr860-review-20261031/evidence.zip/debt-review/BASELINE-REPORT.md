# PR860 debt fallback baseline review

Scope: frozen accepted PR head `16538db009704ece4e0aaa51ac162752d591180c`; backend mapping `d2f6b9205334129b1e332ef08c29cfe3caf22110e823a0897d8a113b40072c12`,1,464files. Normal/O each executed13independent cases: **6passed,7failed,0errors/skips**. This is a reproduced-defect receipt, not repaired/deployment acceptance.

Confirmed:

- **P2, inline4430767846:** fallback source selection with absent record URL reuses same-title KEN REPORT despite wrong URL or publisher. Two independent negatives reproduce it; exact default identity reuse and foreign-country/BUDGET isolation pass.
- **P2, body preservation:** after a controlled actual producer/receipt pipeline writes verified1.2T/1.3T debt stocks and GDP10T, CBK503 falls back to fixture1T, replaces document IDs and removes stock receipts. A simultaneous valid GDP15T produces6.7from fixture1T instead of8.7from retained1.3T. API returns those saved values; qualification downgrades toqualified rather than falsely verifying them. Both sources failing also replaces prior GDP10T with fixture5T and drops proof. Missing one GDP year similarly erases that year's old valid observation. Four distinct negatives cover these preservation/derived-value cases.
- **P2, body status:** actual fresh GDP with no CBK reports fixture-only despite GDP component live. One negative reproduces it; this should remain partial, while wholly unavailable source input must not claim live.

`baseline-seam.json` records actual saved/query/API values and component receipts before/after the fallback, without adding pass credit. `BASELINE-RECEIPT.json` pins both JUnits and test source hash. Candidate source stayed unchanged.

The full dual-source positive path passes through actual transport/retention, CBK table parser, sealed cell evidence, fetcher, record parser, writer, qualification and unwrapped public API consumer. Only PDF page-text extraction is controlled. PDF body and financial figures are explicit synthetic local fixtures; no official financial fact or fabricated runtime capability is asserted. Seals are issued by the real source/receipt code, not constructed by tests.

Extra WB year2026 does not create an unsupported debt-stock year; that passing boundary is deliberate, not a new-year defect. Fixture-only bootstrap never obtains verified stock authority. These tests do not require source evidence to be invented for unsupported historical years.

All execution is owned cached Docker, networknone,1CPU/1GiB/256PIDs, SQLite with JSONB adaptation. Four generation/media/worker flags plus AUTO_SEEDER are false. No product edits, PG, production credentials, network/provider calls, uploads or workers. Shared PG/node are untouched. Await frozen repaired delta for final disposition.
