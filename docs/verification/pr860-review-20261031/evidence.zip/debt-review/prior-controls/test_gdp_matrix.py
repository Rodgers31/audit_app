"""Offline real producer/client, owned SQLite writer and hostile completeness."""
import asyncio,copy,inspect,json
from decimal import Decimal
from pathlib import Path
import httpx,pytest
from sqlalchemy import create_engine,select
from sqlalchemy.orm import Session
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.compiler import compiles
from models import Country,SourceDocument,Extraction,DebtTimeline
from seeding.config import SeedingSettings
from seeding.domains import debt_timeline as domain
from seeding.domains.debt_timeline import fetcher
from seeding.freshness import get,reset
from seeding.http_client import SeedingHttpClient
from seeding.types import DomainRunContext
from services.receipt_store import LocalReceiptStore
from services.figure_qualification import qualify_rows

@compiles(JSONB,'sqlite')
def jsonb_sqlite(element,compiler,**kw):return 'JSON'

def stock(year):
    return {'year':year,'external':400,'domestic':600,'total':1000,
        'gdp':5000,'gdp_ratio':20,'source':'Last-valid fixture stock'}

def row(year,value):
    return dict(indicator={'id':'NY.GDP.MKTP.CN'},country={'id':'KE'},
        countryiso3code='KEN',date=str(year),value=value,unit='')

def setup(tmp_path,monkeypatch,*,years=(2024,2025),values=None,cbk_years=None,
          enabled=True,metadata=None,http_error=False,wb_mutation=None):
    base={'metadata':{'source':'Owned fixture','refresh_components':{'gdp':{'state':'live','stale_claim':True}}},
          'timeline':[stock(y) for y in years]}
    path=tmp_path/'base.json';path.write_text(json.dumps(base))
    values={y:20_000_000_000_000 for y in years} if values is None else values
    rows=[row(y,v) for y,v in values.items()]
    if wb_mutation:wb_mutation(rows)
    body=[metadata if metadata is not None else {'page':1,'pages':1,'total':len(rows)},rows]
    calls=[]
    def publisher(request):
        assert request.url.host=='api.worldbank.org'
        assert request.url.path.endswith('/NY.GDP.MKTP.CN')
        calls.append(str(request.url))
        return httpx.Response(503 if http_error else 200,json=body)
    settings=SeedingSettings(_env_file=None,debt_timeline_dataset_url=path.as_uri(),
        storage_path=tmp_path,cache_path=tmp_path/'cache',http_cache_enabled=False,
        enrich_with_worldbank=enabled,max_retries=1,retry_backoff=.001,rate_limit='1000/sec')
    client=SeedingHttpClient(settings,client=httpx.Client(transport=httpx.MockTransport(publisher)),
        receipt_store=LocalReceiptStore(tmp_path/'receipts'))
    cbk_years=years if cbk_years is None else cbk_years
    debt={y:{'external':Decimal('400000000000'),'domestic':Decimal('600000000000'),
             'total':Decimal('1000000000000')} for y in cbk_years}
    monkeypatch.setattr('seeding.domains.national_debt.cbk_bulletin.fetch_public_debt_timeline_from_cbk_bulletin',lambda *a:debt)
    return settings,client,calls

@pytest.fixture(autouse=True)
def clean_freshness():
    reset('debt_timeline')
    yield
    reset('debt_timeline')

@pytest.mark.parametrize('case,expected',[
    ('complete','live'),('http_error','partial'),('disabled','partial'),
    ('missing_one','partial'),('all_null','partial'),('disjoint','partial'),
    ('paged','partial'),('no_cbk','partial'),
])
def test_real_producer_reports_each_component_honestly(tmp_path,monkeypatch,case,expected):
    kw={}
    if case=='http_error':kw['http_error']=True
    if case=='disabled':kw['enabled']=False
    if case=='missing_one':kw['values']={2025:20_000_000_000_000}
    if case=='all_null':kw['values']={2024:None,2025:None}
    if case=='disjoint':kw['values']={2023:20_000_000_000_000}
    if case=='paged':kw['metadata']={'page':1,'pages':2,'total':2}
    if case=='no_cbk':kw['cbk_years']=()
    settings,client,calls=setup(tmp_path,monkeypatch,**kw)
    with client:payload=fetcher.fetch_debt_timeline_payload(client,settings)
    assert get('debt_timeline')['mode']==expected
    gdp=payload['metadata']['refresh_components']['gdp']
    if expected=='live':assert gdp=={'state':'live','observed_years':2,'missing_years':[]}
    if case=='disabled':assert gdp['state']=='disabled' and calls==[]
    if case=='missing_one':
        assert gdp['missing_years']==[2024] and gdp['observed_years']==1
        assert payload['timeline'][0]['gdp']==5000
    if case in ('http_error','paged'):assert gdp['state']=='unavailable'

@pytest.mark.parametrize('field',['page','pages','total'])
def test_boolean_completeness_cannot_certify_full_gdp_refresh(tmp_path,monkeypatch,field):
    meta={'page':1,'pages':1,'total':1};meta[field]=True
    settings,client,_=setup(tmp_path,monkeypatch,years=(2025,),metadata=meta)
    with client:payload=fetcher.fetch_debt_timeline_payload(client,settings)
    assert get('debt_timeline')['mode']!='live'
    assert payload['metadata']['refresh_components']['gdp']['state']!='live'

def test_partial_debt_cannot_become_full_refresh_by_complete_gdp(tmp_path,monkeypatch):
    settings,client,_=setup(tmp_path,monkeypatch,cbk_years=(2025,))
    with client:payload=fetcher.fetch_debt_timeline_payload(client,settings)
    assert payload['timeline'][0]['source']=='Last-valid fixture stock'
    assert payload['metadata']['refresh_components']['gdp']['state']=='live'
    assert get('debt_timeline')['mode']!='live'

def test_zero_gdp_does_not_keep_the_prior_nonzero_ratio(tmp_path,monkeypatch):
    settings,client,_=setup(tmp_path,monkeypatch,years=(2025,),values={2025:0})
    with client:payload=fetcher.fetch_debt_timeline_payload(client,settings)
    assert payload['timeline'][0]['gdp']==5000
    assert payload['timeline'][0]['gdp_ratio'] is None

@pytest.mark.parametrize('bad',['country','indicator','duplicate','boolean_value','negative_value'])
def test_malformed_or_wrong_source_retains_old_gdp_and_partial_mode(tmp_path,monkeypatch,bad):
    def mutate(rows):
        if bad=='country':rows[0]['countryiso3code']='UGA'
        elif bad=='indicator':rows[0]['indicator']['id']='NY.GDP.MKTP.KD'
        elif bad=='duplicate':rows.append(copy.deepcopy(rows[0]))
        elif bad=='boolean_value':rows[0]['value']=True
        else:rows[0]['value']=-1
    settings,client,_=setup(tmp_path,monkeypatch,wb_mutation=mutate)
    with client:payload=fetcher.fetch_debt_timeline_payload(client,settings)
    assert get('debt_timeline')['mode']=='partial'
    assert payload['metadata']['refresh_components']['gdp']['state']=='unavailable'
    assert payload['timeline'][0]['gdp']==5000

@pytest.fixture
def db(tmp_path):
    engine=create_engine('sqlite:///'+str(tmp_path/'owned.sqlite'))
    for model in (Country,SourceDocument,Extraction,DebtTimeline):model.__table__.create(engine)
    with Session(engine) as session:
        session.add(Country(iso_code='KEN',name='Kenya',currency='KES',timezone='Africa/Nairobi',default_locale='en'))
        session.commit();yield session
    engine.dispose()

@pytest.mark.parametrize('case',['complete','partial','disabled','failed'])
def test_actual_domain_writer_and_result_metadata(db,tmp_path,monkeypatch,case):
    kw={}
    if case=='partial':kw['values']={2025:13_489_642_000_001}
    elif case=='disabled':kw['enabled']=False
    elif case=='failed':kw['http_error']=True
    else:kw['values']={2024:13_489_642_000_001,2025:13_489_642_000_002}
    settings,client,_=setup(tmp_path,monkeypatch,**kw)
    monkeypatch.setattr(domain,'create_http_client',lambda _:client)
    result=domain.run(db,settings,DomainRunContext(None,False));db.commit()
    assert not result.errors and result.items_processed==2 and result.items_created==2
    component=result.metadata['refresh_components']['gdp']
    assert component['state']=={'complete':'live','partial':'partial','disabled':'disabled','failed':'unavailable'}[case]
    assert get('debt_timeline')['mode']==('live' if case=='complete' else 'partial')
    rows=list(db.scalars(select(DebtTimeline).order_by(DebtTimeline.year)))
    assert all(r.total==Decimal('1000000000000') and r.unit=='KES' for r in rows)
    q=qualify_rows(db,'debt_timeline',rows)
    if case in ('complete','partial'):
        assert rows[-1].gdp==Decimal(str(kw['values'][2025]))
        assert q[rows[-1].id]['gdp']['status']=='verified'
        assert q[rows[-1].id]['gdp_ratio']['status']!='verified'
    # Actual consumer function, with its cache wrapper unwrapped and no lifespan/HTTP server.
    import main
    body=asyncio.run(inspect.unwrap(main.get_debt_timeline)(db=db))
    assert body['status']=='success' and body['years']==2
    assert body['timeline'][-1]['qualifications']['gdp_ratio']['status']!='verified'
