"""Independent actual source-byte→sealed cells→writer→qualification/API attacks.
The PDF decoder port returns explicit controlled source-shaped text; no official
PDF extraction claim is made. All other producer, transport and persistence code runs.
"""
import asyncio,copy,inspect,json
from datetime import datetime,timezone
from decimal import Decimal
import httpx,pytest
from sqlalchemy import select
from models import Country,DebtTimeline,DocumentType,Extraction,SourceDocument
from seeding.config import SeedingSettings
from seeding.domains import debt_timeline as domain
from seeding.domains.debt_timeline import fetcher,parser,writer
from seeding.domains.national_debt import cbk_bulletin
from seeding.freshness import get
from seeding.http_client import SeedingHttpClient
from seeding.types import DomainRunContext
from services.figure_qualification import qualify_rows
from services.receipt_store import LocalReceiptStore
from services.response_receipts import receipt_is_sealed
from test_gdp_matrix import db,clean_freshness,setup

URL='https://www.centralbank.go.ke/uploads/statistical_bulletin/standards-2025.pdf'
TITLE='CBK Statistical Bulletin Table 4.1.3'
GENERIC='https://www.centralbank.go.ke/statistics/government-finance-statistics/'
TEXT='4.1.3 Deficit Financing and Public Debt\nShillings million\n2024/2025\nDecember 720000 480000 1200000\n2025/2026\nDecember 780000 520000 1300000'

def observed(tmp_path,monkeypatch,*,gdp=True,text=TEXT):
    base={'metadata':{'source':'Kept historical source'},'timeline':[
        {'year':y,'external':400,'domestic':600,'total':1000,'gdp':5000,'gdp_ratio':20,'source':'Old annual CBK source'} for y in (2024,2025)]}
    path=tmp_path/'base.json';path.write_text(json.dumps(base))
    settings=SeedingSettings(_env_file=None,debt_timeline_dataset_url=path.as_uri(),
        cbk_statistical_bulletin_url=URL,storage_path=tmp_path,http_cache_enabled=False,
        enrich_with_worldbank=gdp,rate_limit='1000/sec',max_retries=1,retry_backoff=.001)
    calls=[]
    def transport(req):
        calls.append(str(req.url))
        if str(req.url)==URL:
            return httpx.Response(200,content=b'%PDF-1.7\ncontrolled parser-port PDF fixture\n%%EOF',headers={'content-type':'application/pdf'})
        assert req.url.host=='api.worldbank.org'
        return httpx.Response(200,json=[{'page':1,'pages':1,'total':2},[
            {'indicator':{'id':'NY.GDP.MKTP.CN'},'country':{'id':'KE'},'countryiso3code':'KEN','date':str(y),'value':10_000_000_000_000,'unit':''} for y in (2024,2025)]])
    monkeypatch.setattr(cbk_bulletin,'_find_public_debt_page_text',lambda _:cbk_bulletin._located_text(text,71))
    client=SeedingHttpClient(settings,client=httpx.Client(transport=httpx.MockTransport(transport)),receipt_store=LocalReceiptStore(tmp_path/'receipts'))
    with client:payload=fetcher.fetch_debt_timeline_payload(client,settings)
    return payload,calls

def write(db,payload):
    records=parser.parse_debt_timeline_payload(payload)
    writer.write_debt_timeline_records(db,records,payload['metadata']);db.commit()
    rows=list(db.scalars(select(DebtTimeline).order_by(DebtTimeline.year)))
    return rows,qualify_rows(db,'debt_timeline',rows)

def doc(db,*,country='KEN',publisher='Central Bank of Kenya / National Treasury',url=URL,kind=DocumentType.REPORT):
    c=db.scalar(select(Country).where(Country.iso_code==country))
    if c is None:
        c=Country(iso_code=country,name=country,currency='KES',timezone='Africa/Nairobi',default_locale='en');db.add(c);db.flush()
    d=SourceDocument(country_id=c.id,title=TITLE,publisher=publisher,url=url,fetch_date=datetime.now(timezone.utc),doc_type=kind)
    db.add(d);db.commit();return d

def test_actual_dual_source_acquisition_saved_precision_and_full_qualification(db,tmp_path,monkeypatch):
    payload,calls=observed(tmp_path,monkeypatch)
    assert get('debt_timeline')['mode']=='live'
    assert payload['metadata']['refresh_components']['debt']=={'state':'live','observed_years':2,'required_years':2}
    assert all(e['source_url']==URL for e in payload['timeline'])
    assert all(receipt_is_sealed(e['_response_receipt']) for r in payload['timeline'] for e in r['source_evidence'])
    rows,q=write(db,payload)
    assert [r.total for r in rows]==[Decimal('1200000000000'),Decimal('1300000000000')]
    assert [r.gdp_ratio for r in rows]==[Decimal('12'),Decimal('13')]
    for r in rows:
        assert all(q[r.id][m]['status']=='verified' for m in ('total','domestic','external','gdp','gdp_ratio'))
    import main
    body=asyncio.run(inspect.unwrap(main.get_debt_timeline)(db=db))
    assert body['timeline'][-1]['total']==1_300_000_000_000
    assert body['timeline'][-1]['qualifications']['total']['source_url']==URL
    assert body['timeline'][-1]['qualifications']['gdp_ratio']['status']=='verified'
    assert calls.count(URL)==1

@pytest.mark.parametrize('case',['generic_old','foreign_country','different_url','budget_lane'])
def test_existing_different_identity_document_is_preserved_not_relabelled(db,tmp_path,monkeypatch,case):
    kwargs={'generic_old':{'url':GENERIC},'foreign_country':{'country':'UGA'},'different_url':{'url':URL+'?edition=old'},'budget_lane':{'kind':DocumentType.BUDGET}}[case]
    old=doc(db,**kwargs);before=(old.country_id,old.url,old.title,old.publisher,old.doc_type)
    payload,_=observed(tmp_path,monkeypatch);rows,q=write(db,payload)
    assert all(r.source_document_id!=old.id for r in rows)
    assert (old.country_id,old.url,old.title,old.publisher,old.doc_type)==before
    assert all(q[r.id]['total']['status']=='verified' for r in rows)

@pytest.mark.parametrize('url',[
    'http://www.centralbank.go.ke/a.pdf','https://centralbank.go.ke.evil.invalid/a.pdf',
    'https://user:pass@www.centralbank.go.ke/a.pdf','https://www.centralbank.go.ke:444/a.pdf',
    'file:///tmp/a.pdf','https://www.centralbank.go.ke@evil.invalid/a.pdf',
])
def test_direct_writer_rejects_nonofficial_document_url(db,url):
    with pytest.raises(ValueError,match='Official CBK source URL'):
        writer._get_or_create_source_document(db,{},title=TITLE,source_url=url)
    assert db.scalar(select(SourceDocument)) is None

def test_existing_wrong_publisher_cannot_become_verified_official_attribution(db,tmp_path,monkeypatch):
    wrong=doc(db,publisher='Unrelated private publisher')
    payload,_=observed(tmp_path,monkeypatch);rows,q=write(db,payload)
    assert all(q[r.id]['total']['publisher']!='Unrelated private publisher' or q[r.id]['total']['status']!='verified' for r in rows)
    assert wrong.publisher=='Unrelated private publisher'

@pytest.mark.parametrize('mutation',['value','period','receipt','serialized','dropped','cross_document'])
def test_changed_or_aliased_evidence_does_not_verify_debt(db,tmp_path,monkeypatch,mutation):
    payload,_=observed(tmp_path,monkeypatch)
    target=payload['timeline'][-1]
    stocks=[e for e in target['source_evidence'] if e['identity']['measure']!='gdp']
    if mutation=='value':
        for e in stocks:e['value']='999'
    elif mutation=='period':
        for e in stocks:e['identity']['period']='2023'
    elif mutation=='receipt':
        for e in stocks:e['_response_receipt']['request_url']='https://evil.invalid/forged.pdf'
    elif mutation=='serialized':
        for e in stocks:e['_response_receipt']=dict(e['_response_receipt'])
    elif mutation=='dropped':target['source_evidence']=[e for e in target['source_evidence'] if e['identity']['measure']=='gdp']
    else:target['source_url']='https://www.centralbank.go.ke/uploads/statistical_bulletin/other.pdf'
    rows,q=write(db,payload)
    assert q[rows[-1].id]['total']['status']!='verified'
    assert q[rows[-1].id]['gdp_ratio']['status']!='verified'

@pytest.mark.parametrize('value',[0,-0.0,0.4,None,True,-1])
def test_invalid_gdp_keeps_prior_unconfirmed_amount_clears_derived_ratio(db,tmp_path,monkeypatch,value):
    settings,client,_=setup(tmp_path,monkeypatch,years=(2025,),values={2025:value})
    monkeypatch.setattr(domain,'create_http_client',lambda _:client)
    result=domain.run(db,settings,DomainRunContext(None,False));db.commit()
    assert not result.errors
    row=db.scalar(select(DebtTimeline));q=qualify_rows(db,'debt_timeline',[row])[row.id]
    assert row.gdp==Decimal('5000000000000') and row.gdp_ratio is None
    assert q['gdp']['status']!='verified' and q['gdp_ratio']['status']=='unavailable'
    assert get('debt_timeline')['mode']=='partial'

@pytest.mark.parametrize('years',[[],[True],[2025,2025],['2025'],[1899],[10000]])
def test_invalid_base_years_refuse_before_publisher_calls(tmp_path,monkeypatch,years):
    settings,client,calls=setup(tmp_path,monkeypatch,years=years)
    with client,pytest.raises(ValueError,match='calendar years'):
        fetcher.fetch_debt_timeline_payload(client,settings)
    assert calls==[]

def test_no_cbk_no_gdp_does_not_claim_any_live_component(tmp_path,monkeypatch):
    settings,client,calls=setup(tmp_path,monkeypatch,cbk_years=(),enabled=False)
    with client:payload=fetcher.fetch_debt_timeline_payload(client,settings)
    assert get('debt_timeline')['mode']=='fixture'
    assert payload['metadata']['refresh_components']['debt']['state']=='unavailable'
    assert payload['metadata']['refresh_components']['gdp']['state']=='disabled'
    assert calls==[]


def test_disabled_gdp_clears_ratio_after_changed_debt_overlay(db,tmp_path,monkeypatch):
    payload,_=observed(tmp_path,monkeypatch,gdp=False)
    assert get('debt_timeline')['mode']=='partial'
    assert payload['metadata']['refresh_components']['gdp']['state']=='disabled'
    assert payload['timeline'][-1]['total']==1300
    assert payload['timeline'][-1]['gdp_ratio'] is None

@pytest.mark.parametrize('raw',['NaN','Infinity','-Infinity'])
def test_nonfinite_gdp_bytes_do_not_become_live(tmp_path,monkeypatch,raw):
    settings,client,_=setup(tmp_path,monkeypatch,years=(2025,))
    body='[{"page":1,"pages":1,"total":1},[{"indicator":{"id":"NY.GDP.MKTP.CN"},"country":{"id":"KE"},"countryiso3code":"KEN","date":"2025","value":'+raw+',"unit":""}]]'
    client._client=httpx.Client(transport=httpx.MockTransport(lambda req:httpx.Response(200,content=body.encode(),headers={'content-type':'application/json'})))
    with client:payload=fetcher.fetch_debt_timeline_payload(client,settings)
    assert get('debt_timeline')['mode']=='partial'
    assert payload['metadata']['refresh_components']['gdp']['state']=='unavailable'
    assert payload['timeline'][0]['gdp_ratio'] is None
