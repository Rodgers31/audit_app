"""Fetcher for fiscal summary data.

Load the configured baseline, then apply source-specific CoB original-gross
and Treasury budget/revenue/framework observations. A failed or partial
refresh retains the baseline and records the missing coverage explicitly.
"""

from __future__ import annotations

import logging
import math
from typing import Any, Dict, Optional

from ...config import SeedingSettings
from ...http_client import SeedingHttpClient
from ...utils import load_json_resource

logger = logging.getLogger("seeding.fiscal_summary.fetcher")

# ── The budget basis decision (2026-08-29) ───────────────────────────
# "The budget" has three legitimate, DIFFERENT values for FY2025/26:
#
#   COB original gross budget   4.69T  (gross ministerial + CFS)
#   COB original net estimates  4.43T  (excludes Appropriations-in-Aid)
#   Budget Policy Statement     4.19T  (what this fixture used to hold)
#
# The user chose GROSS, for current, future and past data. That decision is
# recorded HERE as the one basis a live figure may be promoted on, and in
# ``real_data/fiscal_summary.json`` as an explicit ``budget_basis`` on every
# row, backfilled from each year's COB report rather than relabelled.
CANONICAL_BUDGET_BASIS = "cob_gross"

# Whether a row that declares NO ``budget_basis`` may receive the live gross
# figure. Still FALSE after the basis decision, and deliberately so.
#
# Choosing gross as the house basis does not make an undeclared row gross;
# it makes an undeclared row a DEFECT. Every row in the shipped fixture now
# declares its basis, so "undeclared" can only mean a row arrived from
# somewhere that did not say what measure it holds — exactly the state in
# which a 4.19T Budget Policy Statement number sat one 12% tolerance away
# from being silently overwritten with a 4.69T gross one. Flipping this to
# True would restore that hazard for every future row while saving nothing:
# opting a row in costs one JSON key.
_ALLOW_UNDECLARED_BASIS = False

# World Bank indicator codes for Kenya.
#
# The DT.* pair is EXTERNAL-ONLY. "total" inside those World Bank names means
# total external — long-term + IMF + short-term — not total including domestic,
# and Kenya's domestic side is the larger half of both. The alias for
# DT.TDS.DECT.CD used to read `total_debt_service_usd`, and under that name it
# was written to `debt_service_cost`, a field this dataset defines as "interest
# payments PLUS principal redemptions (domestic + external)". The scope now
# lives in the alias so the next reader cannot make the same substitution.
_WB_INDICATORS: Dict[str, str] = {
    "GC.XPN.TOTL.CN": "government_expenditure_lcu",
    "DT.DOD.DECT.CD": "external_debt_stocks_usd",
    "DT.TDS.DECT.CD": "external_debt_service_usd",
    "GC.REV.TOTL.CN": "government_revenue_lcu",
}


def fetch_fiscal_summary_payload(
    client: SeedingHttpClient, settings: SeedingSettings
) -> dict[str, Any]:
    """Refresh fiscal estimates only from matching financial source contracts."""
    # Always load the fixture as baseline
    payload = load_json_resource(
        url=settings.fiscal_summary_dataset_url,
        client=client,
        logger=logger,
        label="fiscal_summary",
    )

    cob_status = "not_attempted"
    cob_promoted = False
    estimates_status = "not_attempted"
    estimates_applied = False
    revenue_status = "not_attempted"
    revenue_applied = False
    framework_status = "not_attempted"
    framework_applied = False
    estimates = None
    listing_facts = {}

    # World Bank calendar-year expenditure/receipts are actuals with different
    # periods and bases from original gross appropriations and Treasury annual
    # ordinary-revenue estimates. Their own observation domains ingest them;
    # do not spend four requests manufacturing unqualified fiscal-year stubs.
    # Live COB NG-BIRR headline overlay (recommendation #3): refine the
    # latest-year appropriated_budget from the authoritative Controller-of-
    # Budget report — but only through the plausibility + reconciliation
    # overlay, so the fixture remains the last-known-good fallback whenever the
    # parse is missing, implausible, or far from the known value.
    if settings.live_pdf_fetch_enabled:
        try:
            live_budget, live_revenue, report_fy = _fetch_cob_headlines(
                client, settings
            )
            payload, b_status = _overlay_live_budget_headline(
                payload, live_budget, fiscal_year=report_fy
            )
            payload, r_status = _overlay_live_revenue_headline(
                payload, live_revenue, fiscal_year=report_fy
            )
            cob_promoted = b_status == "promoted"
            cob_status = f"fy={report_fy} budget={b_status} revenue={r_status}"
            logger.info(
                "fiscal_summary COB overlay (%s): budget=%s revenue=%s",
                report_fy,
                b_status,
                r_status,
            )
        except Exception as exc:
            logger.warning("COB headline overlay skipped: %s", exc)

        # Treasury's approved Budget Estimates: the ONLY source that can put
        # a NEW fiscal year on the site. COB publishes at quarter-end + 45
        # days, so between 1 July and mid-November nothing else in this
        # pipeline knows the new year exists.
        #
        # Runs AFTER the COB overlay on purpose. The two never contend: this
        # step creates FY N in July/August from the enacted estimates, and
        # COB's first report on FY N does not exist until mid-November, by
        # which time the row is months old and the overlay writes onto it
        # normally. Ordering it second keeps the cheap, every-night COB
        # refresh ahead of a 29MB download that only misses its 30-day cache
        # once a year. If Treasury were unavailable all along, the COB
        # overlay's ``report_year_not_in_payload`` refusal is the correct
        # outcome — a missing row is not a licence to write the figure
        # somewhere else.
        try:
            estimates, estimates_status = _fetch_budget_estimates(client, settings)
            if estimates is not None:
                payload, apply_status = _apply_budget_estimates(payload, estimates)
                estimates_applied = apply_status in ("created", "updated")
                estimates_status = f"{estimates.fiscal_year}:{apply_status}"
            logger.info(
                "fiscal_summary Treasury budget estimates: %s", estimates_status
            )
        except Exception as exc:
            estimates_status = f"error({type(exc).__name__})"
            logger.warning("Treasury budget estimates step skipped: %s", exc)

        # Revenue for the SAME year, from the Budget Summary. Runs after the
        # budget books so the fiscal year already exists when it lands, and is
        # given the prior year's ordinary revenue off the payload as gate 3's
        # cross-vintage check.
        try:
            target_fy = None
            if estimates is not None:
                target_fy = estimates.fiscal_year
            else:
                rows = payload.get("fiscal_years") or []
                if rows:
                    target_fy = max(r.get("fiscal_year", "") for r in rows) or None
            if target_fy:
                prior_label = _previous_fy(target_fy)
                prior_row = next(
                    (
                        r
                        for r in payload.get("fiscal_years") or []
                        if r.get("fiscal_year") == prior_label
                    ),
                    None,
                )
                revenue_est, revenue_status = _fetch_revenue_estimates(
                    client,
                    settings,
                    target_fy,
                    known_prior_ordinary_billion=(prior_row or {}).get("total_revenue"),
                )
                if revenue_est:
                    payload, rev_apply = _apply_revenue_estimates(payload, revenue_est)
                    revenue_applied = rev_apply.startswith("applied=")
                    revenue_status = rev_apply
            else:
                revenue_status = "no_target_fiscal_year"
            logger.info(
                "fiscal_summary Treasury revenue estimates: %s", revenue_status
            )
        except Exception as exc:
            revenue_status = f"error({type(exc).__name__})"
            logger.warning("Treasury revenue estimates step skipped: %s", exc)

        # The split — borrowing, recurrent / development / counties, tax
        # versus non-tax — from the Budget Summary's Annex Table 2a. Runs
        # LAST: each past year's column is found by the ordinary revenue the
        # step above just published for it, so that step has to have run.
        try:
            editions, listing_facts = _fetch_budget_summary_editions(client, settings)
            payload["_run_facts"] = listing_facts
            payload, framework_status = _apply_fiscal_framework(payload, editions)
            framework_applied = framework_status.startswith("applied=")
            logger.info("fiscal_summary Treasury fiscal framework: %s", framework_status)
        except Exception as exc:
            framework_status = f"error({type(exc).__name__})"
            logger.warning("Treasury fiscal framework step skipped: %s", exc)

    # A successful budget overlay alone cannot establish complete revenue,
    # framework and historical-edition coverage for the whole domain.
    from ...freshness import mark_fixture, mark_live, mark_partial

    listed = listing_facts.get(LISTING_EDITIONS_FACT) or {}
    unreadable = {url: entry.get("status", "unrecorded") for url, entry in listed.items()
                  if entry.get("status") != "read"}
    row_gaps = {str(row.get("fiscal_year")): row.get("fiscal_framework_absent_reason")
                or row.get("tax_split_absent_reason") or "no_current_edition_framework"
                for row in payload.get("fiscal_years", [])
                if not row.get("fiscal_framework") or row.get("fiscal_framework_absent_reason")
                or row.get("tax_split_absent_reason")
                or (row["fiscal_framework"].get("source") or {}).get("url") not in listed}
    framework_complete = bool(framework_applied and listed and not unreadable and not row_gaps
                              and " refused=" not in framework_status)
    revenue_complete = revenue_applied and " refused=" not in revenue_status
    budget_applied = estimates_applied or cob_promoted
    components = {
        "budget": {"state": "live" if budget_applied else "unavailable", "detail": estimates_status,
                   "cob_detail": cob_status},
        "revenue": {"state": "live" if revenue_complete else "partial" if revenue_applied
                   else "unavailable", "detail": revenue_status},
        "framework": {"state": ("live" if framework_complete else "partial" if framework_applied
                                 else "unavailable"), "detail": framework_status,
                      "unreadable_editions": unreadable, "unconfirmed_years": row_gaps},
        "worldbank": {"state": "not_applicable", "reason": "financial_measure_or_period_not_established"},
    }
    payload.setdefault("_run_facts", {}).update(refresh_components=components)

    detail = (
        f"COB overlay: {cob_status}; Treasury estimates: {estimates_status}; "
        f"Treasury revenue: {revenue_status}; "
        f"Treasury fiscal framework: {framework_status}; World Bank fiscal promotion: not applicable"
    )
    if budget_applied and revenue_complete and framework_complete:
        mark_live("fiscal_summary", detail=detail)
    elif budget_applied or revenue_applied or framework_applied:
        mark_partial(
            "fiscal_summary",
            reason="fiscal_components_incomplete", detail=detail,
        )
    else:
        mark_fixture(
            "fiscal_summary",
            reason="no_live_overlay_applied",
            detail=detail,
        )

    return payload


def _fetch_budget_estimates(
    client: SeedingHttpClient, settings: SeedingSettings
):
    """Discover, download and parse Treasury's approved Budget Estimates.

    Returns ``(BudgetEstimates | None, status)``. Every failure path returns a
    SPECIFIC status slug rather than None-and-a-log-line, because "the site
    still shows last year" is precisely the class of bug that hides behind a
    generic warning.
    """
    import dataclasses
    from pathlib import Path

    from ...discovery import discover_latest_pdf, parse_fiscal_year
    from ...pdf_download import get_or_download_pdf
    from ...source_registry import SOURCE_REGISTRY
    from .budget_estimates import BudgetEstimatesError, extract_budget_estimates

    dataset = SOURCE_REGISTRY["treasury_budget_estimates"]
    page_url = settings.treasury_budget_books_page_url
    try:
        response = client.get(page_url, raise_for_status=True)
    except Exception as exc:
        return None, f"listing_unreachable({type(exc).__name__})"

    found = discover_latest_pdf(
        response.text,
        page_url,
        must_match=("/budget%20books/",) + dataset.match_keywords,
        # Supplementary estimates revise a budget mid-year and are a
        # DIFFERENT measure from the original gross budget COB reports on;
        # "draft" is not a published figure at all (see _is_publishable_doc).
        must_not_match=("supplementary", "supp-", "draft"),
    )
    if found is None:
        return None, "no_budget_book_discovered"

    fiscal_year = parse_fiscal_year(found.url)
    if not fiscal_year:
        return None, "budget_book_has_no_fiscal_year"

    try:
        pdf_path = get_or_download_pdf(
            client,
            found.url,
            cache_dir=Path(settings.cache_path) / "pdfs",
            ttl_seconds=settings.pdf_cache_ttl_seconds,
            max_seconds=settings.pdf_download_timeout_seconds,
            max_bytes=settings.pdf_download_max_bytes,
        )
    except Exception as exc:
        return None, f"download_failed({type(exc).__name__})"

    try:
        estimates = dataclasses.replace(
            extract_budget_estimates(pdf_path, fiscal_year), source_url=found.url
        )
    except BudgetEstimatesError as exc:
        logger.warning(
            "Treasury budget estimates QUARANTINED for %s: %s",
            fiscal_year,
            exc,
        )
        return None, f"quarantined:{exc.reason}"
    logger.info(
        "Treasury %s enacted gross budget: KSh %.1fB (voted %.1fB + CFS "
        "%.1fB). Checks: %s",
        estimates.fiscal_year,
        estimates.gross_budget_billion,
        float(estimates.voted_gross_kes) / 1e9,
        float(estimates.cfs_kes) / 1e9,
        "; ".join(estimates.checks),
    )
    return estimates, "parsed"


def _previous_fy(label: str):
    """``'FY 2026/27'`` -> ``'FY 2025/26'``; None when unparseable."""
    import re as _re

    m = _re.search(r"(\d{4})/(\d{2})", label or "")
    if not m:
        return None
    start = int(m.group(1)) - 1
    return f"FY {start}/{str(start + 1)[-2:]}"


def _fetch_revenue_estimates(
    client, settings, fiscal_year: str, known_prior_ordinary_billion=None
):
    """Discover, download and parse Treasury's Budget Summary for revenue.

    Returns ``(RevenueEstimates | None, status)``. Every failure path returns a
    reason rather than raising, so a bad run leaves the year's revenue absent
    instead of publishing a figure nothing verified.
    """
    from pathlib import Path

    from ...discovery import discover_latest_pdf
    from ...pdf_download import get_or_download_pdf
    from .revenue_estimates import (
        build_revenue_series,
        parse_fiscal_framework,
        _TABLE_MARKER,
        _squash,
    )

    page_url = settings.treasury_budget_summary_page_url
    try:
        response = client.get(page_url, raise_for_status=True)
    except Exception as exc:
        return None, f"listing_unreachable({type(exc).__name__})"

    found = discover_latest_pdf(
        response.text,
        page_url,
        must_match=("budget", "summary"),
        # A draft is not a published figure, and a supplementary revises the
        # year mid-flight — neither is the approved estimate.
        must_not_match=("draft", "supplementary", "supp-"),
    )
    if found is None:
        return None, "no_budget_summary_discovered"

    try:
        pdf_path = get_or_download_pdf(
            client,
            found.url,
            cache_dir=Path(settings.cache_path) / "pdfs",
            ttl_seconds=settings.pdf_cache_ttl_seconds,
            max_seconds=settings.pdf_download_timeout_seconds,
            max_bytes=settings.pdf_download_max_bytes,
        )
    except Exception as exc:
        return None, f"download_failed({type(exc).__name__})"

    try:
        import pdfplumber

        with pdfplumber.open(pdf_path) as pdf:
            for n, page in enumerate(pdf.pages):
                if _squash(_TABLE_MARKER) not in _squash(page.extract_text() or ""):
                    continue
                table = parse_fiscal_framework(page.extract_words(), page=n + 1)
                published, quarantined = build_revenue_series(
                    table, through_fiscal_year=fiscal_year, source_url=found.url
                )
                if not published:
                    return None, f"all_quarantined({sorted(quarantined.values())})"
                return published, f"{len(published)} year(s); quarantined={quarantined}"
        return None, "fiscal_framework_table_not_found"
    except Exception as exc:
        return None, f"parse_failed({type(exc).__name__})"


def _apply_revenue_estimates(payload, series):
    """Write every gated revenue estimate onto its fiscal year.

    Unlike ``_overlay_live_revenue_headline`` this may CREATE a year, which is
    the whole reason it exists: an overlay can only mutate a row that is
    already there, so a budget year that has never been seeded gets no revenue
    from the COB path no matter how healthy that path is.

    One Budget Summary carries the whole series, so this re-derives the settled
    years too rather than leaving them as stored literals that nothing checks.

    Pure and idempotent. Returns ``(payload, status)``.
    """
    if not series:
        return payload, "no_estimates"
    fiscal_years = payload.setdefault("fiscal_years", [])
    applied, refused = [], {}

    for fiscal_year, estimates in sorted(series.items()):
        row = next(
            (r for r in fiscal_years if r.get("fiscal_year") == fiscal_year), None
        )
        if row is None:
            row = {"fiscal_year": fiscal_year}
            fiscal_years.append(row)

        declared = row.get("revenue_basis")
        if declared is not None and declared != "ordinary_revenue_excl_aia":
            refused[fiscal_year] = f"basis_mismatch({declared})"
            continue

        row["total_revenue"] = float(estimates.ordinary_revenue_billion)
        row["revenue_basis"] = "ordinary_revenue_excl_aia"
        # The split is NOT derivable from this table — it prints only the
        # ordinary/AiA/total triple — so it stays absent rather than being
        # back-filled from a different column that would contradict the total.
        row["tax_revenue"] = None
        row["non_tax_revenue"] = None
        row["revenue_source"] = {
            "title": "Budget Summary",
            "publisher": "The National Treasury",
            "url": estimates.source_url,
            "page": (
                "Table 2: Medium-Term Fiscal Framework, PDF p."
                f"{estimates.page_refs.get('fiscal_framework')}"
            ),
            "measure": "Ordinary Revenue (tax + non-tax, excluding A-i-A and grants)",
            "total_revenue_incl_aia_billion": float(
                estimates.total_revenue_incl_aia_billion
            ),
            "ministerial_aia_billion": float(estimates.ministerial_aia_billion),
            "checks": list(estimates.checks),
        }
        row["_revenue_source"] = "treasury_budget_summary_live"
        applied.append(fiscal_year)

    if not applied:
        return payload, f"none_applied({refused})"
    return payload, f"applied={applied}" + (f" refused={refused}" if refused else "")


#: Key names of the facts the freshness gate reads off the ingestion job.
#: ``seeding/staleness.py`` imports these rather than spelling them again.
LISTING_NEWEST_FY_FACT = "budget_summary_listing_newest_fy"
LISTING_EDITIONS_FACT = "budget_summary_editions"


def _fetch_budget_summary_editions(client, settings):
    """Read EVERY Budget Summary on Treasury's listing, not just the newest.

    Returns ``(editions, facts)``. ``editions`` is ``[(url, Edition)]``,
    newest fiscal year first, holding only the editions that could be read.
    ``facts`` records what the listing carried, including the ones that could
    not, and becomes the ingestion job's metadata for the freshness gate.

    Why every edition: one edition carries the split for its own year and
    for the settled years before it. When FY 2027/28's edition lands and
    cannot be read, FY 2026/27's own edition still supplies FY 2026/27, so
    one bad document costs one year and not the series. The gate reports
    the unread year either way.

    Why the facts are recorded even on failure: "a newer Budget Summary
    exists than the newest year with a split" has to be sayable when the
    newer one is exactly what failed to parse.
    """
    from pathlib import Path

    from ...discovery import find_pdf_links, parse_fiscal_year
    from ...parse_cache import parse_with_cache, parser_digest
    from ...pdf_download import get_or_download_pdf
    from .fiscal_framework import (
        FiscalFrameworkError,
        edition_fiscal_year,
        extract_page_texts,
        read_edition,
    )

    page_url = settings.treasury_budget_summary_page_url
    facts: Dict[str, Any] = {
        "budget_summary_listing_url": page_url,
        LISTING_NEWEST_FY_FACT: None,
        LISTING_EDITIONS_FACT: {},
    }
    try:
        response = client.get(page_url, raise_for_status=True)
    except Exception as exc:
        facts["budget_summary_listing_status"] = f"unreachable({type(exc).__name__})"
        return [], facts
    facts["budget_summary_listing_status"] = "read"
    extractor_hash = parser_digest(extract_page_texts)
    cache_dependencies = None
    try:
        from importlib.metadata import version
        import json
        import pytesseract
        ocr_version = str(pytesseract.get_tesseract_version())
        languages = pytesseract.get_languages(config="")
        packages = {name: version(name) for name in
                    ("pdfplumber", "pdfminer.six", "pytesseract", "numpy", "Pillow", "pypdfium2")}
        if (extractor_hash and ocr_version.strip() and "eng" in languages
                and all(isinstance(v, str) and v.strip() for v in packages.values())):
            cache_dependencies = json.dumps({"extractor": extractor_hash, "ocr": ocr_version,
                                             "languages": sorted(languages), "packages": packages}, sort_keys=True)
    except Exception:
        logger.info("Fiscal extractor fingerprint unavailable; bypassing parse cache")

    links = []
    for absolute, _href in find_pdf_links(response.text, page_url):
        low = absolute.lower()
        if "budget" not in low or "summary" not in low:
            continue
        # Same exclusions as the revenue step: a draft is not a published
        # figure and a supplementary revises the year mid-flight.
        if any(x in low for x in ("draft", "supplementary", "supp-")):
            continue
        links.append(absolute)

    editions = []
    for url in links:
        link_fy = parse_fiscal_year(url)
        entry: Dict[str, Any] = {"fiscal_year": link_fy}
        facts[LISTING_EDITIONS_FACT][url] = entry
        try:
            pdf_path = get_or_download_pdf(
                client,
                url,
                cache_dir=Path(settings.cache_path) / "pdfs",
                ttl_seconds=settings.pdf_cache_ttl_seconds,
                max_seconds=settings.pdf_download_timeout_seconds,
                max_bytes=settings.pdf_download_max_bytes,
            )
            records = parse_with_cache(
                pdf_path,
                cache_dir=Path(settings.cache_path) / "pdfs",
                kind="budget_summary_pages",
                parse_fn=lambda p=pdf_path: extract_page_texts(p),
                enabled=settings.parse_cache_enabled and cache_dependencies is not None,
                key_extra=cache_dependencies or "",
            )
        except Exception as exc:
            entry["status"] = f"unreadable({type(exc).__name__})"
            continue
        pages = [r.get("text") or "" for r in sorted(records, key=lambda r: r["page"])]
        ocr = [{k: r[k] for k in ("page", "ocr_status", "ocr_reason") if k in r}
               for r in records if "ocr_status" in r]
        if ocr:
            entry["image_annex_ocr"] = ocr
        try:
            entry["fiscal_year"] = edition_fiscal_year(pages, fiscal_year=link_fy)
            edition = read_edition(pages, fiscal_year=entry["fiscal_year"])
        except FiscalFrameworkError as exc:
            entry["status"] = f"refused:{exc.reason}"
            entry["detail"] = exc.detail
            continue
        entry["status"] = "read"
        entry["annex_page"] = edition.table.page
        entry["approved_column_score"] = list(edition.narrative_score)
        editions.append((url, edition))

    # Newest year the LISTING names, readable or not. A dead link or an
    # unparseable edition still counts: it is a budget Treasury has
    # published and the site does not yet carry.
    years = [e["fiscal_year"] for e in facts[LISTING_EDITIONS_FACT].values() if e.get("fiscal_year")]
    facts[LISTING_NEWEST_FY_FACT] = max(years) if years else None
    facts["budget_summary_undated_links"] = sorted(
        u for u, e in facts[LISTING_EDITIONS_FACT].items() if not e.get("fiscal_year")
    )
    editions.sort(key=lambda pair: pair[1].fiscal_year, reverse=True)
    return editions, facts


def _apply_fiscal_framework(payload, editions):
    """Write each fiscal year's gated split onto its row. Pure; idempotent.

    For every row, editions are tried newest first and the first one that
    yields a gated column wins:

    * the edition's OWN year takes the column the narrative identifies (the
      approved budget);
    * any other year takes the column printing the ordinary revenue that
      ``revenue_estimates`` published for it from the SAME document. A row
      whose revenue came from elsewhere is not joined, because it is a
      different vintage.

    What is written, all on the fiscal-framework basis, with the total it
    reconciles to (``fiscal_framework.total_expenditure_billion``):

    * ``recurrent_spending``, ``development_spending``, ``county_allocation``
      (county TRANSFERS: the equitable share plus conditional allocations,
      because that is what reconciles; the equitable share alone is carried
      in the object), and ``total_borrowing`` (total deficit financing);
    * ``tax_revenue`` / ``non_tax_revenue`` only when their sum IS the row's
      ``total_revenue``. A split that does not add up to the total it is
      shown beside is withheld, with the reason on the row;
    * ``total_revenue`` itself only for the edition's own year, and only
      when no revenue is there yet. That is the year ``revenue_estimates``
      refuses without a hand-entered BPS figure, which is next year's
      situation by construction.

    A row no edition can supply keeps what it had, and records why.
    """
    from decimal import Decimal

    from .fiscal_framework import (
        FISCAL_FRAMEWORK_BASIS,
        FiscalFrameworkError,
        framework_payload,
        split_for_fiscal_year,
    )

    fiscal_years = payload.setdefault("fiscal_years", [])
    if not editions:
        return payload, "no_editions_read"

    # An edition may describe a year the payload does not have yet. Create it
    # the way the budget books do; the API still withholds it until it can
    # cite a page.
    earliest = min((str(r.get("fiscal_year")) for r in fiscal_years), default="")
    for _url, edition in editions:
        if edition.fiscal_year >= earliest and not any(
            r.get("fiscal_year") == edition.fiscal_year for r in fiscal_years
        ):
            fiscal_years.append({"fiscal_year": edition.fiscal_year})
    fiscal_years.sort(key=lambda r: str(r.get("fiscal_year", "")))

    applied, refused = [], {}
    for row in fiscal_years:
        fy = row.get("fiscal_year")
        reasons = []
        for url, edition in editions:
            revenue_url = (row.get("revenue_source") or {}).get("url")
            same_document = revenue_url == url and row.get("total_revenue") is not None
            if fy != edition.fiscal_year and not same_document:
                continue
            try:
                split = split_for_fiscal_year(
                    edition,
                    fy,
                    known_ordinary_revenue=(
                        float(row["total_revenue"]) if same_document else None
                    ),
                )
            except FiscalFrameworkError as exc:
                reasons.append(f"{edition.fiscal_year} edition: {exc.reason}")
                continue
            break
        else:
            if reasons:
                refused[fy] = reasons
                row["fiscal_framework_absent_reason"] = "; ".join(reasons)
            continue

        framework = framework_payload(split, source_url=url, page=edition.table.page)
        framework["source"]["edition"] = f"Budget Summary for the {edition.fiscal_year} Budget"
        framework["source"]["column_identification"] = (
            "Approved budget (identified by the narrative)"
            if split.identified_by == "approved_budget"
            else "The column printing this row's ordinary revenue (the latest "
            f"vintage the {edition.fiscal_year} edition prints for {fy})"
        )
        v = split.values
        row["fiscal_framework"] = framework
        row["split_basis"] = FISCAL_FRAMEWORK_BASIS
        row["recurrent_spending"] = float(v["recurrent"])
        row["development_spending"] = float(v["development"])
        row["county_allocation"] = float(v["county_transfers"])
        row["total_borrowing"] = float(v["total_financing"])
        row.pop("fiscal_framework_absent_reason", None)

        ordinary = v["ordinary_revenue"]
        if row.get("total_revenue") is None and fy == edition.fiscal_year:
            row["total_revenue"] = float(ordinary)
            row["revenue_basis"] = "ordinary_revenue_excl_aia"
            row["revenue_source"] = {
                **framework["source"],
                "measure": "Ordinary Revenue (tax + non-tax, excluding A-i-A and grants)",
            }
            row["_revenue_source"] = "treasury_budget_summary_annex_live"
        if split.tax_split_ok:
            total = row.get("total_revenue")
            if total is not None and abs(Decimal(str(total)) - ordinary) <= Decimal("0.05"):
                row["tax_revenue"] = float(v["tax_revenue"])
                row["non_tax_revenue"] = float(v["non_tax_revenue"])
                row.pop("tax_split_absent_reason", None)
            else:
                row["tax_split_absent_reason"] = (
                    f"the split sums to ordinary revenue {ordinary}B but the row "
                    f"publishes {total}B, so it is not shown against it"
                )
        else:
            row["tax_split_absent_reason"] = split.tax_split_reason
        applied.append(fy)

    status = f"applied={applied}" if applied else "none_applied"
    if refused:
        status += f" refused={refused}"
    return payload, status


def _apply_budget_estimates(
    payload: Dict[str, Any], estimates
) -> tuple[Dict[str, Any], str]:
    """INSERT (or refresh) the fiscal year the enacted estimates describe.

    This is the one path in the domain that may CREATE a fiscal year. Every
    other overlay mutates ``max(fiscal_years)`` and therefore could never
    move the site onto a new fiscal year, no matter how current its source —
    which is why the homepage still read FY 2025/26 two months into FY
    2026/27.

    Pure and idempotent: re-running with the same estimates rewrites the same
    fields. Returns ``(payload, status)``.
    """
    if estimates is None:
        return payload, "no_estimates"
    fiscal_years = payload.setdefault("fiscal_years", [])
    budget = round(estimates.gross_budget_billion, 1)

    # The plausibility guard runs on the row that would be written, not on
    # the raw figure, so an implausible insert is refused the same way an
    # implausible overlay is.
    candidate = {"fiscal_year": estimates.fiscal_year, "appropriated_budget": budget}
    try:
        from services.trust_guards import check_fiscal_summary

        if check_fiscal_summary(candidate):
            return payload, "failed_plausibility"
    except Exception:
        return payload, "plausibility_unavailable"

    row = next(
        (r for r in fiscal_years if r.get("fiscal_year") == estimates.fiscal_year),
        None,
    )
    created = row is None
    if row is None:
        row = {"fiscal_year": estimates.fiscal_year}
        fiscal_years.append(row)

    declared = row.get("budget_basis")
    if declared is not None and declared != CANONICAL_BUDGET_BASIS:
        return payload, f"basis_mismatch(row={declared},live={CANONICAL_BUDGET_BASIS})"

    row["appropriated_budget"] = budget
    row["budget_basis"] = CANONICAL_BUDGET_BASIS
    # How much of the gross figure is rolling over maturing debt rather than
    # funding new spending. Published only when the book's own interest and
    # redemption sub-totals reconciled to their combined line, so an unproven
    # split never reaches the site. This is what lets the page explain why the
    # gross budget and the enacted headline differ.
    if estimates.debt_redemption_kes is not None:
        row["debt_redemption"] = round(
            float(estimates.debt_redemption_kes) / 1e9, 1
        )
    row["budget_basis_source"] = {
        "title": f"Programme Based Budget {estimates.fiscal_year} (Approved)",
        "publisher": "The National Treasury",
        "url": getattr(estimates, "source_url", None),
        "page": (
            f"voted total PDF p.{estimates.page_refs.get('voted_total')}; "
            f"CFS summary PDF p.{estimates.page_refs.get('cfs_summary')}"
        ),
        "composition": (
            f"gross voted expenditure "
            f"{float(estimates.voted_gross_kes) / 1e9:,.1f}B "
            f"+ Consolidated Fund Services "
            f"{float(estimates.cfs_kes) / 1e9:,.1f}B"
            + (
                f" (of which debt redemption "
                f"{float(estimates.debt_redemption_kes) / 1e9:,.1f}B)"
                if estimates.debt_redemption_kes is not None
                else ""
            )
        ),
        "checks": list(estimates.checks),
    }
    row["_budget_source"] = "treasury_budget_estimates_live"
    fiscal_years.sort(key=lambda r: str(r.get("fiscal_year", "")))
    return payload, ("created" if created else "updated")


def _fetch_cob_headlines(
    client: SeedingHttpClient, settings: SeedingSettings
) -> tuple[Optional[float], Optional[float], Optional[str]]:
    """Discover + download the latest COB NG-BIRR ONCE and extract the headline
    ``(overall_budget, total_revenue, report_fiscal_year)``; money in KSh
    billion. Returns ``(None, None, None)`` on any failure — callers treat that
    as 'no live value' and keep the fixture."""
    import tempfile
    from pathlib import Path

    from ...cob_discovery import discover_latest_cob_pdf_url
    from ..national_budget.fetcher import _NG_BIRR_KEYWORDS
    from ..national_budget.headline import extract_cob_headlines

    resp = client.get(settings.cob_birr_page_url, raise_for_status=True)
    pdf_url = discover_latest_cob_pdf_url(
        resp.text, settings.cob_birr_page_url, keywords=_NG_BIRR_KEYWORDS
    )
    if not pdf_url:
        logger.info("No NG-BIRR PDF found for fiscal_summary headline overlay")
        return None, None, None

    pdf_resp = client.get(pdf_url, raise_for_status=True)
    tmp_path: Optional["Path"] = None
    try:
        with tempfile.NamedTemporaryFile(
            suffix=".pdf", delete=False, prefix="cob_fs_headline_"
        ) as tmp:
            tmp.write(pdf_resp.content)
            tmp_path = Path(tmp.name)
        budget, revenue, report_fy = extract_cob_headlines(tmp_path, original_budget_only=True)
        return (
            float(budget) if budget is not None else None,
            float(revenue) if revenue is not None else None,
            report_fy,
        )
    finally:
        if tmp_path and tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass


def _target_row(
    payload: Dict[str, Any], fiscal_year: Optional[str]
) -> tuple[Optional[Dict[str, Any]], Optional[str]]:
    """The row an overlay should write to, or ``(None, reason)``.

    When the source document names its own fiscal year, that row is the only
    legitimate target. ``max(fiscal_years)`` is the fallback and is only safe
    while the newest row happens to be the year the publisher just reported
    on — which stopped being true the moment Treasury's enacted FY2026/27
    estimates could be ingested months before COB's first FY2026/27 report.
    An unanchored overlay would then stamp COB's FY2025/26 headline onto the
    FY2026/27 row.
    """
    fiscal_years = payload.get("fiscal_years") or []
    if not fiscal_years:
        return None, "no_fixture"
    if fiscal_year:
        for row in fiscal_years:
            if str(row.get("fiscal_year")) == fiscal_year:
                return row, None
        return None, f"report_year_not_in_payload({fiscal_year})"
    return max(fiscal_years, key=lambda r: str(r.get("fiscal_year", ""))), None


def _overlay_live_budget_headline(
    payload: Dict[str, Any],
    live_budget_billion: Optional[float],
    *,
    tolerance_pct: float = 15.0,
    basis: str = "cob_gross",
    fiscal_year: Optional[str] = None,
) -> tuple[Dict[str, Any], str]:
    """Promote a live-parsed headline budget onto the latest fiscal year ONLY
    if it (a) passes the plausibility gate and (b) reconciles within
    ``tolerance_pct`` of the fixture's last-known value. Otherwise the fixture
    stands. Returns ``(payload, status)`` for logging/tests.

    Safe-by-construction: a missing / implausible / far-off live value is a
    no-op, so a bad COB parse can never replace good data. ``borrowing_pct_of_
    budget`` is left to the parser, which derives it from the (possibly
    overlaid) budget so the share stays consistent.
    """
    if live_budget_billion is None:
        return payload, "no_live_value"
    latest, reason = _target_row(payload, fiscal_year)
    if latest is None:
        return payload, reason or "no_fixture"
    try:
        live = float(live_budget_billion)
    except (TypeError, ValueError):
        return payload, "bad_live_value"
    if not math.isfinite(live) or live <= 0 or isinstance(live_budget_billion, bool):
        return payload, "bad_live_value"


    # (a) plausibility gate — substitute the live budget; it must stay
    # internally consistent (in band; spending still ≤ budget).
    try:
        from services.trust_guards import check_fiscal_summary

        if check_fiscal_summary({**latest, "appropriated_budget": live}):
            return payload, "failed_plausibility"
    except Exception:
        return payload, "plausibility_unavailable"

    # (b) reconciliation — must be near the last-known fixture value.
    fixture_budget = latest.get("appropriated_budget")
    if fixture_budget:
        try:
            fb = float(fixture_budget)
            if fb > 0 and abs(live - fb) > (tolerance_pct / 100.0) * fb:
                return payload, "outside_tolerance"
        except (TypeError, ValueError):
            pass

    # ── Basis gate — LAST, so a more specific verdict wins ────────────
    # Ordering is sanity -> continuity -> identity. An implausible or
    # far-off figure must be reported as such; masking that behind
    # "basis_mismatch" would hide the more serious finding.
    #
    # "The budget" has three legitimate, DIFFERENT values for FY2025/26:
    #   COB original gross budget   4.69T  (includes A-I-A and CFS)
    #   COB original net estimates  4.43T
    #   Budget Policy Statement     4.19T  <- what this fixture holds
    # A numeric tolerance cannot separate a revision from a redefinition:
    # gross sits 12% from the fixture, INSIDE the 15% band, so it would be
    # promoted silently and the homepage headline would move from 4.19T to
    # 4.69T with nobody having chosen that.
    #
    # Promotion therefore requires the row to DECLARE the same basis. The
    # live value is recorded either way, so a refusal is inspectable rather
    # than invisible.
    incoming_basis = str(basis or CANONICAL_BUDGET_BASIS)
    declared_basis = latest.get("budget_basis")
    latest["_cob_live_budget_billion"] = round(live, 1)
    latest["_cob_live_budget_basis"] = incoming_basis
    if incoming_basis != CANONICAL_BUDGET_BASIS:
        # The house basis is gross. A net or BPS figure is a real number
        # from a real document and still must not land in this field.
        return payload, (
            f"basis_not_canonical(live={incoming_basis},"
            f"canonical={CANONICAL_BUDGET_BASIS})"
        )
    if declared_basis is not None and declared_basis != incoming_basis:
        return payload, (
            f"basis_mismatch(row={declared_basis},live={incoming_basis})"
        )
    if declared_basis is None and not _ALLOW_UNDECLARED_BASIS:
        return payload, f"basis_undeclared(live={incoming_basis})"

    latest["appropriated_budget"] = round(live, 1)
    latest["_budget_source"] = "cob_ng_birr_live"
    return payload, "promoted"


def _overlay_live_revenue_headline(
    payload: Dict[str, Any],
    live_revenue_billion: Optional[float],
    *,
    tolerance_pct: float = 15.0,
    fiscal_year: Optional[str] = None,
) -> tuple[Dict[str, Any], str]:
    """Refuse an unqualified scalar; it cannot establish an annual estimate.

    CoB collection actuals and Treasury ordinary-revenue estimates have
    different periods and bases. A scalar also provides no tax/non-tax split.
    Only the existing Treasury table/annex readers may replace those fields,
    using their source-specific identity and arithmetic gates.
    """
    if live_revenue_billion is None:
        return payload, "no_live_value"
    return payload, "unqualified_revenue_headline"


def _fetch_worldbank_fiscal_data(
    client: SeedingHttpClient, settings: SeedingSettings
) -> Dict[str, Dict[str, float]]:
    """Fetch Kenya fiscal indicators from World Bank API.

    Returns:
        Dict keyed by calendar year (str), each containing indicator values.
        E.g. {"2023": {"government_expenditure_lcu": 3200000000000, ...}}
    """
    base_url = settings.worldbank_api_base_url
    result: Dict[str, Dict[str, float]] = {}

    for indicator_code, field_name in _WB_INDICATORS.items():
        try:
            url = f"{base_url}/country/KEN/indicator/{indicator_code}"
            logger.info("Fetching World Bank indicator %s ...", indicator_code)

            response = client.get(
                url,
                params={
                    "format": "json",
                    "per_page": "20",
                    "date": "2018:2025",
                },
                raise_for_status=False,
            )

            if response.status_code != 200:
                logger.warning(
                    "World Bank API returned %d for %s",
                    response.status_code,
                    indicator_code,
                )
                continue

            data = response.json()
            # World Bank API returns [metadata, records]
            if not isinstance(data, list) or len(data) < 2:
                continue

            records = data[1]
            if not records:
                continue

            for record in records:
                year = record.get("date")
                value = record.get("value")
                if year and value is not None:
                    result.setdefault(str(year), {})[field_name] = float(value)

        except Exception as exc:
            logger.warning(
                "Failed to fetch World Bank indicator %s: %s",
                indicator_code,
                exc,
            )
            continue

    return result


def _calendar_year_to_fy(year: int) -> str:
    """Convert a calendar year to Kenya fiscal year label.

    Kenya FY runs July-June, so calendar year 2023 maps to FY 2022/23
    (the FY that *ends* in June 2023). World Bank annual data for 2023
    best maps to FY 2022/23.
    """
    return f"FY {year - 1}/{str(year)[-2:]}"


def _merge_worldbank_data(
    payload: Dict[str, Any],
    wb_data: Dict[str, Dict[str, float]],
) -> Dict[str, Any]:
    """Do not promote unqualified calendar-year actuals into fiscal estimates.

    Kept as a refusal boundary for existing callers. The budget, revenue and
    spending fields require their source-specific financial identity; mapping
    a calendar year to an ending fiscal year cannot establish that identity.
    """
    return payload
