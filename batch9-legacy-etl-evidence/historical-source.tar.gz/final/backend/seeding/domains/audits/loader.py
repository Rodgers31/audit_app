"""Layer 4 — load ``extractions`` rows into the ``audits`` fact table.

Every audit row written here carries the full provenance the schema was
built for and never had: ``extraction_id`` (the FK to the middle link),
``page_ref``, ``source_hash``, ``confidence_score``, ``basis`` — and
``publishable`` set by the one rule in ``services/publication_gate.py``,
not a second copy of it.

Keyed on ``extraction_id``: one extraction, one audit row, idempotent
re-runs. Amounts: ``audits.amount`` is set only when the paragraph
carries exactly one ``Kshs`` figure — a paragraph quoting a budget, an
actual and a variance has no single "amount involved", and picking one
by heuristic would be an editorial claim the source does not make. All
parsed amounts stay in ``provenance`` either way.
"""

from __future__ import annotations

import logging
from datetime import datetime, time, timezone
from typing import Collection, Optional

from models import (
    Audit,
    Entity,
    EntityType,
    Extraction,
    FigureBasis,
    FiscalPeriod,
    Severity,
    SourceDocument,
)
from sqlalchemy import and_, select
from sqlalchemy.exc import MultipleResultsFound
from sqlalchemy.orm import Session, load_only

from ...config import SeedingSettings
from ...extractors import oag_county_volume
from ...extractors.oag_blue_book import EXTRACTOR_ID, source_hash_of
from ...types import DomainRunContext
from ...utils import normalize_fiscal_label, slugify_entity
from .writer import PersistenceStats
import re

logger = logging.getLogger("seeding.audits.loader")

#: Extractors whose rows share the Blue Book payload shape and load here. The
#: county-volume extractor reuses the Blue Book's chapter walk, so its rows
#: carry the same finding fields plus the chapter and volume they came from.
LOADED_EXTRACTORS = (EXTRACTOR_ID, oag_county_volume.EXTRACTOR_ID)

_SEVERITY_MAP = {
    "CRITICAL": Severity.CRITICAL,
    "WARNING": Severity.WARNING,
    "INFO": Severity.INFO,
}


#: "County Executive of Kilifi", "County Assembly of Nairobi City" — an
#: auditee that belongs to an EXISTING county, not a new MDA.
_COUNTY_ENTRY_RE = re.compile(
    r"^county\s+(?:executive|assembly|government)\s+of\s+(?P<county>.+)$", re.I
)


class CountyEntityUnresolved(RuntimeError):
    """A county auditee that does not map to a county row we already hold."""


def _county_entity(session: Session, name: str) -> Optional[Entity]:
    """The existing COUNTY entity a county auditee belongs to.

    ``None`` when ``name`` is not a county entry at all (a national vote).
    Raises ``CountyEntityUnresolved`` when it IS one but no county matches —
    the caller must skip, never create.

    Why this exists: the consolidated county volumes number their TOC 1..47,
    and _ensure_entity read those as national vote numbers. It slugified
    "County Executive of Kilifi" to `county-executive-of-kilifi`, missed the
    real `kilifi-county`, and created a MINISTRY with `vote: 3`. A run would
    have written ~94 mis-typed entities duplicating counties that already
    exist. Only the 600s timeout rolling the run back prevented it.
    """
    m = _COUNTY_ENTRY_RE.match((name or "").strip())
    if not m:
        return None

    from ...utils import resolve_entity_by_slug

    raw = m.group("county").strip()
    # "Taita/Taveta" slugifies fine; "Nairobi City" is the county the DB holds
    # as plain "Nairobi", so a trailing City is tried as an alias.
    for probe in (raw, re.sub(r"\s+city$", "", raw, flags=re.I)):
        entity, _how = resolve_entity_by_slug(
            session, slugify_entity(probe), entity_type=EntityType.COUNTY
        )
        if entity is not None:
            return entity

    raise CountyEntityUnresolved(
        f"{name!r} is a county auditee but {raw!r} matches no county entity"
    )


def _ensure_entity(
    session: Session, country_id: int, name: str, vote: Optional[int]
) -> Entity:
    """Resolve a Blue Book vote to an entity, creating it if new.

    Vote 1xxx are executive MDAs (ministries and state departments —
    the DB already types state departments as MINISTRY, e.g. "The State
    Department for Correctional Services"); vote 2xxx are constitutional
    commissions and independent offices.
    """
    county = _county_entity(session, name)
    if county is not None:
        return county

    slug = slugify_entity(name, county_suffix=False)
    entity = session.execute(
        select(Entity).where(Entity.slug == slug)
    ).scalar_one_or_none()
    if entity is not None:
        return entity
    etype = (
        EntityType.COMMISSION
        if vote is not None and vote >= 2000
        else EntityType.MINISTRY
    )
    entity = Entity(
        country_id=country_id,
        type=etype,
        canonical_name=name,
        slug=slug,
        meta={"vote": vote, "created_by": "seeding.audits.loader"},
    )
    session.add(entity)
    session.flush()
    logger.info("Created entity %s (%s, vote %s)", name, etype.value, vote)
    return entity


def _ensure_period(
    session: Session, country_id: int, fy_label: str
) -> FiscalPeriod:
    canonical = normalize_fiscal_label(fy_label)
    period = session.execute(
        select(FiscalPeriod).where(
            and_(
                FiscalPeriod.country_id == country_id,
                FiscalPeriod.label == canonical,
            )
        )
    ).scalar_one_or_none()
    if period is None:
        # canonical is "FY{Y1}/{Y2-short}"; Kenya FY runs 1 Jul → 30 Jun.
        y1 = int(canonical[2:6])
        period = FiscalPeriod(
            country_id=country_id,
            label=canonical,
            start_date=datetime.combine(
                datetime(y1, 7, 1).date(), time.min, tzinfo=timezone.utc
            ),
            end_date=datetime.combine(
                datetime(y1 + 1, 6, 30).date(), time.max, tzinfo=timezone.utc
            ),
        )
        session.add(period)
        session.flush()
    return period


#: How many extraction ids go into one ``IN (...)``. Postgres would take all
#: 2,311 in one statement; SQLite's default host-parameter ceiling is 999,
#: and the tests run on SQLite. 500 keeps both happy and still turns the
#: largest document's 986 round trips into 2.
_LOOKUP_CHUNK = 500


def _audit_lookup():
    """Only fields this loader compares or updates, for both lookup paths.

    Retain ORM mutation/duplicate refusal semantics while omitting unrelated
    management responses, actions and other stored publication details.
    """
    return select(Audit).options(load_only(
        Audit.id, Audit.extraction_id, Audit.entity_id, Audit.period_id,
        Audit.finding_text, Audit.severity, Audit.amount, Audit.page_ref,
        Audit.source_hash, Audit.audit_opinion, Audit.external_reference,
        Audit.provenance,
    ))


def _audits_by_extraction_id(session: Session, extraction_ids: list) -> dict:
    """Existing audit rows for these extractions, keyed by extraction_id.

    Raises on a duplicate rather than picking one. ``audits.extraction_id``
    is indexed but NOT unique (models.py), so the module docstring's "one
    extraction, one audit row" is an invariant this code path upholds rather
    than one the schema enforces. The per-row lookup this replaces used
    ``scalar_one_or_none()``, which raised ``MultipleResultsFound`` on a
    duplicate; a dict build would instead keep whichever row came back last
    and carry on. Swapping a loud failure for a silent arbitrary choice is
    not a performance improvement.
    """
    found: dict = {}
    for start in range(0, len(extraction_ids), _LOOKUP_CHUNK):
        chunk = extraction_ids[start : start + _LOOKUP_CHUNK]
        for audit in (
            session.execute(_audit_lookup().where(Audit.extraction_id.in_(chunk)))
            .scalars()
            .all()
        ):
            clash = found.get(audit.extraction_id)
            if clash is not None and clash.id != audit.id:
                raise MultipleResultsFound(
                    f"audits {clash.id} and {audit.id} both claim extraction "
                    f"{audit.extraction_id}; the loader's one-extraction-one-row "
                    "invariant is broken and the fact table has a duplicate"
                )
            found[audit.extraction_id] = audit
    return found


def load_blue_book_extractions(
    session: Session,
    doc: SourceDocument,
    settings: SeedingSettings,
    context: DomainRunContext,
    *,
    fresh_extraction_ids: Collection[int] = (),
) -> PersistenceStats:
    """Extractions of ``doc`` → audit rows, provenance columns populated.

    ``fresh_extraction_ids`` are extractions the caller created in THIS
    transaction, not yet committed. For those, the per-row confirming SELECT
    below is skipped. It guards against another writer inserting an audit
    for the same extraction mid-loop, and for these rows that cannot happen.
    The rows are invisible to every other transaction until commit, the only
    code that writes an audit for an extraction first SELECTs it, and
    ``audits.extraction_id`` is a foreign key, so no audit can name an
    extraction its writer cannot see. The saving is not small. A combined
    county volume creates 500-1,300 findings, at ~0.1s a round trip to
    production.
    """
    from .scope import (
        parse_manifest,
        verify_registered,
        verify_fetched,
        verify_extraction_evidence,
        AuditSourceScopeError,
    )

    source_entries = parse_manifest(context.audits_source_manifest)
    if source_entries is not None:
        entry = next((e for e in source_entries if e["source_url"] == doc.url), None)
        if entry is None:
            raise AuditSourceScopeError("loader offered an unlisted source")
        from ...source_registry import SOURCE_REGISTRY
        from models import DocumentType

        dataset = SOURCE_REGISTRY["oag_county_audits"]
        verify_registered(
            session,
            [entry],
            country_id=doc.country_id,
            publisher=dataset.publisher,
            doc_type=DocumentType[dataset.doc_type],
        )
        verify_fetched(
            doc,
            entry,
            country_id=doc.country_id,
            publisher=dataset.publisher,
            doc_type=DocumentType[dataset.doc_type],
        )
        verify_extraction_evidence(session, doc, entry)

    fresh = set(fresh_extraction_ids)
    stats = PersistenceStats()
    # Lookup caches for this document. Scoped per call, not module-level, so
    # nothing leaks between documents or between runs.
    _entity_cache: dict = {}
    _period_cache: dict = {}

    extractions = (
        session.execute(
            select(Extraction).where(
                and_(
                    Extraction.source_document_id == doc.id,
                    Extraction.extractor.in_(LOADED_EXTRACTORS),
                )
            )
        )
        .scalars()
        .all()
    )
    # Full extracted_json remains necessary: source_hash_of binds the complete
    # canonical payload, including keys not displayed by the public endpoint.
    if not extractions:
        logger.info(
            "No %s extractions for document %s", "/".join(LOADED_EXTRACTORS), doc.id
        )
        return stats

    # One round trip for all of this document's audit rows, not one per
    # extraction.
    #
    # The entity and period lookups were memoised for exactly this reason
    # (see the comment in the loop). The `existing` lookup was left as a
    # SELECT per extraction, and it is the one that runs on EVERY extraction
    # — the caches skip the other two after the first hit.
    #
    # OBSERVED on the nightly, from the gap between "already extracted …
    # skipping" and "publishable backfill" with nothing logged in between:
    #
    #   run 35048000013  813→84.0s  986→99.2s  512→54.0s   96ms/row  R²=0.999
    #   run 35174426953  813→123.6s 986→140.8s 512→76.9s  137ms/row  R²=0.989
    #   run 35299414702  813→85.7s  986→100.6s 512→54.8s   97ms/row  R²=0.998
    #
    # Linear in the extraction COUNT with a ~5-8s intercept — the signature
    # of one round trip per row against a remote database, not of the
    # backfill (which is the intercept). 2,311 extractions across the three
    # documents, 0 created and 0-1 updated every night: 222-317s a run spent
    # asking 2,311 times whether anything had changed, and being told no.
    existing_by_extraction = _audits_by_extraction_id(
        session, [e.id for e in extractions]
    )

    for ext in extractions:
        stats.processed += 1
        payload = ext.extracted_json or {}
        fy = payload.get("fiscal_year")
        name = payload.get("entity_name")
        text = payload.get("finding_text")
        sev = _SEVERITY_MAP.get(payload.get("severity", ""))
        if not (fy and name and text and sev):
            # An extraction the loader cannot attribute is left in
            # extractions (it IS the evidence) but produces no fact row.
            msg = (
                f"extraction {ext.id}: missing "
                f"{'fiscal_year' if not fy else 'entity/text/severity'}"
            )
            logger.warning("Skipping %s", msg)
            stats.errors.append(msg)
            stats.skipped += 1
            continue

        # Memoised per run. Every finding used to cost its own SELECT for the
        # entity and another for the period, and a consolidated county volume
        # carries ~1,500 findings against 47 entities and ONE fiscal year.
        # Measured at 221 ms per round-trip to the production database, that
        # is ~1,000s of lookups against a 600s domain budget — which is what
        # aborted the 2026-09-05 run, not OCR (only 4 pages of 701 qualify).
        try:
            ekey = (name, payload.get("vote"))
            if ekey in _entity_cache:
                entity = _entity_cache[ekey]
            else:
                entity = _ensure_entity(
                    session, doc.country_id, name, payload.get("vote")
                )
                _entity_cache[ekey] = entity
        except CountyEntityUnresolved as exc:
            # Never invent an entity for a finding: a public audit finding
            # filed against a county row we made up is worse than one absent.
            logger.warning("Skipping finding — %s", exc)
            stats.errors.append(str(exc))
            stats.skipped += 1
            continue
        if fy in _period_cache:
            period = _period_cache[fy]
        else:
            period = _ensure_period(session, doc.country_id, fy)
            _period_cache[fy] = period

        amounts = payload.get("amounts") or []
        amount = amounts[0] if len(amounts) == 1 else None
        vote = payload.get("vote")
        para = payload.get("paragraph_no")
        county_volume = payload.get("schema") == oag_county_volume.SCHEMA
        if county_volume:
            # The executives and assemblies volumes BOTH number their chapters
            # 1..47, so "V1" alone names two different auditees. The FY2020/21
            # rows loaded under that form share 28 references between the two
            # volumes on production. E/A keeps each one unique.
            role = "E" if payload.get("volume_kind") == "executives" else "A"
            reference = f"OAG-CV-{fy}-{role}{payload.get('chapter_no')}-P{para}"
        else:
            reference = f"OAG-BB-{fy}-V{vote}-P{para}"
        page_ref = f"p.{payload.get('pdf_page')}"

        from ...pdf_artifact import BINDING_KEY, valid_binding

        binding = payload.get(BINDING_KEY)
        # Older extractions keep their own artifact, even after a reissue.
        # Missing legacy binding is explicit absence, never filled from doc.
        bound_artifact = binding["artifact"] if valid_binding(binding) else None
        prov_entry = {
            "source": ext.extractor,
            "reference": reference,
            "source_url": doc.url,
            "source_md5": bound_artifact["md5"] if bound_artifact else doc.md5,
            "pdf_page": payload.get("pdf_page"),
            "printed_page": payload.get("printed_page"),
            "subreport": payload.get("subreport"),
            "opinion": payload.get("opinion"),
            "heading": payload.get("heading"),
            "sub_section": payload.get("sub_section"),
            "title": payload.get("title"),
            "amounts": amounts,
            "extraction_id": ext.id,
            "extraction_method": payload.get("extraction_method"),
        }
        if bound_artifact is not None:
            prov_entry[BINDING_KEY] = binding
        if county_volume:
            prov_entry.update(
                volume_kind=payload.get("volume_kind"),
                chapter_no=payload.get("chapter_no"),
                auditee=payload.get("auditee"),
                fiscal_year_sources=payload.get("fiscal_year_sources"),
            )

        # Read from the batch. A HIT is final — the snapshot was taken after
        # this session's own flush, and nothing else rewrites an audit's
        # extraction_id.
        #
        # A MISS is confirmed against the database before inserting. The
        # snapshot is taken once and the loop runs for 55-141s per document
        # on production; `audits.extraction_id` is indexed but NOT unique, so
        # a row landing inside that window would be invisible here and this
        # loop would insert a second audit for the same extraction. That is
        # silent tonight — a duplicated published finding — and a hard
        # failure tomorrow, when _audits_by_extraction_id raises on the pair.
        #
        # The confirming SELECT costs NOTHING on the run this change is for:
        # the nightly creates 0 rows, so every lookup is a hit and never
        # reaches it. It costs one round trip per genuinely-new finding on a
        # night that is writing anyway. It also restores the `IS NULL`
        # semantics of the predicate it replaced, which `IN (NULL)` does not
        # have.
        existing = existing_by_extraction.get(ext.id)
        if existing is None and ext.id not in fresh:
            existing = session.execute(
                _audit_lookup().where(Audit.extraction_id == ext.id)
            ).scalar_one_or_none()

        if context.dry_run:
            stats.created += 0 if existing else 1
            continue

        audit_year = int(fy.split("/")[0]) + 1 if "/" in fy else None
        if existing is None:
            session.add(
                Audit(
                    entity_id=entity.id,
                    period_id=period.id,
                    finding_text=text,
                    severity=sev,
                    recommended_action=None,
                    source_document_id=doc.id,
                    provenance=[prov_entry],
                    query_type=payload.get("subreport"),
                    amount=amount,
                    status="published_report",
                    audit_opinion=payload.get("opinion"),
                    audit_year=audit_year,
                    external_reference=reference,
                    extraction_id=ext.id,
                    page_ref=page_ref,
                    source_hash=source_hash_of(payload),
                    confidence_score=(
                        float(ext.confidence) if ext.confidence is not None else None
                    ),
                    basis=FigureBasis.ACTUAL,
                )
            )
            stats.created += 1
        else:
            changed = False
            for attr, value in (
                ("entity_id", entity.id),
                ("period_id", period.id),
                ("finding_text", text),
                ("severity", sev),
                ("amount", amount),
                ("page_ref", page_ref),
                ("source_hash", source_hash_of(payload)),
                ("audit_opinion", payload.get("opinion")),
                ("external_reference", reference),
            ):
                if getattr(existing, attr) != value:
                    setattr(existing, attr, value)
                    changed = True
            if existing.provenance != [prov_entry]:
                existing.provenance = [prov_entry]
                changed = True
            if changed:
                stats.updated += 1

    session.flush()

    # The gate's verdict, written by the gate itself — never recomputed here.
    if not context.dry_run:
        from services.publication_gate import backfill_publishable_audits

        if source_entries is None:
            backfill_publishable_audits(session)
        else:
            backfill_publishable_audits(session, source_document_ids=[doc.id])

    logger.info(
        "Loaded blue-book extractions for doc %s: %d created, %d updated, "
        "%d skipped",
        doc.id,
        stats.created,
        stats.updated,
        stats.skipped,
    )
    return stats


__all__ = ["load_blue_book_extractions"]
