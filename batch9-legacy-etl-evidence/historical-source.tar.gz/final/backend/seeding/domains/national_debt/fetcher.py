"""Fetcher for Kenya national-government debt data.

Strategy
--------
1. Load the fixture as the baseline payload — it covers every lender
   we display (multilateral, bilateral, commercial, domestic) with
   reasonable values that move slowly.

2. Overlay World Bank IDS rows on top of the baseline. WB IDS is the
   only machine-readable per-creditor source for Kenya external debt
   (see wb_ids.py for why CBK + Treasury PDF paths were retired).
   Any lender we successfully fetch from WB UPDATES the matching
   fixture row in-place; lenders WB doesn't break out (specific
   bilateral countries) keep their fixture values.

3. Overlay CBK Statistical Bulletin Table 4.1.4 ("Composition of
   Government Gross Domestic Debt by Instrument") on top, when the
   bulletin URL is configured. CBK is the only live source for the
   per-instrument domestic split (T-bills/T-bonds/overdraft). See
   ``cbk_bulletin.py`` for the parsing approach (text-mode regex
   because pdfplumber's table extractor smushes the cells).

When the external pull is quarantined, this publishes NOTHING
------------------------------------------------------------
Step 2's replacement is gated (see ``wb_ids_creditors``). When a gate refuses
the pull, this fetcher raises ``DebtRegisterIncomplete`` rather than returning
a payload carrying the fixture's external rows.

It used to return them, and that is the more dangerous behaviour. Measured on a
live run with the pull forced to quarantine, the fixture publishes a **13.34T**
headline against the gated register's 12.22T — Eurobonds at 2,276Bn where IDS
reports ~890Bn, syndicated banks at 400Bn against ~124Bn. So a gate doing its
job correctly would have put the worst number in this codebase on the homepage,
loudly in the log and invisibly on the page.

Raising fails the domain with zero writes (``__init__.run`` catches it), so the
previous seed's rows stand and the freshness/staleness gates see a run that did
not reach its publisher — recorded as ``freshness.REFUSED``, which is neither
"live" nor "fixture", because nothing was served either way. Stale and correct
beats fresh and 1.1T wrong.

Two things this deliberately does NOT do. It does not drop the external rows
and publish a domestic-only 6.76T — that is a different wrong number, not a
safer one. And it does not apply when ``live_pdf_fetch_enabled`` is False,
which is the offline/dev path where the fixture is the declared source.

Why we dropped the CBK PDF discovery path
-----------------------------------------
The original `_fetch_from_cbk_pdf` scraped
https://www.centralbank.go.ke/public-debt/ for "debt-bulletin"
PDFs. CBK's content reorganization left that page with five PDFs,
none of which are debt bulletins (auction rules, repo agreement,
diaspora remittances, etc.). The CBK Public Debt Statistical
Bulletin moved into the broader CBK Statistical Bulletin under
/releases/statistical-bulletin/ and the published format is now
aggregated by instrument type, not by lender — so even a successful
discovery wouldn't have given us the per-loan rows the original
parser expected. See PR #75 for the full investigation.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

from ...config import SeedingSettings
from ...http_client import SeedingHttpClient
from ...utils import load_json_resource
from .cbk_bulletin import fetch_domestic_debt_from_cbk_bulletin
from .cbk_web_tables import check_bond_coverage, fetch_bond_register, partition_ambiguous
from .cbk_web_tables import fetch_public_debt_monthly, fetch_tbill_91d_yield
from .wb_ids_creditors import fetch_external_creditors
from .wb_ids import fetch_external_debt_from_wb_ids

logger = logging.getLogger("seeding.national_debt.fetcher")


class DebtRegisterIncomplete(RuntimeError):
    """The register could not be assembled, so nothing may be published.

    Raised instead of returning a payload whose external rows are the fixture's.
    The domain's ``run`` turns this into a failed run with zero writes, which
    leaves the previous seed's rows in place — see the module docstring for why
    publishing the fixture is the worse of the two.
    """


# Domestic bond rows in the loans payload.
#
# Infrastructure and green bonds are Treasury bonds in CBK's own
# classification: they sit INSIDE the Table 4.1.4 "Treasury Bonds" line, and
# the fixture's own note on that row says so ("Includes infrastructure bonds",
# national_debt.json). The payload nonetheless carries a separate KES 300B
# "Domestic Infrastructure & Green Bonds" row, so matching it here added those
# bonds to the denominator a second time — inflating the published bond stock
# by 300B and able to flip the coverage gate's verdict.
#
# Match the inclusive Treasury-bonds aggregate only. Eurobonds are external
# commercial debt and must not appear here either.
#
# NOTE: excluding the subset here only ever fixed the coverage-gate
# DENOMINATOR. The row itself stayed in the loans payload and went on being
# summed into the published headline, which is the KSh 300Bn double-count
# _drop_subsumed_rows below removes from the register itself.
_DOMESTIC_BOND_MARKERS = ("treasury bond", "domestic bond")
_NOT_A_DOMESTIC_BOND = ("eurobond", "external", "syndicated", "commercial bank")


@dataclass(frozen=True)
class _SubsumedRow:
    """A row another row in the same category already counts."""

    #: Lender substrings (lowercased) that identify the subset row.
    subset_markers: Tuple[str, ...]
    #: Lender substring that identifies the aggregate containing it.
    aggregate_marker: str
    #: The category both must be in. A subset is only subsumed within the
    #: bucket its aggregate is published in.
    category: str
    #: The published classification that says the aggregate contains it.
    because: str


# Subsets the register must never carry beside their own aggregate.
#
# CBK's Statistical Bulletin Table 4.1.4 ("Composition of Government Gross
# Domestic Debt by Instrument") publishes ONE Treasury Bonds column, and that
# column is the whole bond stock — infrastructure and green bonds are Treasury
# bonds in CBK's classification, sit inside it, and get no line of their own.
# ``cbk_bulletin._COLUMN_MAPPINGS`` maps that column straight onto the
# "Domestic Treasury Bonds" row here, so the aggregate is inclusive by
# construction and there is no published figure that would make it exclusive:
# netting 300B off it would be inventing a split CBK does not publish, and the
# next bulletin overlay would overwrite it anyway. The subset row is what goes.
_SUBSUMED_ROWS: Tuple[_SubsumedRow, ...] = (
    _SubsumedRow(
        subset_markers=("infrastructure bond", "infrastructure &", "green bond"),
        aggregate_marker="treasury bond",
        category="domestic_bonds",
        because=(
            "CBK Statistical Bulletin Table 4.1.4 publishes a single Treasury "
            "Bonds column and infrastructure and green bonds are inside it"
        ),
    ),
)


# Categories the IDS creditor pull owns outright. When it succeeds, every
# fixture row in these categories is dropped: keeping them beside the real
# creditors would count the same debt twice.
_EXTERNAL_CATEGORIES = {
    "external_multilateral",
    "external_bilateral",
    "external_commercial",
}


def _cbk_published_external_kes(client, settings, year: int) -> float | None:
    """CBK's own external-debt total FOR ``year``, for the IDS coverage gate.

    The denominator must be independent of the thing it checks AND of the same
    vintage. Two sources, in order:

      1. CBK's monthly /public-debt/ table, if it carries that year. Every row
         there must satisfy CBK's own domestic + external = total before the
         parser will emit it.
      2. The CBK Statistical Bulletin series (Table 4.1.3) carried in
         debt_timeline.json, which is where 2022 onwards comes from and which
         cites its table and page per row.

    Returns ``None`` — which quarantines the pull — when neither publishes that
    year. That matters in practice: /public-debt/ is currently frozen at
    2021-12, so measuring a 2024 IDS pull against its newest row gives a 1.20x
    ratio and quarantines every pull for a reason that is about CBK's website,
    not about the data.
    """
    try:
        series = fetch_public_debt_monthly(client, settings)
        rows = [
            r
            for r in (series.get("rows") or [])
            if r.identity_holds() and r.year == year
        ]
        if rows:
            newest = max(rows, key=lambda r: r.month)
            logger.info(
                "IDS coverage denominator: CBK /public-debt/ external "
                "KES %.3fT as of %04d-%02d",
                newest.external_kes / 1e12, newest.year, newest.month,
            )
            return newest.external_kes or None
        logger.info(
            "CBK /public-debt/ does not publish %d (it covers %s); trying the "
            "Statistical Bulletin series",
            year, series.get("covers"),
        )
    except Exception as exc:
        logger.warning("CBK /public-debt/ unavailable: %s", exc)

    try:
        from pathlib import Path
        import json as _json

        path = Path(__file__).resolve().parents[2] / "real_data" / "debt_timeline.json"
        rows = _json.loads(path.read_text(encoding="utf-8")).get("timeline", [])
        match = next((r for r in rows if r.get("year") == year), None)
        if match and match.get("external") and "cbk" in str(match.get("source", "")).lower():
            # The fixture carries billions.
            external = float(match["external"]) * 1e9
            logger.info(
                "IDS coverage denominator: %s — external KES %.3fT for %d",
                match.get("source"), external / 1e12, year,
            )
            return external
    except Exception as exc:
        logger.warning("debt-timeline denominator unavailable: %s", exc)

    logger.warning(
        "No CBK external total published for %d, so the IDS pull has nothing "
        "independent of the same vintage to check against; quarantining", year
    )
    return None


def _replace_external_loans(
    payload: Dict[str, Any], creditor_rows: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """Swap every external row for the IDS creditor rows, leaving domestic
    and pending-bill rows untouched."""
    kept = [
        loan
        for loan in payload.get("loans", [])
        if (loan.get("debt_category") or "") not in _EXTERNAL_CATEGORIES
    ]
    return {**payload, "loans": kept + list(creditor_rows)}


def _row_amount_kes(loan: Dict[str, Any]) -> float:
    """A loan row's shilling amount, or 0.0 when it carries none."""
    try:
        return float(loan.get("outstanding") or loan.get("principal") or 0)
    except (TypeError, ValueError):
        return 0.0


def _lender_key(loan: Dict[str, Any]) -> str:
    return " ".join((loan.get("lender") or "").lower().split())


def _drop_subsumed_rows(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Remove rows another row in the same category already counts.

    Runs on the FINAL register, after every overlay, because that list is what
    gets summed into the published headline. Until this existed, the
    ``domestic_bonds`` category held both CBK's inclusive Treasury Bonds
    aggregate (5,579Bn) and a separate 300Bn infrastructure/green bond row that
    is a subset of it, and the site published 5,879Bn.

    A subset is dropped only when its aggregate is actually present in the same
    category: on its own it is the only bond row there is, and removing it
    would understate rather than correct.

    Loud on purpose — WARNING plus a metadata record — because a silent drop
    and a register that never had the row look identical from the outside.
    """
    loans: List[Dict[str, Any]] = list(payload.get("loans", []))
    kept: List[Dict[str, Any]] = []
    dropped: List[Dict[str, Any]] = []

    for loan in loans:
        lender = _lender_key(loan)
        category = loan.get("debt_category") or ""
        rule = next(
            (
                r
                for r in _SUBSUMED_ROWS
                if r.category == category
                and any(m in lender for m in r.subset_markers)
            ),
            None,
        )
        aggregate = (
            next(
                (
                    other
                    for other in loans
                    if other is not loan
                    and (other.get("debt_category") or "") == rule.category
                    and rule.aggregate_marker in _lender_key(other)
                ),
                None,
            )
            if rule is not None
            else None
        )
        if rule is None or aggregate is None:
            kept.append(loan)
            continue

        amount = _row_amount_kes(loan)
        dropped.append(
            {
                "lender": loan.get("lender"),
                "debt_category": category,
                "amount_kes": amount,
                "already_counted_by": aggregate.get("lender"),
                "reason": rule.because,
            }
        )
        logger.warning(
            "Dropping %s (KES %.1fBn, %s): %s already counts it — %s. Carrying "
            "both would publish the same debt twice.",
            loan.get("lender"),
            amount / 1e9,
            category,
            aggregate.get("lender"),
            rule.because,
        )

    if not dropped:
        return payload

    meta = dict(payload.get("metadata", {}))
    meta["subsumed_rows_dropped"] = dropped
    meta["subsumed_rows_dropped_kes"] = sum(d["amount_kes"] for d in dropped)
    return {**payload, "loans": kept, "metadata": meta}


def _published_bond_stock_kes(payload: Dict[str, Any]) -> float | None:
    """CBK's own domestic Treasury-bond total from the loans payload.

    The denominator for the register's coverage gate. Read off the payload
    rather than hardcoded, so republishing the bond stock moves it instead of
    silently pushing the gate out of band.
    """
    total = 0.0
    for loan in payload.get("loans", []):
        lender = (loan.get("lender") or "").lower()
        if any(bad in lender for bad in _NOT_A_DOMESTIC_BOND):
            continue
        if any(marker in lender for marker in _DOMESTIC_BOND_MARKERS):
            try:
                total += float(loan.get("outstanding") or loan.get("principal") or 0)
            except (TypeError, ValueError):
                continue
    return total or None


#: Why a row with no publisher's rate carries none. Kept as data so a test can
#: hold the page to exactly these sentences.
NO_PUBLISHED_RATE_REASON = (
    "No publisher this site reads gives an interest rate or an interest-paid "
    "figure for this facility."
)
FIXTURE_ONLY_RATE_REASON = (
    "Live sources were not fetched on this run, and the April 2025 fixture's "
    "rates are not published."
)


def _strip_fixture_rates(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Remove the fixture's interest rates before anything can persist them.

    The fixture carries April-2025 rates (14.5% bonds, 16% bills, 1.25% World
    Bank ...). Nothing ever refreshed them: overlays carry no rate and the
    writer kept whatever was stored. CBK's 91-day yield was 8.778% the day
    this was measured, against the fixture's 16%. A rate either comes from a
    live publisher on this run, with its source, or is absent — see
    ``interest_terms``.
    """
    loans = []
    for loan in payload.get("loans", []):
        loan = dict(loan)
        loan["interest_rate"] = None
        loan.pop("interest_terms", None)
        loans.append(loan)
    return {**payload, "loans": loans}


def _bond_coupon_terms(
    loan: Dict[str, Any], bond_register: Dict[str, Any]
) -> Dict[str, Any] | None:
    """Face-weighted coupon over the CBK register, applied to the bond row.

    Arithmetic on published coupons, and the register sees only part of the
    stock (auction issues since 2007), so its coverage goes into the label
    rather than a footnote nobody reads.
    """
    from .interest_terms import published_rate_terms

    priced = [
        s
        for s in bond_register.get("securities", [])
        if s.get("coupon_rate") is not None and (s.get("face_value_kes") or 0) > 0
    ]
    face = sum(float(s["face_value_kes"]) for s in priced)
    if not priced or face <= 0:
        return None
    rate = sum(float(s["face_value_kes"]) * float(s["coupon_rate"]) for s in priced) / face
    coverage = (bond_register.get("coverage") or {}).get("coverage_ratio")
    coverage_text = f", {coverage:.0%} of the bond stock" if coverage else ""
    return published_rate_terms(
        rate_pct=rate,
        basis="coupon_weighted_average",
        label=(
            f"Average coupon of the {len(priced)} bonds in CBK's register, "
            f"weighted by face value{coverage_text}"
        ),
        source={
            "publisher": "Central Bank of Kenya",
            "title": bond_register.get("source_title") or "CBK — Issues of Treasury Bonds",
            "url": bond_register.get("source_url"),
            "as_of": bond_register.get("as_of"),
        },
        outstanding_kes=_row_amount_kes(loan),
        cost_label=(
            "Modelled: balance × the register's average coupon. The register "
            "does not cover the whole stock."
        ),
    )


def _tbill_yield_terms(loan: Dict[str, Any], tbill: Dict[str, Any]) -> Dict[str, Any]:
    from .interest_terms import published_rate_terms

    rate = tbill["rate"]
    return published_rate_terms(
        rate_pct=rate.rate_pct,
        basis="auction_yield",
        label=(
            f"CBK's 91-day T-bill yield (publisher date: {rate.cbk_date_text or 'not stated'}; "
            "date meaning unconfirmed). The stock also "
            "holds 182- and 364-day bills sold at other auctions and rates."
        ),
        source={
            "publisher": "Central Bank of Kenya",
            "title": tbill["source_title"],
            "url": tbill["source_url"],
            "as_of": None,
            "publisher_date": rate.cbk_date.isoformat() if rate.cbk_date else None,
            "publisher_date_text": rate.cbk_date_text,
            "date_basis": "publisher_date_meaning_unconfirmed",
            "retrieved_at": tbill["retrieved_at"],
        },
        outstanding_kes=_row_amount_kes(loan),
        cost_label=(
            "Modelled: balance × the 91-day yield. Not a published interest "
            "figure for the bill stock."
        ),
    )


def _declare_interest_terms(
    payload: Dict[str, Any],
    bond_register: Dict[str, Any] | None,
    tbill: Dict[str, Any] | None,
    default_reason: str = NO_PUBLISHED_RATE_REASON,
) -> Dict[str, Any]:
    """Give every row an interest declaration — a sourced value or a reason.

    Rows the IDS pull built already carry theirs. Domestic rows get CBK's
    figures where CBK publishes one this run; every other row is declared
    absent with ``default_reason``, so no row reaches the writer undeclared.
    """
    from .interest_terms import absent_terms, validate_terms

    declared: List[Dict[str, Any]] = []
    counts: Dict[str, int] = {}
    for loan in payload.get("loans", []):
        loan = dict(loan)
        terms = loan.get("interest_terms")
        category = loan.get("debt_category") or ""
        if terms is None and category == "domestic_bonds" and bond_register:
            if "treasury bond" in _lender_key(loan):
                terms = _bond_coupon_terms(loan, bond_register)
        if terms is None and category == "domestic_bills" and tbill:
            terms = _tbill_yield_terms(loan, tbill)
        if terms is None or validate_terms(terms):
            if terms is not None:
                logger.warning(
                    "Interest terms for %s failed validation and are withheld: %s",
                    loan.get("lender"), validate_terms(terms),
                )
            terms = absent_terms(default_reason)
        loan["interest_terms"] = terms
        # The column mirrors the declaration and nothing else: a published
        # rate, or NULL. Never the fixture's, never a manufactured 0.
        # Rounded to the column's precision (Numeric(5,2)) so the writer's
        # change check compares like with like instead of seeing a new rate
        # on every run. The declaration keeps the full figure.
        loan["interest_rate"] = (
            round(terms["rate_pct"], 2) if terms["rate_pct"] is not None else None
        )
        declared.append(loan)
        kind = (
            f"cost:{terms['annual_cost_basis']}"
            if terms["annual_cost_kes"] is not None
            else "cost:absent"
        )
        counts[kind] = counts.get(kind, 0) + 1

    meta = dict(payload.get("metadata", {}))
    meta["interest_terms_declared"] = counts
    logger.info("Interest declarations: %s", counts)
    return {**payload, "loans": declared, "metadata": meta}


def fetch_debt_payload(
    client: SeedingHttpClient, settings: SeedingSettings
) -> dict[str, Any]:
    """Return a debt payload combining fixture baseline with live WB IDS."""

    # ── Baseline: fixture ──────────────────────────────────────────
    payload = _strip_fixture_rates(
        load_json_resource(
            url=settings.national_debt_dataset_url,
            client=client,
            logger=logger,
            label="national_debt",
        )
    )

    if not settings.live_pdf_fetch_enabled:
        logger.info("Live fetch disabled; using fixture for national debt")
        return _declare_interest_terms(
            _drop_subsumed_rows(payload), None, None, FIXTURE_ONLY_RATE_REASON
        )

    # ── Overlay: World Bank IDS per-creditor external debt ─────────
    try:
        wb_loans = fetch_external_debt_from_wb_ids(client, settings)
    except Exception as exc:
        logger.warning("WB IDS fetch failed entirely: %s", exc)
        wb_loans = []

    if wb_loans:
        before = len(payload.get("loans", []))
        payload = _overlay_loans(payload, wb_loans)
        after = len(payload.get("loans", []))
        logger.info(
            "Merged %d WB IDS rows into national debt payload "
            "(loans: %d → %d)",
            len(wb_loans),
            before,
            after,
        )
        # Surface that we did the overlay so downstream consumers /
        # admin dashboards can show "data freshness: WB IDS YYYY".
        meta = dict(payload.get("metadata", {}))
        meta["wb_ids_overlay_applied"] = True
        meta["wb_ids_overlay_count"] = len(wb_loans)
        payload["metadata"] = meta

    # ── REPLACE: external debt, by individual creditor ─────────────
    # Not an overlay. A successful, gated IDS pull replaces every external
    # fixture row, because the two describe the same debt under different
    # names and appending would double-count it — which is what the lender
    # treemap was withdrawn over.
    #
    # The fixture's external rows are round numbers that overstate the book.
    # Against IDS 2024: Eurobonds 2,276Bn where IDS reports 858Bn (+165%),
    # syndicated banks 400Bn against 120Bn (+234%). It also has no row at all
    # for creditors like the Eastern & Southern African Trade & Development
    # Bank, which lends Kenya USD 1.43bn.
    external_creditors = None
    ids_skip_reason: str | None = None
    try:
        external_creditors = fetch_external_creditors(
            client,
            settings,
            published_external_kes_for_year=lambda yr: _cbk_published_external_kes(
                client, settings, yr
            ),
        )
        if not external_creditors:
            # fetch_external_creditors logs its own reason, but only inside
            # itself. Record one HERE too: on the 2026-09-04 nightly this
            # replacement did not run and left no trace at all in the log or
            # the payload, so there was no way to tell a quarantine from a
            # block that never executed.
            ids_skip_reason = "returned_no_creditors"
    except Exception as exc:
        ids_skip_reason = f"{type(exc).__name__}: {exc}"[:200]
        logger.warning("IDS creditor fetch failed entirely: %s", exc)

    if external_creditors:
        payload = _replace_external_loans(payload, external_creditors["loans"])
        meta = dict(payload.get("metadata", {}))
        meta["ids_creditor_replacement_applied"] = True
        meta["ids_creditor_year"] = external_creditors["year"]
        meta["ids_creditor_count"] = len(external_creditors["creditors"])
        meta["ids_creditor_coverage"] = external_creditors["coverage"]
        payload["metadata"] = meta
        logger.info(
            "Replaced the external fixture rows with %d IDS creditors (%s)",
            len(external_creditors["creditors"]),
            external_creditors["year"],
        )
    else:
        # PUBLISH NOTHING. Not the fixture.
        #
        # Falling back used to look like the cautious option. It is the
        # opposite. Measured on a live run with the pull forced to quarantine,
        # what the fixture publishes is:
        #
        #   external              6,584.7Bn   (against 5,465.8 from the pull)
        #     Eurobonds             2,276.0Bn — IDS reports ~890Bn, 2.6x
        #     Commercial banks        400.0Bn — IDS reports ~124Bn, 3.2x
        #   HEADLINE                  13.34T   (against 12.22T)
        #
        # So the gate firing correctly would put the single worst number in
        # this codebase on the homepage — 1.1T above the register, and roughly
        # the figure the 2026-09-06 audit was opened over. Loud in the log,
        # invisible on the page. A gate whose failure mode is worse than its
        # success is not protecting anything.
        #
        # Raising instead fails the domain with zero writes, so the PREVIOUS
        # seed's rows stand and the staleness gate sees a run that did not
        # reach the publisher — recorded as freshness.REFUSED just below, so
        # the nightly can name the refusal instead of guessing at it. Stale
        # and correct beats fresh and 1.1T wrong.
        #
        # Note this also abandons the CBK domestic overlay for the run, which
        # is deliberate: the register is published as one total, and half of it
        # refreshed beside a stale half is the mixed-basis problem in miniature.
        # It is raised HERE, before the bulletin download, so a run that is
        # already going to be refused does not spend the domain's time budget
        # fetching a PDF it will discard.
        reason = ids_skip_reason or "not_attempted"
        logger.error(
            "IDS creditor replacement did NOT apply (%s). REFUSING to publish "
            "the national-debt register: the fixture's external rows overstate "
            "the book (Eurobonds 2,276Bn against IDS's ~890Bn) and would put "
            "~13.34T on the page against the register's ~12.22T. This run "
            "writes nothing; the previous seed's rows stand.",
            reason,
        )
        # Record the refusal BEFORE raising, or it is not recorded at all.
        #
        # mark_live/mark_fixture sit at the end of this function and the raise
        # jumps over both, so this run used to reach the job row with
        # source_mode="unknown" — and the nightly rendered that as "served
        # from a FIXTURE in all 1 recent run(s) ... (reasons: unrecorded)".
        # Right severity, false prose: no fixture was served, nothing at all
        # was served, and the reason was already in job.errors.
        #
        # NOT mark_fixture(reason=...), which would make the message read
        # correctly by putting a false statement in the provenance record.
        # See freshness.REFUSED.
        from ...freshness import mark_refused

        mark_refused(
            "national_debt",
            reason="external_register_incomplete",
            detail=(
                f"IDS creditor replacement did not apply ({reason}); the "
                f"fixture's external rows would have published ~13.34T "
                f"against the register's ~12.22T"
            ),
        )
        raise DebtRegisterIncomplete(
            f"external creditor pull did not apply ({reason}), so the register "
            f"would have published the fixture's external rows — which "
            f"overstate the book by ~1.1T. Nothing was written; the previous "
            f"seed's rows stand. Fix the pull (see the wb_ids_creditors "
            f"warnings above for which gate refused it) rather than relaxing a "
            f"gate."
        )

    # ── Overlay: CBK Statistical Bulletin domestic debt ────────────
    # Disjoint from WB IDS — CBK covers the domestic instruments
    # (T-bills, T-bonds, overdraft) that IDS doesn't publish. Same
    # overlay merge: fixture lender names that match get replaced;
    # new lenders (Advances, Other) get appended.
    try:
        cbk_loans = fetch_domestic_debt_from_cbk_bulletin(client, settings)
    except Exception as exc:
        logger.warning("CBK bulletin fetch failed entirely: %s", exc)
        cbk_loans = []

    if cbk_loans:
        before = len(payload.get("loans", []))
        payload = _overlay_loans(payload, cbk_loans)
        after = len(payload.get("loans", []))
        logger.info(
            "Merged %d CBK bulletin rows into national debt payload "
            "(loans: %d → %d)",
            len(cbk_loans),
            before,
            after,
        )
        meta = dict(payload.get("metadata", {}))
        meta["cbk_bulletin_overlay_applied"] = True
        meta["cbk_bulletin_overlay_count"] = len(cbk_loans)
        payload["metadata"] = meta

    # ── Enforce: no row beside an aggregate that already counts it ──
    # After every overlay, because this is the list that gets summed into the
    # headline. See _drop_subsumed_rows.
    payload = _drop_subsumed_rows(payload)

    # ── Attach: instrument-level Treasury bond register ────────────
    # NOT an overlay. The register is a list of individual securities with
    # real maturities and coupons; it covers ~74% of CBK's published bond
    # stock, so summing it into the debt total would trade a correct total for
    # a lower wrong one. It rides alongside the loans payload as a maturity
    # and coupon profile, gated on coverage, and carries the ratio so no
    # consumer can mistake it for a stock measure.
    #
    # This is what the withdrawn maturity ladder needed: the loans payload has
    # three rows with a maturity date, and applied one assumed 14.5% coupon to
    # the entire bond book (credibility audit F24/F42).
    bond_register: Dict[str, Any] | None = None
    try:
        register = fetch_bond_register(client, settings)
        # Withhold the ISINs whose maturity this table cannot settle before
        # anything is measured or published. See partition_ambiguous.
        publishable, withheld = partition_ambiguous(register["securities"])
        published_bond_stock = _published_bond_stock_kes(payload)
        coverage = check_bond_coverage(publishable, published_bond_stock)
        if coverage["status"] == "out_of_band":
            logger.warning(
                "Treasury bond register quarantined: %s", coverage["reason"]
            )
        else:
            bond_register = {
                "source_url": register["source_url"],
                "source_title": register["source_title"],
                "retrieved_at": register["retrieved_at"],
                "as_of": register["as_of"],
                "tranche_rows": register["tranche_rows"],
                "coverage": coverage,
                "withheld_isins": withheld,
                "securities": [
                    {
                        "isin": s.isin,
                        "issue_no": s.issue_no,
                        "instrument_type": s.instrument_type,
                        "maturity_date": s.maturity_date.isoformat(),
                        "first_issued": s.first_issued.isoformat(),
                        "coupon_rate": s.coupon_rate,
                        "tenor_years": s.tenor_years,
                        "face_value_kes": s.face_value_kes,
                        "tranches": s.tranches,
                    }
                    for s in publishable
                ],
            }
            logger.info(
                "Treasury bond register: %d redemption lines from %d tranches "
                "(%d ISIN(s) withheld as ambiguous), %.0f%% of the published "
                "bond stock",
                len(bond_register["securities"]),
                register["tranche_rows"],
                len(withheld),
                (coverage["coverage_ratio"] or 0) * 100,
            )
    except Exception as exc:
        logger.warning("Treasury bond register fetch failed: %s", exc)

    if bond_register:
        payload = {**payload, "bond_register": bond_register}

    # ── Declare: what each row may publish about its interest ──────
    # After the register (the bond coupon comes from it) and after every
    # overlay (overlays replace whole row dicts, which is how a fixture rate
    # once survived beside a live balance).
    tbill = None
    try:
        tbill = fetch_tbill_91d_yield(client)
    except Exception as exc:  # noqa: BLE001 - the row then declares why
        logger.warning("CBK 91-day T-bill yield unavailable: %s", exc)
    payload = _declare_interest_terms(payload, bond_register, tbill)

    # Provenance: "live" requires that an authoritative overlay actually
    # landed. A fixture baseline with no overlay is fixture data, however
    # many creditors it lists.
    from ...freshness import mark_fixture, mark_live

    if cbk_loans or wb_loans:
        mark_live(
            "national_debt",
            detail=(
                f"CBK bulletin rows={len(cbk_loans)}, "
                f"WB IDS rows={len(wb_loans)}"
            ),
        )
    else:
        mark_fixture(
            "national_debt",
            reason="no_live_overlay_applied",
            detail="neither the CBK bulletin nor World Bank IDS returned rows",
        )

    return payload


def _overlay_loans(
    payload: Dict[str, Any], overlay: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """Replace any baseline loan whose ``lender`` matches an overlay
    row, then append any overlay rows that didn't match. Lender
    matching is case-insensitive + whitespace-collapsed so cosmetic
    drift in the source name doesn't fork rows.
    """

    def _key(loan: Dict[str, Any]) -> str:
        return " ".join((loan.get("lender") or "").lower().split())

    overlay_by_key = {_key(l): l for l in overlay}
    base_loans: List[Dict[str, Any]] = list(payload.get("loans", []))
    out: List[Dict[str, Any]] = []
    matched_keys: set[str] = set()
    for loan in base_loans:
        k = _key(loan)
        if k in overlay_by_key:
            out.append(overlay_by_key[k])
            matched_keys.add(k)
        else:
            out.append(loan)
    # Append overlay rows that didn't match any baseline lender so a
    # newly-tracked WB IDS creditor still lands in the DB.
    for k, loan in overlay_by_key.items():
        if k not in matched_keys:
            out.append(loan)
    return {**payload, "loans": out}


__all__ = ["fetch_debt_payload"]
