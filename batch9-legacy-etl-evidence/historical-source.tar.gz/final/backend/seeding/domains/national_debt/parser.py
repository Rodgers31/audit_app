"""Parser for National Treasury debt bulletin data."""

from __future__ import annotations

import logging
from datetime import datetime
from decimal import Decimal
from typing import Any

logger = logging.getLogger("seeding.national_debt.parser")


class DebtRecord:
    """Represents a parsed debt/loan record."""

    def __init__(
        self,
        entity_name: str,
        entity_type: str,
        lender: str,
        principal: Decimal,
        outstanding: Decimal,
        issue_date: datetime,
        maturity_date: datetime | None,
        currency: str,
        source_url: str | None = None,
        source_title: str | None = None,
        publisher: str | None = None,
        debt_category: str | None = None,
        interest_rate: Decimal | None = None,
        notes: str | None = None,
        interest_terms: dict | None = None,
        source_evidence: list | None = None,
        measurement_period: str | None = None,
    ):
        self.entity_name = entity_name
        self.entity_type = entity_type
        self.lender = lender
        self.principal = principal
        self.outstanding = outstanding
        self.issue_date = issue_date
        self.maturity_date = maturity_date
        self.currency = currency
        self.source_url = source_url
        self.source_title = source_title
        #: Who published THIS row. The national-debt payload is a CBK/Treasury
        #: bulletin, but the IDS creditor rows merged into it are World Bank
        #: data — attributing them to the Treasury would be a false citation.
        self.publisher = publisher
        self.debt_category = debt_category
        self.interest_rate = interest_rate
        self.notes = notes
        #: What this row may publish about its rate and annual cost — a
        #: sourced value or a reason there is none. See ``interest_terms``.
        self.interest_terms = interest_terms
        self.source_evidence = source_evidence
        self.measurement_period = measurement_period


def _declared(value: Any) -> str | None:
    """A declared label, or None when the payload declares nothing usable."""
    if not isinstance(value, str):
        return None
    return value.strip() or None


def _source_or_inherited(value: Any, inherited: Any) -> Any:
    """Inherit absent labels/locators, but retain malformed values for refusal."""
    if value is None or (isinstance(value, str) and not value.strip()):
        return inherited
    return value


def parse_debt_payload(payload: dict[str, Any]) -> list[DebtRecord]:
    """
    Parse debt payload into structured records.

    Expected payload format:
    {
        "loans": [
            {
                "entity_name": "National Government",
                "entity_type": "national",
                "lender": "World Bank",
                "principal": "50000000000.00",
                "outstanding": "45000000000.00",
                "issue_date": "2020-01-15",
                "maturity_date": "2030-01-15",
                "currency": "KES"
            }
        ],
        "source_url": "https://treasury.go.ke/...",
        "source_title": "Public Debt Bulletin Q3 2024"
    }

    Args:
        payload: Raw JSON payload from fetcher

    Returns:
        List of parsed DebtRecord objects
    """
    records: list[DebtRecord] = []
    loans_data = payload.get("loans", [])
    source_url = payload.get("source_url")
    # A display fallback is not a publisher's declaration of source identity.
    source_title = payload.get("source_title")
    # Who published the payload's own source. It belongs to ``source_url``, so
    # a row inherits it only when it inherits that URL too (issue #274).
    payload_publisher = _declared(payload.get("publisher"))

    logger.info(f"Parsing {len(loans_data)} debt records")

    for idx, loan_data in enumerate(loans_data, start=1):
        try:
            # Parse dates
            issue_date = datetime.fromisoformat(loan_data["issue_date"])
            maturity_date = None
            if loan_data.get("maturity_date"):
                maturity_date = datetime.fromisoformat(loan_data["maturity_date"])

            # Parse amounts
            principal = Decimal(str(loan_data["principal"]))
            outstanding = Decimal(str(loan_data["outstanding"]))

            # Parse optional interest rate. ``is not None``, not truthiness:
            # a published 0% is a rate, and an absent one is None — the old
            # ``if loan_data.get(...)`` could not tell them apart.
            interest_rate = None
            if loan_data.get("interest_rate") is not None:
                interest_rate = Decimal(str(loan_data["interest_rate"]))

            row_source_url = _source_or_inherited(
                loan_data.get("source_url"), source_url
            )
            row_source_title = _source_or_inherited(
                loan_data.get("source_title"),
                source_title if row_source_url == source_url else None,
            )
            record = DebtRecord(
                entity_name=loan_data["entity_name"],
                entity_type=loan_data["entity_type"],
                lender=loan_data["lender"],
                principal=principal,
                outstanding=outstanding,
                issue_date=issue_date,
                maturity_date=maturity_date,
                currency=loan_data.get("currency", "KES"),
                # A row's own source wins over the payload's. The IDS creditor
                # rows are World Bank data merged into a CBK-sourced payload;
                # without this they persisted as if CBK had published them.
                source_url=row_source_url,
                source_title=row_source_title,
                publisher=(
                    _declared(loan_data.get("publisher"))
                    or (payload_publisher if row_source_url == source_url else None)
                ),
                debt_category=loan_data.get("debt_category"),
                interest_rate=interest_rate,
                notes=loan_data.get("notes"),
                interest_terms=loan_data.get("interest_terms"),
                source_evidence=loan_data.get("source_evidence"),
                measurement_period=loan_data.get("measurement_period"),
            )

            records.append(record)

        except (KeyError, ValueError, TypeError) as exc:
            logger.warning(
                f"Skipping malformed debt record #{idx}: {exc}",
                extra={"record": loan_data, "error": str(exc)},
            )
            continue

    logger.info(f"Successfully parsed {len(records)} debt records")
    return records
