"""Budget domain fetcher with live COB PDF integration.

Strategy (in order):
1. If counties_budget_prefer_live_source AND live_pdf_fetch_enabled,
   try to discover the latest COB County Budget Implementation Review
   Report (C-BIRR) PDF and parse it.
2. Fall back to the static fixture / configured URL.

County budget data primarily comes from the Controller of Budget (COB)
quarterly reports. Unlike national-level data, there is no free API —
the data is published in PDF reports at
https://cob.go.ke/publications/consolidated-county-budget-implementation-review-reports/
"""

from __future__ import annotations

import logging
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ...cob_discovery import discover_latest_cob_pdf_url
from ...config import SeedingSettings
from ...http_client import SeedingHttpClient
from ...utils import load_json_resource, slugify_entity
from ...freshness import mark_fixture, mark_live

logger = logging.getLogger("seeding.counties_budget.fetcher")

# Upper bound of the plausible KSh-MILLIONS band for county-level BIRR
# aggregates. Real parses run ~40 (smallest half-year absorption) to
# ~45,000 (Nairobi's annual total); 200,000 (= KES 200B after scaling)
# leaves generous headroom. CoB BIRR tables publish these figures in
# KSh millions — stored raw, Nairobi's "44,621" landed as KES 44,621,
# which is why development_budget read as ~0 in the API.
_BIRR_MILLIONS_BAND_MAX = 200_000


def _birr_amount_to_kes(value: float) -> float:
    """Scale a CoB BIRR county-AGGREGATE figure from KSh millions to KES.

    Only values inside the plausible millions band (0, 200,000] are
    scaled. Anything above is either already absolute KES (real county
    aggregates start at ~KES 40M, far above the band) or anomalous —
    both pass through unscaled, so a hypothetical absolute-KES vintage
    is never inflated and anomalies stay visibly wrong instead of
    silently becoming trillions. Do NOT reuse for fine-grained line
    items: the band assumption is aggregate-level only
    (Total / Recurrent / Development / Personnel Emoluments).
    """
    return value * 1_000_000 if 0 < value <= _BIRR_MILLIONS_BAND_MAX else value

# COB migrated from /reports/ to /publications/ paths (2025). Order is
# significant — the consolidated page publishes the single "all counties"
# BIRR PDF that covers sectoral + aggregate breakdowns in one artefact,
# so we try that first. /county-reports/ hosts per-county PDFs (harder
# to aggregate), and the legacy /reports/ path only survives as a redirect
# for old search hits.
_COB_COUNTY_BIRR_URLS = [
    "https://cob.go.ke/publications/consolidated-county-budget-implementation-review-reports/",
    "https://cob.go.ke/publications/county-reports/",
    "https://cob.go.ke/reports/county-governments-budget-implementation-review-reports/",  # legacy
]

# April-2026: the COB landing pages sit behind a CDN that rejects the
# seeder's default `Accept: */*` with HTTP 415 and frequently reports
# 000 at the CI edge even though the origin is up. Sending a browser-
# shaped Accept header + UA makes the probe behave the same way as the
# WP REST API (which is also exposed on the same host and returns 200
# reliably). We only override per-request because the default seeder UA
# is the preferred identity for everything else.
_BROWSER_UA = (
    "Mozilla/5.0 (compatible; KenyaAuditAppSeeder/1.0; "
    "+https://github.com/Rodgers31/audit_app-)"
)
_COB_HTML_HEADERS = {
    "User-Agent": _BROWSER_UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
}
_COB_JSON_HEADERS = {
    "User-Agent": _BROWSER_UA,
    "Accept": "application/json",
}

# County/BIRR-related keywords used to filter the WP REST media feed
# (and, as a fallback, HTML anchor hrefs). Keep lowercase.
_COUNTY_PDF_KEYWORDS = (
    "county",
    "c-birr",
    "cbirr",
    "county-government",
    "county_government",
    "county-budget",
    "consolidated-county",
)


def _derive_fiscal_year_dates(fy: str) -> Tuple[Optional[str], Optional[str]]:
    """Return ISO start_date/end_date for a Kenyan fiscal-year label.

    Kenya runs FY July 1 → June 30. Accepts "2024/2025", "2024/25",
    "FY2024/25", "FY 2024-25" and similar. Returns ("2024-07-01",
    "2025-06-30") or (None, None) if the label cannot be parsed.
    """
    if not fy:
        return None, None
    m = re.search(r"(\d{4})[/\-](\d{2,4})", fy)
    if not m:
        return None, None
    start_year = int(m.group(1))
    tail = m.group(2)
    # "25" → 2025; "2025" → 2025 (idempotent).
    end_year = int(tail) if len(tail) == 4 else 2000 + int(tail)
    # Sanity: end must be start+1.
    if end_year - start_year != 1:
        return None, None
    return f"{start_year}-07-01", f"{end_year}-06-30"


#: Last month of each part-year period, counted from the July the FY opens.
_SUB_PERIOD_END_MONTH_OFFSET = {"Q1": 2, "H1": 5, "Q2": 5, "Q3": 8, "9M": 8}


def _derive_period_dates(
    fy: str, sub_period: Optional[str]
) -> Tuple[Optional[str], Optional[str]]:
    """ISO start/end dates for a fiscal year, cut short by a sub-period.

    ``("2025/26", "9M")`` -> ``("2025-07-01", "2026-03-31")``. A full-year
    report (``sub_period`` None) runs to June 30. A sub-period this does not
    know yields ``(None, None)`` rather than a guessed end date.
    """
    import calendar

    start_iso, end_iso = _derive_fiscal_year_dates(fy)
    if not start_iso or not sub_period:
        return start_iso, end_iso
    offset = _SUB_PERIOD_END_MONTH_OFFSET.get(sub_period.upper())
    if offset is None:
        return None, None
    start_year = int(start_iso[:4])
    month_index = 6 + offset  # 0-based months from January of the start year
    year, month = start_year + month_index // 12, month_index % 12 + 1
    last_day = calendar.monthrange(year, month)[1]
    return start_iso, f"{year}-{month:02d}-{last_day:02d}"


#: Libraries whose version changes what the CoB parse returns, even though
#: none of our own source moved. Fed into the parse cache's key.
_PDF_STACK = ("pdfplumber", "pdfminer.six")


def _pdf_stack_versions() -> str:
    """``pdfplumber=0.11.10;pdfminer.six=20260107`` — the cache's key_extra.

    A version that cannot be read becomes ``unknown``, which is a value like
    any other: two runs on different unreadable versions still share it, so
    this must never be the only thing distinguishing them. It is not — the
    document digest and the parser digest are the other two thirds of the
    key, and this is only the part that tracks the library.
    """
    from importlib.metadata import PackageNotFoundError, version

    parts = []
    for name in _PDF_STACK:
        try:
            parts.append(f"{name}={version(name)}")
        except PackageNotFoundError:
            parts.append(f"{name}=unknown")
    return ";".join(parts)


class CobSourceUnreachable(RuntimeError):
    """No COB URL could be reached at all.

    Distinct from "the page loaded and the parser found nothing": the first is
    the publisher being down (an expired certificate, DNS, a 5xx), the second
    is our extraction being wrong about a document we hold. Recording them
    under one reason cost a day of reading a parser that was fine.
    """


def fetch_budget_payload(
    client: SeedingHttpClient, settings: SeedingSettings
) -> Any:
    """Retrieve the budgets dataset, trying live COB PDF first.

    Strategy:
    1. Try live PDF fetch from COB county BIRR reports page.
    2. Fall back to configured fixture/API URL.
    """
    # Strategy 1: Live PDF fetch — gated by two toggles so operators
    # can disable independently:
    #   * live_pdf_fetch_enabled — global kill-switch for all PDF
    #     scraping (CBK, Treasury, COB). Useful for offline dev.
    #   * counties_budget_prefer_live_source — domain-specific toggle
    #     added April-2026 to let us freeze the fixture output for
    #     snapshot tests even when global PDF fetching is on.
    prefer_live = getattr(settings, "counties_budget_prefer_live_source", True)
    if settings.live_pdf_fetch_enabled and prefer_live:
        try:
            payload = _fetch_from_cob_county_pdf(client, settings)
            if payload and len(payload) > 0:
                logger.info(
                    "Successfully fetched county budgets from COB PDF (%d records)",
                    len(payload) if isinstance(payload, list) else 0,
                )
                mark_live(
                    "counties_budget",
                    detail=f"COB county BIRR PDF, {len(payload)} records",
                )
                return payload
            else:
                logger.warning(
                    "COB county PDF fetch returned no budget data, "
                    "falling back to fixture"
                )
                mark_fixture(
                    "counties_budget", reason="parser_returned_nothing"
                )
        except CobSourceUnreachable as exc:
            # The publisher was down, not our parser. Naming it separately is
            # the whole point: `parser_returned_nothing` sends the reader to
            # the extraction code, and on 2026-09-04 that was a day spent on a
            # parser that produces 75 records perfectly well.
            logger.warning(
                "COB county source unreachable, falling back to fixture: %s", exc
            )
            mark_fixture(
                "counties_budget",
                reason="source_unreachable",
                detail=str(exc)[:200],
            )
        except Exception as exc:
            logger.warning(
                "COB county PDF fetch failed, falling back to fixture: %s", exc
            )
            mark_fixture(
                "counties_budget",
                reason="live_fetch_failed",
                detail=str(exc)[:200],
            )
    elif not prefer_live:
        logger.info(
            "counties_budget_prefer_live_source=False — skipping COB PDF fetch"
        )
        mark_fixture("counties_budget", reason="live_source_disabled")
    else:
        mark_fixture("counties_budget", reason="live_pdf_fetch_disabled")

    # Strategy 2: Fixture fallback
    logger.info("Using fixture/configured URL for county budget data")
    return load_json_resource(
        url=settings.budgets_dataset_url,
        client=client,
        logger=logger,
        label="budgets",
    )


def _fetch_from_cob_county_pdf(
    client: SeedingHttpClient, settings: SeedingSettings
) -> Optional[List[Dict[str, Any]]]:
    """Discover and parse the latest COB county BIRR PDF.

    Discovery strategy (April-2026):
      1. **WP REST API** (preferred) — `/wp-json/wp/v2/media` returns
         structured {title, date, source_url, mime_type} records sorted
         by upload date. Single 200 request, no HTML parsing, no WAF
         Accept-header issues.
      2. **HTML landing pages** (fallback) — try each known COB BIRR
         URL with a browser-shaped Accept header so the CDN does not
         reject us with 415. Useful when the WP API is temporarily
         disabled or the PDF we want lives under a different page.

    If both fail, the caller falls back to the fixture.
    """
    # Strategy 1: WP REST API — more reliable than HTML scraping.
    pdf_url: Optional[str] = None
    try:
        pdf_url = _discover_latest_county_birr_via_wp_api(client, settings)
    except Exception as exc:
        logger.warning("COB WP REST API discovery failed: %s", exc)

    # Strategy 2: HTML landing pages with browser-shaped headers.
    if not pdf_url:
        pdf_url = _discover_latest_county_birr_via_html(client, settings)

    if not pdf_url:
        # Both strategies empty — caller falls through to fixture.
        return None

    logger.info("Downloading COB county BIRR PDF: %s", pdf_url)
    return _download_and_parse_county_pdf(client, pdf_url, settings)


def _discover_latest_county_birr_via_wp_api(
    client: SeedingHttpClient, settings: SeedingSettings
) -> Optional[str]:
    """Query the COB WordPress REST API for the latest county BIRR PDF.

    We can't blindly trust the API's `orderby=date&order=desc` or the
    first "county" keyword match: empirically (CI run 24901989493) it
    surfaced a 2015 single-county file as the "latest", which also
    returned 404 because the CDN no longer hosts it. So:

      1. Pull up to 100 PDFs (the API default cap).
      2. Score each candidate by specificity — the *consolidated*
         county BIRR is what we actually want, not ad-hoc single-
         county files from years ago. Stronger keywords win.
      3. Sort ourselves by (score desc, parsed date desc) to avoid
         WordPress-plugin ordering quirks.
      4. HEAD-probe each candidate in order; return the first 200.
         Skipping 404s / 4xx / 5xx means a stale link in the API
         feed no longer poisons the whole seeding run.
    """
    api_url = getattr(
        settings,
        "counties_budget_cob_wp_api_url",
        "https://cob.go.ke/wp-json/wp/v2/media"
        "?per_page=100&mime_type=application/pdf&orderby=date&order=desc",
    )
    if not api_url:
        return None

    logger.info("Querying COB WP REST API for county BIRR PDFs: %s", api_url)
    response = client.get(
        api_url, raise_for_status=True, headers=_COB_JSON_HEADERS
    )
    try:
        items = response.json()
    except Exception as exc:
        logger.warning("COB WP REST API returned non-JSON payload: %s", exc)
        return None

    if not isinstance(items, list) or not items:
        logger.warning(
            "COB WP REST API returned %d media items (expected >0)",
            len(items) if isinstance(items, list) else -1,
        )
        return None

    # Score reflects how specifically the filename/title screams "the
    # consolidated, most-recent-BIRR-for-all-counties PDF". The same
    # signal set as before is still used, but weighted — plain "county"
    # alone is a weak hint; "consolidated" + "BIRR" + a FY marker win.
    def _score(item: Dict[str, Any]) -> int:
        title = (item.get("title") or {}).get("rendered", "") or ""
        slug = item.get("slug") or ""
        source = item.get("source_url") or ""
        haystack = f"{title} {slug} {source}".lower()
        if not any(kw in haystack for kw in _COUNTY_PDF_KEYWORDS):
            return 0
        score = 1  # baseline for any county match
        if "consolidated" in haystack:
            score += 5
        if "c-birr" in haystack or "cbirr" in haystack:
            score += 3
        if "budget-implementation-review" in haystack or "birr" in haystack:
            score += 2
        # FY markers — prefer recent years strongly.
        # Matches "2024-25", "2024/25", "fy-2024-25", "fy2024-25", etc.
        fy_match = re.search(r"(20\d{2})[-/](\d{2,4})", haystack)
        if fy_match:
            score += 1
            year = int(fy_match.group(1))
            # Give very recent fiscal years an extra nudge.
            score += max(0, year - 2020)
        return score

    def _parsed_date(item: Dict[str, Any]) -> str:
        # Fall back to empty string so sort is stable for items missing
        # the field (they'll rank last).
        return item.get("date") or ""

    scored = [
        (s, _parsed_date(i), i)
        for i in items
        if isinstance(i, dict) and (s := _score(i)) > 0
    ]
    if not scored:
        logger.warning(
            "COB WP REST API returned %d PDFs but none matched county keywords",
            len(items),
        )
        return None
    scored.sort(key=lambda t: (t[0], t[1]), reverse=True)

    # Liveness probe candidates in order, skipping 404s / 4xx / 5xx.
    # Keeps the failure mode of a stale feed entry (common with the
    # COB WP-Download-Manager plugin's orphaned links) local: one bad
    # URL just moves us on to the next candidate instead of poisoning
    # the whole domain run.
    head_headers = {
        "User-Agent": _BROWSER_UA,
        "Accept": "application/pdf,*/*;q=0.8",
    }
    for score, date, item in scored[:10]:
        source_url = item.get("source_url")
        if not isinstance(source_url, str) or not source_url.lower().endswith(".pdf"):
            continue
        try:
            head = client.head(
                source_url,
                raise_for_status=False,
                headers=head_headers,
                timeout=20.0,
            )
        except Exception as exc:
            logger.info(
                "Candidate %s HEAD failed (%s); trying next",
                source_url,
                exc,
            )
            continue
        if head.status_code >= 400:
            logger.info(
                "Candidate %s returned HTTP %d; trying next",
                source_url,
                head.status_code,
            )
            continue
        title = (item.get("title") or {}).get("rendered", "")
        logger.info(
            "COB WP REST API selected BIRR PDF: %s (date=%s, score=%d, title=%r)",
            source_url,
            date,
            score,
            title,
        )
        return source_url

    # All scored candidates failed HEAD probes — this is the
    # expected state since COB migrated BIRR distribution to the
    # WordPress Download Manager plugin (~Q4 2025), which doesn't
    # surface in /wp/v2/media. The endpoint now returns ~4 unrelated
    # stale image PDFs that score above the threshold but 404 on
    # fetch. The HTML fallback handles this correctly, so demote to
    # INFO — operators only need a real warning if both strategies
    # fail (the orchestrator logs that case at the caller level).
    logger.info(
        "COB WP REST API: %d scored candidates but none passed HEAD "
        "probe (expected post-WPDM-migration; HTML fallback in use)",
        len(scored),
    )
    return None


def _discover_latest_county_birr_via_html(
    client: SeedingHttpClient, settings: SeedingSettings
) -> Optional[str]:
    """Fallback: scrape the COB HTML landing pages for a BIRR PDF link.

    Uses browser-shaped Accept / User-Agent headers so the CDN does not
    reject us with HTTP 415 the way the default `Accept: */*` triggers.
    """
    candidate_urls: List[str] = []
    configured = getattr(settings, "counties_budget_cob_reports_url", None)
    if configured:
        candidate_urls.append(configured)
    reach_errors: List[Tuple[str, str]] = []
    for url in _COB_COUNTY_BIRR_URLS:
        if url not in candidate_urls:
            candidate_urls.append(url)

    html: Optional[str] = None
    page_url = candidate_urls[0] if candidate_urls else ""
    for url in candidate_urls:
        try:
            logger.info("Fetching COB county BIRR reports page: %s", url)
            # The COB CDN regularly takes ~25s to serve this page —
            # the default seeder 30s is on the edge and flaps in CI.
            response = client.get(
                url,
                raise_for_status=True,
                headers=_COB_HTML_HEADERS,
                timeout=60.0,
            )
            html = response.text
            page_url = url
            break
        except Exception as exc:
            reach_errors.append((url, f"{type(exc).__name__}: {exc}"))
            logger.warning("COB county page unavailable at %s: %s", url, exc)

    if not html:
        # NOT a parser problem. On the 2026-09-04 nightly every COB URL failed
        # with "[SSL: CERTIFICATE_VERIFY_FAILED] certificate has expired", the
        # parser never ran, and the run still recorded
        # `parser_returned_nothing` — which is what sent the next person
        # reading the parser. Raise so the caller can name the transport.
        detail = "; ".join(f"{u}: {e}" for u, e in reach_errors) or "no URL tried"
        logger.warning(
            "Could not reach COB county reports at any known URL — %s", detail
        )
        raise CobSourceUnreachable(detail)

    pdf_url = _discover_latest_county_birr_pdf(html, page_url)
    if not pdf_url:
        logger.warning("No county BIRR PDF link found on COB reports page")
        return None
    return pdf_url


_COUNTY_BIRR_KEYWORDS = (
    "county", "c-birr", "cbirr", "county-government",
    "county_government", "county-budget", "counties",
    "consolidated-county",
)


def _discover_latest_county_birr_pdf(
    html: str, base_url: str
) -> Optional[str]:
    """Extract the most recent county BIRR PDF URL from the COB page.

    Delegates to the shared COB WPDM discovery helper. See
    ``seeding.cob_discovery`` for the WPDM anchor + legacy ``.pdf``
    fallback strategy.
    """
    return discover_latest_cob_pdf_url(
        html, base_url, keywords=_COUNTY_BIRR_KEYWORDS
    )


def convert_county_pdf_records(
    parsed_records: List[Dict[str, Any]], pdf_url: str, artifact_sha256: str | None,
    *, receipt: Optional[dict] = None
) -> List[Dict[str, Any]]:
    """Convert actual CBIRR producer output without downloading or caching.

    Shared by the live fetcher and source-bound local adoption planning, so
    amounts, accounting bases, periods and provenance use the same mapping.
    """
    from .parser import _to_decimal

    budget_records: List[Dict[str, Any]] = []
    dropped_no_fy = 0
    for record in parsed_records:
        county = record.get("county", "Unknown")
        entity_slug = slugify_entity(county)
        fy = record.get("fiscal_year") or ""
        sub_period = record.get("quarter")

        start_iso, end_iso = _derive_period_dates(fy, sub_period)
        if not start_iso or not end_iso:
            dropped_no_fy += 1
            continue
        # "2025/26 9M": the report's own period, sub-period and all. A
        # nine-month CBIRR filed under the bare year would share a period
        # with — and be overwritten by — the annual report.
        period_label = f"{fy} {sub_period}" if sub_period else fy

        allocated = _to_decimal(record.get("allocated"))
        absorbed = _to_decimal(record.get("absorbed"))

        if record.get("amounts_in") != "kes":
            # Chapter 2 aggregates are printed in KSh millions. The
            # Chapter 3 revenue tables are printed in shillings, and a
            # small stream (a KSh 50,000 refund) scaled here would become
            # KSh 50 billion.
            if allocated is not None:
                allocated = _birr_amount_to_kes(allocated)
            if absorbed is not None:
                absorbed = _birr_amount_to_kes(absorbed)

        converted = {
            "entity_slug": entity_slug,
            "entity": f"{county} County",
            "fiscal_year": fy,
            "period_label": period_label,
            "start_date": start_iso,
            "end_date": end_iso,
            "category": record.get("category", "Total"),
            "subcategory": record.get("subcategory"),
            "allocated_amount": float(allocated) if allocated is not None else None,
            # IMPORTANT: parser reads "actual_amount" or "actual";
            # the old "actual_spent" key was silently dropped.
            "actual_amount": float(absorbed) if absorbed is not None else None,
            "committed_amount": None,
            "currency": "KES",
            "source_label": f"Controller of Budget County BIRR FY{period_label}",
            "source_url": pdf_url,
            "data_quality": "official",
            "notes": record.get("notes"),
            "page_ref": record.get("page_ref"),
            "artifact_sha256": artifact_sha256,
            "revenue_coverage": record.get("revenue_coverage"),
        }
        if receipt is not None:
            from ...pdf_evidence import cell_evidence
            converted["source_evidence"] = []
            for measure, value in (("allocated_amount", allocated), ("actual_spent", absorbed)):
                cell = record.get("_pdf_cells", {}).get(measure)
                if cell is None or value is None:
                    continue
                converted["source_evidence"].append(cell_evidence(receipt=receipt, identity={
                    "measure": measure, "entity_id": None, "geography": f"{county} County",
                    "period": period_label, "unit": "KES", "basis": "actual",
                    "dimensions": {"category": converted["category"], "subcategory": converted["subcategory"], "line_type": None}},
                    raw_value=cell["raw_value"], value=value, raw_unit=cell["raw_unit"],
                    factor="1" if record.get("amounts_in") == "kes" else "1000000",
                    locator=cell["locator"], unit_checked=cell.get("unit_checked", False)))
        budget_records.append(converted)

    if dropped_no_fy:
        logger.warning(
            "Dropped %d COB records with un-parseable fiscal_year label",
            dropped_no_fy,
        )

    if receipt is not None:
        from ...pdf_evidence import seal_pdf_observations
        seal_pdf_observations([e for row in budget_records for e in row.get("source_evidence", [])])
    return budget_records


def _download_and_parse_county_pdf(
    client: SeedingHttpClient, pdf_url: str, settings: SeedingSettings
) -> Optional[List[Dict[str, Any]]]:
    """Download a COB county BIRR PDF, parse it, return budget records."""
    try:
        from ...pdf_parsers import CoBQuarterlyReportParser
        from ...cob_cbirr import download_cbirr
        from ...parse_cache import parse_with_cache
        from .parser import _to_decimal

        # The PDF request carries a browser-shaped UA and
        # `Accept: application/pdf` (cob_cbirr.PDF_HEADERS): the CDN rule
        # that rejects the HTML landing with 415 can block `*/*` downloads
        # too. get_or_download_pdf enforces a TOTAL wall-clock cap on the transfer
        # (not httpx's per-chunk timeout, which a slow-but-steady 48MB body
        # never trips) and reuses a cached copy across runs. So a slow-CDN
        # night either reuses the last good download or bails to the fixture,
        # instead of eating the 600s domain budget and aborting mid-parse
        # (issue #119). Phase logging brackets each phase so a future stall
        # still points at the real culprit (CDN vs parser).
        logger.info("Starting COB county BIRR PDF download: %s", pdf_url)
        download_start = time.monotonic()
        # Through the shared CBIRR helper, not get_or_download_pdf directly:
        # stalled_projects reads the same ~50MB file, and the two share one
        # cache entry only if they pass the same server fingerprint (#230).
        downloaded = download_cbirr(client, pdf_url, settings)
        pdf_path = downloaded.path
        download_elapsed = time.monotonic() - download_start

        logger.info(
            "COB county BIRR PDF ready (%d bytes, %.1fs) at %s",
            pdf_path.stat().st_size,
            download_elapsed,
            pdf_path,
        )

        # The parse, not the download, is the expensive half. pdfplumber
        # walks all ~700 pages and pulls 1,048 tables out of this document to
        # find four of them, and it did that every night against a file the
        # PDF cache already held:
        #
        #   Sep 16  Parsed COB county BIRR PDF (188 records, 251.5s)
        #   Sep 17  Parsed COB county BIRR PDF (188 records, 249.1s)
        #   Sep 18  Parsed COB county BIRR PDF (188 records, 258.5s)
        #
        # ~250s of a 1320s budget, for the same 188 records. parse_with_cache
        # banks the RESULT under the PDF's content digest AND a digest of the
        # parser's own source, so a republished report and an edited parser
        # both miss; see seeding/parse_cache.py for why the second half of
        # that key is not optional.
        logger.info("Parsing COB county BIRR PDF: %s", pdf_path)
        parse_start = time.monotonic()
        parser = CoBQuarterlyReportParser(pdf_path)
        # The PDF stack's versions are part of the key. The parser digest
        # covers pdf_parsers.py, which is self-contained (KENYAN_COUNTIES and
        # every table helper are defined in it; its only non-stdlib import is
        # pdfplumber) — but the tables themselves come out of the library,
        # and an upgrade changes them without touching a byte of our source.
        # Without this the upgrade would land and every cached parse would go
        # on serving the previous version's tables.
        #
        # pdfminer.six as well as pdfplumber: extract_tables() clusters chars
        # and words that pdfminer produced, requirements.txt pins only
        # `pdfplumber>=0.10.3`, and pdfminer.six is not pinned at all — so it
        # is the one most likely to move underneath us unannounced.
        parsed_records = parse_with_cache(
            pdf_path,
            cache_dir=Path(settings.cache_path) / "pdfs",
            kind="cob_county_birr",
            parse_fn=parser.parse,
            enabled=settings.parse_cache_enabled,
            key_extra=_pdf_stack_versions(),
        )
        parse_elapsed = time.monotonic() - parse_start
        logger.info(
            "Parsed COB county BIRR PDF (%d records, %.1fs)",
            len(parsed_records) if parsed_records else 0,
            parse_elapsed,
        )

        if not parsed_records:
            logger.warning("CoBQuarterlyReportParser returned no records")
            return None

        from ...pdf_evidence import receipt_for_pdf, bind_parse_receipt

        receipt = receipt_for_pdf(client, settings, pdf_path, pdf_url, "cob-county-budget-v1")
        receipt = bind_parse_receipt(receipt, parsed_records)
        return convert_county_pdf_records(
            parsed_records, pdf_url, getattr(downloaded, "sha256", None), receipt=receipt
        ) or None

    except ImportError:
        logger.warning(
            "CoBQuarterlyReportParser not available — "
            "install pdfplumber for live PDF parsing"
        )
        return None
    # No temp-file cleanup: get_or_download_pdf() returns a path in the
    # persistent PDF cache (reused across runs), so it must NOT be unlinked.


__all__ = ["fetch_budget_payload"]
